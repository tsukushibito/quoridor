"""Static figures from already checked scalars; no model or new resampling."""

import csv
import json
import os
from pathlib import Path
import tempfile

ROOT = Path(__file__).resolve().parent


def main():
    result = json.loads((ROOT / "result.json").read_text())
    with (ROOT.parent / "fit-q-preparation-v1/curves.csv").open() as stream:
        curves = list(csv.DictReader(stream))
    with tempfile.TemporaryDirectory(prefix="plot-tmp-", dir=ROOT) as config:
        os.environ["MPLCONFIGDIR"] = config
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        plt.rcParams.update({"svg.hashsalt": "quoridor423-original", "font.size": 9})
        metadata = {"Date": None, "Creator": "423 saved analysis / Matplotlib"}
        fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.0))
        for name, color in [("U", "#0072B2"), ("R", "#E69F00"), ("W", "#009E73")]:
            rows = [r for r in curves if r["condition"] == name]
            axes[0].plot(
                [int(r["step"]) for r in rows],
                [float(r["newV_family_MSE"]) for r in rows],
                "o-",
                label=name,
                color=color,
            )
        axes[0].set(
            xlabel="Completed updates (same warmstart schedule)",
            ylabel="New V family MSE",
            title="Warmstart: U / R / W",
        )
        axes[0].legend()
        rows = [r for r in curves if r["condition"] == "F"]
        for column, label, color in [
            ("newT_row_MSE", "new T row MSE", "#0072B2"),
            ("newV_row_MSE", "new V row MSE", "#D55E00"),
        ]:
            axes[1].plot(
                [int(r["step"]) for r in rows],
                [float(r[column]) for r in rows],
                "o-",
                label=label,
                color=color,
            )
        axes[1].set(
            xlabel="Completed updates (F has different LR/exposure)",
            ylabel="MSE (log scale)",
            yscale="log",
            title="Fresh F: BEST is step 0",
        )
        axes[1].legend()
        for ax in axes:
            ax.grid(alpha=0.25)
        fig.suptitle(
            "423 original fits: markers are saved observations; connectors are guides"
        )
        fig.tight_layout()
        fig.savefig(ROOT / "fit-curves.svg", metadata=metadata)
        fig.savefig(ROOT / "fit-curves.png", dpi=120)
        plt.close(fig)

        primary = result["arena"]["W/BEST43"]
        secondary = result["arena"]["W/D"]
        fig, ax = plt.subplots(figsize=(9.5, 3.5))
        for y, summary, interval, color in [
            (2, primary, primary["global64_analysis_percentile_95"], "#009E73"),
            (
                1,
                secondary,
                secondary["native13_complete_pair_percentile_95"],
                "#0072B2",
            ),
        ]:
            score = summary["complete_pair_mean"]
            ax.errorbar(
                score * 100,
                y,
                xerr=[[100 * (score - interval[0])], [100 * (interval[1] - score)]],
                fmt="o",
                capsize=5,
                color=color,
            )
            ax.text(interval[1] * 100 + 1, y, f"{score:.2%}", va="center", color=color)
        bounds = secondary["planned_score_bounds"]
        ax.plot(
            [v * 100 for v in bounds],
            [0, 0],
            color="#666666",
            linewidth=6,
            solid_capstyle="butt",
        )
        ax.text(
            100 * bounds[1] + 1, 0, "5 UNKNOWN retained", va="center", color="#444444"
        )
        ax.axvline(50, linestyle="--", linewidth=1, color="black")
        ax.set(
            yticks=[0, 1, 2],
            yticklabels=[
                "W/D planned 32: arithmetic bounds (not CI)",
                "W/D: 13 complete families, native 95% CI",
                "W/BEST43: 64 families, global analysis 95% CI",
            ],
            xlabel="Candidate score (%)",
            xlim=(30, 95),
            ylim=(-0.6, 2.6),
        )
        ax.set_title(
            "Conditional fixed-book evidence; shared starts, no Elo / superiority claim"
        )
        ax.grid(axis="x", alpha=0.2)
        fig.tight_layout()
        fig.savefig(ROOT / "arena-family-intervals.svg", metadata=metadata)
        fig.savefig(ROOT / "arena-family-intervals.png", dpi=120)
        plt.close(fig)

        example = result["new_arena_example"]
        fig, ax = plt.subplots(figsize=(10.2, 4.0))
        ax.set_axis_off()
        ax.text(
            0.5,
            0.9,
            "Global family 0: same full starting prefix [161, 178, 195, 125]\nstandard_2p_threefold / ply 4 / STM 0",
            ha="center",
            va="center",
            bbox={
                "boxstyle": "round,pad=0.5",
                "facecolor": "#eeeeee",
                "edgecolor": "#777777",
            },
        )
        for x, row, color in [
            (0.25, example["records"][0], "#009E73"),
            (0.75, example["records"][1], "#0072B2"),
        ]:
            text = f"{row['model']} / game {row['game']}\nAction {row['action']}\nSearched root STM value {row['value_STM']:+.8f}\nCompleted selective depth {row['completed_depth']}\nPV {row['PV']}\nCaller {row['caller_seconds'] * 1000:.3f} ms"
            ax.text(
                x,
                0.43,
                text,
                ha="center",
                va="center",
                bbox={
                    "boxstyle": "round,pad=0.6",
                    "facecolor": "white",
                    "edgecolor": color,
                },
                color=color,
            )
            ax.annotate(
                "",
                xy=(x, 0.67),
                xytext=(0.5, 0.80),
                arrowprops={"arrowstyle": "->", "color": color},
            )
        ax.text(
            0.5,
            0.05,
            "Separate clocked games/sessions. Not static leaf values, identical TT/work, or an optimal-move oracle.\nExample fixed as first two records; family 0 candidate pair score is 0.5.",
            ha="center",
            va="center",
            fontsize=8,
        )
        fig.tight_layout()
        fig.savefig(ROOT / "candidate-example.svg", metadata=metadata)
        fig.savefig(ROOT / "candidate-example.png", dpi=120)
        plt.close(fig)
    assert not list(ROOT.glob("plot-tmp-*"))
    print(
        json.dumps(
            {
                "static_figures": [
                    "fit-curves.svg",
                    "arena-family-intervals.svg",
                    "candidate-example.svg",
                ],
                "scientific_calls": 0,
                "TMP_remaining": [],
            }
        )
    )


if __name__ == "__main__":
    main()
