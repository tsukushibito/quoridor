423.1 元の最終保存分析COMPLETE。元claimant/in_progress、backup sync済み。新science/scale/fit/forward/Search/game/native/旧suite再演0、Astra/新session/委譲0です。

原arena job b495b1c5はFAILED、lastoperation/dataFAILED・cleanupfalse、nativeprocesscleanuptrueを保持。155GOAL+5UNKNOWN（1started/4未入場、元Unclassified5）で有限試行完了、refill/枠貸借0。global common_total_node_capを個別unknown理由に書換えません。

主要W/BEST43=72W0D56L/128GOAL/64completefamilies、score.5625。全64の一度の新保存解析95%区間[.4765625,.6484375]、50%を含む。既存NumPy2.5.3 Generator.choice/mean/quantile、PCG64/seed42320261027/10000/linear percentile。native16-family各chunkCIは保持し合成/平均0、native乱数とbyteexactという主張はしません。primary20両勝/32片勝/12両負、色0は35/64・色1は37/64。表示名16が4chunkで反復するので、globalID+fullprefix+lineageで真64へjoin、全160slotを原CSV照合しました。

副次W/D=17W0D10L/27GOAL5UNKNOWN、13complete3incompletefamilies。pair17/26=.653846/nativeconditional95%[.5,.8076923]、validgame17/27=.629630、予定32の算術bounds[17/32,22/32]=[.53125,.6875]を区別。先頭16startsをprimaryと共有、independent80pairs/160trialsにはしません。

W新V familyMSE .9458764451→.9155112500（-3.210%）、publicfullV .4256808014（U .4238859726/R .4239649996とのtrade-off）。高在庫選択314（stock16=293/17=21/18..20=0）、V76で全openingへ一般化不可。FはfreshBEST0、LAST941でnewT .00069024対newV1.46340584/family1.48897623、F不可能/teacherinvalidは未証明。R nativefitCOMPLETE vs operationFAILEDは元事実のまま。U/Rファイル順減衰を世代強さとしません。

NNUE fits2210086+480selected-nativeheads=2210566<4M、Sigma716901+oldq1294=718195<2M、arenacharged752662738<1G。primaryunused247337262を貸さずsecondary200Mで終了。TTgauge/opaque予約/overlappingclockをactualvisited/physicalNN/RSSへ変換せず、全費UNKNOWNを保持。把握した原outer4075.352295644sはFAILED込み各一度、nested非加算。旧q28は保存説明だけ、qfit0。

元primaryの最初2recordsだけ一度decode（原gzip不変）、同fullprefix[161,178,195,125]/ply4/STM0でWaction138/value-.27509895とBEST43action146/-.31973183、両completedselectiveD4。別game/clock/TT/workなので因果/最善手oracleなし、family0score.5。candidate表とstaticSVG/PNG3枚、16pointcurves、80family/160slot表、52Vfamily変化/oldq28tableを保存しました。私有working extractは必要root/prefix/next8movesだけへ縮小、原RAW・原行SHA保持、unique data削除/refund0。

completion:
/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/final-analysis-v1/final-saved-v1/completion.json SHAb0034c658737d640088c6cd2f65bd2114269af0a3412ffa22b1fc7e842b0d5e2 /10940B0644
report:
/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/final-analysis-v1/final-saved-v1/report-ja.md SHAe8c7321d28be1c1f346e65de02f1f3af96cc2172d39cbf5594eeaa2482bc3a7a /13977B0644
同dir result/control/checks/selectedrefs-final/STOP/usageとfigures。56selected refs前後+final exact、Ruff/Prettier/算術・XML・図目視PASS。

実selectedreaderSTOP19:23:29.409494Z、substantialhelper直接reap19:23:34.022711Z、finalpacket guard実reap19:25:52.423921Z。全既知own source/fitq helper IDsfreshabsent/different、directwait/reap/handles/TMP/leases/owned[]。一回のOWN final-analysis-v1 snapshot7434240B、既coverとの差の正増だけ通常合成用（sharedtarget/asset再課金/refund/globalinventory0、later tiny admin tail別）。

Wは研究candidate/evidence保持のみ、一般strength/noninferiority/Elo/defaultpromotion0。次提案は凍結Wの別固定独立book確認設計まで（例192families/384gamesは今回枠外で未発行）、q+z/NNUEselfplay/追加fitは発行しません。必要な同423.4限定確認/出版/通常acceptanceは324所有、本人を独立reviewへ兼用せず、作者からreviewerdispatchもしません。原423spec/one-time256と全legacy USERPAUSE/default/model/seal/RAWFAILEDfees不変。Root/humanACK/親close待ちを入口にしません。
