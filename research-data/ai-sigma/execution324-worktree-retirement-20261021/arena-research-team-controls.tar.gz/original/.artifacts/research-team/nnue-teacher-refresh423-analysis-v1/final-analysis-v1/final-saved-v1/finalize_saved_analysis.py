"""Aggregate only stopped 423 evidence; the one interval is loaded, never rerun."""

import collections
import csv
import datetime
import io
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(name):
    return json.loads((ROOT / name).read_text())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def near(a, b):
    return math.isclose(a, b, abs_tol=1e-12, rel_tol=1e-11)


def main():
    incoming = load("inlet.json")
    evidence = incoming["values"]
    arena = evidence["arena_collection"]
    fit = evidence["saved_fit_q"]
    small_inlet = load("native-small-inlet.json")
    small = small_inlet["values"]
    costs_inlet = load("remaining-cost-inlet.json")
    costs = costs_inlet["values"]
    interval = load("primary-global-family-interval.json")
    two = load("first-two-records-inlet.json")
    table = evidence["family_table"]["rows"]
    assert evidence["saved_fit_checks"]["status"] == "PASS"
    assert small["outer"]["outcome"] == "failed" and small["outer"]["cleanup_complete"]
    assert arena["original_job_FAILED_and_operation_data_FAILED_retained"]
    assert len(table) == 80
    operations = arena["operations"]
    family_csv, game_csv, summaries = [], [], {}
    all_native_rows = {}
    for operation in operations:
        index = operation["operation_index"]
        cfg = small[f"op{index}_config.json"]
        ids = small[f"op{index}_evaluator-identities.json"]
        assert cfg["ruleset"] == "standard_2p_threefold"
        assert cfg["arena"]["tt_entries"] == 1048576
        assert cfg["arena"]["max_total_nodes"] == 200000000
        assert cfg["arena"]["return_reserve_ms"] == 5
        assert cfg["arena"]["retained_outcome_bytes"] == 630784
        assert (
            cfg["arena"]["search_artifact_sha256"]
            == ["35e47e65effdb04763e7f7b38475514490915f6a97bfa285bfeb2dbe4cf449a2"] * 2
        )
        assert [item["content_sha256"] for item in ids] == cfg["arena"][
            "evaluator_sha256"
        ]
        assert (
            ids[0]["content_sha256"]
            == "8a8eb7fb87035f03c4cfa6b45ca1aa5d2f1b144c6fa1298dd11b82975307953d"
        )
        assert ids[1]["content_sha256"] == (
            "96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875"
            if index < 4
            else "c83db10ba1403b7fc3417e73e14cc5f1a1040c65ac4ac23a5f5703abbb5aa887"
        )
        for engine in cfg["engines"]:
            assert engine["ordering_profile"] == "control"
            assert engine["lmr"] is True and engine["lmr_method"] == "depth_rank"
            assert engine["time_ms"] == 100 and engine["max_nodes"] == 1000000
        native_rows = list(csv.DictReader(io.StringIO(small[f"op{index}_games.csv"])))
        assert len(native_rows) == 32
        for row in native_rows:
            key = (index, int(row["game"]))
            assert key not in all_native_rows
            all_native_rows[key] = row

    for contrast, expected_families in [("W/BEST43", 64), ("W/D", 16)]:
        families = sorted(
            (r for r in table if r["contrast"] == contrast),
            key=lambda r: r["family_id"],
        )
        assert len(families) == expected_families
        assert {r["family_id"] for r in families} == set(range(expected_families))
        assert (
            len(
                {
                    (r["family_id"], tuple(r["source_prefix"]), r["lineage"])
                    for r in families
                }
            )
            == expected_families
        )
        flattened, completed_scores = [], []
        for family in families:
            assert len(family["games"]) == 2
            assert {g["candidate_color"] for g in family["games"]} == {0, 1}
            games = sorted(family["games"], key=lambda g: g["candidate_color"])
            for game in games:
                row = all_native_rows[(game["operation_index"], game["local_game"])]
                assert row["family"] == game["native_family"]
                assert int(row["candidate_color"]) == game["candidate_color"]
                assert (row["started"] == "true") == game["started"]
                assert row["status"] == game["status"]
                if game["score"] is not None:
                    assert game["status"] == "goal"
                    assert game["score"] == float(
                        int(row["winner"]) == game["candidate_color"]
                    )
                flattened.append(game)
                game_csv.append(
                    {
                        **game,
                        "source_prefix": json.dumps(
                            game["source_prefix"], separators=(",", ":")
                        ),
                        "plies": row["plies"],
                    }
                )
            is_complete = all(g["score"] is not None for g in games)
            assert family["complete"] == is_complete
            if is_complete:
                score = sum(g["score"] for g in games) / 2
                assert score == family["score"]
                completed_scores.append(score)
            family_csv.append(
                {
                    "contrast": contrast,
                    "family_id": family["family_id"],
                    "lineage": family["lineage"],
                    "source_prefix": json.dumps(
                        family["source_prefix"], separators=(",", ":")
                    ),
                    "complete": is_complete,
                    "score": family["score"],
                    "color0_score": games[0]["score"],
                    "color1_score": games[1]["score"],
                    "color0_started": games[0]["started"],
                    "color1_started": games[1]["started"],
                }
            )
        wins = sum(g["score"] == 1 for g in flattened)
        losses = sum(g["score"] == 0 for g in flattened)
        unknown = sum(g["score"] is None for g in flattened)
        colors = {}
        for color in [0, 1]:
            rows = [g for g in flattened if g["candidate_color"] == color]
            colors[str(color)] = {
                "planned": len(rows),
                "started": sum(g["started"] for g in rows),
                "W": sum(g["score"] == 1 for g in rows),
                "L": sum(g["score"] == 0 for g in rows),
                "UNKNOWN": sum(g["score"] is None for g in rows),
            }
        summaries[contrast] = {
            "planned_slots": len(flattened),
            "started_games": sum(g["started"] for g in flattened),
            "goal": wins + losses,
            "W": wins,
            "D": 0,
            "L": losses,
            "UNKNOWN": unknown,
            "complete_families": len(completed_scores),
            "incomplete_families": len(families) - len(completed_scores),
            "complete_pair_mean": sum(completed_scores) / len(completed_scores),
            "valid_game_score": wins / (wins + losses),
            "planned_score_bounds": [
                wins / len(flattened),
                (wins + unknown) / len(flattened),
            ],
            "complete_family_score_histogram": dict(
                collections.Counter(str(x) for x in completed_scores)
            ),
            "by_candidate_colour": colors,
        }
    primary, secondary = summaries["W/BEST43"], summaries["W/D"]
    assert (
        primary["W"],
        primary["L"],
        primary["UNKNOWN"],
        primary["complete_families"],
    ) == (72, 56, 0, 64)
    assert (
        secondary["W"],
        secondary["L"],
        secondary["UNKNOWN"],
        secondary["started_games"],
        secondary["complete_families"],
    ) == (17, 10, 5, 28, 13)
    assert near(secondary["complete_pair_mean"], 17 / 26)
    assert near(secondary["valid_game_score"], 17 / 27)
    assert secondary["planned_score_bounds"] == [17 / 32, 22 / 32]
    assert interval["score_mean"] == primary["complete_pair_mean"] == 0.5625
    primary["global64_analysis_percentile_95"] = interval["percentile_95"]
    primary["global64_interval_method"] = (
        "Installed NumPy PCG64/choice+linear quantile; separately labelled saved-analysis interval, not native per-chunk CI"
    )
    primary["primary_lower_above_half"] = interval["percentile_95"][0] > 0.5
    secondary["native13_complete_pair_percentile_95"] = operations[4][
        "native_family_summary"
    ]["bootstrap"]["percentile_95"]
    assert primary["primary_lower_above_half"] is False
    same_first16 = {
        r["family_id"]: (r["lineage"], r["source_prefix"])
        for r in table
        if r["contrast"] == "W/BEST43" and r["family_id"] < 16
    }
    assert all(
        same_first16[r["family_id"]] == (r["lineage"], r["source_prefix"])
        for r in table
        if r["contrast"] == "W/D"
    )
    native_display_names = {
        g["native_family"]
        for r in table
        if r["contrast"] == "W/BEST43"
        for g in r["games"]
    }
    assert len(native_display_names) == 16
    charged = [
        o["operation_node_budget"]["charged_nodes_including_opaque_reservations"]
        for o in operations
    ]
    assert sum(charged) == arena["total_charged_nodes"] == 752662738 < 1000000000
    assert (
        800000000 - sum(charged[:4])
        == arena["primary_unused_nodes_not_lent"]
        == 247337262
    )
    assert charged[4] == 200000000
    assert (
        operations[4]["process_cleanup_complete"] is True
        and operations[4]["original_operation_cleanup_complete"] is False
    )

    original_first = next(
        r for r in table if r["contrast"] == "W/BEST43" and r["family_id"] == 0
    )
    prefix = original_first["source_prefix"]
    example_rows = []
    for row in two["records"]:
        game = row["record"]
        assert game["game"] in [0, 1] and game["moves"][: len(prefix)] == prefix
        observation = game["observations"][0]
        assert observation["ply"] == len(prefix) == 4 and observation["side"] == 0
        assert observation["accepted"] and observation["counters"]["authority_legal"]
        assert (
            observation["counters"]["authority_receipt_ns"]
            <= observation["deadline_ns"]
        )
        example_rows.append(
            {
                "model": "W" if observation["engine_index"] == 0 else "BEST43",
                "game": game["game"],
                "candidate_color": game["candidate_color"],
                "archive_line": row["archive_line"],
                "raw_line_sha256": row["raw_line_sha256"],
                "raw_line_bytes": row["raw_line_bytes"],
                "ply": 4,
                "side_to_move": 0,
                "action": observation["action"],
                "value_STM": observation["value_stm"],
                "completed_depth": observation["completed_depth"],
                "PV": observation["pv"],
                "stop": observation["stop"],
                "authority_receipt_ns": observation["counters"]["authority_receipt_ns"],
                "deadline_ns": observation["deadline_ns"],
                "returned_ns": observation["returned_ns"],
                "commit_ns": observation["counters"]["state_commit_ns"],
                "caller_seconds": observation["caller_seconds"],
                "thinking_seconds": observation["thinking_seconds"],
                "completed_snapshot_work": observation["completed_iteration_counters"],
                "whole_search_work_alternative_view": observation["counters"][
                    "whole_search"
                ],
                "AI_worker_core": observation["counters"]["AI_worker_core"],
                "actual_namespace": observation["counters"]["actual_search_namespace"],
                "actual_following_actions": game["moves"][4:12],
                "actual_goal_winner": game["winner"],
            }
        )
    assert {r["model"] for r in example_rows} == {"W", "BEST43"}
    example = {
        "selection": two["selection"],
        "global_family_id": 0,
        "lineage": original_first["lineage"],
        "full_prefix": prefix,
        "rules": "standard_2p_threefold",
        "original_archive": two["source_before"],
        "records": example_rows,
        "meaning": "Same saved starting history/rules/STM, independently clocked games and sessions. Not isolated weights/LMR causality, static values, same tree/work, or a move/WDL oracle. Completed depth4 is selective nominal.",
        "known_local_result": "Both games end with colour1 goal; family0 candidate pair score0.5. Example fixed before decode, not selected for a W win.",
    }
    save("candidate-example.json", example)
    for name, rows in [("families.csv", family_csv), ("games.csv", game_csv)]:
        with (ROOT / name).open("w", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    old_scale = json.loads(
        (ROOT.parent.parent / "one-time-scale-v1/inlet.json").read_text()
    )["values"]
    known_costs = dict(fit["original_known_outer_seconds_once"])
    known_costs.update(
        {
            "pilot32_generation_once": costs["suffix"][
                "original_pilot_seconds_reused_not_recharged"
            ],
            "suffix224_generation_once": costs["suffix"]["original_outer_seconds_once"],
            "pilot_conversion_once": old_scale["conversion_collection"][
                "outer_seconds_once"
            ],
            "final_conversion_once": costs["final_conversion"]["outer_seconds_once"],
            "changed_weight_original_preentry_FAILURE_once": costs[
                "changed_weight_preentry_failure"
            ]["wall_seconds"],
            "arena_original_parse_FAILURE_once": costs["arena_parse_refusal"][
                "original_outer_wall_seconds_once"
            ],
            "arena_original_forecast_FAILURE_once": costs["arena_forecast_refusal"][
                "outer_wall_seconds_once"
            ],
            "arena_original_partial_FAILED_outer_once": arena[
                "original_outer_wall_seconds_once"
            ],
        }
    )
    assert costs["suffix"]["suffix_entered"] == 224 and costs["suffix"][
        "suffix_statuses"
    ] == {"goal": 224}
    assert costs["suffix"]["Sigma"]["logical_rows"] == 716901
    result = {
        "issue": "quoridor-4lc.423.1",
        "status": "ORIGINAL_FINITE_SAVED_ANALYSIS_COMPLETE_OPERATIONAL_FAILURES_AND_UNKNOWNS_RETAINED",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "arena": summaries,
        "arena_operational_outcome": {
            "original_job": small["outer"],
            "last_data_and_operation_FAILED": True,
            "last_operation_cleanup_complete": False,
            "native_process_cleanup_complete": True,
            "global_stop": operations[4]["original_native_stopped"],
            "individual_UNKNOWN_causes": "Original Unclassified5, not reassigned",
            "incomplete_secondary_families": [
                r["family_id"]
                for r in table
                if r["contrast"] == "W/D" and not r["complete"]
            ],
            "original_native_STOP": arena["original_sequence_reader_STOP"],
            "original_collection_STOP": arena["at"],
        },
        "family_identity": {
            "primary_true_global_families": 64,
            "native_display_names": 16,
            "key": "global schedule family_id+fullprefix+lineage",
            "shared_secondary_starts": 16,
            "primary_native_chunk_intervals_not_combined": [
                o["native_family_summary"]["bootstrap"]["percentile_95"]
                for o in operations[:4]
            ],
        },
        "charged_node_budget": {
            "operations": charged,
            "total": sum(charged),
            "primary_unused_not_lent": 247337262,
            "secondary_cap_exhausted": 200000000,
            "scope": "charged nodes include opaque reservations; not an exact visited-node/NNUE-call count; terminal work nested",
        },
        "native_work_clocks": [
            {
                "operation": i,
                "report_wall_seconds_nested_not_added": small[f"op{i}_result.json"][
                    "report"
                ]["wall_seconds"],
                "native_report_peak_RSS_B": small[f"op{i}_result.json"]["report"][
                    "peak_rss"
                ],
                "outcome_count_including_placeholders": small[f"op{i}_result.json"][
                    "outcome_count"
                ],
                "journal_count": small[f"op{i}_result.json"]["journal_count"],
            }
            for i in range(5)
        ],
        "fits_and_old_q": fit,
        "new_arena_example": example,
        "known_original_outer_seconds_once": known_costs,
        "known_original_outer_subtotal_seconds": sum(known_costs.values()),
        "cost_scope": "Known selected original science/failure outers only. WF shared once, pilot once, no nested native addition. Full software/source/LLM/admin/continuous family RSS/physical NN and isolated costs UNKNOWN.",
        "disposition": {
            "W": "Keep frozen research candidate/evidence; newV loss gain and observed primary56.25% are promising finite observations, primary CI includes50%; no general superiority/noninferiority/Elo/default/model promotion",
            "R": "Small saved loss change under file-order weighting; no old-generation strength conclusion, no arena R/U contrast",
            "F": "Fresh BEST0 with strong train/held-out divergence under this one data/LR/exposure schedule; not proof of impossible scratch learning or invalid teacher",
            "finite_trial_complete": True,
            "UNKNOWN_refill_or_new_science": False,
            "existing_pauses_defaults_models_seals_RAW_FAILED_fees": "UNCHANGED",
        },
        "next_proposal_only": {
            "priority": 1,
            "proposal": "If a new research comparison is authorized, freeze W and use a separately fixed independent-start book before further fitting or q+z teacher changes. About192 family pairs would target roughly5-point normal-planning halfwidth if the current family variance persists;384games is outside this160-game/1G authorization and is not launched or guaranteed sufficient. Existing family owner must count true available families; repeating initial states does not create independence.",
            "q_plus_z_or_NNUE_selfplay": "Separate teacher/design decision only; old28 q is not an oracle and no new fit/teacher/selfplay is issued.",
        },
        "limits": [
            "NewV checkpoint selection uses the same52 held-out families, so selected-loss improvements are not independent confirmation",
            "Teacher/data/initialization/LR/updates change together across relevant conditions; no single-cause claim",
            "High-wall selectedT314, only293 atstock16 and21 at17, none18..20; high-wall V76; do not generalize to the entire opening",
            "Current128-game primary and32-slot partial secondary share starts and have clock/selective-search variability",
            "Only two new game records decoded for fixed example, not all155 per-move histories; aggregate fallback/error/receipt-tail totals beyond owning summaries remain UNKNOWN",
            "No hidden model/corpus payload, Torch/ORT/forward/Search/game/solver/native build execution by analyst",
        ],
    }
    save("result.json", result)
    save(
        "checks.json",
        {
            "status": "PASS",
            "checks": [
                "80 true family rows,160 planned slots and exact original games.csv joins",
                "primary128GOAL/64pairs/72W56L, secondary27GOAL5UNKNOWN/13complete3incomplete",
                "all starts/lineages/prefixes join globally;16 repeated displaynames do not collapse64starts",
                "one primary64 saved interval loaded; no resampling repeat/native perchunk CI averaging",
                "charged752662738<1G, primaryunused247337262notlent, secondary200M",
                "exact actualW/BEST43/D IDs, TT1M/PVS/Control/LMR depth_rank100ms/5msreserve",
                "fixed first family example same fullprefix/STM and legal accepted authoritative receipts",
                "original operationalFAILED/dataFAILED/cleanupfalse/processcleanuptrue preserved",
                "shared fits/oldq checks reused, no original forward/suite replay",
            ],
            "extra_science": 0,
        },
    )
    save(
        "control.json",
        {
            "issue": "quoridor-4lc.423.1",
            "saved_analysis_complete": True,
            "blockers": [],
            "ordinary": [
                "Original arena jobFAILED and five UNKNOWN retained; no refill",
                "Primary95% interval47.65625..64.84375 includes50%; strength/default promotion not supported",
                "F freshINITIAL BEST0 and R operationFAILED stay explicit",
                "Final owneracceptance/publication and limited independent check belong to324/423.4, not this analyst",
            ],
            "leaf_status": "in_progress pending ordinary owner acceptance; do not close from source-only or interim results",
            "scientific_dispatch": 0,
            "ACK_gate": False,
        },
    )
    print(
        json.dumps(
            {
                "status": "PASS",
                "primary": primary,
                "secondary": secondary,
                "known_outer_subtotal": sum(known_costs.values()),
                "example_actions": [
                    [r["model"], r["action"], r["value_STM"]] for r in example_rows
                ],
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
