"""Describe frozen fit/q metadata only. Never load weights, rows, or an engine."""

import csv
import datetime
import json
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(name):
    return json.loads((ROOT / name).read_text())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def near(a, b):
    return math.isclose(a, b, rel_tol=1e-11, abs_tol=1e-12)


def metric_summary(metric):
    keys = [
        "rows",
        "mse",
        "family_mse",
        "sign_rows",
        "sign_accuracy",
        "saturation_fraction",
        "draw_rows",
        "draw_mean_absolute_value",
    ]
    return {k: metric.get(k) for k in keys}


def main():
    incoming = load("inlet.json")
    curves_inlet = load("curve-inlet.json")
    old_inlet = load("old-q-input-inlet.json")
    example_inlet = load("fixed-example-inlet.json")
    values, training = incoming["values"], curves_inlet["values"]
    conditions = {
        "U": (values["fit_U"], training["fit_U_training"]),
        "R": (values["fit_R"], training["fit_R_training"]),
        "W": (values["saved_W"], training["saved_W_training"]),
        "F": (values["saved_F"], training["saved_F_training"]),
    }
    counts = values["final_counts"]
    assert (
        counts["rows"]
        == counts["train_eligible_rows"] + counts["validation_eligible_rows"]
        == 12803
    )
    assert (counts["train_families"], counts["validation_families"]) == (204, 52)
    assert (
        counts["selected_T_rows"] == counts["exact_distinct_selected_T_inputs"] == 3763
    )
    assert len(set(counts["selected_T_indices"])) == 3763
    assert counts["final_fit_view"]["changed_global_ids"] == [18]
    stock = {}
    for split, histogram in counts["stock_histograms"].items():
        stock[split] = {
            "16..20": sum(histogram[16:21]),
            "8..15": sum(histogram[8:16]),
            "1..7": sum(histogram[1:8]),
            "0": histogram[0],
        }
    assert sum(stock["selected_T"].values()) == 3763
    assert counts["stock_histograms"]["selected_T"][16:21] == [293, 21, 0, 0, 0]

    fits, csv_rows, family_changes = {}, [], []
    initials = {}
    best_expected = {"U": 79, "R": 118, "W": 118, "F": 0}
    last_expected = {"U": 118, "R": 118, "W": 118, "F": 941}
    row_total, measurement_total, training_total = 0, 0, 0
    for name, (collection, data) in conditions.items():
        assert data["status"] == "COMPLETE"
        assert data["best_step"] == collection["best_step"] == best_expected[name]
        assert data["last_checkpoint_step"] == last_expected[name]
        assert (
            data["cache_manifest_sha256"]
            == "b08d071af76d6684654c20d0e1e4467bca0248f8d6f1f170a4163465b6b1e718"
        )
        points = data["curves"]
        assert [p["step"] for p in points] == (
            [0, 314, 628, 941] if name == "F" else [0, 40, 79, 118]
        )
        selected = min(
            points,
            key=lambda p: (p["scopes"]["added_validation"]["family_mse"], p["step"]),
        )
        assert selected["step"] == data["best_step"]
        initial, last = points[0], points[-1]
        initials[name] = initial["scopes"]
        for p, brief in zip(points, collection["observation_summary"]):
            scopes = p["scopes"]
            new_v = scopes["added_validation"]
            new_t = scopes["added_train"]
            public_t = scopes["public_train"]
            assert (
                new_v["rows"] == 2498
                and new_t["rows"] == 3763
                and public_t["rows"] == 8192
            )
            assert len(new_v["families"]) == 52
            assert sum(f["rows"] for f in new_v["families"].values()) == 2498
            assert near(
                statistics.mean(f["mse"] for f in new_v["families"].values()),
                new_v["family_mse"],
            )
            assert near(brief["newV_familyMSE"], new_v["family_mse"])
            assert near(brief["newV_rowMSE"], new_v["mse"])
            for scope in scopes.values():
                assert sum(b["rows"] for b in scope["calibration"]) == scope["rows"]
            csv_rows.append(
                {
                    "condition": name,
                    "step": p["step"],
                    "selected_BEST": p["step"] == selected["step"],
                    "newV_rows": new_v["rows"],
                    "newV_families": len(new_v["families"]),
                    "newV_row_MSE": new_v["mse"],
                    "newV_family_MSE": new_v["family_mse"],
                    "newV_sign_accuracy": new_v["sign_accuracy"],
                    "newV_saturation_fraction": new_v["saturation_fraction"],
                    "newT_row_MSE": new_t["mse"],
                    "publicT_panel_MSE": public_t["mse"],
                }
            )
        initial_v = initial["scopes"]["added_validation"]
        selected_v = selected["scopes"]["added_validation"]
        family_keys = sorted(initial_v["families"])
        assert set(family_keys) == set(selected_v["families"])
        deltas = []
        for key in family_keys:
            before = initial_v["families"][key]
            after = selected_v["families"][key]
            assert before["rows"] == after["rows"]
            difference = after["mse"] - before["mse"]
            deltas.append(difference)
            family_changes.append(
                {
                    "condition": name,
                    "family": key,
                    "rows": before["rows"],
                    "initial_MSE": before["mse"],
                    "BEST_MSE": after["mse"],
                    "difference": difference,
                }
            )
        assert near(
            statistics.mean(deltas), selected_v["family_mse"] - initial_v["family_mse"]
        )
        forwards, trained, measured = (
            data["forward_rows"],
            data["training_forwards"],
            data["measurement_forwards"],
        )
        assert forwards == trained + measured == collection["actual_forward_rows"]
        row_total += forwards
        measurement_total += measured
        training_total += trained
        public_v = data["frozen_best_public_validation"]
        assert (
            public_v["checkpoint_step"] == selected["step"]
            and public_v["metrics"]["rows"] == 419150
        )
        fits[name] = {
            "native_fit_status": "COMPLETE",
            "operation_status": "FAILED"
            if name == "R"
            else "saved complete; original manifest retained",
            "BEST_step": selected["step"],
            "LAST_step": data["last_checkpoint_step"],
            "initial_newV": metric_summary(initial_v),
            "BEST_newV": metric_summary(selected_v),
            "LAST_newV": metric_summary(last["scopes"]["added_validation"]),
            "newV_family_relative_change_initial_to_BEST": selected_v["family_mse"]
            / initial_v["family_mse"]
            - 1,
            "initial_newT": metric_summary(initial["scopes"]["added_train"]),
            "BEST_newT": metric_summary(selected["scopes"]["added_train"]),
            "LAST_newT": metric_summary(last["scopes"]["added_train"]),
            "BEST_publicT_panel": metric_summary(selected["scopes"]["public_train"]),
            "BEST_full_publicV": metric_summary(public_v["metrics"]),
            "BEST_newV_stock": selected_v["stock_strata"],
            "initial_newV_stock": initial_v["stock_strata"],
            "BEST_newV_calibration": selected_v["calibration"],
            "family_MSE_decreased_increased_equal": [
                sum(d < 0 for d in deltas),
                sum(d > 0 for d in deltas),
                sum(d == 0 for d in deltas),
            ],
            "actual_training_forwards": trained,
            "actual_measurement_forwards": measured,
            "actual_total_forwards": forwards,
            "added_seen": data["added_seen"],
            "public_seen": data["public_seen"],
            "added_distinct": data["added_distinct"],
            "public_distinct": data["public_distinct"],
            "added_repeated_draws": data["added_repeats"],
            "public_repeated_draws": data["public_repeats"],
            "public_candidate_rows_metadata_not_extra_forwards": data[
                "public_selection_candidate_rows"
            ],
            "public_completed_by_file": data["public_completed_by_file"],
            "public_file_decay": data["public_file_decay"],
            "selected_BEST_descriptor_metadata_ref_only": collection[
                "selected_BEST_descriptor"
            ],
            "per_row_exposure_vector": "not read; totals/distinct are observed, exact individual visit vector not independently decoded",
        }
    assert initials["U"] == initials["R"] == initials["W"]
    assert (
        conditions["U"][0]["initial_observation"]
        == conditions["R"][0]["initial_observation"]
        == conditions["W"][0]["initial_observation"]
    )
    assert row_total == values["fit_WF"]["actual_total_forward_rows"] == 2210086
    assert training_total == 331144 and measurement_total == 1878942
    bank_rows = 3763 + 2498 + 8192
    assert measurement_total == (16 - 2) * bank_rows + 4 * 419150
    changed = values["changed_weights"]
    assert changed["actual_native_heads"] == 480
    assert (
        row_total + 480
        == changed["total_completed_NNUE_logical_rows"]
        == 2210566
        < 4000000
    )
    assert values["fit_R"]["original_operation_failed_not_relabelled"] is True

    qrows = values["old_q_table"]["rows"]
    old_input = old_inlet["value"]
    assert len(qrows) == len(old_input["states"]) == 28
    assert [r["state_id"] for r in qrows] == [
        r["state_id"] for r in old_input["states"]
    ]
    for row, state in zip(qrows, old_input["states"]):
        assert row["prefix_sha256"] == state["prefix_actions_sha256"]
        assert row["completed_simulations"] == 64
        assert row["stock_sum"] == state["stock_sum"]
        assert (
            -1 <= row["current_MCTS_q"] <= 1
            and -1 <= row["current_static_root_nn"] <= 1
        )
    q_collection = values["old_q_collection"]
    actual_q_nn = sum(r["nn_calls"] for r in qrows)
    assert actual_q_nn == q_collection["backend_work"]["logical_rows"] == 1294
    assert (
        q_collection["backend_work"]["physical_rows"]
        == q_collection["backend_work"]["executed_rows"]
        == 1294
    )
    assert (
        q_collection["backend_work"]["warm_rows"]
        == q_collection["backend_work"]["failed_rows"]
        == 0
    )
    sigma_total = 716901 + actual_q_nn
    assert (
        sigma_total
        == q_collection["Sigma_generation_plus_old_q_logical_rows"]
        == 718195
        < 2000000
    )
    old = example_inlet["value"]
    first = qrows[0]
    assert first["prefix_sha256"] == old["prefix_actions_sha256"]
    assert old["prefix_actions"] == old_input["states"][0]["full_prefix_actions"]
    observation = old["original_observation"]
    q_summary = {
        "states": 28,
        "original_games": old_input["games"],
        "states_are_not_independent_or_population_sample": True,
        "selection": old_input["selection"],
        "stock_strata_counts": {
            key: sum(r["stock_stratum"] == key for r in qrows)
            for key in sorted({r["stock_stratum"] for r in qrows})
        },
        "simulations_per_state": 64,
        "logical_physical_executed_rows": actual_q_nn,
        "terminal_no_nn_counter_sum": sum(r["terminal_no_nn"] for r in qrows),
        "MCTS_q_min_mean_max": [
            min(r["current_MCTS_q"] for r in qrows),
            statistics.mean(r["current_MCTS_q"] for r in qrows),
            max(r["current_MCTS_q"] for r in qrows),
        ],
        "static_root_min_mean_max": [
            min(r["current_static_root_nn"] for r in qrows),
            statistics.mean(r["current_static_root_nn"] for r in qrows),
            max(r["current_static_root_nn"] for r in qrows),
        ],
        "q_static_opposite_nonzero_signs": sum(
            r["current_MCTS_q"] * r["current_static_root_nn"] < 0 for r in qrows
        ),
        "fixed_first_example": {
            "state_id": first["state_id"],
            "source_position": first["source_position_record"],
            "prefix_sha256": first["prefix_sha256"],
            "full_prefix_actions": old["prefix_actions"],
            "state": old["state"],
            "old_actual_NNUE_action": old["nnue_action"],
            "old_actual_NNUE_searched_value_STM": observation["value_stm"],
            "old_actual_NNUE_completed_depth": observation["completed_depth"],
            "old_actual_NNUE_PV": observation["pv"],
            "old_actual_NNUE_stop": observation["stop"],
            "current_Sigma_MCTS64_q_STM": first["current_MCTS_q"],
            "current_Sigma_static_root_nn_STM": first["current_static_root_nn"],
            "current_Sigma_action": first["action"],
            "stock_sum": first["stock_sum"],
            "comparison_limit": "Same full prefix, different evaluator/search/budget. Historical NNUE root-searched value, current MCTS q, and current static head are different quantities. No teacher-truth, forced-WDL, same-leaf, causal old-loss or good/bad-move conclusion.",
        },
        "labels": "q is descriptive only; all four fits used z, no q fit or new forward",
    }
    known_outer = {
        "U_original_preinitialization_FAILED_1": 8.276654534012778,
        "U_original_preinitialization_FAILED_2": 7.641188381006941,
        "U_completed_fit_original_outer": values["fit_U"]["original_seconds_once"],
        "R_completed_fit_OPERATION_FAILED_original_outer": values["fit_R"][
            "original_seconds_once"
        ],
        "WF_shared_outer_once_not_twice": values["fit_WF"]["outer_WF_seconds_once"],
        "changed_weights_original_outer": changed["original_seconds_once"],
        "oldq_original_outer": q_collection["original_outer_wall_seconds_once"],
    }
    result = {
        "issue": "quoridor-4lc.423.1",
        "phase": "original saved-fit/q analysis preparation; arena genuinely unentered",
        "status": "SAVED_FIT_Q_PREPARATION_COMPLETE_FINAL_ARENA_DEPENDENCY_OPEN",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "fits": fits,
        "stock_rows": stock,
        "raw_eligible_T_distinct": counts["exact_distinct_eligible_T_inputs"],
        "actual_selected_R": 3763,
        "selection_4096_guide_shortfall": 333,
        "shared_INITIAL_observed": {
            "scope_rows": bank_rows,
            "physical_new_observations_reused_for_R_W": 0,
            "duplicated_rows_not_executed": 2 * bank_rows,
            "same_actual_FileRef_and_step0_metrics": True,
        },
        "forward_accounting": {
            "training_rows": training_total,
            "measurement_rows": measurement_total,
            "fits_total": row_total,
            "changed_weights_native_heads": 480,
            "NNUE_completed_total": row_total + 480,
            "NNUE_cap": 4000000,
            "Sigma_generation": 716901,
            "Sigma_oldq": actual_q_nn,
            "Sigma_total": sigma_total,
            "Sigma_cap": 2000000,
            "physical_FT_hardware": "UNKNOWN; logical rows/heads do not establish physical FT counts",
        },
        "old_q": q_summary,
        "original_known_outer_seconds_once": known_outer,
        "known_outer_subtotal_seconds": sum(known_outer.values()),
        "cost_limit": "WF counted once; no nested native or overlapping fit wall addition. Generation/conversion/other failed jobs/source/LLM/admin total and continuous family peak not all covered here; UNKNOWN remains.",
        "frozen_conditions": "No new scale, generation, fifth fit, q teacher, model/feature/default change, bootstrap or scientific dispatch. Future original arena160/1G keeps its fixed family/method/model scope.",
        "disposition": "Descriptive preparation only. W newV loss improvement and publicV trade-off do not establish strength; F BEST0 is fresh initialization, not incumbent. R original operational FAILED stays FAILED. Await original arena on this same claimant/in_progress leaf.",
    }
    save("result.json", result)
    save("family-MSE-changes.json", family_changes)
    save("old-q-compact-table.json", qrows)
    with (ROOT / "curves.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(csv_rows[0]))
        writer.writeheader()
        writer.writerows(csv_rows)
    refs = [
        r
        for blob in [incoming, curves_inlet, old_inlet, example_inlet]
        for r in blob["refs"]
    ]
    assert len({r["before"]["path"] for r in refs}) == len(refs)
    save("selectedrefs-before-after.json", refs)
    save(
        "checks.json",
        {
            "status": "PASS",
            "checks": [
                "T+V12803,204T/52V,R3763 and distinct3763",
                "Only pilotID18 final-fit split change",
                "all16 curve points and family/row denominators agree with owning collections",
                "BEST79/118/118/0 equals family-MSE selector, LAST118/118/118/941",
                "actual shared U INITIAL for R/W; no fictitious rows credited",
                "training331144+measurement1878942=fits2210086; plus480=2210566",
                "oldq28 exact ordered prefix hashes,64 completed sims each,1294 actual NN rows",
                "generation716901+oldq1294=718195",
                "R operationalFAILED retained, F0 fresh model distinguished",
            ],
            "new_native_forward_fit_Search_game_bootstrap": 0,
        },
    )
    print(
        json.dumps(
            {
                "status": "PASS",
                "curve_points": len(csv_rows),
                "selected_refs": len(refs),
                "NNUE_actual": row_total + 480,
                "Sigma_actual": sigma_total,
                "fixed_first_example": {
                    k: q_summary["fixed_first_example"][k]
                    for k in [
                        "state_id",
                        "old_actual_NNUE_searched_value_STM",
                        "old_actual_NNUE_completed_depth",
                        "current_Sigma_MCTS64_q_STM",
                        "current_Sigma_static_root_nn_STM",
                        "current_Sigma_action",
                    ]
                },
                "readerSTOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
