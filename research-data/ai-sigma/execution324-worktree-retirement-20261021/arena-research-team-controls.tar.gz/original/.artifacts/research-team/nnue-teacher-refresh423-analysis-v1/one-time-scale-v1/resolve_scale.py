"""Resolve the one authorized scale from frozen small metadata; execute no science."""

import collections
import datetime
import json
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
MIB = 1024 * 1024


def load(name):
    return json.loads((ROOT / name).read_text())


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def schedule(rows, multiplier, limit):
    total = min(multiplier * rows, limit)
    updates = math.ceil(total / 256)
    return {
        "selected_R": rows,
        "training_rows": total,
        "updates": updates,
        "last_batch": total - 256 * (updates - 1),
        "exposures_per_selected_row": total / rows,
    }


def main():
    inlet = load("inlet.json")
    support = load("support-inlet-v1.json")
    storage = load("storage-inlet-v1.json")
    forecast = load("forecast-inlet-v1.json")
    v, s, t, f = (
        inlet["values"],
        support["values"],
        storage["values"],
        forecast["values"],
    )
    counts = v["pilot_counts"]
    producer = v["producer_collection"]
    spec = v["fixed_spec"]
    assert (producer["requested"], producer["goal"], producer["UNKNOWN"]) == (
        32,
        32,
        0,
    )
    assert (
        counts["rows"],
        counts["train_eligible_rows"],
        counts["validation_eligible_rows"],
        counts["train_families"],
        counts["validation_families"],
        counts["selected_T_rows"],
        counts["exact_distinct_selected_T_inputs"],
    ) == (1704, 1289, 415, 25, 7, 460, 460)
    assert sum(counts["stock_histograms"]["selected_T"]) == 460
    assert len(set(counts["selected_T_indices"])) == 460
    assert counts["final_scale_fixed"] is False

    pilot_n = producer["requested"]
    target = spec["one_time_main_resolution"][
        "coverage_planning_targets_not_power_guarantees"
    ]
    target_terms = {
        "pilot_floor": pilot_n,
        "T_families": pilot_n * target["T_families"] / counts["train_families"],
        "V_families": pilot_n * target["V_families"] / counts["validation_families"],
        "selected_T": pilot_n * target["selected_T_rows"] / counts["selected_T_rows"],
        "distinct_T": pilot_n
        * target["distinct_T_model_inputs"]
        / counts["exact_distinct_selected_T_inputs"],
    }
    data_n = 4 * math.ceil(max(target_terms.values()) / 4)
    assert data_n == 288

    slices = [s["slice00"], *producer["new_slice_collections"]]
    rows_by_slice = [z["backend_work"]["logical_rows"] for z in slices]
    completed_by_slice = [z["goal"] for z in slices]
    assert completed_by_slice == [8] * 4
    assert rows_by_slice == [24545, 23819, 25731, 21449]
    assert sum(rows_by_slice) == producer["Sigma"]["logical_rows"] == 95544
    for z in slices:
        work = z["backend_work"]
        assert work["logical_rows"] == work["physical_rows"] == work["executed_rows"]
        assert work["warm_rows"] == work["failed_rows"] == 0
    rate = max(a / n for a, n in zip(rows_by_slice, completed_by_slice))
    forecast_rate = 1.25 * rate
    sigma_cap, old_q_reserve = 2_000_000, 10_000
    remaining_suffix = sigma_cap - 95544 - old_q_reserve
    sigma_forecast_n = pilot_n + math.floor(remaining_suffix / forecast_rate)

    # These are explicit planning allowances inside the existing single whole guard,
    # not measured peaks, new independent budgets, or completion guarantees.
    pilot_bytes = t["conversion_storage"]["allocated_B"]
    assert pilot_bytes == 3477504
    allowances = {
        "four_fits_models_metrics_and_controls_B": 32 * MIB,
        "arena_saved_outputs_archives_and_controls_B": 48 * MIB,
        "serial_TMP_and_unmeasured_peak_allowance_B": 8 * MIB,
    }
    bytes_per_suffix_request = 1.25 * pilot_bytes / pilot_n
    whole_cap = 128 * MIB
    storage_n = pilot_n + math.floor(
        (whole_cap - pilot_bytes - sum(allowances.values())) / bytes_per_suffix_request
    )
    resolved_n = 4 * math.floor(min(data_n, 256, sigma_forecast_n, storage_n) / 4)
    assert resolved_n == 256
    suffix_n = resolved_n - pilot_n

    # Preserve the actual pilot's eight-request/60k-row operation shape. The
    # suffix is fixed before new results and unused operation caps are not lent.
    assert suffix_n % 8 == 0
    suffix_slices = suffix_n // 8
    suffix_operation_rows = 60_000
    sigma_hard_total = 95544 + suffix_slices * suffix_operation_rows + old_q_reserve
    sigma_forecast = 95544 + suffix_n * forecast_rate + old_q_reserve
    assert sigma_hard_total == 1785544 <= sigma_cap
    assert sigma_forecast == 1006129 <= sigma_hard_total

    assignments = t["prospective_partition"]["assignments"]
    assert len(assignments) == len({q["family"] for q in assignments}) == 256
    assert t["prospective_partition"]["seed"] == spec["seeds"]["whole_family_split"]
    split_counts = dict(collections.Counter(q["split"] for q in assignments))
    assert split_counts == {"validation": 52, "train": 204}
    old = {q["game"]: q for q in s["entry_binding"]["partition"]["assignments"]}
    assert len(old) == 32
    final = {q["game"]: q for q in assignments}
    split_changes = []
    for game, before in old.items():
        after = final[game]
        assert before["family"] == after["family"]
        assert before["prefix"] == after["prefix"]
        if before["split"] != after["split"]:
            split_changes.append(
                {
                    "game": game,
                    "family": before["family"],
                    "pilot_split": before["split"],
                    "final_fit_view_split": after["split"],
                }
            )
    assert len(split_changes) == 1
    projected_r = split_counts["train"] * counts["selected_T_rows"] / 25
    projected_v = split_counts["validation"] * counts["validation_eligible_rows"] / 7
    projected_t = split_counts["train"] * counts["train_eligible_rows"] / 25
    illustrative_r = math.ceil(projected_r)
    max_r, max_v = split_counts["train"] * 32, split_counts["validation"] * 200
    train_max = 3 * min(8 * max_r, 32768) + min(64 * max_r, 524288)
    bank_max = max_r + max_v + 8192
    nnue_bound = train_max + 16 * bank_max + 4 * 419150 + 1024
    assert nnue_bound == 2595640 <= 4000000
    stock_projection = {
        key: value * split_counts["train"] / 25
        for key, value in enumerate(counts["stock_histograms"]["selected_T"])
    }

    old_variance = []
    arena_raw = []
    for selected in v["old_family_variance"]["selected"]:
        value = selected["values"]
        scores = [q["score"] for q in value["native_summary"]["pairs"]]
        variance = statistics.variance(scores)
        old_variance.append(
            {
                "saved_pairs": len(scores),
                "sample_variance": variance,
                "planning_64_family_halfwidth_normal_95": 1.96
                * math.sqrt(variance / 64),
                "planning_64_family_two_sided_80_MDE": 2.8 * math.sqrt(variance / 64),
                "cross_experiment_variance_transfer_unqualified": True,
            }
        )
        arena_raw.append(value["archive_raw_bytes"])
    old_arena_forecast = 1.25 * max(arena_raw) * 160 / 196
    assert (
        old_arena_forecast < allowances["arena_saved_outputs_archives_and_controls_B"]
    )
    byte_forecast = (
        pilot_bytes + suffix_n * bytes_per_suffix_request + sum(allowances.values())
    )
    assert byte_forecast == 126180352 < whole_cap
    resource = f["resource_correction"]
    assert resource["whole423_B"] == whole_cap
    assert resource["covered_before_small_tails_B"] == 49040753664
    assert resource["headroom_before_small_tails_B"] == 959246336
    assert resource["actual_used_or_cost_refund_B"] == 0

    clocks = [z.get("native_seconds_nested_not_added") for z in slices[1:]]
    suffix_time_estimate = 1.25 * max(clocks) / 8 * suffix_n
    result = {
        "issue": "quoridor-4lc.423.1",
        "status": "ONE_TIME_SCALE_FIXED_SAVED_METADATA_ONLY",
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "decision": {
            "total_generation_requests": resolved_n,
            "original_pilot_requests_reused": pilot_n,
            "genuinely_unentered_suffix_requests": suffix_n,
            "request_IDs": {"reused": [0, 31], "suffix": [32, 255]},
            "new_generation_launched_by_analyst": 0,
            "source_model_payload_forward_fit_Search_arena_calls": 0,
            "rationale": "Coverage formula requires288;256 is the largest feasible authorized finite comparison, with expected selectedT3754 below4096 guide. It broadens W's finite question, while F remains a small scratch-training exploration. Not an effect-size/sample-size guarantee or an automatic pilot-to-fit promotion.",
            "PILOT_ONLY": False,
        },
        "original_spec": next(
            z["before"] for z in inlet["refs"] if z["name"] == "fixed_spec"
        ),
        "resolved_seeds_unchanged": spec["seeds"],
        "pilot_actual": {
            "requests_GOAL": 32,
            "eligible_rows": 1704,
            "T_rows": 1289,
            "V_rows": 415,
            "T_families": 25,
            "V_families": 7,
            "selected_T_rows": 460,
            "exact_distinct_selected_T_inputs": 460,
            "selected_stock_histogram": counts["stock_histograms"]["selected_T"],
            "selected_per_training_game": 460 / 25,
            "R_over_former_800_example": 460 / 800,
            "Sigma_actual_rows": 95544,
            "Sigma_warm_failed": [0, 0],
            "observed_directed_bulk_allocated_B": pilot_bytes,
            "serial_TMP_historical_peak": "UNKNOWN",
        },
        "scale_arithmetic": {
            "guide_is_not_power_requirement": True,
            "individual_N_terms": target_terms,
            "data_formula_N": data_n,
            "request_ceiling": 256,
            "Sigma_forecast_feasible_total_N": sigma_forecast_n,
            "storage_forecast_feasible_total_N": storage_n,
            "resolved_N": resolved_n,
        },
        "suffix_settings": {
            "existing_controller_only": True,
            "operations": suffix_slices,
            "requests_per_operation": 8,
            "fixed_ranges": [[32 + 8 * k, 39 + 8 * k] for k in range(suffix_slices)],
            "each_operation_Sigma_rows_cap": suffix_operation_rows,
            "quality": "Same canonical MCTS64 completed simulations/move,200ply inclusive prefix, original model/factory/codec and temperature0. No simulation-quality reduction, new engine, scheduler or classifier.",
            "seed": spec["seeds"]["suffix_MCTS_seed"],
            "seed_binding": "Use this one frozen suffix seed with existing native per-game/global-ID semantics in all planned operations; no new seed sweep or outcome-dependent reassignment.",
            "unused_operation_caps": "not transferred or refilled; genuine UNKNOWN/failure/missing slots remain",
            "actual_process_width": "Root chooses1..4 at ordinary physical/RAM admission, no width sweep",
        },
        "Sigma": {
            "four_original_slice_actual_rows": rows_by_slice,
            "worst_actual_rows_per_GOAL_request": rate,
            "suffix_forecast_margin": 1.25,
            "suffix_forecast_rows": suffix_n * forecast_rate,
            "old_q_boundary_reserve": old_q_reserve,
            "total_forecast_including_pilot_reserve": sigma_forecast,
            "hard_sum_of_fixed_operation_caps_plus_actual_pilot_reserve": sigma_hard_total,
            "whole_limit": sigma_cap,
            "unallocated_whole_rows": sigma_cap - sigma_hard_total,
            "logical_physical_executed_warm_failed": "Actual separate counters retained; forecasts do not imply completed games or count simulations as forwards",
        },
        "final_fit_view": {
            "frozen_prospective_partition": next(
                z["before"]
                for z in storage["refs"]
                if z["name"] == "prospective_partition"
            ),
            "canonical_families_if_all_256_complete": split_counts,
            "pilot_to_final_fit_view_changes": split_changes,
            "original_RAW_split_cache": "immutable pilot provenance; do not silently relabel or overwrite",
            "binding": "Use existing normal canonical owner and original fac3fd19 split correspondence to bind final global IDs, schedule, realized successful row game codes, and exact final fit-view assignment. Suffix operational/raw split provenance is separate. No alternate registry or split algorithm.",
            "if_missing": "Keep fixed256 prospective assignments, realized missingness and eligible T/V subset explicit; no re-ranking by outcome or success and no substitute requests",
            "estimated_eligible_T_rows": projected_t,
            "estimated_all_V_rows": projected_v,
            "estimated_selected_T_rows": projected_r,
            "estimated_distinct_T_inputs": "UNKNOWN; pilot selected inputs are460/460 distinct, no guarantee at256",
            "density_scenario_distinct_if_pilot_uniqueness_persists": projected_r,
            "selected_4096_guide_shortfall_estimate": 4096 - projected_r,
            "selected_stock_density_scenario": stock_projection,
            "actual_before_fit": "Freeze actual R/distinct/T/V/stock/prefix and forward arithmetic once after this suffix. Practical minimum coverage for the planned main comparison: >=128 eligible T families, >=32 V families, >=2048 distinct selected T inputs. These are prospective scope choices, not statistical sufficiency. If materially unmet, report PILOT_ONLY; do not fit just to exhaust authorization or resolve a second scale.",
            "R4096_guide": "target only; projected3754 permits this explicitly limited main comparison, not a hidden hard guarantee",
        },
        "fits": {
            "unchanged_rules": spec["training_schedule"],
            "projected_R_ceil_for_schedule_example_only": illustrative_r,
            "U_R_W_example_not_actual": schedule(illustrative_r, 8, 32768),
            "F_example_not_actual": schedule(illustrative_r, 64, 524288),
            "exact_row_exposure": "W at most8 and F at most64 per selected row, same shuffled stream prefix and no padded extra batch; save actual visits. U/R/W share actual updates, batches and warmstart; R alone changes 0.92^(43-i) public-row weights. F also differs in initialization/LR/update/exposure, not an initialization-only contrast.",
            "hard_bounds_for_frozen_204T_52V_partition": {
                "selected_T_rows": max_r,
                "V_rows_200ply_bound": max_v,
                "four_fit_training": train_max,
                "one_observation_bank": bank_max,
                "observations_max": 16,
                "four_BEST_full_public_V": 4 * 419150,
                "changed_weights_allowance": 1024,
                "logical_NNUE_rows_without_INITIAL_sharing": nnue_bound,
                "logical_NNUE_whole_cap": 4000000,
            },
            "scope": "Shared INITIAL only actual exact scope; no421U/C substitution. No extra LR/seed/fit/checkpoints or q teacher. Search/arena node work is separate, never hidden in training counts.",
        },
        "arena": {
            "fixed_allocation_unchanged": spec["arena"],
            "planning_old_family_variance_only": old_variance,
            "worst_range_64_family_normal95_halfwidth": 0.1225,
            "worst_range_64_family_normal80_two_sided_MDE": 0.175,
            "scope": "Only W/BEST43 primary64 starts; W/D secondary16 shared starts. Actual missing/UNKNOWN retained. No pooling old408/412/421 results, no population/Elo/superiority/noninferiority guarantee. U/R/F have no direct strength contrast here.",
        },
        "storage": {
            "existing_whole_cap_B": whole_cap,
            "actual_pilot_conversion_receipt_allocated_B": pilot_bytes,
            "suffix_generation_conversion_growth_forecast_B": suffix_n
            * bytes_per_suffix_request,
            "planning_allowances_not_measured_peaks": allowances,
            "old_saved_arena_196game_raw_bytes": arena_raw,
            "scaled160game_old_largest_raw_with25pct_margin_B": old_arena_forecast,
            "whole_forecast_B": byte_forecast,
            "forecast_margin_B": whole_cap - byte_forecast,
            "serial_TMP_peak": "UNKNOWN;8MiB is an allowance, not measured peak",
            "admission": "Existing aggregate whole guard plus ordinary actual owner output forecasts/TMP/control checks are authoritative at each real stage; partial stop is allowed. This forecast does not certify future arena output size or guarantee256 games, fits or160 arena completion. Do not add a budget framework or silently expand128MiB.",
            "latest_Root_support": resource,
            "no_global_inventory_refund_or_shared_recharge": True,
        },
        "cost": {
            "pilot_outer_once_seconds": producer["original_outer_seconds_once"],
            "conversion_outer_once_seconds": v["conversion_collection"][
                "outer_seconds_once"
            ],
            "known_original_outer_subtotal_seconds": producer[
                "original_outer_seconds_once"
            ]
            + v["conversion_collection"]["outer_seconds_once"],
            "suffix_elapsed_planning_seconds": suffix_time_estimate,
            "suffix_time_basis": "1.25*max(original slices1..3 native wall/8)*224, sequential operation planning only; not added to already counted pilot and not a kill deadline or parallel speed guarantee",
            "all_other_source_software_LLM_admin_fit_arena_actual_cost": "UNKNOWN or not entered; no fabricated zero",
        },
        "interpretation": {
            "W": "Test a finite practical transfer procedure from many more lineages with bounded exposure against same-schedule public continuation and frozen incumbent; small general strength gains remain unresolved by64-family arena.",
            "F": "Exploratory scratch learning on a few thousand selected states plus inherited input normalization. Negative/INITIAL BEST cannot establish impossible scratch training, bad teacher, bad old weights or sufficient sample size.",
            "U_R": "Same43 public sources/warmstart/schedule, only stated recency weights differ; old generations are not independently proved weak.",
            "limitations": "No causal isolation of teacher/data/initialization/LR/updates, no MSE-to-strength equivalence, no D/Sigma oracle, newV checkpoint selection optimism and within-family dependence retained.",
        },
        "unchanged": "All342.17/323 USERPAUSE,421 separate evidence, product/generator defaults, models/features/weights/seals/oldfits96/foreign/old RAW/FAILED/fees remain unchanged",
        "next_dependency": "Root324 normal one suffix admission -> actual final cache/count/fit-view and schedules -> original four fits/finite arena -> same423.1 saved analysis. No new science by this analyst and no ACK/parentclose gate.",
    }
    save("resolution.json", result)
    save(
        "control.json",
        {
            "issue": "quoridor-4lc.423.1",
            "scale_resolution_complete": True,
            "total_requests": 256,
            "genuine_suffix_requests": 224,
            "pilot_success_replay": 0,
            "scientific_launches": 0,
            "PILOT_ONLY_now": False,
            "blockers": [],
            "ordinary": [
                "Expected3754 selectedT misses4096 coverage guide; no effect/sample guarantee.",
                "Actual distinct input count, final count/fit-view and4M bound must be frozen after suffix; materially low coverage means PILOT_ONLY without refill.",
                "Historical TMP peak unknown; future output admission and aggregate128MiB guard remain authoritative.",
                "F and secondary arena are exploratory; no general teacher/initialization/strength conclusion.",
            ],
            "leaf_status": "in_progress; original future saved-analysis dependency retained",
            "Root_human_ACK_gate": False,
            "new_model_source_native_forward_fit_arena": 0,
        },
    )
    checks = {
        "pilot_row_census": True,
        "four_slice_actual_Sigma": True,
        "coverage_formula_N288": True,
        "resolved_N256_under_all_planning_limits": True,
        "fixed28x8_suffix_ranges_disjoint_cover32_to255": True,
        "Sigma_hard_sum1785544_le2M": True,
        "projected_Sigma1006129_le_hard_sum": True,
        "prospective256_unique_families204T52V": True,
        "original32_prefix_family_exact_one_fit_split_change": True,
        "NNUE_worst2595640_le4M_without_INITIAL_credit": True,
        "bulk_forecast126180352_lt134217728": True,
        "old_arena_density_forecast_lt48MiB_allowance": True,
        "Root_resource_support_corrected_once_no_refund": True,
        "new_science": 0,
    }
    ranges = result["suffix_settings"]["fixed_ranges"]
    assert [i for lo, hi in ranges for i in range(lo, hi + 1)] == list(range(32, 256))
    save("checks.json", {"status": "PASS", "checks": checks})
    refs = []
    for blob in [inlet, support, storage, forecast]:
        refs.extend(blob["refs"])
    unique = {}
    for ref in refs:
        key = ref["before"]["path"]
        if key in unique:
            assert unique[key]["before"] == ref["before"]
        else:
            unique[key] = ref
    save("selectedrefs-before-after.json", list(unique.values()))
    print(
        json.dumps(
            {
                "status": "PASS",
                "N": 256,
                "suffix": 224,
                "predicted_selected_T": projected_r,
                "Sigma_forecast": sigma_forecast,
                "Sigma_hard_bound": sigma_hard_total,
                "NNUE_bound": nnue_bound,
                "bulk_forecast_B": byte_forecast,
                "pilot_fit_split_changes": split_changes,
                "selected_ref_count": len(unique),
                "readerSTOP": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
