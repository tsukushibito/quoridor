"""Freeze the 423 design using saved metadata and scalar arithmetic only."""

from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parent


def load(name):
    return json.loads((ROOT / name).read_text())


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{path.stat().st_mode & 0o777:04o}",
    }


def fit_work(rows):
    warm_seen = min(8 * rows, 128 * 256)
    fresh_seen = min(64 * rows, 2048 * 256)
    return {
        "selected_new_T_rows": rows,
        "U_R_W_each_training_rows": warm_seen,
        "U_R_W_each_updates": math.ceil(warm_seen / 256),
        "F_training_rows": fresh_seen,
        "F_updates": math.ceil(fresh_seen / 256),
        "W_exposure_equivalents": warm_seen / rows,
        "F_exposure_equivalents": fresh_seen / rows,
        "total_four_fit_training_forwards": 3 * warm_seen + fresh_seen,
    }


# No bootstrap, predicate, geometry, game replay or model evaluation occurs here.
family_metadata = load("old-family-variance-metadata.json")
old_variance = []
for item in family_metadata["selected"]:
    v = item["values"]
    scores = [row["B_score"] for row in v["family_scores"]]
    assert len(scores) == 98 and all(x in (0, 0.5, 1) for x in scores)
    sd = statistics.stdev(scores)
    old_variance.append(
        {
            "evaluator": v["evaluator"],
            "n_families": len(scores),
            "mean_B": statistics.mean(scores),
            "sample_sd": sd,
            "pair_score_hist": dict(sorted(Counter(scores).items())),
            "normal_planning_only": [
                {
                    "families": n,
                    "half_width_95": 1.96 * sd / math.sqrt(n),
                    "difference_80pct_two_sided": 2.80 * sd / math.sqrt(n),
                }
                for n in (16, 64)
            ],
            "limitation": "旧412 LMR比較の分散。今回のモデル/分布へ移植できる保証も、旧対局の合算もない。",
        }
    )

old = load("old-position-candidates.json")
locators = {c["index"]: c for c in old["case_locators"]}
selected, seen = [], set()
positions = sorted(
    old["positions"],
    key=lambda p: (
        p["original_record"]["files"]["journal"]["path"],
        p["original_record"]["game"],
        p["case_index"],
        p["ply"],
    ),
)
for p in positions:
    stocks = p["recorded_attributes"]["stock_sum"]
    assert type(stocks) is int and 0 <= stocks <= 20
    stratum = (
        "16..20"
        if stocks >= 16
        else "8..15"
        if stocks >= 8
        else "1..7"
        if stocks
        else "0"
    )
    key = (p["case_index"], stratum)
    if key in seen or len(selected) == 32:
        continue
    seen.add(key)
    actions = [t["action"] for t in locators[p["case_index"]]["trace"][: p["ply"]]]
    assert len(actions) == p["ply"]
    encoded = json.dumps(actions, separators=(",", ":")).encode()
    computed = hashlib.sha256(encoded).hexdigest()
    assert computed == p["prefix_actions_sha256"]
    selected.append(
        {
            "state_id": f"383-case{p['case_index']:02d}-ply{p['ply']:03d}",
            "case_index": p["case_index"],
            "slot": p["slot"],
            "opponent": p["opponent"],
            "ply": p["ply"],
            "side_to_move_from_standard_start_parity": p["ply"] % 2,
            "stock_sum": stocks,
            "stock_stratum": stratum,
            "full_prefix_actions": actions,
            "prefix_actions_sha256": computed,
            "source_position_record": p["position_record"],
            "original_raw": p["original_record"],
        }
    )
write(
    "old-q-inputs.json",
    {
        "source": old["source"],
        "selection": "原journal path/game/case順、各game/残壁層の最初の保存局面、chronological、最大32。欠測補充なし。",
        "pool_states": len(old["positions"]),
        "actual_selected_states": len(selected),
        "games": len({p["case_index"] for p in selected}),
        "stock_strata": dict(Counter(p["stock_stratum"] for p in selected)),
        "states": selected,
        "admission": "保存済み完全action prefixの抽出だけ。新しいrules replayは0。実native from_prefix/rules/非終端/STM admissionは324の通常入口。",
        "bias": "元383のNNUE敗戦を選んだ12game/36局面からの記述用。public全域/独立32標本/教師正解ではない。",
    },
)

forward = {
    "requests_ceiling": 256,
    "conservative_selected_new_T": 256 * 32,
    "conservative_new_V": 256 * 200,
    "public_T_panel": 8192,
    "full_opened_public_V": 419150,
    "max_four_fit_training": 3 * 128 * 256 + 2048 * 256,
    "conservative_distinct_observations_without_initial_alias": 16,
    "max_observation_bank_rows": 256 * 200 + 256 * 32 + 8192,
    "frozen_best_public_V": 4 * 419150,
    "changed_weights_native_correspondence_allowance": 1024,
}
forward["upper_without_INITIAL_alias"] = (
    forward["max_four_fit_training"]
    + forward["conservative_distinct_observations_without_initial_alias"]
    * forward["max_observation_bank_rows"]
    + forward["frozen_best_public_V"]
    + forward["changed_weights_native_correspondence_allowance"]
)
forward["upper_with_actual_shared_warm_INITIAL"] = (
    forward["upper_without_INITIAL_alias"] - 2 * forward["max_observation_bank_rows"]
)
assert forward["upper_without_INITIAL_alias"] == 3381560 < 4000000
assert forward["upper_with_actual_shared_warm_INITIAL"] == 3246392

arithmetic = {
    "kind": "deterministic saved-metadata and scalar design arithmetic; no new science",
    "pilot_ideal_only": {
        "requests": 32,
        "families_if_all_distinct_completed": 32,
        "T_families": 25,
        "V_families": 7,
        "selected_T_ceiling": 800,
    },
    "forward_bounds": forward,
    "fit_examples_not_forecasts": [fit_work(r) for r in (217, 800, 4096, 6528, 8192)],
    "arena_normal_planning_worst_sd_half": [
        {
            "families": n,
            "games": 2 * n,
            "half_width_95": 1.96 * 0.5 / math.sqrt(n),
            "difference_80pct_two_sided": 2.80 * 0.5 / math.sqrt(n),
        }
        for n in (16, 64)
    ],
    "five_percentage_point_difference_worst_sd_normal_80pct": {
        "families_approx": math.ceil((2.80 * 0.5 / 0.05) ** 2),
        "games_approx": 2 * math.ceil((2.80 * 0.5 / 0.05) ** 2),
    },
    "old_412_variance_for_planning_only": old_variance,
    "old_412_reference": family_metadata["source"],
    "ideal_pilot_data_target_requests": 4
    * math.ceil(
        max(32, 128 * 32 / 25, 32 * 32 / 7, 4096 * 32 / 800, 2048 * 32 / 800) / 4
    ),
    "global_storage_conservative_prior_B": 49479413760,
    "pending_421_ceiling_B": 256 * 1024**2,
    "new_423_whole_B": 128 * 1024**2,
    "sum_prior_plus_two_pending_B": 49479413760 + 384 * 1024**2,
    "remaining_to_decimal_50GB_before_other_actual_positive_B": 50000000000
    - (49479413760 + 384 * 1024**2),
}
assert arithmetic["ideal_pilot_data_target_requests"] == 164
assert arithmetic["sum_prior_plus_two_pending_B"] == 49882066944
assert (
    arithmetic["remaining_to_decimal_50GB_before_other_actual_positive_B"] == 117933056
)
write("design-arithmetic.json", arithmetic)

contract = load("contract-ref.json")
amendment = next(
    x["ref"]
    for x in load("scale-addendum-refs.json")
    if "size-correction" in x["ref"]["path"]
)
spec = {
    "issue": "quoridor-4lc.423.1",
    "status": "FIXED_PILOT_AND_PROSPECTIVE_MAIN_RESOLUTION; FINAL_MAIN_COUNTS_DEPEND_ON_REAL_PILOT",
    "authority": {
        "original_contract": contract,
        "size_amendment_takes_precedence": amendment,
    },
    "owner": {
        "analyst": "codex:01a118a1-aef1-7252-b21b-42f07dd5b1e6",
        "model": "gpt-6.1-sol",
        "effort": "max",
        "cwd": "/workspaces/quoridor",
        "sandbox": "danger-full-access",
        "approvalPolicy": "never",
        "write_only": str(ROOT),
        "report_to": "quoridor-4lc.324 / 01a1376a-bfd3-75d2-bd64-61e9416b3b13",
        "science_by_analyst": 0,
    },
    "seeds": {
        "generation_prefix": 42320261016,
        "evaluation_prefix": 42320261017,
        "whole_family_split": 42320261018,
        "pilot_MCTS_slice_seeds": [42320261100, 42320261101, 42320261102, 42320261103],
        "suffix_MCTS_seed": 42320261104,
        "U_R_W_training_base": 42320261020,
        "F_fresh_initialization": 42320261021,
        "W_F_shuffled_row_stream": 42320261022,
        "U_R_uniform_proposal_stream": 42320261023,
        "reflection_stream": 42320261024,
        "fixed_public_T_panel": 42320261025,
        "arena": 42320261026,
        "native_family_interval": 42320261027,
        "R_acceptance_stream": 42320261028,
        "old_q": 42320261029,
    },
    "input_selection": {
        "generation_request_ids": "0..255 prospective maximum; first32 retain original pilot inputs and do not wait for suffix preparation. Freeze genuinely unentered suffix rules-only actions/IDs before its numerical entry; actual suffix length chosen once from pilot counts/costs, not q/outcomes/model merit",
        "prefix_lengths_by_request": "[4,8,12,16][request_id % 4]",
        "rules_candidates_per_request": 32,
        "collision_owner": "existing quoridor_data::terminal::partition_families; reflection/canonical-prefix-extension/same-endpoint transitive families",
        "split": "existing seeded whole-family floor(4F/5) T/rest V; final combined frozen before any fit; record any pilot-to-final family/split change explicitly",
        "evaluation": "at most64 canonical families, disjoint from all prospective generation inputs, existing books and actual421 schedule/book; existing first-ID representative; reject/collision/missing retained, no refill",
        "missing_public_history": "UNKNOWN; no invented NPZ history and no full-public re-decode premise",
        "unknown_future_refs": "actual prefixes/schedules/partition/model outputs require normal prepared bindings; no placeholder SHA/FileRef",
    },
    "generation": {
        "entry": "current quoridor-runner selfplay / current MCTS/config/codec",
        "teacher_ONNX_sha256": "d790dac68389f7602ff8a887a2385417d3c925fe22da7164c86e9226f943908d",
        "backend": "CPU FP32 batch1 intra1/inter1 synchronous ORT, GPU0",
        "simulations_per_move": 64,
        "completed_simulations_required": True,
        "temperature": 0.0,
        "temperature_source": "runtime::choose_action existing zero-temperature snapshot fallback/best; no new visit sampler/Dirichlet",
        "total_ply_including_opening": 200,
        "pilot": [
            {
                "slice": s,
                "request_ids": list(range(8 * s, 8 * s + 8)),
                "Sigma_rows_ceiling": 60000,
            }
            for s in range(4)
        ],
        "pilot_unused_budget": "no cross-slice lending or pilot retry/refill",
        "max_independent_backends": 4,
        "each_backend": "one game sequentially, one physical CPU; actual width1..4 fixed before entry, aggregate family4GiB/hostreserve4GiB",
        "whole_study_Sigma_rows": 2000000,
        "old_q_and_needed_boundary_Sigma_rows": 10000,
        "suffix": "one genuinely unentered fixed request suffix after pilot resolution, aggregate residual under same existing inference/controller counter; no simulation-quality reduction",
        "charge": "count actual setup/warm/failed/executed logical and physical rows separately; simulation count is not inference-row count",
        "labels": "zSTM only actual GOAL/genuine threefold; UNKNOWN/cap/error/cancel have no invented outcome; q/root_raw/visits descriptive only",
    },
    "one_time_main_resolution": {
        "when": "after original32 pilot saved counts/actual cost/bytes, before any suffix entry or fit; Max/324 resolve once, no human/Root ACK",
        "pilot_required_small_summary": [
            "requested/entered/returned/statuses/reasons",
            "actual canonical T/V family count and eligible games",
            "selected T rows, exact distinct T model-input keys and stock/prefix-length coverage",
            "all eligible V rows/families/stock distribution",
            "actual logical/physical/warm/failed Sigma rows per slice and accepted goal/threefold game",
            "whole bytes/serial TMP peak/output forecast and outer/internal costs",
            "actual STOP and remaining original suffix",
        ],
        "coverage_planning_targets_not_power_guarantees": {
            "T_families": 128,
            "V_families": 32,
            "selected_T_rows": 4096,
            "distinct_T_model_inputs": 2048,
        },
        "data_target_formula": "N_data=4*ceil(max(32,32*128/F_Tpilot,32*32/F_Vpilot,32*4096/Rpilot,32*2048/Dpilot)/4); undefined denominators => no extrapolated launch",
        "why_these_targets": "約128 training lineages/32 held-out lineages、4層×8 capの下で数千rowとdistinct入力を目指すcoverage設計。既往8game/217T/76Vの反復過多から大きく離し、Wの上限32768 row-updatesを数千入力へ分散。Fの必要学習量を導いた公式ではない。",
        "rows_projection": "conservative per-request pilot rows=max(slice_actual_rows/max(actual_completed_eligible_games,1)), include warm/failed; zero completed slice is an insufficiency signal. Forecast suffix at1.25 times this rate, retaining actual global2M guard and remaining old-q allowance",
        "bytes_projection": "use actual pilot bytes/TMP/output owner forecast plus needed final cache/four models/curve/160-arena forecast; same aggregate128MiB guard. Do not grant completion from projection or add a budget framework",
        "chosen_N": "round down to multiple4 of min(N_data,256,rows-feasible-total-requests,storage-feasible-total-requests); no automatic run to256",
        "ideal_density_example_only": {
            "pilot_F_T": 25,
            "pilot_F_V": 7,
            "pilot_R": 800,
            "pilot_distinct_R": 800,
            "N_data": 164,
        },
        "insufficiency": "32 alone never auto-enters four fits/160games. If no defensible data/cost projection, or feasible scale materially misses the stated questions, preserve PILOT_ONLY and report the concrete shortfall. Max/324's one actual count-based resolution states which W/F questions remain exploratory before committing fits; no outcome/MSE/q-based selection or second scale sweep",
        "fit_freeze": "final actual T/V, selected rows, distinct counts, schedules/forward forecast frozen after this one suffix and before four fits; missingness/failure never refilled",
    },
    "training_data": {
        "T_view": "reuse421 family_training_view with compact pre-action geometry stocks/row_game_codes: [16..20,8..15,1..7,0], eachgame/stratum chronological equally-spaced<=8, game<=32; no empty-stratum fill or loss/outcome-based reselection",
        "V": "all ordinarily eligible admitted V rows, no T-thinning/augmentation, whole-family split",
        "raw_plusminus2_mask": False,
        "U_R": "same qualified all43 public T, no sealed/newE; R uses source file i=1..43 row weight0.92**(43-i), not claimed model generation/quality",
        "R_sampling": "exact weighted-row sampling; minimal existing indexed-reader option: uniform T-index proposals, accept with weight_i using separate seeded uniforms, then ordinary unweighted MSE. This gives P(row)=weight_i/sum_rows(weight). No equal-file masses, doubled loss weighting, corpus scan/NPZ re-decode, fallback to uniform; log proposals and accepted per-source exposure",
        "warmstart": {
            "weights_sha256": "046fe926e56b955b0fb7de8f147a74ec33eace9cbc00a55c307f9b6541ab9841",
            "descriptor_sha256": "46ec2c4708f96dcf9fad579c2fb0d1299c6663df27412f0faac98267467715e1",
            "typed_evaluator_sha256": "96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875",
        },
        "F": "fresh seeded existing same architecture; no learned public weights/labels in optimization, but same incumbent public-T-only normalization/scale metadata and separate public monitoring; not wholly public-free",
        "objective": "zSTM-only MSE; no q teacher/head reset/freeze/new feature or loss",
    },
    "training_schedule": {
        "architecture": "current FT32/H32/QF1/Zero4 FP32/tanh, standardized distance inputs, bypassOFF; same frozen normalization/scale",
        "optimizer_each": "fresh Adam betas[0.9,0.999], eps1e-8, weight_decay0",
        "R_actual": "actual nonempty selected newT rows, not requests/maximum rows",
        "U_R_W": "S=min(8R,32768); U=ceil(S/256); at update j, b_j=min(256,S-256*(j-1)); same actual b_j/update/LR for U/R/W",
        "U_R_W_learning_rate": "1e-4, linear warmup min(10,U) then constant",
        "F": "S_F=min(64R,524288); U_F=ceil(S_F/256); same actual-tail rule",
        "F_learning_rate": "1e-3, linear warmup min(20,U_F) then constant; one prospective choice extrapolated from362/366/371, not a scratch-LR qualification/optimum",
        "shuffle_and_reflection": "W/F same seeded shuffled-cycling row stream prefix; actual per-row visit counts; train-only correct LR reflection0.5 using separate stream; no ceil padding beyond8R/64R",
        "observations": "unique{0,ceil(U/3),ceil(2U/3),U}, F uses U_F; <=4 per condition; no validation-driven extra points/fit",
        "selector": "existing newV canonical-family mean of within-family row MSE, tie earlier step; public_non_regression=false; INITIAL/BEST/LAST only",
        "public_monitor": "full opened V419150 once per distinct actual frozen BEST/scope; fixed publicT8192 diagnostics, not fullT",
        "shared_INITIAL": "U/R/W only reuse actual saved exact-model/normalization/bank/scope record; no421C substitution or fabricated forward credits; conservative budget does not require aliasing",
        "descriptive_metrics": "family/stock/prefix-length MSE and sign; fixed10 equal-width post-tanh[-1,1] calibration bins with last endpoint included, mean prediction vs mean z, from same predictions; no extra forwards",
        "logical_forward_ceiling": 4000000,
        "conservative_forward_bound": forward,
        "changed_weight_boundary": "necessary native/full-delta/undo/scale only, <=1024 additional logical rows within4M; no old successful suite replay",
    },
    "old_state_q": {
        "fixed_inputs": ref(ROOT / "old-q-inputs.json"),
        "selected_count": len(selected),
        "MCTS": "same Sigma/current MCTS64 completed simulations, canonical from_prefix, no fabricated NPZ/from_counts history",
        "total_rows_including_new_boundary": 10000,
        "422": "reuse actual7 successful direct-static result when supplied; source-closed metadata is not executed success; static Sigma raw != MCTS root mean q; no standalone successful forward replay",
        "interpretation": "same STM existing saved z/NNUE/D values only, separate searched/static/history/budget provenance; q not true WDL and no new fit from old-q table",
    },
    "arena": {
        "allocation_before_new_outcomes": [
            {
                "contrast": "W versus frozen BEST43",
                "families": "first64 available canonical eval families",
                "maximum_games": 128,
                "role": "primary",
            },
            {
                "contrast": "W versus fixedD(0,8,tanh)",
                "families": "first16 of same eval families",
                "maximum_games": 32,
                "role": "secondary exploratory",
            },
        ],
        "total_maximum_games": 160,
        "total_maximum_colour_pairs": 80,
        "formerly_planned_five_by32": "unentered original plan retained in contract history; R/U,W/U,W/F have no direct game-strength comparison in this allocation, their curves remain descriptive",
        "method": "Control/PVS/TT1048576/LMR ON depth_rank/approxOFF/safeOFF, same frozen image,100ms authority receipt/5ms reserve/1M nodes per turn/200 total ply",
        "aggregate_nodes": 1000000000,
        "completion": "actual<=64 disjoint eval families, two colours; missing/UNKNOWN/storage cap preserved, no replacement/refill;160 is a ceiling not guaranteed complete",
        "uncertainty": "family paired scores; reuse existing family owner across necessary sequential batches, no averaging batch CIs/repeated bootstrap; same families in secondary are dependent; only saved native interval authority",
        "normal_planning_only": arithmetic["arena_normal_planning_worst_sd_half"],
        "limitations": "even64 families has worst-case approximate95% halfwidth12.25points and80%-power MDE17.5points; no guaranteed small-gain/Elo/superiority claim. NewV BEST selection and multiple fits do not make arena an unbiased population certificate",
    },
    "required_minimal_current_inlets": [
        {
            "owner": "data/current MCTS",
            "gap": "Config logical_row_limit currently rejects non-Sigma-static entries; connect actual2M aggregate and original four60k slice budgets to existing MCTS inference owner before forward, counting warm/failed, preserving64sim completion/error/partial policy",
        },
        {
            "owner": "data/current selfplay",
            "gap": "bind actual full-prefix schedule and normal family split/exclusions; expose already existing q/raw/visits and ordinary outcome z without raw-value mask; no new game/MCTS loop",
        },
        {
            "owner": "learning/current mixed-outcome+IndexedPublicCorpus",
            "gap": "one per-source weighted-row sampler using existing compact shard provenance; exact final batch lengths and same U/R/W schedule; no public data copy/redecode",
        },
        {
            "owner": "learning/current train+LC prepare",
            "gap": "honest F fresh-init inlet with same frozen normalization/scale (current prepare_fit requires warmstart); per-point newV-only selector and once-per-frozenBEST publicV monitoring; actual INITIAL record reuse only",
        },
        {
            "owner": "data/current MCTS benchmark",
            "gap": "bounded <=32 fixed full-prefix q-only requests through current invocation, not hardcoded old fixtures; charge10k total, reuse422 direct-static results with distinct meaning",
        },
    ],
    "storage_and_stop": {
        "whole_bulk_B": 128 * 1024**2,
        "included": "generation RAW/cache/views/four checkpoints/curves/arena/archive/controls/failures/serialTMP",
        "prior_plus_pending_conservative_B": arithmetic["sum_prior_plus_two_pending_B"],
        "actual_global": "UNKNOWN; Root adds only actual positive422/ordinary increments once; no target-holding re-charge/refund/global walk/deletion",
        "scope": "no new science by423.1; actual STOP/identity/directwait/reap/handles/TMP/leases, preserve failed and returned-vs-disk masks; no auto additional fit/seed/LR/teacher/roots",
    },
    "necessary_review_and_result": "one related independent Sol review of changed teacher/STM/family/sampler/scale/native boundaries, not per-run ACK. Source/software/numeric/strength are separate. Return original pilot small summary for one count/cost resolution, later same423.1 saved analysis; keep leaf open as actual dependency",
    "not_identifiable": [
        "32 requests as statistical/sample-size justification",
        "teacher/data/initialization as isolated causal effects",
        "F inadequacy as scratch impossibility",
        "R file number as weaker historical model generation",
        "small W/F differences as teacher uselessness",
        "q as optimal WDL",
        "160games as small-gain formal strength guarantee",
    ],
}
write("spec.json", spec)
print(
    json.dumps(
        {
            "selected_old_q": len(selected),
            "old_q_strata": Counter(p["stock_stratum"] for p in selected),
            "variance": old_variance,
            "forward": forward,
            "ideal_N_data": 164,
        },
        ensure_ascii=False,
    )
)
