"""Read only the named immutable API fragments needed by the 423 design."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess


OWN = Path(__file__).resolve().parent
PIN = "bbfba2cca6d3389359811552878936262947932e"
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def identity(pid):
    try:
        return {
            "pid": pid,
            "start_ticks": Path(f"/proc/{pid}/stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19],
            "boot_id": BOOT,
        }
    except (FileNotFoundError, ProcessLookupError):
        return None


def main():
    start = {
        "identity": identity(os.getpid()),
        "at": datetime.now(timezone.utc).isoformat(),
        "own_children": [],
        "scope": "named immutable source and compact metadata, no import/execution",
    }
    (OWN / "inlet-worker-start.json").write_text(json.dumps(start, indent=2) + "\n")
    target = OWN / "inlet-source-fragments.json"
    assert not target.exists(), "preserve already completed source intake"
    result = {
        "source_fragments": [],
        "metadata": [],
        "children": [],
        "worker_identity": start["identity"],
    }

    def checkpoint():
        target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

    for path, ranges in (
        ("scripts/dev/research-lifecycle.py", [(1515, 1585), (1600, 1665)]),
        ("crates/quoridor-runner/src/config.rs", [(72, 145), (260, 310)]),
        ("crates/quoridor-runner/src/runtime.rs", [(1850, 1935)]),
    ):
        env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
        process = subprocess.Popen(
            ["git", "-c", "core.fsmonitor=false", "cat-file", "blob", PIN + ":" + path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
        )
        child = identity(process.pid)
        out, error = process.communicate()
        result["children"].append(
            {
                "identity": child
                if child
                else "UNKNOWN: transient original identity unobserved",
                "directwait_reaped": True,
                "returncode": process.returncode,
                "handles_closed": process.stdout.closed and process.stderr.closed,
                "fresh": identity(process.pid),
            }
        )
        assert process.returncode == 0, error.decode()
        assert len(out) < 600000
        lines = out.decode().splitlines()
        value = {
            "commit": PIN,
            "path": path,
            "blob_sha1": hashlib.sha1(
                b"blob " + str(len(out)).encode() + b"\0" + out
            ).hexdigest(),
            "sha256": hashlib.sha256(out).hexdigest(),
            "bytes": len(out),
            "selected_fragments": [
                {
                    "start": a,
                    "end": b,
                    "text": "\n".join(
                        f"{i + 1}: {lines[i]}" for i in range(a - 1, min(b, len(lines)))
                    ),
                }
                for a, b in ranges
            ],
        }
        result["source_fragments"].append(value)
        checkpoint()
        print(json.dumps(value, ensure_ascii=False))
    for path in (
        "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-diverse421-v1/issue422-inlet.json",
        "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-loss-leaf419-v1/input-support-v1.json",
    ):
        p = Path(path)
        meta = p.stat()
        assert meta.st_size < 150000
        data = p.read_bytes()
        value = json.loads(data)
        assert p.read_bytes() == data
        result["metadata"].append(
            {
                "ref": {
                    "path": path,
                    "sha256": hashlib.sha256(data).hexdigest(),
                    "bytes": len(data),
                    "mode": f"{stat.S_IMODE(meta.st_mode):04o}",
                },
                "data": value,
            }
        )
        checkpoint()
        print("META", json.dumps(result["metadata"][-1], ensure_ascii=False))
    result["reader_STOP"] = datetime.now(timezone.utc).isoformat()
    result["input_handles_closed"] = True
    checkpoint()


if __name__ == "__main__":
    main()
