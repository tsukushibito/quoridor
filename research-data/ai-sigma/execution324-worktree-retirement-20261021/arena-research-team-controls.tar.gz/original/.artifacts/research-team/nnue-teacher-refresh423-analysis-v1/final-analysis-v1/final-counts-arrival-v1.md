423.1 元の保存分析の入力到着メモ。規模の再解決・数値dispatchではない。

2026-10-16のRoot配送による事実を保存する。以下の元ファイルはこのturnでは未読であり、SHA・自己整合の独立確認済みとはしない。元one-time256/spec/seed/条件は変更しない。

実turn_contextは2026-10-16T17:43:45.145Z、turn01a145d0-0abe-7e92-92a4-4481b216e33b、gpt-6.1-sol/max、cwd=/workspaces/quoridor、danger-full-access、approval neverを確認した。今回のsubstantial reader/helper/formatter/science entryは0。既存の実reader STOPは不変。現在のfitの実native+collection STOPまでは軽い保存proseだけとし、重い読取・helper・整形・Beads controllerを追加しない。

最終conversion job12897ce2はRoot報告でexit0/cleanuptrue、outer8.044397427001968sを一度。collector STOP17:33:31.984161Z/directreap/owned[]。原32+224 RAW/config/splitsを保持し、最終sampling viewの変更はID18だけ。

入力locator:

- `/workspaces/quoridor/.artifacts/research-team/integration324/nnue-teacher-refresh423-v1/science-v1/final-conversion-v1/final-counts.json`
- 配送SHA256 `129ae26c2a32f4bc4b3bc4bf3c777c6dc69340601c172151d5d15ce2ef3405e7`、271920B。
- 実cache manifestの配送SHA256 `b08d071af76d6684654c20d0e1e4467bca0248f8d6f1f170a4163465b6b1e718`、550865B。実pathは後のbound collectionから取得し、推測しない。

配送された実件数は12803行、最終T10305/V2498、204T/52V系列。選択T3763行、選択distinct3763、適格Tdistinct10303。固定した実用coverage128T/32V/distinct2048を満たす。選択4096目安から333行少ないままで、効果・標本数十分性・強さの保証へ変換しない。選択stock16=293、17=21、18..20=0。残り層の分布は配送がないため補完しない。

実materialized scheduleはU/R/W30104行・118updates・tail152、観測0/40/79/118。F240832行・941updates・tail192、観測0/314/628/941。配送されたwhole NNUE保守上界2240016行はchanged-weight reserve1024を含み、INITIAL共有creditなし。四fit/4M、160arena/1G nodes、Sigma2M、whole128MiBは不変。Sigma実績716901というRoot集計を保持し、このメモではscopeの再加算をしない。

Uの二つの原entryはFAILEDとして保持する。第一はcheckpoint parent欠損、第二は公開T/V ctimeがaccepted STOPを越えたことによる拒否で、いずれもmodel initialization前、training.json NOT_INITIALIZED、forward_rows0、attempted_update0。原outer8.276654534012778sと7.641188381006941sを別々に保存し、nested時間を加算しない。新しい成功へ再分類しない。

Rootはparentを修復し、原公開train555320634B/validation27663900Bの実SHAが原受入れと一致することを限定確認してcustodyを再bindしたと報告。sealed test未開封、payload decode/model forwardなし、原受入れ364bfは不変。四つのconfig-v2の差はpublic_acceptance FileRefのみという配送を保持する。正本はpublic-custody-rebind-v1/receipt.json/finalization.json。これを本人の新しいsource reviewやguard緩和承認と扱わない。

Rootがfit-U-entry-v3、実modeloutputU-v2を準備・入場する。旧U-v1 INCOMPLETEを保持する。Uの成功/curve/BEST、残るR/W/Fやarenaの結果はまだこのメモから推定しない。423.1は同claimant/in_progressで、元の一度の実結果保存分析を待つ。新しいscale/generation/fifth fit、ACK/親closeのgateを設けない。

この到着メモはWIPで、現在はformatterを起動しない。実fit STOP後に必要な小metadataのexact FileRef確認・限定整形と元の保存分析へ進む。全legacy USERPAUSE/defaults/models/weights/seals/RAW/FAILED/費UNKNOWNは不変。
