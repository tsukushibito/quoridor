423.1 元の一度のcount-cost規模解決完了。科学entry0、同claimant/in_progressで後の保存分析を保持します。

合計256 requests = 原pilot32再用 + 真正未入場ID32..255の224件。既存8件/slice・60000 Sigma行を28操作、同64sims/200ply/モデル/teacher/温度0、既定suffix seed42320261104。補充・再演・未使用枠転用0。pilot95544 + suffix cap1680000 + 旧q/境界10000 = hard1785544 <=2M、25%余裕付き密度forecast1006129。新しい数値は見ずに固定しました。

実R460/25T/7VからN_data288、許可上限と費用からN256。固定bookは204T/52V、密度scenario R3753.6/distinct UNKNOWN、4096目安未達は明記。Fは探索的、小改善/一般強さの保証なし。suffix後に実count/distinct/view/forwardを一度freezeし、実用coverage(T128/V32/distinct2048)を大きく満たさなければPILOT_ONLY、追加suffix/fit補充なし。原32のみから四fitへ自動接続しません。

原pilotID18だけV→最終fit-view Tとなることを確定。原RAW/split/cache不変、fac3方針+既存canonical ownerで最終256IDと実row game codeのfit-viewを結合してください。新split実装や原RAWのsilent relabelは不要です。

四fit元条件不変。固定204T/52VでINITIAL共有を引かないNNUE上界2595640 <=4M。主要W/BEST43=64family二色128games、副次W/D=同first16二色32、160/1G維持。old-family分散はplanningのみ、bootstrap0。bulk既存128MiB内のforecast126180352B（余裕8037376B）；historical TMP peak UNKNOWNであり将来actual output/TMP admissionとwhole guardが正本。Root重複cover訂正15:21適用済みを参照、global actual UNKNOWN・refund/target再課金0。

completion: /workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/one-time-scale-v1/completion.json SHAb1875f7fdaebbe87a890ad708c37eccd3382808d0f8b01a44b7eda17aeb3a800 /4931B0644
report: /workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-teacher-refresh423-analysis-v1/one-time-scale-v1/report-ja.md SHA0afe76f3f47804d1627610302a1517a6bf1070de9f1a86a83e2510e4c70cc97d /8866B0644
resolution/checks/control/selectedrefs-final/STOP/usageは同dir。24selected refs前後+final exact、Ruff/Prettier/算術PASS。実selected readerSTOP15:34:55.485091Z・helperreap15:34:59.812499Z、最終packetreap15:37:03.435853Z、fresh original IDs absent/directwait/reap/handles/TMP/leases/owned[]。一回OWN snapshot1478656B、以後tiny admin tailは別。Beads同owner/in_progress/backup sync PASS。

原spec c919/completion71c/splitfac3と全legacy pauses/defaults/models/RAWFAILEDfeesは不変。Root普通の実source/software/入力/physical/容量admissionで元のsuffixへ進めます。再承認/RootACK/421親close待ち0。本本人は数値をdispatchせず、同leafで実保存結果を受けます。なお421.1は既送の本人close/backup済みで423と別です。
