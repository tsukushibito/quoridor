423.1の元の保存fit/q分析の途中成果。最終arena分析は未実施、本人leafは同claimant/in_progressのまま保持する。新しい規模解決・science・review・adoptionではない。

Rはnative fit COMPLETEである一方、原operationはFAILEDのまま。Rootが存在しないローカルinitial-observation.jsonを宣言したための失敗であり、実際にはUのINITIALを正確なFileRefで共有していた。保存された数値を分析できることと、原operationの成功を区別する。Uの初期化前の二FAILED、変更重み対応のCPU-affinity事前拒否も保持する。

| 条件 | BEST / LAST step | 新V family-MSE 初期→BEST | 新V row-MSE BEST | 公開fullV MSE、BESTだけ |
| --- | --- | --- | --- | --- |
| U：全43公開T | 79 / 118 | 0.945876→0.944336 | 0.981644 | 0.423886 |
| R：同公開T、recency weight | 118 / 118 | 0.945876→0.941504 | 0.980087 | 0.423965 |
| W：BEST43から新Sigma zのみ | 118 / 118 | 0.945876→0.915511 | 0.955989 | 0.425681 |
| F：新規初期化から同じ新T | 0 / 941 | 1.000000→1.000000 | 1.000000 | 1.000000 |

全新Vは2498行・52 held-out family。family-MSEはfamily内row-MSEの非加重平均で、row-MSEと同一の分母ではない。各条件のBESTはこの同じ新V family-MSE最小・同点早いstepで選択した。公開fullV419150行は各BESTに一度だけで、curveの公開V nullは未測定を意味し、欠損を埋めていない。公開T8192行の固定panelは別に保持する。

U/R/Wは同じBEST43・同じ118更新・実30104訓練行。Rだけ全43源の0.92^(43-i) row weightを変える。Rの公開候補index150394件はaccepted30104行と別であり、候補indexを追加NNUE forwardとして数えない。古い世代が弱いという根拠にはならない。U/R/Wの新V family-MSE改善はそれぞれ約0.163%/0.462%/3.210%。family別の改善/悪化はU29/23、R31/21、W29/23で、Wが全familyで改善したわけではない。

Wは新T row-MSEが0.871007→0.824278、新Vも低下するが、公開Vにはtrade-offがある。これは今回の更新手順の有限なloss観測であり、棋力・教師正解・一般優越ではない。BEST選択に使ったVでの改善を、独立した確認結果へ水増ししない。

FのBEST0は実際のfresh initial modelであり、旧BEST43へ戻した結果ではない。共通の入力正規化を引き継いだことと、旧学習重みを引き継ぐことは別である。Fは941更新・実240832訓練行、訓練行数/選択Tは64相当で、Wの8相当より多い。F LASTの新T MSEは0.000690まで下がる一方、新V row-MSEは1.463406、family-MSEは1.488976へ上がった。この設定での訓練と汎化の隔たりとして記録し、F不可能・教師無効・必要データ数が十分だったとは結論しない。LR/初期化/更新/露出も違うため、初期化単独の比較ではない。個々のvisit配列は読まず、実total/distinct/repeated-draw counterの範囲を残す。

| 残壁層 | 適格T行 | 選択T行 | 全V行 |
| --- | ---: | ---: | ---: |
| 16..20 | 320 | 314 | 76 |
| 8..15 | 2217 | 1183 | 558 |
| 1..7 | 6685 | 1632 | 1709 |
| 0 | 1083 | 634 | 155 |

選択Tは3763行・distinct3763。高在庫の選択はstock16が293、17が21、18..20は0であり、層の名前だけで序盤全域を覆ったとはしない。Vの高在庫も76行に限られる。W BESTのV層別MSEは1.159371 / 1.078505 / 0.974814 / 0.207640、各分母は表のV行数である。全条件の層別・10bin calibration・52family変化をresult.json/family-MSE-changes.jsonへ保持し、有利な層の選別で有意性を作らない。

四fit訓練331144 + 測定1878942 = 2210086 logical NNUE行。新T3763 + 新V2498 + 公開T8192 = INITIAL bank14453行。R/Wは実U INITIALの同じFileRef・同じstep0 metricsを共有して追加forward0であり、16観測分から実共有2回を除いた14×14453 + BEST公開V4×419150 = 測定1878942と一致する。native変更重み対応はU/R/W/F各120、計480 headsで、合計2210566 < 4M。これを物理FT回数と同一視しない。

旧qは固定28局面/原12敗戦、各64 completed simulations、論理/物理/実行Sigma行はいずれも1294、warm/failed0。terminal_no_nnの合計498はMCTS内のcounterであり、28局面や対局の勝敗数ではない。生成716901 + 旧q1294 = 718195 < 2M。qを教師にした追加fitは0。原敗戦からchronological・残壁層別で選ばれた集合なので、独立28標本やpublic全体の精度測定ではない。

先頭の固定例は383-case08-ply011（slot4、残壁14）。元position recordと今回のinput/tableは完全prefixのSHA71d535e9880ecb07aeae3864da71a62edb3223651dbe03bf1c2e6dcca97757c1が一致する。

| 保存観測 | 着手 | STM値 | 値の範囲・意味 |
| --- | --- | ---: | --- |
| 原NNUE対局snapshot | 156 = V(d2) | +0.95947003 | 完成depth3、internal_time_limit、searched root、PV156/193/207 |
| 今回Sigma MCTS64 | 68 | +0.097117811 | 現モデル/64simのroot q |
| 同じSigmaのstatic root | 着手順位ではない | -0.005028306 | root head出力、searched rootではない |

同じ完全履歴に対して値の見え方は異なるが、評価器・探索・予算が違う。原NNUE値をstatic値へ読み替えず、SigmaをWDL oracleや正しい候補手とはしない。この一例から元敗因・壁手の誤り・勝敗を回避できた代案を認定しない。現在Wの同一葉評価を追加したわけでもない。旧qの現在値はresult.jsonとold-q-compact-table.jsonの範囲に限り、original RAWの再decodeや対局再演は0。

この途中集計で把握した原outerは、U初期化前FAILED二つ、U、RのFAILED operation、W/F共有outerを一度、変更重み対応、旧qで計61.487176436028676s。WとFの共有outer18.122861409006873sを二回足さず、旧qのnested4.983279387sも加算しない。生成/変換/その他の失敗・source/LLM/adminを全て覆う合計ではなく、全費用・continuous RSS・物理FTはUNKNOWNを保持する。

保存数値だけの算術checksはPASS、手書きhelperはRuff format/check済み。16の元selected refsをhash-before-parse/after exactで記録した。最後の元position readerは18:31:28.228430Zに直接reap、直前の有限helperは2026-10-16T18:35:04.725713Zに直接wait/reap、exact child absent、handles closed、TMP/lease/owned[]で終了している。

18:35以後のRoot arena timing intentに従い、新しいreader/helper/formatter/Beads/admin jobは開始しない。この軽いproseはWIPで、Prettier・最終stable refs・このphaseの通常backup/handoffは実native+collection STOP後へ残す。原arenaは64固定family、主要128/800M + 副次32/200Mの元scopeであり、開始前checksから結果を推定しない。Root/人間ACKやこのproseの完成を入口にしない。全legacy pause/defaults/models/weights/seals/RAW/FAILED/費UNKNOWNは不変。
