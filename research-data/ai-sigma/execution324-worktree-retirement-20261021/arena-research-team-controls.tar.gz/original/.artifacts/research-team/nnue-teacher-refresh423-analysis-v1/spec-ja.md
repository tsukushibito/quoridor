# 423 初回pilotと一度の本比較規模解決

32自己対局は効果量・学習曲線から求めた数ではなく、費用とデータ密度を測るpilot上限である。32件だけで四fit・160局の採否比較へ自動接続しない。元契約と規模訂正文を併記し、256 requests／Sigma合計2M rowsを今回全体の上限とする。全上限の実行指示ではない。本稿の科学実行は0、最終件数は実pilotに依存する。

## 固定する入口と入力

現在の`quoridor-runner selfplay`とMCTSを使う。Sigma d790／CPU FP32 ORT／batch1／intra1・inter1、各手64 completed simulations、temperature=0.0、序盤込み200ply。temperature=0は現役のbest/fallback選択であり、新しい着手samplerを加えない。420のSigma価値＋αβとは別である。

元32 requestsは四slice各8・60k Sigma rowsのまま、同じ成功分を再演しない。未使用枠をpilot slice間で融通せず、追加の本比較は一度の真正未入場suffixとして束縛する。各backendは一gameを順番に処理し、実資源に応じ1～4独立CPU backend、合計family4GiB／GPU0。setup・warm・失敗forwardも実counterへ含め、simulation数をrow-forward数へ読み替えない。

rules-only prefixは4/8/12/16手のround-robin。既存32候補attemptとcanonical/reflection/extension/endpointのfamily ownerを再用する。元32の入力は保持し、そのpilotをsuffix準備待ちにしない。将来の真正未入場suffix候補と評価用最大64familyは、その新しい数値入場前に固定する。評価bookは全生成候補・既存book・421の実schedule/bookと分離する。衝突・欠測・終端prefixを別入力で埋めない。最終splitは同じ正本でwhole-family `floor(4F/5)` T／残りVとし、fit前に凍結する。pilotからfamily/splitが変わる場合も元の記録を残す。

seedはspec.jsonに固定した。主要なものは生成prefix=42320261016、評価prefix=42320261017、split=42320261018。初期四sliceのMCTS seedは42320261100～103、本比較suffixは42320261104。値・勝敗・q・MSEでseedや入力を選び直さない。

## pilot後に一度だけ決める規模

32件から受け取るのは、実入場・完了・理由、canonical T/V family数、有効game数、選択T row数、正確なdistinct入力数、残壁／序盤長別分布、全V row、Sigma実forward／時間／bytes／TMPとactual STOPである。GOAL／真正threefoldのzを得た通常適格データだけが学習候補となる。打切り・取消・errorへzを作らず、不足を補充しない。

coverageの設計目標をT 128family、V 32family、選択T 4096行、distinct T入力2048に置く。8game／217T／76Vの旧371から、系列の広さとholdoutを増やし、Wの最大32768 row-updatesを数千入力へ分散する狙いである。学習サンプル数の確立した公式でも、Wの改善やFの十分性を保証する数字でもない。stock層が空なら別層で埋めず、その不足も記す。

pilotの実値を`F_T,F_V,R,D`として、データ密度からの目安を次で計算する。

```text
N_data = 4 * ceil(max(32, 32*128/F_T, 32*32/F_V,
                       32*4096/R, 32*2048/D) / 4)
```

全32が別系列で完了しT25／V7、各Tから最大32行でR=D=800の場合、目安は164 requestsである。これは理想密度の例であり、実完了数・distinct数を800と仮定しない。

実pilotのslice当たり全forward（warm／failedを含む）を適格完了数で割った保守的費用を使い、suffixの計画値へ1.25倍を置く。完了0などで推定できない場合は巨大生成へ外挿しない。実bytes／serial TMPと既存publisherの残工程forecastも合わせ、2M Sigma rows・whole128MiB内で実行可能な総件数を求める。最終件数は`min(N_data,256,forwardで可能な件数,保存量で可能な件数)`を4の倍数へ切り下げ、一度だけ固定する。推定時間はkill期限ではなく、実aggregate guardは残す。

Max／324がこの実counts・費用から本比較の問いを一度解決する。目標へ大きく届かず解釈可能な比較が組めない場合はPILOT_ONLYを保存し、具体的な不足を返す。32だけを根拠に四fitと160局を消費しない。一方、目標数字を資格証明にはせず、残るW／Fの識別限界を明記して有限範囲を選ぶ。人間再承認・全員ACK・421/422親closeは条件にしない。

## 四fitとforward算術

Tは421と同じ、pre-action残壁16..20／8..15／1..7／0の各game・層からchronological等間隔で最大8行、game最大32行。Vは適格全行を保持する。raw探索値±2のmaskを持ち込まない。教師はzSTMのみで、qは説明用に保存する。

| 条件 | 初期値と学習データ                                              | 更新・露出                                 |
| ---- | --------------------------------------------------------------- | ------------------------------------------ |
| U    | 実BEST43、同じ全43 public T、uniform rows                       | Wと同じ実batch長・updates・LR              |
| R    | 同BEST43、同public T、元ファイル番号iのrow weight `0.92^(43-i)` | Uとの差はsamplerだけ                       |
| W    | 同BEST43、新Sigma Tのみ                                         | `S=min(8R,32768)` row-updates、最大128更新 |
| F    | 同構造の新規重み、Wと同じ新Tのみ                                | `S_F=min(64R,524288)`、最大2048更新        |

ここでRは実選択newT row数。各更新batchは最大256、最後だけ実残数にして8R／64Rをceil paddingで超えない。U/R/Wは`ceil(S/256)`回と実batch長も一致させる。W/Fは既存shuffled cyclingの同じrow streamの先頭を共有し、各rowの実露出を残す。

U/R/WはLR1e-4、最初min(10,U)回linear warmup後constant。FはLR1e-3、最初min(20,U_F)回warmup後constantの一条件だけとする。全てfresh Adam／betas(.9,.999)／eps1e-8／decay0／train-only左右反転.5。366/371の高LRはT低下とV悪化を同時に示し、scratchでの最適LRやデータ充足性を確認していない。この選択をFの一般的な到達可能性の検証とは呼ばない。

FT32/H32/QF1/Zero4/FP32/tanh・bypassOFF、同じ凍結distance正規化・尺度を保つ。Fはpublicの学習済み重みやラベルを最適化に使わないが、共通正規化metadataとpublic監視は利用するため「完全にpublic無利用」ではない。W/FはLR・更新・露出も異なり、初期値だけの因果効果にはならない。

Rの重みは適格T内の各rowに掛ける。現compactの元shard provenanceを使い、uniform T-index提案を重みに応じて受理する最小samplerなら、各rowの確率は`w_i / sum_rows(w)`になる。43ファイルを等確率で選ぶ方式や、samplerとlossの二重重み付けにはしない。元ファイル番号をモデル世代や弱さと同一視しない。全NPZの再decode・公開全域scan・corpus複製は不要である。

観測は各条件`unique{0,ceil(U/3),ceil(2U/3),U}`の最大4点。newVの既存canonical family-MSE最小・同点早期をBESTとし、public非退行条件は加えない。full opened public V419150行は凍結BESTごとに一度だけ監視する。固定publicT8192診断をfullTと呼ばない。stock／family MSE・符号と10等幅post-tanh校正は同じ予測から求める。

256 requestsを全て各200行・各32T行として重複する上界まで保守的に数えても、training622592＋16観測×67584＋4BEST publicV1676600＋changed-weights対応1024＝**3,381,560 logical NNUE rows**。4M以下である。実同一model・正規化・bank・scopeのINITIALが保存されている場合だけ共有でき、U/R/Wの共有で3,246,392以下になる。未使用forward枠は追加fit・観測点・sweepを発行する理由にしない。

## 対局配分と識別力

主要W対凍結BEST43に、事前固定した最大64family×二色＝128局を配分する。副次W対Dには同じbookの先頭16family×二色＝32局。最大160局／80pair／1G nodesのままで、R/U・W/U・W/Fの直接棋力比較はこの配分では行わない。旧五対照×32の未入場案は履歴に残す。

Control／PVS／TT1M／LMR ON-depth_rank／近似・safeOFF、100ms receipt authority／5ms reserve／1M nodes per move／200 total ply。同じ16familyを共有する副次対照を独立な新規familyに数えず、異軌跡・selected nominal depth・UNKNOWNを残す。whole128MiBは部分停止予算であり160局の完了保証ではない。

family二色scoreの標準偏差を最大0.5と置いたnormal近似の設計情報では、95%半幅は16familyで24.5pt、64で12.25pt。80%検出力の粗い差の目安は35pt／17.5ptで、5ptの改善には約784family／1568局を要する計算になる。正式power保証・新bootstrapではない。

旧412の保存98familyから計算したSDはNNUE .37080、D .26374。同じ分散を仮置きした64familyの半幅は9.08pt／6.46pt、差の目安は12.98pt／9.23ptだが、別のLMR比較であり今回へ移植できる保証はない。旧対局を合算しない。小さいW差、Fの不改善、Rの変化から教師無効・旧重みの良否・新規学習不可能を結論しない。

## 古い局面と現在の本当の実装差分

元383の12敗戦／36保存局面から、原journal/game順・各game/残壁層で最初の局面という規則により**28状態**を固定した。内訳16..20=1、8..15=11、1..7=12、0=4。32へ補充しない。完全action prefixのhashは元保存値と一致し、今回新しいrules replayはしていない。実nativeのcanonical from_prefix／STM／非終端admissionは通常入口で行う。q確認と必要な新境界を合わせ10k Sigma rows、study全体2Mに含める。

422の7状態はdirect-static値であり、MCTS root mean qではない。現在確認済みのsource CLOSED metadataから実forward成功を推定しない。実結果が届けば再用し、成功した単独static forwardを再演しない。旧NNUE/D searched値、static値、z、今回qはscopeを分け、qを真のWDLや新fit教師にしない。

現入口で必要な差分は、MCTSへの実Sigma row上限接続、既存full-prefix入力・q/raw/visits保存、compact shard由来R sampler、実tail batch、新V-only selector／BEST-only public監視、同正規化のF fresh-init admissionである。現在`logical_row_limit`はSigma static-valueだけに制限され、fit prepareはwarmstart必須なので、設定だけで実行可能とは扱わない。現役ownerを薄く接続し、別の探索loop・encoder・registry・cacheコピーを作らない。

## 引渡しと限界

spec.json、design-arithmetic.json、old-q-inputs.jsonを正本の固定specとする。実prefix／cache／weightsの未来Refを捏造しない。必要softwareと一つの関連Sol確認、実入力／資源／whole128MiB・decimal50GBの通常admissionは324が進める。本担当423.1はspecだけでcloseせず、実pilotのcountsによる一度の規模解決と元比較の保存分析を待つ。普通の返信・親closeを入口にしない。

既往source読取helperの3失敗は原capture・receiptを保持した。最初のguard `/proc` raceは元child identity／directreapがUNKNOWN、後の選択CPU snapshotでは残存なし。残りはmetadata上限と私有JSON shapeの誤りで、科学・モデル・forwardの再試行は0。既存pause、sealed、モデル／製品既定、旧RAW／FAILED／費UNKNOWNは不変である。
