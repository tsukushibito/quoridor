# 413：可変LMR三候補の独立設定draft

cost192 calls/96sessions/576M nodes上限とarena384局/192色ペアを、既存408の入力参照とoperation形式で準備した。image・Build・Experiment・runtime・support・currentcallerは未確定null、全draft ready=false。Rootだけが新imageを正常bindingして実行する。旧411/412と元成果・送信UNKNOWNは変更も再送もしていない。

## 明示methodと条件

| コード | requested name       | 役割                         |
| ------ | -------------------- | ---------------------------- |
| A      | depth_rank           | 選択済みの現行標準、変更なし |
| B      | depth_rank_late_one  | 後順位を1追加する候補        |
| C      | depth_rank_deep_two  | 深い後順位を2追加する候補    |
| D      | depth_rank_early_one | 順位を前倒しする候補         |

式・閾値・保護・PVS確認は人間契約と413.1のtyped LmrMethodが正本で、このhelperに再実装していない。ID/suffix/namespaceをPythonで合成していない。native actual method ID・reduction ruleは新software/runtimeが得られるまでnull。既存Engine.lmr_method文字列とsession factory/setterのarityを前提にしたdraftで、最終413.1源泉との対応はRootの通常compositionで確認する。

## cost recipe

stratum順はNNUE Control、NNUE Cheap、FixedD Control、FixedD Cheap。各stratumはA→B→C→D→D→C→B→Aの固定8 operation、合計32 operation。各6 calls/3sessions/18M上限で、192/96/576Mになる。

| root                   | target | node cap | session寿命                               |
| ---------------------- | -----: | -------: | ----------------------------------------- |
| 元cold family102       |     D8 |       2M | 独立cold                                  |
| 元cold family34        |     D8 |       8M | 独立cold                                  |
| 元family0 local0/2/4/6 |   各D8 |     各2M | 同一warm-family0 session内の4 roots、元順 |

root input/pointer/prefix_lenと完全履歴の参照は元408と同じ。旧D4/D6を新subject内のD8 request/labelへだけ変更し、旧結果へ遡及しない。全requestで時間上限なし、diagnostics/depth callback/warmup=false。共通TT1048576/PVS/LMR ON、旧近似min_root_walls=null、safe-race=falseを明示した。NNUE BEST43とFixedD(0,8tanh)は別stratumで、根拠は入力/モデルFileRefsだけを読みpayloadは開いていない。

native output/record boundは元正常measure設定の3MiB/512KiBを保持。将来のnormal output/capture guardで超過すれば失敗として止め、切捨て成功や自動cap拡大をしない。actualforecast/whole retained unionとdecimal50GBはRootの正常supportで確定する。

## arena recipe

costの実STOP後にだけ開始する。四strataの各々でB対A、C対A、D対Aをこの順に一度、合計12 operation。候補B/C/Dが左engine0、標準Aが右engine1。各対照は元408の全16family×二色=32局/16pairを一operationで保持し、native family区間はこの対照全体の16pairで一度だけ作る。

familyは14/16/23/27/37/38/39/44/64/74/82/86/103/109/118/124。元openingのprefix/history/lineageとfirst_candidate_colorsをそのまま使用した。412の未使用family主要標本は使っていない。seed41320261015、bootstrap10000は結果前に固定するproposalで、今回bootstrap自体は実行していない。

TT1M/PVS/LMR ON、100ms receipt/5ms reserve、node safety1M/depth64/200ply、AI2/6/main4/family4GiB/GPU0のprospective設定。arena Engineにはsafe-race/旧近似のselectorが無いので、共有factoryのdefaultOFFを新413source/softwareで確認する条件を残した。未対応JSON flagやfake zero counterは挿入していない。authority receipt用の既存completed-result経路は維持し、診断depth callbackと混同しない。

各32局operationのnormal native forecast既知項は48,771,237B（8MiB＋raw cap＋archive cap）、12本では585,254,844B。typed config/actual checked slots metadata項は未確定であり、これは完全forecast/予約/実使用量ではない。各64MiB output capは元正常設定のproposalで、64MiB×12をwhole実retentionと呼ばない。新image/currentnormalentryでのexact forecastと全体supportはRootがbindingする。

同じ16familyを12対照で共有しており384独立標本ではない。B/C/D同士は直接対局していない。対A scoreだけで確定順位・一般棋力・Elo・新標準への昇格をしない。後続保存解析ではUNKNOWNをdraw/敗戦に変えず、nominal selective depthの中央値/全hist/平均、terminal workとselected snapshotを別に記録する。追加削減counterの名前/実値はnative源泉が正本で、未記録はUNKNOWN。

## 最小consumer差分

immutable Git2e4846a7のLC arena_plan_checkにはmethod名をfixed_one/depth_rankに限るtupleがある。私有patch/inverseはこの一membership式に3 literalを足すだけ。測定側measurement_config_checkは413.1の担当なので重複編集しない。runtime/arenaは既存Option<String>→native from_nameを使い、別builderを追加しない。

Ruffはfunction文字列のstdin/stdoutに適用した。厳密patch forward/inverse（fuzz0）をOWNの一時subjectで確認し、元全byteへ復元して一時fileを削除済み。ASTはこの3 literalを戻せば全moduleでbeforeと一致し、他関数はbyte不変。Main/LC sourceそのものを書いていない。Rootの現callerがdriftしていれば一式だけ疎合成する。

新source/type/native testsはUNBUILT/UNTYPED/UNRUN。Rootに必要なconsumer定義は新3methodのsemantic intakeと、LMR OFFでもunknown名を拒否する境界。既存profile/runtime eligibilityを弱めない。関連413確認はRootが既存max担当へまとめ、このleafはreview dispatchしない。

## 検証・STOP

設定census、D8/cap/coldwarm、ABCDDCBA二反復、slot一意、各対照の16family二色、explicit requested methods、clock/TTと未確定nullを静的検証した。parse前/読取後の選択FileRefsを照合。Ruff/scoped Prettierとpatch proof以外のtest/native/model/library/solver/Search/game/fit実行は0。

source CPU8/controller11、family512MiB（child448＋controller64）、GPU0/hostreserve4GiB。実affinity/topologyとexact child/directwait/reap/handles/TMP/leases/STOP、OWN一回usageはcompletion.json/STOP.jsonへ束縛する。continuous RSS/LLM全費/将来quietはUNKNOWN。Main/Git/Cargo/Beads/backup/closeは324のみ。全mixed/learner prep/pipeline/323 USERPAUSE・defaults/models/weights/seals/旧RAWFAILED費を保持する。
