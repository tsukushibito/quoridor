"""Finite static draft/patch checks only; no production imports or engine entry."""

import ast
import hashlib
import json
import os
import subprocess
import tempfile
from collections import Counter
from pathlib import Path

OWN = Path(__file__).resolve().parent
cost = json.loads((OWN / "cost/settings.json").read_text())
arena = json.loads((OWN / "arena/settings.json").read_text())
plan = json.loads((OWN / "arena/plan.json").read_text())
schedule = json.loads((OWN / "arena/schedule.json").read_text())
requests = json.loads((OWN / "cost/requests.json").read_text())
methods = cost["methods"]
assert sum(o["calls"] for o in cost["measurements"]) == 192
assert sum(o["sessions"] for o in cost["measurements"]) == 96
assert sum(o["node_cap_sum"] for o in cost["measurements"]) == 576000000
assert all(
    r["depth"] == 8
    and r["time_limit_ms"] is None
    and not r["diagnostic"]
    and not r["observe_completed_depths"]
    and not r["warmup"]
    for r in requests
)
for stratum in range(4):
    ops = [o for o in cost["measurements"] if o["stratum"] == stratum]
    assert [o["method_code"] for o in ops] == list("ABCDDCBA")
    assert Counter(o["method_code"] for o in ops) == dict(A=2, B=2, C=2, D=2)
    for o in ops:
        c = json.loads(Path(o["config"]["path"]).read_text())
        assert c["lmr"] is True and c["lmr_method"] == methods[o["method_code"]]
        assert c["tt_entries"] == 1048576 and c["use_pvs"] and c["use_tt"]
        assert (
            c["zero_stock_safe_race"] is False
            and c["zero_stock_approx_min_root_walls"] is None
        )
        assert (
            o["artifact"] is None
            and o["Build"] is None
            and o["Experiment"] is None
            and not o["ready"]
        )
for o, batch in zip(arena["operations"], plan["batches"], strict=True):
    c = json.loads(Path(o["config"]["path"]).read_text())
    rows = [r for r in schedule if r["batch"] == o["batch"]]
    assert len(rows) == 32 and [r["slot"] for r in rows] == batch["slots"]
    assert [r["local_game"] for r in rows] == list(range(32))
    for i, fid in enumerate(arena["family_ids"]):
        assert [r["family_id"] for r in rows[2 * i : 2 * i + 2]] == [fid, fid]
        assert {r["candidate_color"] for r in rows[2 * i : 2 * i + 2]} == {0, 1}
    assert c["arena"]["search_artifact_sha256"] == [None, None]
    assert c["arena"]["tt_entries"] == 1048576 and c["arena"]["return_reserve_ms"] == 5
    assert c["max_plies"] == 200 and c["arena"]["retained_outcome_bytes"] == 630784
    assert c["engines"][0]["lmr_method"] == methods[o["left_candidate"]]
    assert c["engines"][1]["lmr_method"] == methods["A"]
    assert all(
        e["lmr"]
        and e["depth"] == 64
        and e["max_nodes"] == 1000000
        and e["time_ms"] == 100
        for e in c["engines"]
    )
assert len(schedule) == len({r["slot"] for r in schedule}) == 384

commands = []


def run(argv):
    proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        st = Path(f"/proc/{proc.pid}/stat").read_text().rsplit(")", 1)[1].split()
        identity = dict(
            pid=proc.pid,
            start_ticks=st[19],
            boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        )
    except FileNotFoundError:
        identity = None
    stdout, stderr = proc.communicate()
    commands.append(
        dict(
            argv=argv,
            pid=proc.pid,
            child=identity,
            directwait_exit=proc.returncode,
            reaped=True,
            handles_closed=True,
            stdout=stdout.decode()
            if "patch" in Path(argv[0]).name
            else "bounded immutable source bytes, SHA bound",
            stderr=stderr.decode(),
        )
    )
    assert proc.returncode == 0, stderr.decode()
    return stdout


gap = json.loads((OWN / "consumer-gap.json").read_text())
before = run(["git", "show", f"{gap['git']}:{gap['path']}"])
assert hashlib.sha256(before).hexdigest() == gap["before_sha256"]
with tempfile.TemporaryDirectory(
    prefix="consumer-subject-", dir=os.environ["TMPDIR"]
) as td:
    subject = Path(td) / "research-lifecycle.py"
    subject.write_bytes(before)
    run(
        [
            "patch",
            "--batch",
            "--forward",
            "--fuzz=0",
            "--no-backup-if-mismatch",
            str(subject),
            "--input",
            str(OWN / "arena-method-consumer.patch"),
        ]
    )
    after = subject.read_bytes()
    assert hashlib.sha256(after).hexdigest() == gap["proposed_after_sha256"]
    tree = ast.parse(after)
    expected = [
        "fixed_one",
        "depth_rank",
        "depth_rank_late_one",
        "depth_rank_deep_two",
        "depth_rank_early_one",
    ]
    normalized = 0
    function = next(
        n
        for n in tree.body
        if isinstance(n, ast.FunctionDef) and n.name == "arena_plan_check"
    )
    for n in ast.walk(function):
        if (
            isinstance(n, ast.Tuple)
            and all(isinstance(e, ast.Constant) for e in n.elts)
            and [e.value for e in n.elts] == expected
        ):
            n.elts = n.elts[:2]
            normalized += 1
    assert normalized == 1 and ast.dump(tree) == ast.dump(ast.parse(before))
    run(
        [
            "patch",
            "--batch",
            "--forward",
            "--fuzz=0",
            "--no-backup-if-mismatch",
            str(subject),
            "--input",
            str(OWN / "arena-method-consumer.inverse.patch"),
        ]
    )
    assert subject.read_bytes() == before
proof = dict(
    issue="quoridor-4lc.413.2",
    strict_forward_inverse=True,
    fuzz=0,
    normalized_AST_equal_to_before=True,
    only_semantic_change="three allowed-name literals in arena_plan_check membership tuple",
    outside_function_bytes_unchanged=True,
    temporary_subject_removed=True,
    source=gap,
    commands=commands,
    code_type_compile_tests="UNBUILT/UNTYPED/UNRUN",
    scientific_calls=0,
)
(OWN / "static-proof.json").write_text(
    json.dumps(proof, ensure_ascii=False, indent=2) + "\n"
)
for ref in json.loads((OWN / "selected-refs.json").read_text()):
    p = Path(ref["path"])
    b = p.read_bytes()
    assert (
        hashlib.sha256(b).hexdigest() == ref["sha256"]
        and len(b) == ref["bytes"]
        and f"{p.stat().st_mode & 0o777:04o}" == ref["mode"]
    )
lines = [
    "# 413：可変LMR三候補の独立設定draft",
    "",
    "cost192 calls/96sessions/576M nodes上限とarena384局/192色ペアを、既存408の入力参照とoperation形式で準備した。image・Build・Experiment・runtime・support・currentcallerは未確定null、全draft ready=false。Rootだけが新imageを正常bindingして実行する。旧411/412と元成果・送信UNKNOWNは変更も再送もしていない。",
    "",
    "## 明示methodと条件",
    "",
    "|コード|requested name|役割|",
    "|---|---|---|",
    "|A|depth_rank|選択済みの現行標準、変更なし|",
    "|B|depth_rank_late_one|後順位を1追加する候補|",
    "|C|depth_rank_deep_two|深い後順位を2追加する候補|",
    "|D|depth_rank_early_one|順位を前倒しする候補|",
    "",
    "式・閾値・保護・PVS確認は人間契約と413.1のtyped LmrMethodが正本で、このhelperに再実装していない。ID/suffix/namespaceをPythonで合成していない。native actual method ID・reduction ruleは新software/runtimeが得られるまでnull。既存Engine.lmr_method文字列とsession factory/setterのarityを前提にしたdraftで、最終413.1源泉との対応はRootの通常compositionで確認する。",
    "",
    "## cost recipe",
    "",
    "stratum順はNNUE Control、NNUE Cheap、FixedD Control、FixedD Cheap。各stratumはA→B→C→D→D→C→B→Aの固定8 operation、合計32 operation。各6 calls/3sessions/18M上限で、192/96/576Mになる。",
    "",
    "|root|target|node cap|session寿命|",
    "|---|---:|---:|---|",
    "|元cold family102|D8|2M|独立cold|",
    "|元cold family34|D8|8M|独立cold|",
    "|元family0 local0/2/4/6|各D8|各2M|同一warm-family0 session内の4 roots、元順|",
    "",
    "root input/pointer/prefix_lenと完全履歴の参照は元408と同じ。旧D4/D6を新subject内のD8 request/labelへだけ変更し、旧結果へ遡及しない。全requestで時間上限なし、diagnostics/depth callback/warmup=false。共通TT1048576/PVS/LMR ON、旧近似min_root_walls=null、safe-race=falseを明示した。NNUE BEST43とFixedD(0,8tanh)は別stratumで、根拠は入力/モデルFileRefsだけを読みpayloadは開いていない。",
    "",
    "native output/record boundは元正常measure設定の3MiB/512KiBを保持。将来のnormal output/capture guardで超過すれば失敗として止め、切捨て成功や自動cap拡大をしない。actualforecast/whole retained unionとdecimal50GBはRootの正常supportで確定する。",
    "",
    "## arena recipe",
    "",
    "costの実STOP後にだけ開始する。四strataの各々でB対A、C対A、D対Aをこの順に一度、合計12 operation。候補B/C/Dが左engine0、標準Aが右engine1。各対照は元408の全16family×二色=32局/16pairを一operationで保持し、native family区間はこの対照全体の16pairで一度だけ作る。",
    "",
    "familyは14/16/23/27/37/38/39/44/64/74/82/86/103/109/118/124。元openingのprefix/history/lineageとfirst_candidate_colorsをそのまま使用した。412の未使用family主要標本は使っていない。seed41320261015、bootstrap10000は結果前に固定するproposalで、今回bootstrap自体は実行していない。",
    "",
    "TT1M/PVS/LMR ON、100ms receipt/5ms reserve、node safety1M/depth64/200ply、AI2/6/main4/family4GiB/GPU0のprospective設定。arena Engineにはsafe-race/旧近似のselectorが無いので、共有factoryのdefaultOFFを新413source/softwareで確認する条件を残した。未対応JSON flagやfake zero counterは挿入していない。authority receipt用の既存completed-result経路は維持し、診断depth callbackと混同しない。",
    "",
    "各32局operationのnormal native forecast既知項は48,771,237B（8MiB＋raw cap＋archive cap）、12本では585,254,844B。typed config/actual checked slots metadata項は未確定であり、これは完全forecast/予約/実使用量ではない。各64MiB output capは元正常設定のproposalで、64MiB×12をwhole実retentionと呼ばない。新image/currentnormalentryでのexact forecastと全体supportはRootがbindingする。",
    "",
    "同じ16familyを12対照で共有しており384独立標本ではない。B/C/D同士は直接対局していない。対A scoreだけで確定順位・一般棋力・Elo・新標準への昇格をしない。後続保存解析ではUNKNOWNをdraw/敗戦に変えず、nominal selective depthの中央値/全hist/平均、terminal workとselected snapshotを別に記録する。追加削減counterの名前/実値はnative源泉が正本で、未記録はUNKNOWN。",
    "",
    "## 最小consumer差分",
    "",
    "immutable Git2e4846a7のLC arena_plan_checkにはmethod名をfixed_one/depth_rankに限るtupleがある。私有patch/inverseはこの一membership式に3 literalを足すだけ。測定側measurement_config_checkは413.1の担当なので重複編集しない。runtime/arenaは既存Option<String>→native from_nameを使い、別builderを追加しない。",
    "",
    "Ruffはfunction文字列のstdin/stdoutに適用した。厳密patch forward/inverse（fuzz0）をOWNの一時subjectで確認し、元全byteへ復元して一時fileを削除済み。ASTはこの3 literalを戻せば全moduleでbeforeと一致し、他関数はbyte不変。Main/LC sourceそのものを書いていない。Rootの現callerがdriftしていれば一式だけ疎合成する。",
    "",
    "新source/type/native testsはUNBUILT/UNTYPED/UNRUN。Rootに必要なconsumer定義は新3methodのsemantic intakeと、LMR OFFでもunknown名を拒否する境界。既存profile/runtime eligibilityを弱めない。関連413確認はRootが既存max担当へまとめ、このleafはreview dispatchしない。",
    "",
    "## 検証・STOP",
    "",
    "設定census、D8/cap/coldwarm、ABCDDCBA二反復、slot一意、各対照の16family二色、explicit requested methods、clock/TTと未確定nullを静的検証した。parse前/読取後の選択FileRefsを照合。Ruff/scoped Prettierとpatch proof以外のtest/native/model/library/solver/Search/game/fit実行は0。",
    "",
    "source CPU8/controller11、family512MiB（child448＋controller64）、GPU0/hostreserve4GiB。実affinity/topologyとexact child/directwait/reap/handles/TMP/leases/STOP、OWN一回usageはcompletion.json/STOP.jsonへ束縛する。continuous RSS/LLM全費/将来quietはUNKNOWN。Main/Git/Cargo/Beads/backup/closeは324のみ。全mixed/learner prep/pipeline/323 USERPAUSE・defaults/models/weights/seals/旧RAWFAILED費を保持する。",
]
(OWN / "report.md").write_text("\n".join(lines) + "\n")
print(
    json.dumps(
        dict(
            strict_patch_forward_inverse=True,
            AST_only_three_names=True,
            cost_calls=192,
            arena_games=384,
            ready=False,
        )
    )
)
