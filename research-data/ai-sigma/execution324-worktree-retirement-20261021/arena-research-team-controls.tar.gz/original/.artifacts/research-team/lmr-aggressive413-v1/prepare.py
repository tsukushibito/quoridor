"""Two finite413 recipes, metadata only; no launcher, model or outcome reader."""

import ast
import copy
import difflib
import gzip
import hashlib
import json
import os
import subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-adaptive408-v1"
)
COST = ROOT / "cost96-v1"
ARENA = ROOT / "arena128-unentered-v1"
COST_OWNER = Path(
    "/workspaces/quoridor/.worktree/assets/perf/lmr-aggressive413-cost192-v1"
)
ARENA_OWNER = Path(
    "/workspaces/quoridor/.worktree/assets/perf/lmr-aggressive413-arena384-v1"
)
METHODS = dict(
    A="depth_rank",
    B="depth_rank_late_one",
    C="depth_rank_deep_two",
    D="depth_rank_early_one",
)
ORDER = list("ABCDDCBA")
REFS = []


def ref(path):
    body = path.read_bytes()
    st = path.stat()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{st.st_mode & 0o777:04o}",
    )


def read(path, expected=None):
    actual = ref(path)
    if expected:
        for k, v in expected.items():
            assert actual[k] == v, (path, k)
    REFS.append(actual)
    return json.loads(path.read_bytes())


def write(name, value):
    path = OWN / name
    path.parent.mkdir(exist_ok=True, parents=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


old_cost = read(COST / "settings.json")
old_arena = read(
    ARENA / "plan.json",
    {"sha256": "51f0569acfd91db8c7d4d75aa8e2fc01fd7e285c864a525a07d1f4ca42cf0404"},
)
assert old_arena["family_ids"] == [
    14,
    16,
    23,
    27,
    37,
    38,
    39,
    44,
    64,
    74,
    82,
    86,
    103,
    109,
    118,
    124,
]
requests = read(COST / "requests.json")
old_requests = copy.deepcopy(requests)
for request in requests:
    request["id"] = request["id"].replace("D4", "D8").replace("D6", "D8")
    request["session"] = request["session"].replace("D4", "D8").replace("D6", "D8")
    request["depth"] = 8
    assert (
        request["time_limit_ms"] is None
        and request["diagnostic"] is False
        and request["observe_completed_depths"] is False
        and request["warmup"] is False
    )
assert [r["node_cap"] for r in requests] == [
    2000000,
    8000000,
    2000000,
    2000000,
    2000000,
    2000000,
]
request_ref = write("cost/requests.json", requests)

# Existing pure configuration resolvers, not duplicated artifact implementations.
resolver_path = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/lmr-adaptive408-analysis-v1/research-lifecycle.py.immutable.gz"
)
source = gzip.decompress(resolver_path.read_bytes())
assert (
    hashlib.sha256(source).hexdigest()
    == "386d37456360402502569a4fc20a81309a2c5c4255ce7aaf37a8736ccb2167ef"
)
tree = ast.parse(source)
nodes = [
    n
    for n in tree.body
    if isinstance(n, ast.FunctionDef)
    and n.name in {"apply_comparison_cost", "apply_comparison_arena"}
]
assert len(nodes) == 2
namespace = {}
exec(
    compile(
        ast.Module(body=nodes, type_ignores=[]),
        "immutable408/research-lifecycle.py",
        "exec",
    ),
    namespace,
)
common = dict(
    tt_entries=1048576,
    use_tt=True,
    use_pvs=True,
    rules="research-standard-2p-threefold-goal-first-v1",
    ruleset="standard_2p_threefold",
    family_B=4 * 1024**3,
    controller_B=64 * 1024**2,
    host_reserve_B=4 * 1024**3,
    arena=dict(
        depth=64,
        max_nodes=1000000,
        time_ms=100,
        return_reserve_ms=5,
        max_plies=200,
        AI_workers=[2, 6],
        management_guardian=4,
    ),
)
strata = [
    ("nnue", "control"),
    ("nnue", "cheap"),
    ("distance", "control"),
    ("distance", "cheap"),
]
cost_ops, arena_configs, arena_batches, arena_matchups, arena_ops, schedule = (
    [],
    [],
    [],
    [],
    [],
    [],
)
source_roots = []
for stratum, (evaluator, profile) in enumerate(strata):
    template_operation = old_cost["measurements"][stratum * 4]
    experiment = read(
        Path(template_operation["experiment"]["path"]), template_operation["experiment"]
    )
    base = read(Path(experiment["config"]["path"]), experiment["config"])
    source_roots.append(
        dict(
            evaluator=evaluator,
            profile=profile,
            inputs=experiment["inputs"],
            original_root_selectors=base["roots"],
            original_requests=old_requests,
        )
    )
    for pass_index, code in enumerate(ORDER):
        index = len(cost_ops)
        config = copy.deepcopy(base)
        namespace["apply_comparison_cost"](
            config, common, dict(profile=profile, lmr=True)
        )
        config["lmr_method"] = METHODS[code]
        config["zero_stock_approx_min_root_walls"] = None
        config["zero_stock_approx_method"] = "race"
        config["zero_stock_safe_race"] = False
        for root in config["roots"]:
            root["label"] = root["label"].replace("D4", "D8").replace("D6", "D8")
        config_ref = write(f"cost/config-{index:03}.json", config)
        cost_ops.append(
            dict(
                index=index,
                stratum=stratum,
                evaluator=evaluator,
                profile=profile,
                pass_index=pass_index,
                method_code=code,
                requested_lmr_method=METHODS[code],
                config=config_ref,
                schedule=request_ref,
                inputs=experiment["inputs"],
                models=experiment["models"],
                rules=experiment["rules"],
                distance_units=experiment["distance_units"],
                value_perspective=experiment["value_perspective"],
                calls=6,
                sessions=3,
                target_depth=8,
                node_cap_sum=18000000,
                artifact=None,
                Build=None,
                Experiment=None,
                runtime=None,
                support=None,
                current_callers=None,
                effective_native_method_id=None,
                native_reduction_rule=None,
                namespace="base remains config-owned; effective suffix owned by native LmrMethod",
                output=str(COST_OWNER / f"operation-{index:03}/data"),
                ready=False,
            )
        )

    base_arena = read(
        ARENA / f"config-{stratum:03}.json", old_arena["batches"][stratum]["config"]
    )
    assert all(
        e["kind"] == evaluator and e["ordering_profile"] == profile
        for e in base_arena["engines"]
    )
    for candidate in "BCD":
        batch = len(arena_batches)
        config = copy.deepcopy(base_arena)
        namespace["apply_comparison_arena"](
            config, common, [dict(evaluator=evaluator, profile=profile, lmr=True)] * 2
        )
        config["engines"][0]["lmr_method"] = METHODS[candidate]
        config["engines"][1]["lmr_method"] = METHODS["A"]
        config.update(
            run_id=f"413-{evaluator}-{profile}-{candidate}-vs-A",
            output=str(ARENA_OWNER / f"batch-{batch:03}/data"),
            seed=41320261015,
        )
        config["arena"]["bootstrap_seed"] = 41320261015
        config["arena"]["search_artifact_sha256"] = [None, None]
        config["arena"]["book"]["id"] = "413-fixed408-exploratory-sixteen"
        config["arena"]["book"]["independence"] = (
            "Same16 old408 families across12 contrasts; conditional family intervals, not384 independent games; no412 unused-family pooling."
        )
        assert config["games"] == 32 and len(config["arena"]["book"]["openings"]) == 16
        assert (
            config["max_output_bytes"] == 64 * 1024**2
            and config["arena"]["retained_outcome_bytes"] == 630784
        )
        config_ref = write(f"arena/config-{batch:03}.json", config)
        arena_configs.append(config_ref)
        slots = []
        for i, fid in enumerate(old_arena["family_ids"]):
            first = config["arena"]["first_candidate_colors"][i]
            for local_color, color in enumerate([first, 1 - first]):
                slot = len(schedule)
                schedule.append(
                    dict(
                        slot=slot,
                        batch=batch,
                        matchup=batch,
                        local_game=i * 2 + local_color,
                        family_id=fid,
                        candidate_color=color,
                    )
                )
                slots.append(slot)
        arena_batches.append(
            dict(batch=batch, matchup=batch, config=config_ref, slots=slots)
        )
        arena_matchups.append(
            dict(
                id=batch,
                engines=config["engines"],
                evaluator_sha256=config["arena"]["evaluator_sha256"],
                inference=config["inference"],
            )
        )
        raw = 32 * (630784 + 1)
        arena_ops.append(
            dict(
                batch=batch,
                stratum=stratum,
                evaluator=evaluator,
                profile=profile,
                left_candidate=candidate,
                left_method=METHODS[candidate],
                right_reference="A",
                right_method=METHODS["A"],
                config=config_ref,
                families=16,
                games=32,
                pairs=16,
                artifact=None,
                Build=None,
                Experiment=None,
                runtime=None,
                support=None,
                current_callers=None,
                effective_native_method_ids=None,
                normal_native_output_forecast=None,
                native_fixed_forecast_components_B=8 * 1024**2
                + raw
                + raw
                + ((raw + 8191) // 8192) * 5
                + 64,
                output_cap_proposal_B=config["max_output_bytes"],
                ready=False,
                safe_exact_OFF="no arena selector in Engine; existing shared factory defaultOFF must be confirmed in genuine413 software",
                old_approx_OFF="no arena selector; normal shared factory has approximationOFF",
                output=config["output"],
            )
        )

schedule_ref = write("arena/schedule.json", schedule)
arena_plan = {
    key: copy.deepcopy(old_arena[key])
    for key in [
        "schema",
        "phase",
        "comparison",
        "rules",
        "distance_units",
        "value_perspective",
        "book",
        "inputs",
        "models",
        "family_ids",
    ]
}
arena_plan.update(
    schedule=schedule_ref,
    matchups=arena_matchups,
    batches=arena_batches,
    planned_slots=len(schedule),
)
arena_plan_ref = write("arena/plan.json", arena_plan)
cost_recipe = dict(
    issue="quoridor-4lc.413.2",
    kind="sequence",
    status="draft_not_ready",
    owner=str(COST_OWNER),
    output=str(COST_OWNER / "execution-v1"),
    arena=None,
    arena_block=1,
    serial_order=["measure", "arena"],
    measurements=cost_ops,
    methods=METHODS,
    stratum_order=strata,
    method_order=ORDER,
    planned_calls=192,
    planned_sessions=96,
    node_cap_sum=576000000,
    all_target_depth8=True,
    common=common,
    requests=request_ref,
    source_root_binding=source_roots,
    artifact=None,
    Build=None,
    current_callers=None,
    support=None,
    runtime=None,
    ready=False,
)
arena_recipe = dict(
    issue="quoridor-4lc.413.2",
    kind="sequence",
    status="draft_not_ready",
    owner=str(ARENA_OWNER),
    output=str(ARENA_OWNER / "execution-v1"),
    arena_range=[0, 11],
    arena_block=16,
    serial_order=["arena", "measure"],
    measurements=[],
    arena_plan=arena_plan_ref,
    arena_schedule=schedule_ref,
    operations=arena_ops,
    methods=METHODS,
    stratum_order=strata,
    candidate_order=list("BCD"),
    left="candidate B/C/D",
    right="standard A depth_rank",
    family_ids=old_arena["family_ids"],
    planned_games=384,
    planned_pairs=192,
    common=common,
    artifact=None,
    Build=None,
    current_callers=None,
    support=None,
    runtime=None,
    ready=False,
    start_requires="actual original413cost STOP plus normal fresh physical/reader/resource guards; 412priority preserved",
)
write("cost/settings.json", cost_recipe)
write("arena/settings.json", arena_recipe)

# Narrow owning caller gap against a named immutable current-generation source.
git = "2e4846a7"
source_path = "scripts/dev/research-lifecycle.py"
before = subprocess.run(
    ["git", "show", f"{git}:{source_path}"], check=True, capture_output=True
).stdout.decode()
function = next(
    n
    for n in ast.parse(before).body
    if isinstance(n, ast.FunctionDef) and n.name == "arena_plan_check"
)
lines = before.splitlines(keepends=True)
fragment = "".join(lines[function.lineno - 1 : function.end_lineno])
old = 'engine["lmr_method"] in ("fixed_one", "depth_rank")'
new = 'engine["lmr_method"] in ("fixed_one", "depth_rank", "depth_rank_late_one", "depth_rank_deep_two", "depth_rank_early_one")'
assert fragment.count(old) == 1
updated_fragment = fragment.replace(old, new)
formatter_argv = [
    "/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff",
    "format",
    "--stdin-filename",
    "scripts/dev/research-lifecycle.py",
    "-",
]
formatter = subprocess.Popen(
    formatter_argv,
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
)
try:
    stat = Path(f"/proc/{formatter.pid}/stat").read_text().rsplit(")", 1)[1].split()
    formatter_identity = dict(
        pid=formatter.pid,
        start_ticks=stat[19],
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    )
except FileNotFoundError:
    formatter_identity = None
formatted, formatter_error = formatter.communicate(updated_fragment.encode())
assert formatter.returncode == 0, formatter_error.decode()
assert ast.dump(ast.parse(formatted)) == ast.dump(ast.parse(updated_fragment))
updated_fragment = formatted.decode()
write(
    "consumer-format-receipt.json",
    dict(
        argv=formatter_argv,
        child=formatter_identity,
        directwait_exit=formatter.returncode,
        reaped=True,
        handles_closed=True,
        stderr=formatter_error.decode(),
        actual_affinity=sorted(os.sched_getaffinity(0)),
        scope="only function text on stdin/stdout; no LC subject file written",
    ),
)
after = (
    "".join(lines[: function.lineno - 1])
    + updated_fragment
    + "".join(lines[function.end_lineno :])
)
(OWN / "arena-method-consumer.patch").write_text(
    "".join(
        difflib.unified_diff(
            before.splitlines(True),
            after.splitlines(True),
            fromfile="a/" + source_path,
            tofile="b/" + source_path,
        )
    )
)
(OWN / "arena-method-consumer.inverse.patch").write_text(
    "".join(
        difflib.unified_diff(
            after.splitlines(True),
            before.splitlines(True),
            fromfile="a/" + source_path,
            tofile="b/" + source_path,
        )
    )
)
write(
    "consumer-gap.json",
    dict(
        git=git,
        path=source_path,
        function="arena_plan_check(experiment, plan)",
        before_sha256=hashlib.sha256(before.encode()).hexdigest(),
        proposed_after_sha256=hashlib.sha256(after.encode()).hexdigest(),
        scope="one allowed-name membership expression in arena_plan_check only, scoped Ruff-formatted; no LC file written",
        other_function_bytes_unchanged=True,
        method_names=METHODS,
        exact_API="Observed existing Engine.lmr_method Option<String>; native LmrMethod::from_name/name/id/reduction_rule and SearchSession set_lmr_method(method)->(), set_lmr(bool)->Result, lmr_method()->Option. Final413.1 signature correspondence pending frozen source; no new local runtime API/ID builder assumed.",
        measurement_owner="413.1 measurement_config_check must accept same canonicalnames; do not duplicate its function patch",
        namespace_builder_added=False,
        software_cases_UNRUN=[
            "three explicit new arena method names pass semantic intake with bound toy metadata",
            "unknown name rejected even LMR OFF; existing profile/runtime eligibility unchanged",
        ],
        source_and_native_status="UNBUILT/UNTYPED/UNRUN; Rootonlycompose; rebase this single function expression if currentcaller drifted",
    ),
)

assert len(cost_ops) == 32 and len(arena_ops) == 12 and len(schedule) == 384
assert (
    sum(o["calls"] for o in cost_ops) == 192
    and sum(o["sessions"] for o in cost_ops) == 96
    and sum(o["node_cap_sum"] for o in cost_ops) == 576000000
)
assert len({r["session"] for r in requests}) == 3
assert len({r["slot"] for r in schedule}) == 384
for r in REFS:
    assert ref(Path(r["path"])) == r
write("selected-refs.json", REFS)
write(
    "validation.json",
    dict(
        cost_operations=32,
        cost_calls=192,
        cost_sessions=96,
        cost_node_cap=576000000,
        requests_depths=[r["depth"] for r in requests],
        request_node_caps=[r["node_cap"] for r in requests],
        method_order=ORDER,
        arena_operations=12,
        arena_games=384,
        arena_pairs=192,
        all16old408families_each_contrast=True,
        future_image_Build_runtime=None,
        ready=False,
        no_model_payload_RAW_native_Search_tests_games_bootstrap=True,
    ),
)
print(
    json.dumps(
        dict(
            cost_calls=192,
            sessions=96,
            node_cap=576000000,
            arena_games=384,
            pairs=192,
            cost_operations=32,
            arena_operations=12,
            ready=False,
        )
    )
)
