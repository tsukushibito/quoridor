"""One authorized saved-MCTS conversion, using the maintained native/guardian owners."""

import importlib.util
import os
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
OUT = OWN / "conversion-v1"
loader = importlib.util.spec_from_file_location(
    "lc429conversion", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
sys.modules["lc429conversion"] = lc
loader.loader.exec_module(lc)


def checked(ref):
    return lc.read_ref(ref, max(lc.CONTROL_BYTES, ref["bytes"]))


def main():
    binding = lc.artifact_ref(OUT / "entry-binding.json")
    data = lc.document(binding)
    operation = OUT / "operation-v1"
    operation.mkdir()
    tmp = operation / "TMP"
    tmp.mkdir()
    spec = dict(
        kind="source",
        owner=str(ROOT),
        cwd=str(ROOT),
        output=str(operation),
        data_root=data["output"],
        TMP=str(tmp),
        env=dict(
            os.environ,
            TMPDIR=str(tmp),
            CUDA_VISIBLE_DEVICES="",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
            PYTHONDONTWRITEBYTECODE="1",
        ),
        finalizers=[],
        data=[],
        owned_outputs=data["whole_science_roots"],
        support=data["resource"],
        limits=dict(
            worker_cpu=2,
            guardian_cpu=6,
            family_B=4 * 1024**3,
            controller_B=64 * 1024**2,
            host_reserve_B=4 * 1024**3,
            log_B=2 * 1024**2,
            owned_B=128 * 1024**2,
            free_B=None,
        ),
    )
    checks, primary = [], None
    try:
        with lc.lease():
            lc.physical_and_quiet(spec)
            for ref in data["small_refs"] + data["caller_refs"] + [data["artifact"]]:
                checked(ref)
            checked(binding)
            assert not Path(data["output"]).exists()
            spec["intent_sha256"] = lc.canonical_sha(spec)
            admission = operation / "resource-admission.json"
            lc.new_json(
                admission,
                dict(
                    schema="quoridor.research.phase-admission.v1",
                    owner=str(ROOT),
                    limits=spec["limits"],
                    spec_sha256=spec["intent_sha256"],
                    support_sha256=spec["support"]["sha256"],
                    ready=True,
                    scope="One actual saved conversion; no model/forward/Search/game/fit",
                    no_fair_clock_or_hostquiet_claim=True,
                    guardian_management_shared=True,
                ),
            )
            spec["admission"] = lc.artifact_ref(admission)
            lc.new_json(operation / "original-guard-spec.json", spec)
            resources = lc.Limits(spec)
            resources.check()
        lc.command(
            spec,
            dict(name="actual-converter", role="conversion", argv=data["argv"]),
            operation,
            resources,
            executor=lambda *a, **kw: lc.process.execute(*a, **kw, no_new_privs=True),
            ledger=checks,
        )
        for ref in data["small_refs"] + data["caller_refs"] + [data["artifact"]]:
            checked(ref)
        lc.new_json(
            OUT / "returned.json",
            dict(
                status="PROCESS_COMPLETE; CACHE/ROW_CENSUS_COLLECTION_PENDING",
                cache_path=str(Path(data["output"]) / "cache.json"),
                new_Sigma_NNUE_heads=0,
            ),
        )
    except BaseException as error:
        primary = lc.error_fact(error)
        raise
    finally:
        lc.new_json(
            operation / "returned-receipt.json", dict(checks=checks, primary=primary)
        )
        identities = []
        for check in checks:
            returned = check.get("guardian_return")
            if returned and returned.get("child"):
                original = returned["child"]
                current = lc.process.identity(lc.process.process_info(original["pid"]))
                assert current != original
                identities.append(dict(original=original, current=current))
        if not any(tmp.iterdir()):
            tmp.rmdir()
        lc.new_json(
            OUT / "STOP.json",
            dict(
                at=lc.stamp(),
                primary=primary,
                identities=identities,
                TMP_absent=not tmp.exists(),
                owned_readers_children_handles_leases=[],
                native_process_receipt_is_authority=True,
            ),
        )


if __name__ == "__main__":
    main()
