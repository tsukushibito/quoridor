"""Collect original 429 native metadata without replaying games or decoding Arrow."""

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import stat

OWN = Path(__file__).resolve().parent
READS = []


def ref(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def document(path, expected=None):
    before = ref(path)
    if expected is not None:
        assert before == expected
    value = json.loads(Path(path).read_bytes())
    assert ref(path) == before
    READS.append(before)
    return value


def main():
    binding = document(OWN / "generation-entry-binding.json")
    sequence = document(OWN / "generation-sequence-v1/result.json")
    outer = document(OWN / "generation-runtime-v1/result.json")
    state = document(OWN / "generation-runtime-v1/state.json")
    assert sequence["primary"] is None and sequence["returned_operations"] == 160
    assert (
        outer["exit_code"] == 0
        and outer["cleanup_complete"]
        and outer["direct_child_reaped"]
    )
    assert not outer["remaining"]
    cm = document(OWN / "cohort-map.json")
    assert len(cm) == 1280
    counts = Counter()
    work = Counter()
    per_cohort = {"quantity": Counter(), "early": Counter()}
    ids = set()
    families = {"quantity": set(), "early": set()}
    slices, original_ids = [], []
    rows_total = 0
    source_splits = Counter()
    for index, selected in enumerate(binding["configs"]):
        assert index == selected["index"]
        root = Path(selected["output"])
        config = document(root / "config.json")
        requested = document(selected["config"]["path"], selected["config"])
        # Native config adds defaults; the exact requested fields must survive.
        assert all(config[k] == v for k, v in requested.items())
        sr = sequence["operations"][index]["result"]
        native = document(sr["path"], sr)
        receipt = document(
            OWN / f"generation-operations-v1/slice-{index:03}/returned-receipt.json"
        )
        stop = document(OWN / f"generation-operations-v1/slice-{index:03}/STOP.json")
        assert (
            receipt["primary"] is None
            and stop["primary"] is None
            and stop["TMP_absent"]
        )
        assert len(receipt["checks"]) == 1
        check = receipt["checks"][0]
        assert check["status"] == "PASS" and check["capture_complete"]
        returned = check["guardian_return"]
        assert (
            returned["direct_child_reaped"]
            and returned["cleanup_complete"]
            and not returned["remaining"]
        )
        assert returned["handle_closes_complete"]
        original = returned["child"]
        assert not Path("/proc", str(original["pid"])).exists()
        original_ids.append(original)
        assert (
            native["planned"]
            == len(native["outcomes"])
            == selected["actual_nonmissing_games"]
        )
        assert native["all_workers_joined"] and native["stopped"] is None
        bw = native["pump"]["backend_work"]
        assert bw["logical_rows"] <= 60000
        assert native["nn_calls"] == bw["logical_rows"]
        work.update(bw)
        manifest = document(root / "dataset/manifest.json")
        assert sum(s["rows"] for s in manifest["shards"]) == native["rows"]
        assert sum(manifest["eligible_rows"].values()) == native["eligible_rows"]
        # Content hashes/row legality of compressed Arrow are converter authority.
        manifest_ref = ref(root / "dataset/manifest.json")
        slice_rows = 0
        for result in native["outcomes"]:
            i = result["game"]
            assert i in selected["requested_ids"] and i not in ids
            ids.add(i)
            row = cm[i]
            assert row["accepted"] and result["started"] and result["failure"] is None
            assert result["family"] == row["family"]
            assert result["moves"][: row["prefix_length"]] == row["fullprefix"]
            assert result["plies"] == len(result["moves"]) <= 200
            assert result["status"] in ["goal", "draw", "unknown"]
            counts[result["status"]] += 1
            cohort = row["cohort"]
            per_cohort[cohort][result["status"]] += 1
            source_splits[(cohort, row["source_split"])] += 1
            families[cohort].add(row["family"])
            completion = next(
                x for x in native["pump"]["completions"] if x["game"] == i
            )
            per_cohort[cohort]["rows"] += completion["rows"]
            per_cohort[cohort]["logical_rows"] += completion["nn_calls"]
            slice_rows += completion["rows"]
        assert slice_rows == native["rows"]
        rows_total += native["rows"]
        slices.append(
            dict(
                index=index,
                requested_ids=selected["requested_ids"],
                accepted=selected["actual_nonmissing_games"],
                input_missing=selected["missing_ids"],
                native_result=sr,
                native_config=ref(root / "config.json"),
                dataset=str(root / "dataset"),
                manifest=manifest_ref,
                rows=native["rows"],
                eligible_rows=native["eligible_rows"],
                backend_work=bw,
                native_seconds_nested=native["wall_seconds"],
                native_STOP=ref(
                    OWN / f"generation-operations-v1/slice-{index:03}/STOP.json"
                ),
            )
        )
    assert ids == {x["global_ordinal"] for x in cm if x["accepted"]}
    assert len(ids) == 1204 and rows_total == sum(s["rows"] for s in slices)
    assert work["logical_rows"] <= 9600000 < 10000000
    exact_outer = []
    for name in ["child"]:
        original = state[name]
        assert not Path("/proc", str(original["pid"])).exists()
        exact_outer.append(dict(original=original, fresh_identity=None))
    result = dict(
        at=datetime.now(timezone.utc).isoformat(),
        status="ORIGINAL160_NATIVE_RESULTS_COLLECTED; CONVERSION_AND_ROW_VALIDATION_PENDING",
        requested=1280,
        accepted_inputs=1204,
        missing_inputs=76,
        entered=len(ids),
        returned=len(ids),
        outcomes=dict(counts),
        rows=rows_total,
        eligible_rows=sum(x["eligible_rows"] for x in slices),
        unique_canonical_input_families=1176,
        cohorts={k: dict(v) for k, v in per_cohort.items()},
        source_split_games={":".join(k): v for k, v in source_splits.items()},
        distinct_canonical_families={k: len(v) for k, v in families.items()},
        Sigma=dict(work),
        inclusive_all_Sigma_limit=10000000,
        unspent_inclusive_rows_not_new_authority=10000000 - work["logical_rows"],
        unspent_generation_quota_nontransferable=9600000 - work["logical_rows"],
        necessary_non_generation_overhead_cap_original=400000,
        requested_operation_quota_lending=False,
        actual_conversion_model_forward=0,
        outer_seconds_once=outer["wall_seconds"],
        native_times="Nested, not added to outer",
        original_sequence_STOP=document(OWN / "generation-sequence-v1/STOP.json"),
        exact_native_identities_fresh_absent=original_ids,
        exact_outer=exact_outer,
        supervisor="Notification-only identity/lifetime is separate; not a numerical child",
        old423_replay=0,
        refill=0,
        actual_row_STM_z_history_quality="Normal converter validation pending; metadata alone is not row qualification",
        distinct_model_inputs=None,
        stock18_to20=None,
        selected_TV_rows=None,
        cache=None,
        slices=slices,
        selectedrefs=READS,
        owned_native_children_handles_TMP_leases=[],
    )
    (OWN / "generation-collection.json").write_text(
        json.dumps(result, separators=(",", ":")) + "\n"
    )
    print(
        json.dumps(
            {
                k: v
                for k, v in result.items()
                if k
                not in [
                    "slices",
                    "selectedrefs",
                    "exact_native_identities_fresh_absent",
                ]
            }
        )
    )


if __name__ == "__main__":
    main()
