"""Run the fixed 160 serial common-MCTS operations through existing guardians."""

import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
BINDING = OWN / "generation-entry-binding.json"
loader = importlib.util.spec_from_file_location(
    "lc429", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
sys.modules["lc429"] = lc
loader.loader.exec_module(lc)


def checked(ref):
    return lc.read_ref(ref, max(lc.CONTROL_BYTES, ref["bytes"]))


def main():
    binding_ref = lc.artifact_ref(BINDING)
    data = lc.document(binding_ref)
    checks = []
    primary = None
    summary = []
    directory = OWN / "generation-sequence-v1"
    directory.mkdir()
    # Shared immutable payloads are checked once at entry and once after the
    # sequence. Each native process still performs its maintained model checks.
    try:
        with lc.lease():
            for ref in (
                data["shared_small_refs"]
                + data["caller_refs"]
                + data["large_immutable_refs"]
            ):
                checked(ref)
            for row in data["configs"]:
                checked(row["config"])
            assert len(data["configs"]) == 160
            assert sum(r["logical_Sigma_rows_cap"] for r in data["configs"]) == 9600000
        for index, selected in enumerate(data["configs"]):
            assert selected["index"] == index
            operation = OWN / "generation-operations-v1" / f"slice-{index:03}"
            operation.mkdir(parents=True)
            tmp = operation / "TMP"
            tmp.mkdir()
            spec = dict(
                kind="source",
                owner=str(ROOT),
                cwd=str(ROOT),
                output=str(operation),
                data_root=selected["output"],
                TMP=str(tmp),
                env=dict(
                    os.environ,
                    TMPDIR=str(tmp),
                    CUDA_VISIBLE_DEVICES="",
                    OMP_NUM_THREADS="1",
                    OPENBLAS_NUM_THREADS="1",
                    MKL_NUM_THREADS="1",
                    RAYON_NUM_THREADS="1",
                    ORT_DISABLE_TELEMETRY="1",
                    PYTHONDONTWRITEBYTECODE="1",
                ),
                finalizers=[],
                data=[],
                owned_outputs=data["whole_science_roots"],
                support=data["resource"],
                limits=dict(
                    worker_cpu=2,
                    guardian_cpu=6,
                    family_B=4 * 1024**3,
                    controller_B=64 * 1024**2,
                    host_reserve_B=4 * 1024**3,
                    log_B=2 * 1024**2,
                    owned_B=128 * 1024**2,
                    free_B=None,
                ),
            )
            ledger, error = [], None
            try:
                # This is short live-caller/resource admission, not a Main
                # lifetime lease while an immutable native image computes.
                with lc.lease():
                    os.sched_setaffinity(0, {2, 6})
                    affinity_before = sorted(os.sched_getaffinity(0))
                    lc.physical_and_quiet(spec)
                    for ref in data["caller_refs"]:
                        checked(ref)
                    checked(binding_ref)
                    checked(selected["config"])
                    assert not Path(selected["output"]).exists()
                    spec["intent_sha256"] = lc.canonical_sha(spec)
                    admission = operation / "resource-admission.json"
                    lc.new_json(
                        admission,
                        dict(
                            schema="quoridor.research.phase-admission.v1",
                            owner=str(ROOT),
                            limits=spec["limits"],
                            spec_sha256=spec["intent_sha256"],
                            support_sha256=spec["support"]["sha256"],
                            ready=True,
                            scope="Existing untimed native admission; no scientific success grant",
                            affinity_before=affinity_before,
                            guardian_management_shared=True,
                            no_fair_clock_or_host_quiet_claim=True,
                            topology={
                                str(c): {
                                    k: Path(
                                        f"/sys/devices/system/cpu/cpu{c}/topology/{k}"
                                    )
                                    .read_text()
                                    .strip()
                                    for k in ["physical_package_id", "core_id"]
                                }
                                for c in [2, 6]
                            },
                        ),
                    )
                    spec["admission"] = lc.artifact_ref(admission)
                    lc.new_json(operation / "original-guard-spec.json", spec)
                    resources = lc.Limits(spec)
                    resources.check()
                lc.command(
                    spec,
                    dict(
                        name="actual-selfplay",
                        role="generation",
                        argv=[
                            data["image"]["path"],
                            "selfplay",
                            "--config",
                            selected["config"]["path"],
                        ],
                    ),
                    operation,
                    resources,
                    executor=lambda *a, **kw: lc.process.execute(
                        *a, **kw, no_new_privs=True
                    ),
                    ledger=ledger,
                )
                checked(selected["config"])
                result_path = Path(selected["output"]) / "result.json"
                result_ref = lc.artifact_ref(result_path)
                result = json.loads(checked(result_ref))
                assert result["planned"] == selected["actual_nonmissing_games"]
                assert result["all_workers_joined"] is True
                summary.append(
                    dict(
                        index=index,
                        requested_ids=selected["requested_ids"],
                        missing_input_ids=selected["missing_ids"],
                        result=result_ref,
                        actual_counts_authority="Original result/Arrow and later converter census",
                    )
                )
            except BaseException as caught:
                error = lc.error_fact(caught)
                raise
            finally:
                lc.new_json(
                    operation / "returned-receipt.json",
                    dict(checks=ledger, primary=error),
                )
                identities = []
                for check in ledger:
                    returned = check.get("guardian_return")
                    if returned and returned.get("child"):
                        current = lc.process.identity(
                            lc.process.process_info(returned["child"]["pid"])
                        )
                        assert current != returned["child"]
                        identities.append(
                            dict(original=returned["child"], current=current)
                        )
                # The owned command has been waited/reaped. No retry or repair
                # removes scientific output, partial dataset, or failed receipt.
                if tmp.exists() and not any(tmp.iterdir()):
                    tmp.rmdir()
                lc.new_json(
                    operation / "STOP.json",
                    dict(
                        at=lc.stamp(),
                        primary=error,
                        identities=identities,
                        TMP_absent=not tmp.exists(),
                        original_request_ids=selected["requested_ids"],
                        owned_readers_children_jobs_handles_leases=[],
                        recorded_checks=len(ledger),
                        unrecorded_or_failed_cleanup="Original process receipt authority; UNKNOWN if absent",
                    ),
                )
                checks.append(
                    dict(
                        index=index,
                        primary=error,
                        receipt=lc.artifact_ref(operation / "returned-receipt.json"),
                    )
                )
        with lc.lease():
            for ref in (
                data["shared_small_refs"]
                + data["caller_refs"]
                + data["large_immutable_refs"]
            ):
                checked(ref)
    except BaseException as error:
        primary = lc.error_fact(error)
        raise
    finally:
        lc.new_json(
            directory / "result.json",
            dict(
                at=lc.stamp(),
                primary=primary,
                requested_operations=160,
                returned_operations=len(summary),
                operations=summary,
                original_checks=checks,
                Sigma_actual="Original native counters; not inferred from exit0 or ceilings",
                failed_unentered="All later operations stay unentered on actual exception; no replay/refill",
                owned_readers_children_handles_leases=[],
            ),
        )
        lc.new_json(
            directory / "STOP.json",
            dict(
                at=lc.stamp(),
                primary=primary,
                remaining_owned_commands=[],
                Main_lifetime_lease=False,
            ),
        )


if __name__ == "__main__":
    main()
