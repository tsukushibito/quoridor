"""Freeze the completed B evidence and its one directed postwork storage point."""

import importlib.util
import json
from pathlib import Path
import sys

OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
loader = importlib.util.spec_from_file_location(
    "lc429final", ROOT / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
sys.modules["lc429final"] = lc
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, max(lc.CONTROL_BYTES, Path(path).stat().st_size))[0]


def main():
    closed = json.loads((OWN / "showclosed-v1/full.log").read_bytes())[0]
    assert closed["status"] == "closed"
    assert closed["assignee"] == "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0"
    helpers = []
    for directory in OWN.iterdir():
        disk = directory / "command.process.json"
        if not directory.is_dir() or directory.name == sys.argv[1] or not disk.exists():
            continue
        returned = directory / "return.json"
        record = json.loads(returned.read_bytes()) if returned.exists() else None
        authority = "returned"
        if not isinstance(record, dict):
            record = json.loads(disk.read_bytes())
            authority = "original persisted disk; NULL/absent returned record retained"
        if not isinstance(record, dict) or not record.get("child"):
            helpers.append(
                dict(stage=directory.name, authority=authority, identity="UNKNOWN")
            )
            continue
        original = record["child"]
        current = lc.process.identity(lc.process.process_info(original["pid"]))
        assert current != original
        helpers.append(
            dict(
                stage=directory.name,
                authority=authority,
                original=original,
                current=current,
                directwait_reaped=record.get("direct_child_reaped", "UNKNOWN"),
                cleanup_complete=record.get("cleanup_complete", "UNKNOWN"),
                handles_closed=record.get("handle_closes_complete", "UNKNOWN"),
                TMP_absent=not (directory / "TMP").exists(),
            )
        )
    state = json.loads((OWN / "generation-runtime-v1/state.json").read_bytes())
    supervisor = state["supervisor"]
    current_supervisor = lc.process.identity(lc.process.process_info(supervisor["pid"]))
    stop = dict(
        at=lc.stamp(),
        scope="Original numerical work and completed source/admin helpers; final receipt writer separate",
        helpers=helpers,
        notification_only_supervisor=dict(
            original=supervisor, current=current_supervisor
        ),
        generation_STOP=ref(OWN / "generation-sequence-v1/STOP.json"),
        conversion_STOP=ref(OWN / "conversion-v1/STOP.json"),
        reader_STOP=ref(OWN / "result-STOP.json"),
        original160_native_and_outer_reaped=True,
        owned_numerical_jobs_source_readers_children_handles_TMP_leases=[],
        current_final_receipt_writer="Active until enclosing guardian directwait; no future absence claim",
        closed_issue="quoridor-4lc.429.2",
        assignee=closed["assignee"],
        closed_at=closed["closed_at"],
        unrecorded_controller_RSS_and_continuous_peaks="UNKNOWN",
    )
    (OWN / "STOP.json").write_text(json.dumps(stop, separators=(",", ":")) + "\n")
    usage_path = OWN / "usage.json"
    if usage_path.exists():
        usage = json.loads(usage_path.read_bytes())
    else:
        roots = [
            str(OWN),
            str(ROOT / ".worktree/assets/data/nnue-data-expansion429-v1"),
            str(ROOT / ".worktree/assets/perf/nnue-data-expansion429-v1"),
        ]
        seen = set()
        amounts = {p: lc.allocated(p, seen=seen) for p in roots}
        assert sum(amounts.values()) < 134217728
        usage = dict(
            at=lc.stamp(),
            scope="ONE final directed affected point; NEW429 OWN/data/perf only",
            allocated_by_new_root_B=amounts,
            OWN_actual_affected_B=amounts[str(OWN)],
            whole_new429_point_B=sum(amounts.values()),
            whole_cap_B=134217728,
            private_conservatively_inside_whole_guard=True,
            Root_support_application=ref(
                ROOT
                / ".artifacts/research-team/integration324/nnue-data-expansion429-v1/support-application.json"
            ),
            support_reapplied=0,
            old_Main_target_holding_recharge=0,
            refund=0,
            model_public_corpus_copies=0,
            global_actual="UNKNOWN",
            subsequent_small_receipt_delivery_tail="UNKNOWN; exact final packet bytes separately bound",
            ordinary_positive_accounting="Root composes new directed positive once; never reapply whole support",
        )
        usage_path.write_text(json.dumps(usage, indent=2) + "\n")
    names = [
        "report-ja.md",
        "result.json",
        "generation-collection.json",
        "cache-census.json",
        "family-split-census.json",
        "input-collection.json",
        "cohort-map.json",
        "cache-game-correspondence.json",
        "generation-entry-binding.json",
        "source-STOP.json",
        "generation-collection-field-erratum.json",
        "conversion-v1/entry-binding.json",
        "conversion-v1/STOP.json",
        "result-STOP.json",
        "STOP.json",
        "usage.json",
        "run-generation.py",
        "run-conversion.py",
        "collect-generation.py",
        "census-cache.py",
        "final-cache-C-handoff.txt",
        "final-C-cache-delivery-v1/full.log",
        "showclosed-v1/full.log",
        "backup-before-close-v1/return.json",
        "backup-after-close-v1/return.json",
    ]
    completion = dict(
        at=lc.stamp(),
        status="COMPLETE_CLOSED_ORIGINAL_OWNER",
        issue="quoridor-4lc.429.2",
        assignee=closed["assignee"],
        model="gpt-6.1-sol",
        effort="high",
        cwd=str(ROOT),
        sandbox="danger-full-access",
        approvalPolicy="never",
        selectedrefs=[ref(OWN / n) for n in names],
        cache=json.loads((OWN / "cache-census.json").read_bytes())["cache"],
        counts=dict(
            requested=1280,
            entered=1204,
            GOAL=1190,
            threefold=14,
            UNKNOWN=0,
            missing=76,
            rows=62186,
            Sigma_logical_physical_executed=3513011,
        ),
        C_final_nested_matched_views="PENDING C and outside B; no fit/eval permission",
        old423_model_input_overlap="UNKNOWN",
        production_source_patch=None,
        old_raw_failures_fees_pauses_defaults_models_seals_unchanged=True,
        owner_close_at=closed["closed_at"],
        original_metadata_errors="Preserved, including finalizer NULL-return reader failure; no native replay",
        final_writer="Enclosing guardian receipt outside self-reference records actual completion",
    )
    path = OWN / "completion.json"
    path.write_text(json.dumps(completion, indent=2) + "\n")
    (OWN / "final-Root-handoff.txt").write_text(
        "SAME429.2 original B COMPLETE/CLOSED by original owner. No new science/ACK.\n"
        f"Completion {ref(path)}\nReport {ref(OWN / 'report-ja.md')}\nResult {ref(OWN / 'result.json')}\n"
        "Original160ops job62e05483 once:1280requested/1204entered-returned/76inputmissing/"
        "1190GOAL14true-threefold UNKNOWN0;62186eligible rows49911T12275V. Sigma3513011logical="
        "physical=executed,warm/failed0;unused generation6086989 NONTRANSFERABLE, original necessary"
        "overhead400k/newactual0. No refill/oldreplay/fit/eval/arena.\n"
        "ONE converterc445b7e5/Build94af4aa4 PASS43.255940147s STOP05:10:17.038803; "
        "normalTerminalCorpus/censusPASS readerSTOP05:12:30.503212. Actualcache89d3012d/"
        "2089716B (>1MiB use boundFileRef/normal reader). Q50537rows40614T9923V;"
        "E11649rows9297T2352V. Highstock18..20 Q6T0V/E907T223V. Families1176=940T236V;"
        "Q1016/E186 share26(20T6V), not independent.62043exactmodelkeys/143excess,conflictingz/"
        "crossTV/crosscohortkeys0;old423inputoverlapUNKNOWN. BaselineTstockview18822 is NOT Cfinal"
        "nested/matchedview. Cache/cohort/game-row/source-split refs delivered once toC accepted.\n"
        "All originalnative/outer/helper directwait-reap/exactfreshdifferent-orabsent/handles/TMP"
        "and notification-only lifetime facts inSTOP. No Main lifetime lease/hostquiet/continuouspeak"
        "claim. New production source delta0/MainGitCargo0. Original FAILED/NULL-vs-disk/captures/"
        "fees preserved incl ordinary collector/finalizer fixes; no native replay.\n"
        f"STOP {ref(OWN / 'STOP.json')} at{stop['at']}. Leaf429.2 closed{closed['closed_at']},"
        "sameassignee verified; backupbefore/after0. Parent429/324 unchanged.\n"
        f"One affectedOWN {usage['OWN_actual_affected_B']}B; whole NEW429 point"
        f"{usage['whole_new429_point_B']}B<134217728. Usage {ref(usage_path)}."
        "Rootsupport appliedONCE; do not reapply/oldholdingrecharge/refund. Private conservatively"
        "insidewholeguard; Rootcompose ordinary positiveonce. Globalactual/postpointsmalltailsUNKNOWN."
        " No new review/Policycopy/ACKgate. All oldpause/default/models/seals held.\n"
    )
    print(
        json.dumps(
            dict(completion=ref(path), usage=usage, STOP=ref(OWN / "STOP.json")),
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
