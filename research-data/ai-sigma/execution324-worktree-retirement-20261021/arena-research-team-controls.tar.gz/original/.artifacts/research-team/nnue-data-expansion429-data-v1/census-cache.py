"""Census the actual new compact cache with maintained readers and sampling."""

from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import sys
import json
from pathlib import Path
import stat

import numpy as np


OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
CACHE = ROOT / ".worktree/assets/data/nnue-data-expansion429-v1/cache-v1"


def ref(p):
    p = Path(p).resolve()
    data = p.read_bytes()
    return dict(
        path=str(p),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(p.stat().st_mode):04o}",
    )


def main():
    owner_paths = [
        "terminal_cache.py",
        "public_features.py",
        "compact_cache.py",
        "sampling.py",
        "common.py",
        "distance_steps.py",
        "cache.py",
    ]
    loader = importlib.util.spec_from_file_location(
        "lc429census", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lc = importlib.util.module_from_spec(loader)
    sys.modules["lc429census"] = lc
    loader.loader.exec_module(lc)
    with lc.lease():
        owner_refs = [ref(ROOT / "python/quoridor_training" / f) for f in owner_paths]
        from quoridor_training.public_features import model_keys
        from quoridor_training.sampling import family_training_view
        from quoridor_training.terminal_cache import TerminalCorpus

        assert [ref(r["path"]) for r in owner_refs] == owner_refs
    before = ref(CACHE / "cache.json")
    manifest = json.loads((CACHE / "cache.json").read_bytes())
    file_refs = [ref(CACHE / name) for name in manifest["sha256"]]
    for r in file_refs:
        assert r["sha256"] == manifest["sha256"][Path(r["path"]).name]
    corpus = TerminalCorpus(CACHE)
    assert corpus.row_count == 62186 and corpus.common
    assert int(corpus.eligible.sum()) == corpus.row_count
    cm = json.loads((OWN / "cohort-map.json").read_bytes())
    gen = json.loads((OWN / "generation-collection.json").read_bytes())
    stock = corpus.maps[0]["geometry"]["stocks"].sum(axis=1).astype(np.uint8)
    keys = model_keys(corpus.maps[0])
    strata = [
        {"min": 16, "max": 20, "rows": 8},
        {"min": 8, "max": 15, "rows": 8},
        {"min": 1, "max": 7, "rows": 8},
        {"min": 0, "max": 0, "rows": 8},
    ]
    base_train = family_training_view(
        corpus.groups,
        corpus.splits,
        corpus.eligible,
        None,
        games=corpus.row_game_codes,
        stock=stock,
        strata=strata,
    )
    chosen = np.zeros(corpus.row_count, dtype=bool)
    chosen[base_train] = True
    cohort_code = np.empty(corpus.row_count, dtype=np.uint8)
    game_rows, joined = [], set()
    for block in manifest["sampling"]["games"]:
        game = block["game"]
        i = int(game.removeprefix("game-"))
        assert game == f"game-{i}" and i not in joined
        joined.add(i)
        row = cm[i]
        start, end = block["start"], block["start"] + block["rows"]
        assert (
            row["accepted"] and corpus.families[block["family_code"]] == row["family"]
        )
        expected_split = 0 if row["source_split"] == "train" else 1
        assert np.all(corpus.splits[start:end] == expected_split)
        cohort_code[start:end] = row["cohort"] == "early"
        row_ids = corpus.row_ids[start:end]
        assert all(x.startswith(game + "-ply-") for x in row_ids)
        plies = [int(x.split("-ply-")[1]) for x in row_ids]
        assert plies == list(
            range(row["prefix_length"], row["prefix_length"] + len(plies))
        )
        game_rows.append(
            dict(
                source_index=0,
                source_schedule_sha256=row["source_schedule_sha256"],
                global_ordinal=i,
                request_id=row["request_id"],
                row_game_id=game,
                cohort=row["cohort"],
                source_split=row["source_split"],
                final_view_split=row["final_view_split"],
                canonical_family=row["family"],
                cache_rows=dict(start=start, count=end - start),
                baseline_T_stock_strata_selected=int(chosen[start:end].sum()),
                stock18_to20_rows=int(np.count_nonzero(stock[start:end] >= 18)),
            )
        )
    assert joined == {x["global_ordinal"] for x in cm if x["accepted"]}
    result = {}
    for code, cohort in enumerate(["quantity", "early"]):
        mask = cohort_code == code
        rows = np.flatnonzero(mask)
        cohort_keys = [bytes(keys[i]) for i in rows]
        banks = defaultdict(set)
        for i in rows:
            banks[bytes(keys[i])].add(float(corpus.labels[i, 1]))
        split_rows = {}
        for split_code, split in enumerate(["train", "validation"]):
            sub = mask & (corpus.splits == split_code) & corpus.eligible
            ix = np.flatnonzero(sub)
            split_rows[split] = dict(
                eligible_rows=int(sub.sum()),
                distinct_model_inputs=len({bytes(keys[i]) for i in ix}),
                stock18_to20_rows=int(np.count_nonzero(sub & (stock >= 18))),
                stock18_to20_distinct=len(
                    {bytes(keys[i]) for i in np.flatnonzero(sub & (stock >= 18))}
                ),
                total_stock_histogram={
                    str(k): v
                    for k, v in sorted(Counter(int(x) for x in stock[sub]).items())
                },
                baseline_T_stock_strata_selected=int(np.count_nonzero(sub & chosen))
                if split_code == 0
                else None,
                V_retained_all_eligible=int(sub.sum()) if split_code == 1 else None,
            )
        result[cohort] = dict(
            requested=1024 if code == 0 else 256,
            entered_games=sum(x["cohort"] == cohort for x in game_rows),
            missing_inputs=sum(x["cohort"] == cohort and not x["accepted"] for x in cm),
            eligible_rows=len(rows),
            distinct_model_inputs=len(set(cohort_keys)),
            same_input_excess_rows=len(rows) - len(set(cohort_keys)),
            same_input_conflicting_z_keys=sum(len(v) > 1 for v in banks.values()),
            split_rows=split_rows,
            distinct_canonical_families=len(
                {
                    cm[x["global_ordinal"]]["family"]
                    for x in game_rows
                    if x["cohort"] == cohort
                }
            ),
        )
    all_banks = defaultdict(lambda: dict(z=set(), splits=set(), cohorts=set(), rows=0))
    for i, key in enumerate(keys):
        b = all_banks[bytes(key)]
        b["z"].add(float(corpus.labels[i, 1]))
        b["splits"].add(int(corpus.splits[i]))
        b["cohorts"].add(int(cohort_code[i]))
        b["rows"] += 1
    same_input = dict(
        exact_model_key_definition="maintained public_features.model_keys; injective geometry+FP32 distance28B, no history projection is a qualification",
        distinct_keys=len(all_banks),
        excess_rows=corpus.row_count - len(all_banks),
        conflicting_z_keys=sum(len(v["z"]) > 1 for v in all_banks.values()),
        crossing_TV_keys=sum(len(v["splits"]) > 1 for v in all_banks.values()),
        crossing_cohorts_keys=sum(len(v["cohorts"]) > 1 for v in all_banks.values()),
        old423_model_input_overlap="UNKNOWN; B did not reopen old423 compact/RAW; C owns any cross-corpus view correspondence",
        no_label_based_selection_or_repair=True,
    )
    assert {k: result[k]["eligible_rows"] for k in result} == {
        k: gen["cohorts"][k]["rows"] for k in result
    }
    assert ref(CACHE / "cache.json") == before
    assert [ref(r["path"]) for r in file_refs] == file_refs
    assert [ref(r["path"]) for r in owner_refs] == owner_refs
    (OWN / "cache-game-correspondence.json").write_text(
        json.dumps(game_rows, separators=(",", ":")) + "\n"
    )
    out = dict(
        at=datetime.now(timezone.utc).isoformat(),
        status="NORMAL_MCTS_COMPACT_READER_AND_CENSUS_PASS",
        cache=before,
        cache_file_refs=file_refs,
        maintained_consumer_refs=owner_refs,
        expected_rows=62186,
        actual_rows=corpus.row_count,
        common_eligible_rows=int(corpus.eligible.sum()),
        eligible_split_rows={
            "train": int(np.count_nonzero(corpus.eligible & (corpus.splits == 0))),
            "validation": int(np.count_nonzero(corpus.eligible & (corpus.splits == 1))),
        },
        game_count=len(game_rows),
        cohorts=result,
        same_input=same_input,
        canonical_family_count=len(corpus.families),
        baseline_existing_T_selection=dict(
            name="existing421/423 chronological game*stock<=8, NOT C final nested/matched view",
            strata=strata,
            selected_rows=len(base_train),
            new_C_training_view_materialized=False,
        ),
        game_correspondence=ref(OWN / "cache-game-correspondence.json"),
        old423_unchanged_finalfit204T52V_ID18=True,
        allV_kept_without_selection=True,
        z_only_targets=True,
        raw_q_not_teacher=True,
        extra_Sigma_NNUE_forward_Search_games_fits=0,
        history_legality_authority="original native commonMCTS and canonical converter, not model-key equality",
        final_C_nested_matched_selected_TV=None,
    )
    (OWN / "cache-census.json").write_text(
        json.dumps(out, separators=(",", ":")) + "\n"
    )
    print(
        json.dumps(
            {
                k: v
                for k, v in out.items()
                if k
                not in [
                    "cache_file_refs",
                    "maintained_consumer_refs",
                    "game_correspondence",
                ]
            }
        )
    )


if __name__ == "__main__":
    main()
