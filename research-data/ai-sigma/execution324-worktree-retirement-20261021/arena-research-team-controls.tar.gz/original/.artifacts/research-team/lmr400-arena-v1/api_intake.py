"""Necessary readonly factory/score-domain interface excerpts, no AI edits."""

import hashlib
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
OWN = Path(__file__).resolve().parent
p = Path("/workspaces/quoridor/crates/quoridor-ai/src/alphabeta.rs")
d = p.read_bytes()
assert len(d) < 256 * 1024
s = d.decode()
markers = [
    ("pub trait StaticEvaluator", "pub trait MoveOrderer"),
    ("pub enum ScoreDomain", "pub struct SearchLimits"),
    ("    pub fn new_for_ordering_assessment", "    pub fn "),
    ("    pub fn reset(", "    pub fn "),
]
excerpts = []
for start, end in markers:
    at = s.find(start)
    if at < 0:
        excerpts.append({"start": start, "absent": True})
        continue
    finish = s.find(end, at + len(start))
    if finish < 0:
        finish = min(at + 6000, len(s))
    excerpts.append(
        {"start": start, "line": s[:at].count("\n") + 1, "text": s[at:finish]}
    )
binding = {
    "path": str(p),
    "sha256": hashlib.sha256(d).hexdigest(),
    "bytes": len(d),
    "mode": format(p.stat().st_mode & 0o777, "04o"),
}
assert p.read_bytes() == d
(OWN / "api-current.json").write_text(
    json.dumps(
        {
            "readonly_before_after": binding,
            "excerpts": excerpts,
            "write_to_AI": False,
            "native": False,
        },
        indent=2,
    )
    + "\n"
)
print(json.dumps({"status": "INTERFACE_BOUND", "ref": binding}))
