# LMRのControl/Cheap対局接続と固定128局の準備

既存arenaへ設定からControl/CheapとLMR ON/OFFを接続する私有差分を凍結した。Main、Git、共有target、画像、モデルには書いていない。源泉の整形、Pythonの限定静的検査、正逆パッチの完全復元はPASS。新しいRust 6定義とPython 2定義はUNBUILT/UNTYPED/UNRUNであり、対局、探索、モデル評価は実行していない。

## 接続した境界

Engineに任意の`ordering_profile`（`control` / `cheap`）と既定falseの`lmr`を追加した。指定のない製品・生成経路は従来のfactoryと既定OFFを保持する。明示指定はarenaのsigned alpha二対象だけに限定し、既存の全体static無効設定との矛盾、未知profile、profile無しのLMR、非arenaでの指定を拒否する。evaluatorだけを比較する従来の対照ではprofile/LMRも一致させる。

直接alpha経路と長寿命AI workerは、探索担当の既存`new_for_ordering_assessment`と`set_lmr`を共通使用する。ControlはCheapStaticControl、CheapはCombinedSignedCheapStatic。arenaの実際の従来ScoreDomain::LEGACYを保持し、評価値・係数・単位を変えない。固定DのCheap親map修復とLMR探索本体は相手の正本を使用し、ここに複製しない。

factoryへ渡す元namespaceと、呼出境界で照合するmethod付きnamespaceを分けた。後者には正本factoryと同じprofile/LMR suffixを付ける。これにより毎手の照合で元namespaceにresetしてTT/historyを消す誤接続を防ぐ。実session.namespace()とlmr_enabled()をTT集計と実観測へ保存する。名前の文字列からLMRを有効にせず、設定からsetterを呼ぶ。LMR三work数は完成snapshotとterminalを分け、未完成結果にも実作業を残す。

Pythonの差分は現役research-lifecycle.pyのarena_plan_checkとarena_observationだけで、他関数のASTは完全一致した。明示profileの結果では実evaluator/rules/method/LMR状態を設定に照合する。元の時計判断、evaluation_turn、合法適用commit_actionの本体はbyte一致。100ms実receipt、5ms reserve、完成結果選択、合法fallback、最初のerror、cancel、terminal drainと次turn前のjoinは変更していない。

## 結果前に固定した対局案

既存355 bookの実SHA/size/modeを照合し、保存済みprefix、root_key、fullhistory countsを選択した。4/8/12/16 ply各32候補から、seed40020261014とfamily ID・長さのSHA256順で各2familyを選び、選んだ組を元family順へ戻した。選択は23、29、34、46、64、93、105、108。結果参照・新開幕生成・prefix再生・geometry処理は0。

このbookは現役Mainの宣言済み使用源泉であり、古いcompiled_sources/OPAQUE_UNVERIFIED等の限界を解除・再資格化していない。sealed集合、混合学習の評価book、モデルpayloadは読んでいない。実launchに必要なprefix/fullhistoryの通常検証はRootが既存arena入口で行う。

NNUE/BEST43と固定D(0,8tanh)それぞれで、ControlOFF対ControlON、CheapOFF対CheapON、ControlOFF対CheapOFF、ControlON対CheapONを順に行う案。各対照で同じ8familyを2色ずつ使い、計128局・64色pair。左条件をcandidate engine0とし、familyごとの先行candidate色は0/1交互、同pairの次局は反対色。8共有familyを128独立標本へ水増ししない。

両者depth64、node safety cap1,000,000、100ms、reserve5ms、全ply200、scalar評価。NNUE TT4096、D TT1048576を別stratumとして固定。LMRのcompleted depthは選択的nominalであり全幅証明ではない。1game/2AI worker/main管理の意味を保持し、AI CPU2・6、main/guardian4を提案。将来の実physical配置・quiet・RAM成立はUNKNOWNでRootが入場時に確認する。

resolved-draft.jsonに8個の現役Config形式案と128slot順を保存した。future outputは未作成、LMR共通image/Build/actual configs・Experiment・sequence refsはnullで、readyな入力ではない。既存accepted399 image/Buildとモデルdescriptor/weightsは歴史の真正参照であり、LMR画像とは扱わない。Rootが二作者の差分を合成し、必要compile/test/Clippy/release、関連factory/TT境界確認、真正共通imageと実設定・資源を束ねて既存sequenceへ接続する。新schedulerや手書きpair admissionは追加していない。

出力16MiB、retained outcome630784の既存保証・refusalを保持する。追加metadataの実capture/RAM/時間費とfitは未測定。failure/cancel/pause/resource refusalでstageを停止し、skip/refill/replayしない。勝分負、family単位score、不確実性、時間・深さ・work・fallback/errorは探索的記録であり、速度だけで棋力/default/非劣性を認定しない。

## 未実行の限定検証

Rustはarena設定の型と排他、四対照の色・時計・cap、未開始を含むreport拒否の3定義、および実factory四namespace・LMR状態、namespace文字からの偽ON拒否、未完成結果のwork保存の3定義。Pythonは実method/getter対応とzero-completed合法fallback/失敗の非昇格の2定義。正確な名前とexpected countはverification-plan.json。旧arena/book/資格/時計/成功suiteを再演しない。

## 実停止と残る限界

CPU5の元EAGAINは子・源泉・TMP入場前の拒否として保存しholderはUNKNOWN。CPU8への実配分変更後に必要intakeを進めた。最初の存在しないcommon.py推測の失敗、誤って見つけたtraining共通consumerの読取も原記録を保持し、実ownerがLC arena関数であると訂正した。不要な自分の圧縮派生だけを撤去し、元ファイルは不変更。

最終guardのreaderSTOPは2026-10-14T15:03:21.632587+00:00、内側environment/canonical解放の観測は15:03:21.634503+00:00。actual returned guardianのdirectreap、handles、mask restoration、capture、cleanupは完了。persisted process receiptは別参照で保持する。source-TEMP/patch復元TMP/guardTMPは撤去し、owned remaining[]。外側project-envの独立environment UTCはUNKNOWNで、通常wrapper returnで終了。formatter各実子のwait/reapとfresh identityの確認、最終adminSTOP、対象usageはsource-binding.jsonに保存する。連続peakと今後の科学PASSはUNKNOWN。

Main・Git統合、実資源、必要な現input/model/library照合とnative software、関連review、探索費96callsおよび128対局の入場は324が所有する。混合学習準備・全pipelineと323のUSERPAUSE、既存models/defaults/seals/fits96、RAW/FAILED/費/UNKNOWNは維持する。
