"""Resolve the actual arena consumer and bind only necessary config/book sources."""

import gzip
import hashlib
import json
import resource
import subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent


def read(p, limit=1024 * 1024):
    d = p.read_bytes()
    assert len(d) <= limit
    return d, {
        "path": str(p),
        "sha256": hashlib.sha256(d).hexdigest(),
        "bytes": len(d),
        "mode": format(p.stat().st_mode & 0o777, "04o"),
    }


scan = subprocess.run(
    [
        "rg",
        "-l",
        "^def (arena_config|measurement_config)\\(",
        str(MAIN / "python"),
        str(MAIN / "scripts"),
        str(MAIN / "tools"),
    ],
    capture_output=True,
    text=True,
    check=True,
)
paths = [Path(s) for s in scan.stdout.splitlines()]
assert paths, "no owning arena/measurement consumer"
bindings = []
for relative in [
    "crates/quoridor-runner/src/config.rs",
    "crates/quoridor-runner/src/value_search_strength.rs",
] + [str(p.relative_to(MAIN)) for p in paths]:
    data, r = read(MAIN / relative)
    r["relative"] = relative
    r["consumer_scope"] = (
        "arena functions only; measurement peer-owned"
        if relative.endswith(".py")
        else "engine config or saved Book source"
    )
    bindings.append(r)
    recovery = OWN / "before" / (relative.replace("/", "__") + ".gz")
    if recovery.exists():
        assert gzip.decompress(recovery.read_bytes()) == data
    else:
        with recovery.open("xb") as f:
            f.write(gzip.compress(data, mtime=0))
old = json.loads((OWN / "intake.json").read_text())
plan = old["saved_metadata"][0]["value"]
b = plan["book"]
data, r = read(Path(b["path"]))
assert r == b
book = json.loads(data)
sample_ref = plan["batches"][2]["config"]
data, r = read(Path(sample_ref["path"]))
assert r == sample_ref
for b in bindings:
    _, a = read(Path(b["path"]))
    assert all(a[k] == b[k] for k in ["sha256", "bytes", "mode"])
(OWN / "supplement.json").write_text(
    json.dumps(
        {
            "source_before_after": bindings,
            "book": {"ref": plan["book"], "value": book},
            "current_timed_config_sample": {
                "ref": sample_ref,
                "value": json.loads(data),
            },
            "targeted_consumer_lookup": scan.stdout.splitlines(),
            "native_geometry_or_prefix_replay": 0,
            "mixed_learner_323": "USERPAUSE",
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "status": "NECESSARY_CONFIG_BOOK_CONSUMER_BOUND",
            "sources": bindings,
            "book_ref": plan["book"],
            "config_sample": sample_ref,
        }
    )
)
