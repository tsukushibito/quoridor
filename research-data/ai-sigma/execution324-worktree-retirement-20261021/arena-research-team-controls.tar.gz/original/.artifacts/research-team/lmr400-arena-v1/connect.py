"""Sparse current-before arena wiring; no maintained source or scientific entry."""

import gzip
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
OWN = Path(__file__).resolve().parent
TEMP = OWN / "source-TEMP"
paths = [
    "crates/quoridor-runner/src/config.rs",
    "crates/quoridor-runner/src/arena.rs",
    "crates/quoridor-runner/src/runtime.rs",
    "scripts/dev/research-lifecycle.py",
]
before = {
    p: gzip.decompress(
        (OWN / "before" / (p.replace("/", "__") + ".gz")).read_bytes()
    ).decode()
    for p in paths
}
after = dict(before)


def once(s, a, b):
    assert s.count(a) == 1, a[:100]
    return s.replace(a, b, 1)


config = once(
    after[paths[0]],
    "    pub simd: bool,\n}",
    """    pub simd: bool,
    /// Arena-only selection of the two existing research ordering targets.
    /// None retains the current product/generation constructor.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub ordering_profile: Option<String>,
    /// Explicit runtime mode; input namespace strings never enable it.
    #[serde(default)]
    pub lmr: bool,
}""",
)
after[paths[0]] = config
arena = once(
    after[paths[1]],
    "        let research = self.comparison != Comparison::Functional;",
    """        for engine in &c.engines {
            if let Some(profile) = engine.ordering_profile.as_deref() {
                if !matches!(profile, "control" | "cheap")
                    || !matches!(engine.kind.as_str(), "nnue" | "distance")
                    || self.disable_continuation_static_ordering
                {
                    return Err("explicit arena ordering requires signed alpha Control/Cheap".into());
                }
            } else if engine.lmr {
                return Err("LMR requires an explicit Control/Cheap arena ordering target".into());
            }
        }
        let research = self.comparison != Comparison::Functional;""",
)
# Config validation also rejects accidentally enabling this through self-play.
after[paths[0]] = once(
    after[paths[0]],
    "        if self.engines.is_empty() || self.engines.len() > 2 {",
    """        if self.arena.is_none()
            && self.engines.iter().any(|e| e.ordering_profile.is_some() || e.lmr)
        {
            return Err("explicit ordering/LMR settings belong to an arena config".into());
        }
        if self.engines.is_empty() || self.engines.len() > 2 {""",
)
# Evaluator comparisons must keep method selectors equal; search/whole comparisons may differ.
arena = arena.replace(
    "a.depth != b.depth\n                    || a.max_nodes != b.max_nodes",
    "a.depth != b.depth\n                    || a.ordering_profile != b.ordering_profile\n                    || a.lmr != b.lmr\n                    || a.max_nodes != b.max_nodes",
)
arena = once(arena, "    fn fixture(\n", "    pub(super) fn fixture(\n")
after[paths[1]] = (
    arena
    + '\n#[cfg(test)]\n#[path = "arena_lmr400_tests.rs"]\nmod arena_lmr400_tests;\n'
)
runtime = after[paths[2]]
helpers = """/// Config-driven selection only: existing factory owns ranking and LMR.
/// Expected namespace is checked against the actual session by the unchanged
/// invocation/reset boundary. It is never used to enable a mode.
fn arena_alpha_namespace(engine: &Engine, mut base: alphabeta::SearchNamespace) -> alphabeta::SearchNamespace {
    if let Some(profile) = engine.ordering_profile.as_deref() {
        base.selectivity.push_str(":cheap-static376-integer-parent-v1:");
        base.selectivity.push_str(profile);
        if engine.lmr {
            base.selectivity.push(':');
            base.selectivity.push_str(alphabeta::LMR_METHOD);
        }
    }
    base
}
fn arena_alpha_session(
    evaluator: Arc<dyn StaticEvaluator>, base: alphabeta::SearchNamespace,
    capacity: usize, engine: &Engine, arena: Option<&crate::arena::ArenaConfig>,
) -> alphabeta::Result<alphabeta::SearchSession> {
    let session = if let Some(profile) = engine.ordering_profile.as_deref() {
        let profile = match profile {
            "control" => alphabeta::OrderingProfile::CheapStaticControl,
            "cheap" => alphabeta::OrderingProfile::CombinedSignedCheapStatic,
            _ => return Err(alphabeta::SearchError::Limits("unknown arena ordering target".into())),
        };
        // Preserve the actual existing arena score domain; no new evaluator math.
        let mut session = alphabeta::SearchSession::new_for_ordering_assessment(
            evaluator, base, capacity, alphabeta::ScoreDomain::LEGACY, profile, false,
        )?;
        session.set_lmr(engine.lmr)?;
        session
    } else if arena.is_some_and(|a| a.disable_continuation_static_ordering) {
        alphabeta::SearchSession::new_without_continuation_or_static(evaluator, base, capacity)?
    } else {
        alphabeta::SearchSession::new(evaluator, base, capacity)?
    };
    if engine.ordering_profile.is_none() && engine.lmr {
        return Err(alphabeta::SearchError::Limits("LMR needs an explicit ordering target".into()));
    }
    // The setter acts on configuration, not the namespace string; log the getter.
    if session.lmr_enabled() != engine.lmr {
        return Err(alphabeta::SearchError::Limits("arena/session LMR mode mismatch".into()));
    }
    Ok(session)
}

"""
runtime = once(
    runtime,
    "/// One TT caller attempt, including allocation errors and early cancellation.",
    helpers
    + "/// One TT caller attempt, including allocation errors and early cancellation.",
)
runtime = once(
    runtime,
    "    pub shared_evaluator_bytes: Option<usize>,\n}",
    """    pub shared_evaluator_bytes: Option<usize>,
    #[serde(default)]
    pub actual_namespace: Option<serde_json::Value>,
    #[serde(default)]
    pub actual_lmr_enabled: Option<bool>,
    #[serde(default)]
    pub lmr_attempts: u64,
    #[serde(default)]
    pub lmr_full_depth_confirmations: u64,
    #[serde(default)]
    pub lmr_full_window_researches: u64,
}""",
)
runtime = once(
    runtime,
    "        self.probes += s.tt_probes;",
    """        self.lmr_attempts += s.lmr_attempts;
        self.lmr_full_depth_confirmations += s.lmr_full_depth_confirmations;
        self.lmr_full_window_researches += s.lmr_full_window_researches;
        self.probes += s.tt_probes;""",
)
runtime = once(
    runtime,
    "        profile.search_invocations += 1;",
    """        profile.actual_namespace = Some(serde_json::json!({
            "evaluator":session.namespace().evaluator,
            "rules":session.namespace().rules,
            "selectivity":session.namespace().selectivity,
        }));
        profile.actual_lmr_enabled = Some(session.lmr_enabled());
        profile.search_invocations += 1;""",
)
old = """                    |evaluator, namespace, capacity| {
                        if config
                            .arena
                            .as_ref()
                            .is_some_and(|a| a.disable_continuation_static_ordering)
                        {
                            alphabeta::SearchSession::new_without_continuation_or_static(
                                evaluator, namespace, capacity,
                            )
                        } else {
                            alphabeta::SearchSession::new(evaluator, namespace, capacity)
                        }
                    },"""
runtime = once(
    runtime,
    old,
    """                    |evaluator, _qualified_namespace, capacity| {
                        arena_alpha_session(evaluator, base_namespace.clone(), capacity, e, config.arena.as_ref())
                    },""",
)
old = """                                |evaluator, namespace, capacity| {
                                    if c.arena.as_ref().unwrap().disable_continuation_static_ordering {
                                        alphabeta::SearchSession::new_without_continuation_or_static(evaluator, namespace, capacity)
                                    } else { alphabeta::SearchSession::new(evaluator, namespace, capacity) }
                                },"""
runtime = once(
    runtime,
    old,
    """                                |evaluator, _qualified_namespace, capacity| {
                                    arena_alpha_session(evaluator, base_namespace.clone(), capacity, &e, c.arena.as_ref())
                                },""",
)
# Each constructor still runs inside the original timed invoke; passing the
# same qualified expected namespace prevents clearing TT/history every turn.
runtime = once(
    runtime,
    "                let mut completion = crate::arena_clock::Completion::default();\n                let observed = !g.record_teacher;",
    """                let base_namespace = namespace;
                let namespace = arena_alpha_namespace(e, base_namespace.clone());
                let mut completion = crate::arena_clock::Completion::default();
                let observed = !g.record_teacher;""",
)
runtime = once(
    runtime,
    "                            let mut completion = crate::arena_clock::Completion::default();\n                            let mut publish = |result: &alphabeta::SearchResult| {",
    """                            let base_namespace = namespace;
                            let namespace = arena_alpha_namespace(&e, base_namespace.clone());
                            let mut completion = crate::arena_clock::Completion::default();
                            let mut publish = |result: &alphabeta::SearchResult| {""",
)
runtime = once(
    runtime,
    '        "completed_snapshot_validation_failed":!valid,\n        "last_completed_iteration_ns":completion.at.map(ns),',
    """        "completed_snapshot_validation_failed":!valid,
        "actual_search_namespace":game.tt_profiles[engine].actual_namespace,
        "actual_lmr_enabled":game.tt_profiles[engine].actual_lmr_enabled,
        "lmr_work_completed":selected.map(|r| serde_json::json!({"attempts":r.stats.lmr_attempts,"full_depth_confirmations":r.stats.lmr_full_depth_confirmations,"full_window_researches":r.stats.lmr_full_window_researches})),
        "lmr_work_terminal":result.as_deref().map(|r| serde_json::json!({"attempts":r.stats.lmr_attempts,"full_depth_confirmations":r.stats.lmr_full_depth_confirmations,"full_window_researches":r.stats.lmr_full_window_researches})),
        "last_completed_iteration_ns":completion.at.map(ns),""",
)
after[paths[2]] = (
    runtime
    + '\n#[cfg(test)]\n#[path = "runtime_lmr400_tests.rs"]\nmod runtime_lmr400_tests;\n'
)
lc = after[paths[3]]
start = lc.index("def arena_plan_check(")
end = lc.index("\n\ndef planned_game_slice(", start)
part = lc[start:end]
part = once(
    part,
    '            and type(engine["simd"]) is bool',
    """            and type(engine["simd"]) is bool
            and type(engine.get("lmr", False)) is bool
            and engine.get("ordering_profile") in {None, "control", "cheap"}
            and (not engine.get("lmr", False) or engine.get("ordering_profile") is not None)
            and (engine.get("ordering_profile") is None or (engine["kind"] in {"nnue", "distance"} and not a.get("disable_continuation_static_ordering", False)))""",
)
lc = lc[:start] + part + lc[end:]
start = lc.index("def arena_observation(")
end = lc.index("\n\nARENA_PUBLICATION", start)
part = lc[start:end]
part = once(
    part,
    '        counters = obs["counters"]\n        fallback = (',
    """        counters = obs["counters"]
        engine = config["engines"][index]
        if engine.get("ordering_profile") is not None:
            method = counters.get("actual_search_namespace")
            require(
                isinstance(method, dict)
                and set(method) == {"evaluator", "rules", "selectivity"}
                and all(isinstance(v, str) and v for v in method.values())
                and method["rules"] == "research-standard-2p-threefold-goal-first-v1"
                and method["evaluator"] == a["evaluator_sha256"][index] + ":simd=" + str(engine["simd"]).lower()
                and method["selectivity"].endswith(
                    ":cheap-static376-integer-parent-v1:" + engine["ordering_profile"]
                    + (":lmr400-late4-depth3-minus1-pvs-verify-v1" if engine.get("lmr", False) else "")
                )
                and type(counters.get("actual_lmr_enabled")) is bool
                and counters["actual_lmr_enabled"] == engine.get("lmr", False),
                "configured/actual arena ordering-LMR method correspondence",
            )
        fallback = (""",
)
after[paths[3]] = lc[:start] + part + lc[end:]
TEMP.mkdir(exist_ok=True)
for path, text in after.items():
    out = TEMP / path
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(text)
for name, relative in [
    ("test_arena_lmr400.py", "scripts/dev/test_arena_lmr400.py"),
    ("arena_lmr400_tests.rs", "crates/quoridor-runner/src/arena_lmr400_tests.rs"),
    ("runtime_lmr400_tests.rs", "crates/quoridor-runner/src/runtime_lmr400_tests.rs"),
]:
    target = TEMP / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text((OWN / name).read_text())
(OWN / "composition-input.json").write_text(
    json.dumps(
        {
            "existing": paths,
            "new": [
                "crates/quoridor-runner/src/arena_lmr400_tests.rs",
                "crates/quoridor-runner/src/runtime_lmr400_tests.rs",
                "scripts/dev/test_arena_lmr400.py",
            ],
            "AI_measurement_written": False,
            "Python_arena_functions_only": ["arena_plan_check", "arena_observation"],
            "native": "UNBUILT/UNTYPED/UNRUN",
        },
        indent=2,
    )
    + "\n"
)
