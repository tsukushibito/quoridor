"""Current named arena sources and saved input metadata only; no engine entry."""

import gzip
import hashlib
import json
import resource
import subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent


def read(path, maximum=1024 * 1024):
    data = path.read_bytes()
    assert len(data) <= maximum
    return data, {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": format(path.stat().st_mode & 0o777, "04o"),
    }


# Narrow filename discovery inside the short owning intake, not an asset walk.
listing = subprocess.run(
    [
        "rg",
        "--files",
        str(MAIN / "python"),
        str(MAIN / "scripts"),
        str(MAIN / "tools"),
        "-g",
        "common.py",
    ],
    check=True,
    capture_output=True,
    text=True,
)
choices = [Path(line) for line in listing.stdout.splitlines()]
assert len(choices) == 1, f"ambiguous common.py owner: {choices}"
common_relative = str(choices[0].relative_to(MAIN))
sources = [
    "crates/quoridor-runner/src/arena.rs",
    "crates/quoridor-runner/src/runtime.rs",
    common_relative,
]
(OWN / "before").mkdir(exist_ok=True)
bound = []
for path in sources:
    data, binding = read(MAIN / path)
    binding["relative"] = path
    bound.append(binding)
    recovery = OWN / "before" / (path.replace("/", "__") + ".gz")
    if recovery.exists():
        assert gzip.decompress(recovery.read_bytes()) == data, "before drift"
    else:
        with recovery.open("xb") as f:
            f.write(gzip.compress(data, mtime=0))
metadata = []
for relative in [
    "research-data/ai-sigma/three-engine-comparison374/approved-plan-v5.json",
    ".artifacts/research-team/integration324/deferred-tail399-v1/compatible-build-v2/operation-v1/manifest.json",
]:
    data, binding = read(MAIN / relative)
    metadata.append({"ref": binding, "value": json.loads(data)})
for binding in bound:
    _, after = read(Path(binding["path"]))
    assert all(after[k] == binding[k] for k in ["sha256", "bytes", "mode"])
(OWN / "intake.json").write_text(
    json.dumps(
        {
            "issue": "quoridor-4lc.400.2",
            "current_source_before_after": bound,
            "saved_metadata": metadata,
            "native_Cargo_geometry_Search_model_library_calls": 0,
            "future_image_and_prepared_refs": None,
            "mixed_learner_323": "USERPAUSE",
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "status": "NAMED_INTAKE_MATCH",
            "sources": bound,
            "saved_metadata_refs": [m["ref"] for m in metadata],
        }
    )
)
