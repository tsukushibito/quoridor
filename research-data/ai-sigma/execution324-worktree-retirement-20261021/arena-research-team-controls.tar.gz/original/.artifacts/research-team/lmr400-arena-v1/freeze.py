"""Scoped format/reversibility/outside-owner checks, never executes definitions."""

import ast
import difflib
import gzip
import hashlib
import json
import os
import resource
import subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
TEMP = OWN / "source-TEMP"
ROUND = Path(os.environ["TMPDIR"]) / "roundtrip"
RUSTFMT = Path(
    "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt"
)
RUFF = Path("/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff")
commands = []


def ref(p):
    d = p.read_bytes()
    assert len(d) < 128 * 1024**2
    return {
        "path": str(p),
        "sha256": hashlib.sha256(d).hexdigest(),
        "bytes": len(d),
        "mode": format(p.stat().st_mode & 0o777, "04o"),
    }


def cmd(name, argv, cwd):
    stdout = OWN / (name + ".stdout.log")
    stderr = OWN / (name + ".stderr.log")
    with stdout.open("xb") as out, stderr.open("xb") as err:
        with subprocess.Popen(
            argv, cwd=cwd, stdout=out, stderr=err, close_fds=True
        ) as child:
            p = Path("/proc") / str(child.pid) / "stat"
            try:
                identity = {
                    "pid": child.pid,
                    "start_ticks": p.read_text().rsplit(")", 1)[1].split()[19],
                    "boot_id": Path("/proc/sys/kernel/random/boot_id")
                    .read_text()
                    .strip(),
                }
            except FileNotFoundError:
                identity = None
            code = child.wait()
    assert (
        stdout.stat().st_size <= 128 * 1024 and stderr.stat().st_size <= 128 * 1024
    ), "captureoverflow"
    commands.append(
        {
            "name": name,
            "argv": argv,
            "identity": identity,
            "directwait_exit": code,
            "reaped": True,
            "handles_closed": True,
            "stdout": ref(stdout),
            "stderr": ref(stderr),
        }
    )
    (OWN / "freeze-command-facts.json").write_text(
        json.dumps(commands, indent=2) + "\n"
    )
    assert code == 0, (name, code)


composition = json.loads((OWN / "composition-input.json").read_text())
paths = composition["existing"]
new = composition["new"]
allpaths = paths + new
bound = []
for p in paths:
    data = gzip.decompress(
        (OWN / "before" / (p.replace("/", "__") + ".gz")).read_bytes()
    )
    actual = ref(MAIN / p)
    assert actual["sha256"] == hashlib.sha256(data).hexdigest() and actual[
        "bytes"
    ] == len(data), "currentbefore drift " + p
    bound.append(actual)
assert all(not (MAIN / p).exists() for p in new)
tools = [ref(p) for p in [RUSTFMT, RUFF, Path("/usr/bin/patch")]]
rust = [str(TEMP / p) for p in allpaths if p.endswith(".rs")]
py = [str(TEMP / p) for p in allpaths if p.endswith(".py")]
args = [str(RUSTFMT), "--edition", "2024", "--config", "skip_children=true"]
cmd("rustfmt400", args + rust, MAIN)
cmd("rustfmt400-check", args + ["--check"] + rust, MAIN)
args = [str(RUFF), "format", "--config", str(MAIN / "pyproject.toml")]
cmd("ruff400", args + py, MAIN)
cmd("ruff400-check", args + ["--check"] + py, MAIN)
cmd(
    "ruff400-lint",
    [str(RUFF), "check", "--config", str(MAIN / "pyproject.toml")] + py,
    MAIN,
)
before = {
    p: gzip.decompress((OWN / "before" / (p.replace("/", "__") + ".gz")).read_bytes())
    for p in paths
}
post = {p: (TEMP / p).read_bytes() for p in allpaths}
lc = "scripts/dev/research-lifecycle.py"
allowed = {"arena_plan_check", "arena_observation"}


def outside(source):
    tree = ast.parse(source)
    tree.body = [
        node
        for node in tree.body
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        or node.name not in allowed
    ]
    return ast.dump(tree, include_attributes=False)


assert outside(before[lc]) == outside(post[lc]), "outside arena Python owner changed"
runtime = "crates/quoridor-runner/src/runtime.rs"
original = before[runtime].decode()
changed = post[runtime].decode()
protected = []
for start, end in [
    ("fn alpha_receipt_decision(", "#[cfg(test)]"),
    ("fn evaluation_turn(", "\nfn "),
    ("fn commit_action(", "\nfn "),
]:
    at = original.find(start)
    if at < 0:
        continue
    e = original.find(end, at + len(start))
    e = e if e >= 0 else len(original)
    fragment = original[at:e]
    assert fragment in changed, "clock/move application protectedbody changed " + start
    protected.append(
        {
            "scope": start,
            "sha256": hashlib.sha256(fragment.encode()).hexdigest(),
            "bytes": len(fragment.encode()),
        }
    )
forward = ""
inverse = ""
for p in allpaths:
    a = before.get(p, b"")
    b = post[p]
    forward += "".join(
        difflib.unified_diff(
            a.decode().splitlines(True),
            b.decode().splitlines(True),
            fromfile="a/" + p if p in before else "/dev/null",
            tofile="b/" + p,
        )
    )
    inverse += "".join(
        difflib.unified_diff(
            b.decode().splitlines(True),
            a.decode().splitlines(True),
            fromfile="a/" + p,
            tofile="b/" + p if p in before else "/dev/null",
        )
    )
(OWN / "arena400.patch").write_text(forward)
(OWN / "arena400.inverse.patch").write_text(inverse)
ROUND.mkdir()
for p, d in before.items():
    q = ROUND / p
    q.parent.mkdir(parents=True, exist_ok=True)
    q.write_bytes(d)
cmd(
    "forward400",
    ["/usr/bin/patch", "--batch", "--fuzz=0", "-p1", "-i", str(OWN / "arena400.patch")],
    ROUND,
)
assert all((ROUND / p).read_bytes() == post[p] for p in allpaths)
cmd(
    "inverse400",
    [
        "/usr/bin/patch",
        "--batch",
        "--fuzz=0",
        "-p1",
        "-i",
        str(OWN / "arena400.inverse.patch"),
    ],
    ROUND,
)
assert all((ROUND / p).read_bytes() == before[p] for p in paths) and all(
    not (ROUND / p).exists() for p in new
)
for r in bound:
    assert ref(Path(r["path"])) == r
assert all(not (MAIN / p).exists() for p in new)
# Only authored new definitions persist. Existing postimages reconstruct from thinpatch.
for p in new:
    (OWN / Path(p).name).write_bytes(post[p])
for root, contents in [(TEMP, post), (ROUND, before)]:
    actual = {p for p in root.rglob("*") if p.is_file() or p.is_symlink()}
    expected = {root / p for p in contents}
    assert actual == expected
    for p in expected:
        assert p.read_bytes() == contents[str(p.relative_to(root))]
        p.unlink()
    for p in sorted(
        (p for p in root.rglob("*") if p.is_dir()),
        key=lambda p: len(p.parts),
        reverse=True,
    ):
        p.rmdir()
    root.rmdir()
# Remove unmodified/not-owned exploratory recovery copies, retain their original intake facts.
removed = []
for relative in [
    "python/quoridor_training/common.py",
    "scripts/dev/research-lifecycle.py.orig",
    "crates/quoridor-runner/src/value_search_strength.rs",
]:
    p = OWN / "before" / (relative.replace("/", "__") + ".gz")
    if p.exists():
        removed.append(ref(p))
        p.unlink()
result = {
    "status": "SOURCE_FORMAT_STATIC_ROUNDTRIP_PASS",
    "existing_before": bound,
    "after": [
        {
            "path": str(MAIN / p),
            "sha256": hashlib.sha256(post[p]).hexdigest(),
            "bytes": len(post[p]),
            "mode": "0644",
            "state": "PROPOSED_NOT_MAIN",
        }
        for p in allpaths
    ],
    "patch": ref(OWN / "arena400.patch"),
    "inverse": ref(OWN / "arena400.inverse.patch"),
    "tools": tools,
    "commands": commands,
    "Python_outside_arena_AST_unchanged": True,
    "protected_clock_commit_bodies": protected,
    "new_Main_files_absent_before_after": new,
    "source_TEMP_and_roundtrip_removed": True,
    "unmodified_unowned_recovery_derivatives_removed": removed,
    "native_new6_and_Python2": "UNBUILT/UNTYPED/UNRUN",
    "source_CPU": 8,
    "model_library_geometry_Search_native_calls": 0,
    "mixed_learner_323": "USERPAUSE",
}
(OWN / "source-static-result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
print(
    json.dumps(
        {
            "status": result["status"],
            "result": ref(OWN / "source-static-result.json"),
            "patch": result["patch"],
        }
    )
)
