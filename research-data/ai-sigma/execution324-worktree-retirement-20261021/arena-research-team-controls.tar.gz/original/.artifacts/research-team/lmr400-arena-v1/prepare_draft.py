"""Pre-outcome metadata selection and finite trial drafts, no replay or entry."""

import copy
import hashlib
import json
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (384 * 1024**2, 384 * 1024**2))
OWN = Path(__file__).resolve().parent
intake = json.loads((OWN / "intake.json").read_text())
supplement = json.loads((OWN / "supplement.json").read_text())
raw = supplement["book"]["value"]
book_ref = supplement["book"]["ref"]
seed = 40020261014
selected = []
counts = {}
for length in [4, 8, 12, 16]:
    candidates = [f for f in raw["families"] if len(f["prefix"]) == length]
    counts[str(length)] = len(candidates)
    ordered = sorted(
        candidates,
        key=lambda f: (
            hashlib.sha256(f"{seed}:{length}:{f['family_id']}".encode()).digest(),
            f["family_id"],
        ),
    )
    assert len(ordered) >= 2, "available-book stratum shortage; do not refill"
    selected.extend(sorted(ordered[:2], key=lambda f: f["family_id"]))
assert len({f["family_id"] for f in selected}) == 8
assert len({tuple(f["prefix"]) for f in selected}) == 8
selection = {
    "book": book_ref,
    "seed": seed,
    "method": "SHA256 of decimal seed:length:family_id, ascending bytes, first2 eachlength; selected2 restored to originalfamilyorder withinstratum; no outcomes",
    "stratum_available": counts,
    "selected": selected,
    "provenance_scope": "Original355 generated book header/rules/prefix/root_key/fullhistory recorded. Existing current377 OPAQUE_UNVERIFIED/seal limits not requalified here; no native prefix replay. Root actual necessary input/Book checks at entry.",
    "excluded_inputs": "Mixed342.17 evaluation book and all other paused/sealed sets not read",
    "family_unit": "8 shared families, reused across8condition matches; colours and contrasts not independent new families",
    "actual_prefix_replay_Search_geometry_calls": 0,
}
(OWN / "opening-selection.json").write_text(
    json.dumps(selection, ensure_ascii=False, indent=2) + "\n"
)
contrast = [
    ("control-off_vs_control-on", ("control", False), ("control", True)),
    ("cheap-off_vs_cheap-on", ("cheap", False), ("cheap", True)),
    ("control-off_vs_cheap-off", ("control", False), ("cheap", False)),
    ("control-on_vs_cheap-on", ("control", True), ("cheap", True)),
]
base = supplement["current_timed_config_sample"]["value"]
model = intake["saved_metadata"][0]["value"]["models"][0]
old_artifact = intake["saved_metadata"][1]["value"]["artifact"]
configs = []
schedule = []
for evaluator, tt in [("nnue", 4096), ("distance", 1048576)]:
    for name, left, right in contrast:
        batch = len(configs)
        c = copy.deepcopy(base)
        c["run_id"] = f"400-{evaluator}-{name}"
        c["output"] = str(OWN / "future-output" / c["run_id"] / "data")
        c["games"] = 16
        c["cpu_cores"] = [2, 6]
        c["management_cpu_core"] = 4
        c["seed"] = seed + batch
        c["max_memory_bytes"] = 4 * 1024**3 - 64 * 1024**2
        # These are honest prospective settings, not a submit-ready Config.
        c["arena"]["search_artifact_sha256"] = [None, None]
        c["arena"]["evaluator_sha256"] = [
            model["evaluator_sha256"]
            if evaluator == "nnue"
            else base["arena"]["evaluator_sha256"][0]
        ] * 2
        c["arena"]["disable_continuation_static_ordering"] = False
        c["arena"]["tt_entries"] = tt
        c["arena"]["bootstrap_seed"] = seed
        c["arena"]["first_candidate_colors"] = [i % 2 for i in range(8)]
        c["arena"]["book"] = {
            "id": "400-preoutcome-selected355-8",
            "usage": "main",
            "frozen_before_candidate_results": True,
            "independence": "Exploratory same8 shared families,2colours each; no statistical family inflation; historical unsealed355 provenance retained",
            "openings": [
                {
                    "id": f["id"],
                    "cohort": "main",
                    "lineage": f"original355-family-{f['family_id']}",
                    "siblings": [],
                    "original_seed": f["seed"],
                    "reference": {
                        "source_sha256": book_ref["sha256"],
                        "model_sha256": None,
                        "settings": f,
                        "q_definition": None,
                        "q_perspective": None,
                        "q_aggregation": None,
                        "q": None,
                    },
                    "selection_reason": "Pre-outcome fixed length-stratified seeded SHA selection; no refill",
                    "candidate_pool_size": counts[str(len(f["prefix"]))],
                    "prefix": f["prefix"],
                }
                for f in selected
            ],
        }
        c["engines"] = []
        for profile, lmr in [left, right]:
            e = copy.deepcopy(
                base["engines"][1] if evaluator == "nnue" else base["engines"][0]
            )
            e["ordering_profile"] = profile
            e["lmr"] = lmr
            c["engines"].append(e)
        configs.append(
            {
                "batch": batch,
                "evaluator": evaluator,
                "contrast": name,
                "config_draft": c,
                "config_actual_ref": None,
                "future_build": None,
                "future_artifact": None,
            }
        )
        for i, f in enumerate(selected):
            first = i % 2
            for local in [0, 1]:
                slot = len(schedule)
                color = first ^ local
                schedule.append(
                    {
                        "slot": slot,
                        "batch": batch,
                        "matchup": batch,
                        "local_game": 2 * i + local,
                        "family_id": f["family_id"],
                        "candidate_color": color,
                    }
                )
assert len(schedule) == 128 and len(configs) == 8
for config in configs:
    c = config["config_draft"]
    assert (
        c["max_plies"] == 200
        and c["workers"] == c["active_games"] == c["max_batch"] == 1
    )
    assert c["arena"]["return_reserve_ms"] == 5 and all(
        e["time_ms"] == 100 and e["depth"] == 64 and e["max_nodes"] == 1000000
        for e in c["engines"]
    )
    rows = [s for s in schedule if s["batch"] == config["batch"]]
    assert len(rows) == 16 and all(
        {s["candidate_color"] for s in rows if s["family_id"] == f["family_id"]}
        == {0, 1}
        for f in selected
    )
draft = {
    "status": "PROSPECTIVE_NOT_READY_NOT_SUBMITTED",
    "scientific_scope": "400 selected128 games64colourpairs; no old374 subject relaunch",
    "current_book": book_ref,
    "baseline_build": intake["saved_metadata"][1]["ref"],
    "baseline_artifact": old_artifact,
    "model": model,
    "family_ids": [f["family_id"] for f in selected],
    "schedule": schedule,
    "configs": configs,
    "comparison": "whole_wall_time",
    "root_engine_rule": "Sameevaluator/TT/depth64/nodecap1M/100ms5ms perpair, method andLMR differ onlyby selectedcontrast",
    "score_domain": "LEGACY existing arena domain, evaluator math unchanged; LMR completeddepth selective nominal not fullwidth proof",
    "entry_resources_proposal": {
        "native_game_workers": 1,
        "AI_threads": 2,
        "cpu_cores": [2, 6],
        "management_guardian": 4,
        "family_RAM_B": 4 * 1024**3,
        "GPU": 0,
        "future_actual_physical_quiet_allocation": "UNKNOWN/fresh Root entry guard required",
    },
    "sequence_draft": {
        "entry": "existing research sequence arena typedsettings/normalExperiment/execute/directwait/oncefinalize",
        "serial_batches": list(range(8)),
        "prefix_replay_needed": "Root existing nativearena validates exactprefix/fullhistory/rootkey once at realrequiredinput entry; author0",
        "actual_configs_Experiments_settings_refs": None,
        "future_image_ref": None,
        "stop": "Anyunexpectedfailure/cancel/pause/resource refusal stopsstage; no skip/refill/replay",
    },
    "result_interpretation": "WDL/pairedfamily score/uncertainty, timing/depth/work/fallback/errors exploratory; shared8families not128independent samples; no speed-only beststrength/noninferiority/default promotion",
    "source_CPU": 8,
    "storage_budget": None,
    "native_scientific_calls": 0,
    "mixed_learner_323": "USERPAUSE",
}
(OWN / "resolved-draft.json").write_text(
    json.dumps(draft, ensure_ascii=False, indent=2) + "\n"
)
print(
    json.dumps(
        {
            "selected_families": draft["family_ids"],
            "strata": counts,
            "games": len(schedule),
            "batches": len(configs),
            "ready": False,
            "newimage": None,
        }
    )
)
