"""Present already collected412 scalars; never reopen game archives."""

import datetime
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-standard412-v1/arena392-v1"
)


def ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


r = json.loads((OWN / "result.json").read_bytes())
refs = json.loads((OWN / "selected-refs.json").read_bytes())
metadata = []
for name in ["prepared.json", "collection-v1/STOP.json"]:
    p = ROOT / name
    before = ref(p)
    value = json.loads(p.read_bytes())
    assert ref(p) == before
    refs.append(before)
    metadata.append(dict(ref=before, keys=list(value)))
validations = []
for c in r["contrasts"]:
    lo, hi = c["native_A_interval"]["percentile_95"]
    c["B_interval_95"] = [1 - hi, 1 - lo]
    a = c["WDL_A"]
    c["WDL_B"] = dict(
        W=a.get("L", 0), D=a.get("D", 0), L=a.get("W", 0), UNKNOWN=a.get("UNKNOWN", 0)
    )
    c["B_lower_gt_half"] = c["B_interval_95"][0] > 0.5
    assert len(c["family_scores"]) == 98
    assert c["native_summary"]["census"]["complete_pairs"] == 98
    assert sum(a.values()) == 196
    for f in c["family_scores"]:
        assert len(f["A_scores"]) == 2 and f["B_score"] == 1 - f["A_score"]
    validations.append(
        dict(
            evaluator=c["evaluator"],
            family_pairs=98,
            A_native_interval_preserved=True,
            B_interval_only_reflection=True,
            B_criterion=c["B_lower_gt_half"],
        )
    )
for key, m in r["methods"].items():
    counts = m["counts"]
    depth = m["selected_completed_depth"]
    assert sum(depth["histogram"].values()) == depth["n"]
    assert (
        depth["n"] + counts.get("accepted_without_completed_depth", 0)
        == counts["accepted"]
    )
    assert counts["accepted"] + counts["not_accepted"] == counts["observations"]
    assert counts["receipt_deadline_n"] == counts["accepted"]
    assert (
        counts["inflight_zero"]
        == counts["matching_terminal_collected_true"]
        == counts["accepted"]
    )
    assert m["persistent_profile_sums"]["search_invocations"] == counts["observations"]
    for pk, wk in [
        ("probes", "tt_probes"),
        ("key_hits", "tt_key_hits"),
        ("bound_cutoffs", "tt_bound_cutoffs"),
    ]:
        assert m["persistent_profile_sums"][pk] == m["work_views"]["terminal"][wk]
    for lk, pk in [
        ("attempts", "lmr_attempts"),
        ("full_depth_confirmations", "lmr_full_depth_confirmations"),
        ("full_window_researches", "lmr_full_window_researches"),
    ]:
        assert m["LMR_views"]["terminal"][lk] == m["persistent_profile_sums"][pk]
    assert m["gauges"]["effective_tt_slots"] == [1048576]
    assert m["gauges"]["retained_bytes_peak"] == [83886128]
assert r["census"]["unique"] == r["census"]["entered"] == r["census"]["returned"] == 392
assert r["observation_census"]["accepted"] == 20285
r["validation"] = dict(
    contrasts=validations,
    histograms_and_completed_denominators=True,
    terminal_TT_LMR_profile_correspondence=True,
    receipt_terminal_drain_ownership=True,
    retained_TT_bytes_are_not_RSS=True,
    raw_read_once_streamed=True,
)
r["primary_criterion"] = dict(
    evaluator="nnue",
    method="depth_rank",
    condition="B lower 95% bound > .5",
    met=False,
    scope="fixed98 canonical starts and original100ms conditions only; not noninferiority/Elo/general superiority",
)
r["metadata_read_STOP"] = datetime.datetime.now(datetime.UTC).isoformat()
(OWN / "selected-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
(OWN / "result.json").write_text(
    json.dumps(r, ensure_ascii=False, separators=(",", ":")) + "\n"
)
(OWN / "validation.json").write_text(
    json.dumps(
        dict(checks=r["validation"], metadata=metadata, new_Search_games_bootstrap=0),
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
lines = [
    "# 412：原392局の保存解析",
    "",
    "主解析NNUEでB=depth_rankは106勝0分90敗、得点率54.08%、家族pair単位の保存95%区間46.94–61.22%。事前基準Bの区間下限>50%は満たさない。副解析fixedDは99勝0分97敗、50.51% [45.41%,55.61%]。現在のdefault ONという人間の選択とは別の観測であり、既定値変更・採否は行わない。",
    "",
    "元job b4bc6735の2 manifestはいずれもPASS。予定・入場・回収・一意slotは各392、196 complete colour pairs、UNKNOWN/未回収0。各evaluatorは同じ事前固定98 canonical startsを二色196局、全局goal。forfeit/maxply/draw/error終局0。両evaluatorを196独立startsへ水増しせず、旧408や旧400/402の結果を混合しない。原104-family draftは未入場で、実選択98のplan/scheduleだけを照合した。",
    "",
    "|層|A勝/分/敗/UNKNOWN|A得点率|保存A 95%区間|B勝/分/敗/UNKNOWN|B得点率|B 95%区間|",
    "|---|---:|---:|---:|---:|---:|---:|",
]
for c in r["contrasts"]:
    a, b = c["WDL_A"], c["WDL_B"]
    lo, hi = c["native_A_interval"]["percentile_95"]
    blo, bhi = c["B_interval_95"]
    lines.append(
        f"|{c['evaluator']}|{a.get('W', 0)}/{a.get('D', 0)}/{a.get('L', 0)}/{a.get('UNKNOWN', 0)}|{c['mean_A_score']:.6f}|[{lo:.6f},{hi:.6f}]|{b['W']}/{b['D']}/{b['L']}/{b['UNKNOWN']}|{c['mean_B_score']:.6f}|[{blo:.6f},{bhi:.6f}]|"
    )
lines += [
    "",
    "A=fixed_one、B=depth_rank。B score=1−A、区間=[1−A upper,1−A lower]のみを計算した。元nativeの10,000 resamples/seed41220261015によるcomplete family pair区間を引用し、新bootstrapは0。固定book条件付き、家族間交換可能性の仮定とlineage依存未補正という元の限界を保持する。",
    "",
    "## accepted completed snapshotの深さ",
    "",
    "|層/方法|accepted手|完成snapshot n|中央値|平均|p95|最大|fallback|",
    "|---|---:|---:|---:|---:|---:|---:|---:|",
]
for k, m in r["methods"].items():
    d, c = m["selected_completed_depth"], m["counts"]
    lines.append(
        f"|{k}|{c['accepted']}|{d['n']}|{d['median']:g}|{d['mean']:.6f}|{d['p95']}|{d['max']}|{c['fallback']}|"
    )
lines += [
    "",
    "全accepted 20,285手、完成snapshot 20,284件。NNUE Aの合法fallback1手はcompleted depthなしであり、深さ0の完成として扱わない。全depth histogram・色別分母はresult.jsonに保存した。両方法ともLMR ONの選択的nominal depthで、全幅探索資格ではない。nominal設定上限64と実深さを区別する。",
    "",
    "|層/方法|終端前20記録plyの深さ n/中央値/平均|それ以前 n/中央値/平均|",
    "|---|---|---|",
]
for k, m in r["methods"].items():
    a, b = m["final20_recorded_plies_proxy"], m["earlier_recorded_plies"]
    lines.append(
        f"|{k}|{a['n']}/{a['median']:g}/{a['mean']:.3f}|{b['n']}/{b['median']:g}/{b['mean']:.3f}|"
    )
lines += [
    "",
    "終端前20plyは記録手数によるproxyで、wall-stock属性がないため物理的な終盤分類ではない。軌跡・手数・深い尾部が異なり、平均の上昇を探索単体の速さや勝因へ変換しない。",
    "",
    "## 時計・drain・方法対応",
    "",
    "|層/方法|receipt期限以上|terminal return期限以上|commit期限以上|receipt slack最小ms|drain中央値ms|cancelled stop|",
    "|---|---:|---:|---:|---:|---:|---:|",
]
for k, m in r["methods"].items():
    c = m["counts"]
    cl = m["clocks"]
    lines.append(
        f"|{k}|{c['receipt_late_or_equal']}|{c['return_after_deadline']}|{c['commit_after_deadline']}|{cl['receipt_slack_ms']['min']:.6f}|{cl['receipt_to_terminal_drain_ms']['median']:.6f}|{m['stops'].get('cancelled', 0)}|"
    )
lines += [
    "",
    "全acceptedでauthority receipt < caller start+100ms、合法action、matching terminal回収、inflight=0を照合。terminal return/commitがdeadline後でもreceipt lateとは区別する。各手return_reserve設定5ms、reserve stopはuser cancelではないというnative項目は全20,285件true。cancelled stopは記録値として保持し、user取消や不成立対局へ読み替えない。failure/engine_error/first receipt-control error/completed snapshot validation failureはいずれも0。",
    "",
    "両色persistent TTはrequested/effective 1,048,576 slots、retained/persistent cap各83,886,128B。session metadata peakは別gauge。これはRSS/continuous peakではない。authority main core4、AI worker A core2/B core6を全acceptedのnative記録と照合。各ゲームは独立にsession初期化し、方法ごと196 game exposures。actual method ID/namespace/reduction_rule/requested nameをnative profileと各手から一致確認し、Python側でIDを組み立てていない。",
    "",
    "## workの分母",
    "",
    "|層/方法|terminal n|nodes|static evals|delta|PVS再探索|LMR trial/通常深さ確認/fullwindow|TT probes/bound cutoffs|",
    "|---|---:|---:|---:|---:|---:|---|---|",
]
for k, m in r["methods"].items():
    w = m["work_views"]["terminal"]
    lmr = m["LMR_views"]["terminal"]
    lines.append(
        f"|{k}|{m['counts']['terminal_counters_n']}|{w['nodes']}|{w['static_evaluations']}|{w['delta_updates']}|{w['pvs_researches']}|{lmr['attempts']}/{lmr['full_depth_confirmations']}/{lmr['full_window_researches']}|{w['tt_probes']}/{w['tt_bound_cutoffs']}|"
    )
lines += [
    "",
    "terminal totalsとselected completed snapshot totalsはnestedであり加算しない。各scalarのpresent/null分母、全TT/LMR/PVS項目、persistent profileとの照合、caller/thinking/invocation/init等の元scopeはresult.jsonへ保存。TT retained/generationはgauge、重ねてsumしない。static_evaluationsやgeneral nn_callsを物理NNforward回数へ読み替えない。continuous family RSS、全process Search CPU時間、孤立評価/LMR費、全作業費はUNKNOWN。native report peak RSSは元記録のscopeで保持し、連続family peakとは呼ばない。",
    "",
    "## 98 family二色score",
    "",
    "各行はA二色scoreとその平均、B=1−A。順序は事前planのexisting ID順。",
    "",
    "|family|NNUE A二色|NNUE A/B平均|D A二色|D A/B平均|",
    "|---|---|---|---|---|",
]
for a, b in zip(
    r["contrasts"][0]["family_scores"], r["contrasts"][1]["family_scores"], strict=True
):
    assert a["family_id"] == b["family_id"]
    lines.append(
        f"|{a['family_id']}|{a['A_scores']}|{a['A_score']:.2f}/{a['B_score']:.2f}|{b['A_scores']}|{b['A_score']:.2f}/{b['B_score']:.2f}|"
    )
lines += [
    "",
    "## 参照・検証・停止",
    "",
    "settings SHA a9a6c2fa/6163、approved plan/schedule、元sequence、2 manifests/Experiments、2組publication/native manifest/RAWをhash-size-modeでparse前・読取後に一致確認。各compressed SHA、単一gzip member、raw SHA/bytes、196行、各record上限、元journal prefix SHA/bytes、native config/image/cleanupを照合。全RAWは1対局ずつストリームdecodeし、全392局を同時保持していない。既存arena_observationを各行へ再用し、geometry/Search/modelは実行していない。image bb63fc17/Build e934c534は参照だけでpayload未読。",
    "",
    f"実原結果reader STOP {r['reader_STOP']}、小metadata reader STOP {r['metadata_read_STOP']}。directwait/reap/fresh exact identity/handles/TMP/owned[]の最終事実はSTOP.json、affected OWN usageはusage.json、全FileRefsはselected-refs.json/completion.json。",
    "",
    "初回Ruff lintはdynamic Aggregate名とprobe複数importで失敗し、保存解析実行前に修復。原失敗receiptとreturned NULL対disk pending/attemptedを保存、成功後の解析再演0。科学実行/追加ゲーム/旧成功suite/新bootstrap0。Main/Git/Cargo/Beads/backup/closeは324-only。mixed/learner全prep/pipelineと323 USERPAUSE、models/defaults/weights/seals/旧RAWFAILED費UNKNOWNは不変。",
    "",
    "この固定bookでBの主基準は不支持だが、一般的な無効・非劣性・Elo・母集団優越を示さない。重要解釈はRootと同関連reviewerが確認し、追加試合・閾値調整を発行しない。",
]
(OWN / "report.md").write_text("\n".join(lines) + "\n")
print(
    json.dumps(
        dict(
            primary=r["primary_criterion"],
            validation=r["validation"],
            report=ref(OWN / "report.md"),
            result=ref(OWN / "result.json"),
        ),
        ensure_ascii=False,
    )
)
