"""Bounded saved-only interpretation of original412 games; no new bootstrap."""

import ast
import collections
import copy
import datetime
import hashlib
import json
import math
import os
import resource
import sys
import time
import zlib
from pathlib import Path

OWN = Path(__file__).resolve().parent
OLD = OWN.parent / "lmr-adaptive408-analysis-v1"
sys.path.insert(0, str(OLD))
from saved_reader import ORIGINS, lc  # noqa: E402

ROOT = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-standard412-v1/arena392-v1"
)
SELECTED = {}
GAUGES = {"tt_generation", "tt_retained_bytes"}


def ref(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(65536):
            h.update(block)
    stat = path.stat()
    return dict(
        path=str(path),
        sha256=h.hexdigest(),
        bytes=stat.st_size,
        mode=f"{stat.st_mode & 0o777:04o}",
    )


def bound(expected):
    assert ref(expected["path"]) == expected, expected["path"]
    SELECTED[expected["path"]] = expected
    return Path(expected["path"])


def document(expected):
    path = bound(expected)
    assert expected["bytes"] < 2 * 1024**2
    return json.loads(path.read_bytes())


def local(path):
    return document(ref(path))


def rows(path, content, publication, count, cap):
    """Stream the maintained gzip-single-member/raw-hash/record contract."""
    raw_h, prefix_h = hashlib.sha256(), hashlib.sha256()
    raw_n = prefix_n = line_n = 0
    decoder = zlib.decompressobj(31)
    pending = b""
    assert content["encoding"] == "gzip-single-member-v1"
    assert 0 < content["raw_bytes"] <= count * (cap + 1)
    with path.open("rb") as stream:
        while block := stream.read(65536):
            raw = decoder.decompress(block, count * (cap + 1) - raw_n + 1)
            assert not decoder.unused_data and not decoder.unconsumed_tail
            raw_h.update(raw)
            raw_n += len(raw)
            assert raw_n <= content["raw_bytes"]
            pending += raw
            while b"\n" in pending:
                line, pending = pending.split(b"\n", 1)
                line += b"\n"
                assert len(line) <= cap + 1
                if line_n < publication["journal_count"]:
                    prefix_h.update(line)
                    prefix_n += len(line)
                row = json.loads(line)
                if line_n >= publication["journal_count"]:
                    assert row["started"] is False and row["status"] == "unknown"
                line_n += 1
                yield line_n, row
            assert len(pending) <= cap
    assert decoder.eof and not pending
    assert raw_n == content["raw_bytes"] and raw_h.hexdigest() == content["raw_sha256"]
    assert line_n == count
    assert prefix_n == publication["journal_bytes"]
    assert prefix_h.hexdigest() == publication["journal_sha256"]


# Reuse the former owner's aggregation definitions without executing old analysis.
old_ref = ref(OLD / "analyze.py")
tree = ast.parse(bound(old_ref).read_text())
definitions = [
    node
    for node in tree.body
    if isinstance(node, (ast.FunctionDef, ast.ClassDef))
    and node.name in {"measured", "Aggregate"}
]
assert len(definitions) == 2
exec(
    compile(
        ast.Module(body=definitions, type_ignores=[]), str(OLD / "analyze.py"), "exec"
    )
)

Aggregate = globals()["Aggregate"]

start = time.monotonic()
settings_ref = dict(
    path=str(ROOT / "settings.json"),
    sha256="a9a6c2fa841b56e53a48d63634f99131cc47296c12786de86e9f15f57262962c",
    bytes=6163,
    mode="0644",
)
settings = document(settings_ref)
sequence_ref = ref(Path(settings["output"]) / "result.json")
sequence = document(sequence_ref)
assert (
    sequence["status"] == "PASS"
    and sequence["completed_operations"] == sequence["selected_operations"] == 2
)
assert sequence["cleanup_complete"] and not sequence["remaining"]
plan = document(settings["arena"]["template"]["approved_plan"])
schedule = document(plan["schedule"])
families = plan["family_ids"]
assert len(families) == len(set(families)) == 98
assert len(schedule) == plan["planned_slots"] == 392
assert [slot["slot"] for slot in schedule] == list(range(392))
artifact = settings["arena"]["template"]["artifact"]
assert (
    artifact["sha256"]
    == "bb63fc177c1a15eebfa888bbd649591650f725789f045ee6d8d5ee725389c497"
)
aggregates, contrasts, games, global_seen = {}, [], [], set()
manifests = []
for op in sequence["operations"]:
    batch_index = op["index"]
    batch = plan["batches"][batch_index]
    config = document(batch["config"])
    manifest = document(op["manifest"])
    manifests.append(op["manifest"])
    assert manifest["status"] == manifest["data"]["status"] == "PASS"
    assert (
        not manifest["primary"]
        and not manifest["remaining"]
        and manifest["cleanup_complete"]
    )
    assert (
        manifest["build_manifest"]["sha256"]
        == "e934c534bedce904189c30ede4489a53a25c6664d876b87d5ca861b9ca7f56c2"
    )
    experiment = document(manifest["experiment"])
    assert experiment["config"] == batch["config"]
    matchup = plan["matchups"][batch["matchup"]]
    assert config["engines"] == matchup["engines"]
    assert [e["lmr_method"] for e in config["engines"]] == ["fixed_one", "depth_rank"]
    assert (
        config["games"] == 196
        and config["cpu_cores"] == [2, 6]
        and config["management_cpu_core"] == 4
    )
    assert config["max_plies"] == 200
    assert (
        config["arena"]["tt_entries"] == 1048576
        and config["arena"]["return_reserve_ms"] == 5
    )
    assert config["arena"]["search_artifact_sha256"] == [artifact["sha256"]] * 2
    assert all(
        e["lmr"]
        and e["depth"] == 64
        and e["max_nodes"] == 1000000
        and e["time_ms"] == 100
        and e["ordering_profile"] == "control"
        for e in config["engines"]
    )
    files = {Path(r["path"]).name: r for r in manifest["data"]["files"]}
    pub = document(files["result.json"])
    native = document(files["manifest.json"])
    report, summary = pub["report"], native["summary"]
    assert native["result"] == pub and report["outcomes"] == []
    assert report["planned"] == pub["outcome_count"] == 196
    assert report["stopped"] is None and pub["failure_attribution"] is None
    assert report["all_workers_joined"] and native["cleanup"]["archive_closed_verified"]
    serialized = copy.deepcopy(config)
    for flag in ("disable_continuation_static_ordering", "decision_only"):
        if serialized["arena"].get(flag) is False:
            del serialized["arena"][flag]
    assert native["binding"]["config"] == serialized
    assert native["binding"]["executable_sha256"] == artifact["sha256"]
    execution = native["binding"]["execution"]
    assert execution["main_pid"] == execution["main_tid"] == report["process_id"]
    assert execution["management_core"] == execution["management_core_observed"] == 4
    assert execution["AI_cores"] == [2, 6] and execution["AI_workers"] == 2
    assert execution["simultaneous_games"] == 1 and execution["inference_pump"] is False
    for name in ("result.json", "completed.jsonl.gz"):
        assert native["artifacts"][name] == {
            k: files[name][k] for k in ("sha256", "bytes", "mode")
        }
    assert pub["archive"]["compressed"] == files["completed.jsonl.gz"]
    for engine in config["engines"]:
        key = engine["kind"] + ":" + engine["lmr_method"]
        assert key not in aggregates
        aggregates[key] = Aggregate()
    wdl, statuses, reasons = (
        collections.Counter(),
        collections.Counter(),
        collections.Counter(),
    )
    family_scores = collections.defaultdict(list)
    seen = set()
    cap = (
        config["arena"].get("retained_outcome_bytes")
        or config["max_plies"] * 16384 + 16384
    )
    archive = bound(files["completed.jsonl.gz"])
    for line, row in rows(archive, pub["archive"], pub, 196, cap):
        lc.arena_observation(config, row)
        game = row["game"]
        assert type(game) is int and game not in seen and 0 <= game < 196
        seen.add(game)
        slot = schedule[batch["slots"][game]]
        assert slot["batch"] == batch_index and slot["local_game"] == game
        assert slot["candidate_color"] == row["candidate_color"]
        assert slot["slot"] not in global_seen
        global_seen.add(slot["slot"])
        opening = config["arena"]["book"]["openings"][game // 2]
        assert (
            opening["reference"]["settings"]["family_id"]
            == slot["family_id"]
            == families[game // 2]
        )
        statuses[row["status"]] += 1
        reasons[str(row["reason"])] += 1
        if row["status"] in {"goal", "forfeit"} and row["winner"] in (0, 1):
            score = float(row["winner"] == row["candidate_color"])
            outcome = "W" if score else "L"
        elif row["status"] == "draw" and row["winner"] is None:
            score, outcome = 0.5, "D"
        else:
            score, outcome = None, "UNKNOWN"
        wdl[outcome] += 1
        if score is not None:
            family_scores[slot["family_id"]].append(score)
        counts = collections.Counter(o["engine_index"] for o in row["observations"])
        for i, engine in enumerate(config["engines"]):
            profile = row["persistent_tt"][i]
            assert profile["search_invocations"] == counts[i]
            aggregates[engine["kind"] + ":" + engine["lmr_method"]].profile(
                profile, row["candidate_color"] ^ i
            )
        for obs in row["observations"]:
            i = obs["engine_index"]
            assert i == (0 if obs["side"] == row["candidate_color"] else 1)
            c = obs["counters"]
            if obs["accepted"]:
                assert (
                    c["authority_tid"] == report["process_id"]
                    and c["authority_core"] == 4
                )
                assert (
                    c["AI_worker_core"] == [2, 6][i]
                    and c["AI_worker_tid"] != report["process_id"]
                )
                assert c["matching_terminal_collected"] is True
                assert (
                    c["AI_terminal_finished_ns"]
                    <= c["terminal_collected_ns"]
                    <= obs["returned_ns"]
                )
            e = config["engines"][i]
            aggregates[e["kind"] + ":" + e["lmr_method"]].observe(
                obs, e, row["persistent_tt"][i], obs["side"], row["plies"]
            )
        games.append(
            dict(
                global_slot=slot["slot"],
                batch=batch_index,
                local_game=game,
                family_id=slot["family_id"],
                candidate_color=row["candidate_color"],
                started=row["started"],
                status=row["status"],
                winner=row["winner"],
                reason=row["reason"],
                failure=row["failure"],
                A_result=outcome,
                A_score=score,
                plies=row["plies"],
                observations=len(row["observations"]),
                archive_line=line,
            )
        )
    assert seen == set(range(196))
    scores = [
        dict(
            family_id=f,
            A_scores=family_scores[f],
            A_score=math.fsum(family_scores[f]) / 2,
            B_score=1 - math.fsum(family_scores[f]) / 2,
        )
        for f in families
    ]
    assert all(len(s["A_scores"]) == 2 for s in scores)
    assert [s["A_score"] for s in scores] == [s["score"] for s in summary["pairs"]]
    assert math.fsum(s["A_score"] for s in scores) / 98 == summary["complete_pair_mean"]
    contrasts.append(
        dict(
            batch=batch_index,
            evaluator=config["engines"][0]["kind"],
            WDL_A=dict(wdl),
            statuses=dict(statuses),
            reasons=dict(reasons),
            family_scores=scores,
            mean_A_score=summary["complete_pair_mean"],
            mean_B_score=1 - summary["complete_pair_mean"],
            native_A_interval=summary["bootstrap"],
            native_summary=summary,
            manifest=op["manifest"],
            files=files,
            archive_raw_bytes=pub["archive"]["raw_bytes"],
            archive_raw_sha256=pub["archive"]["raw_sha256"],
            native_report_wall_seconds=report["wall_seconds"],
            native_peak_rss=report["peak_rss"],
            general_nn_calls=report["nn_calls"],
            execution=execution,
            declared_model_identity=matchup["evaluator_sha256"],
        )
    )
    del row, native, pub

assert global_seen == set(range(392)) and len(games) == 392
methods = {key: a.output() for key, a in aggregates.items()}
assert len(methods) == 4 and all(
    len(m["actual_method_ids"]) == len(m["actual_namespace"]) == 1
    for m in methods.values()
)
total = collections.Counter()
for method in methods.values():
    total.update(method["counts"])
for expected in SELECTED.values():
    assert ref(expected["path"]) == expected
reader_stop = datetime.datetime.now(datetime.UTC).isoformat()
result = dict(
    issue="quoridor-4lc.412.2",
    scope="original392 saved analysis",
    census=dict(
        planned=392,
        unique=392,
        entered=sum(g["started"] for g in games),
        returned=len(games),
        complete_pairs=sum(
            c["native_summary"]["census"]["complete_pairs"] for c in contrasts
        ),
        unknown=sum(c["WDL_A"].get("UNKNOWN", 0) for c in contrasts),
        shared_canonical_starts=98,
    ),
    contrasts=contrasts,
    methods=methods,
    observation_census=dict(total),
    games=games,
    settings=settings_ref,
    sequence=sequence_ref,
    manifests=manifests,
    image_declared_only=artifact,
    saved_reader_sources=ORIGINS,
    aggregation_source=old_ref,
    reader_STOP=reader_stop,
    costs=dict(
        analysis_wall_seconds=time.monotonic() - start,
        self_ru_maxrss_B=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        worker_affinity=sorted(os.sched_getaffinity(0)),
        continuous_family_peak="UNKNOWN",
    ),
    limitations=[
        "primary NNUE and secondary D separate; same98 starts shared",
        "native family interval quoted without bootstrap rerun",
        "selective nominal depth; different trajectories and terminal mix",
        "terminal work and selected snapshot nested/nonadditive; TT bytes gauges",
        "physical forwards/isolated cost/continuous RSS/all-process Search time UNKNOWN",
        "no old408 RAW, no new games/Search/model/bootstrap",
        "existing default choice independent from finite strength evidence",
    ],
    new_science=0,
)
(OWN / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n"
)
(OWN / "selected-refs.json").write_text(
    json.dumps(list(SELECTED.values()), indent=2) + "\n"
)
print(
    json.dumps(
        dict(
            census=result["census"],
            contrasts=[
                {
                    k: c[k]
                    for k in ("evaluator", "WDL_A", "mean_B_score", "native_A_interval")
                }
                for c in contrasts
            ],
            methods={
                k: dict(depth=m["selected_completed_depth"], counts=m["counts"])
                for k, m in methods.items()
            },
            reader_STOP=reader_stop,
            costs=result["costs"],
        )
    )
)
