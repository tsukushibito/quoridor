import ast
import gzip
import hashlib
import json
from pathlib import Path

root = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-standard412-v1/arena392-v1"
)


def read(p):
    b = p.read_bytes()
    print("REF", str(p), hashlib.sha256(b).hexdigest(), len(b))
    return json.loads(b)


s = read(root / "settings.json")
plan = read(Path(s["arena"]["template"]["approved_plan"]["path"]))
seq = read(Path(s["output"]) / "result.json")
print("PLAN", json.dumps(plan)[:14000])
print("SEQ", json.dumps(seq)[:6000])
for op in seq["operations"]:
    m = read(Path(op["manifest"]["path"]))
    print("MANIFEST", json.dumps(m)[:13000])
    for ref in m["data"]["files"]:
        if Path(ref["path"]).name in ("manifest.json", "result.json"):
            d = read(Path(ref["path"]))
            print("NATIVE", json.dumps(d)[:14000])
    break
old = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/lmr-adaptive408-analysis-v1"
)
src = gzip.decompress(
    (old / "research-lifecycle.py.immutable.gz").read_bytes()
).decode()
for n in ast.parse(src).body:
    if isinstance(n, ast.FunctionDef) and n.name in (
        "arena_reference_report",
        "arena_observation",
        "arena_outcome",
        "arena_archive",
    ):
        print("FUNCTION", ast.get_source_segment(src, n))
