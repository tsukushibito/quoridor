"""Final exact saved-reference checks and reader/report closure, no new analysis."""

import hashlib
import json
import resource
import stat
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
scout = json.loads((OWN / "scout.json").read_text())
refs = {ref["path"]: ref for ref in scout["bindings"]}
for ref in json.loads((OWN / "selectedrefs.json").read_text()):
    refs[ref["path"]] = ref
semantics = json.loads((OWN / "source-semantics.json").read_text())
for ref in semantics["refs_before_after"]:
    refs[ref["path"]] = ref
for ref in refs.values():
    path = Path(ref["path"])
    info = path.stat()
    assert (
        info.st_size == ref["bytes"]
        and f"{stat.S_IMODE(info.st_mode):04o}" == ref["mode"]
    )
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(64 * 1024), b""):
            digest.update(chunk)
    assert digest.hexdigest() == ref["sha256"], path
(OWN / "selectedrefs.json").write_text(
    json.dumps(list(refs.values()), ensure_ascii=False, indent=2) + "\n"
)
report_path = OWN / "report.md"
report = report_path.read_text()
report = report.replace(
    "Cheapは既存signed keyへの整数静的項を同じ正本係数で加える。",
    "Controlは共通signed history/keyとgoal tierを保持し、Cheapだけが整数静的項を加える。Cheapのpawn進捗係数は128、距離差の符号gapは±64、壁近接は相手128/64・自分64/32、既存壁接点64、水平外縁32、pawnからの直接下降edge遮断差96。これはsource係数の説明であり、各項の時間利益や棋力寄与は未分離。",
)
result = json.loads((OWN / "result.json").read_text())
index = json.loads((OWN / "game-index.json").read_text())
assert len(index) == result["observed_original_unique_games"] == 128
assert result["complete_pairs"] == 64 and result["unknown_games"] == 0
assert (
    sum(
        m["counts"]["observations"]
        for m in result["method_exposures_not_independent"].values()
    )
    == 6765
)
assert all(g["status"] == "goal" and g["failure"] is None for g in index)
assert all(b["native_census"]["incomplete_pairs"] == 0 for b in result["batches"])
assert all(
    m["counts"]["accepted"]
    == m["counts"]["matching_terminal_collected"]
    == m["counts"]["inflight_zero_recorded"]
    == m["counts"]["actual_method_recorded"]
    == m["counts"]["observations"]
    for m in result["method_exposures_not_independent"].values()
)
report_path.write_text(report)
# Retain selection/refs and result, discard the temporary copied detailed row and source snippets.
scout["records"] = [
    {
        "batch": r["batch"],
        "config_source": r["manifest"]["experiment"],
        "lifecycle_status": r["manifest"]["status"],
    }
    for r in scout["records"]
]
scout.pop("consumer_functions", None)
(OWN / "scout-metadata.json").write_text(
    json.dumps(scout, ensure_ascii=False, indent=2) + "\n"
)
(OWN / "scout.json").unlink()
print(
    json.dumps(
        {
            "fixed_report": "report.md",
            "exact_after_refs": len(refs),
            "temporary_detailed_row_removed": True,
            "scientific_calls": 0,
        }
    )
)
