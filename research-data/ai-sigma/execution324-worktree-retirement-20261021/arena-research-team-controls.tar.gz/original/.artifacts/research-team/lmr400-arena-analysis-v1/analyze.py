"""Original saved arena interpretation through the maintained reference consumer."""

import collections
import hashlib
import importlib.util
import json
import math
import resource
import stat
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
LC = MAIN / "scripts/dev/research-lifecycle.py"
assert (
    hashlib.sha256(LC.read_bytes()).hexdigest()
    == "1b1a94450a577b4957a7e1cdf2c9bf49bf510343f6c261480d40f317c8b895da"
)
loader = importlib.util.spec_from_file_location("saved_arena_lifecycle", LC)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)
refs = {}


def read(ref):
    path = Path(ref["path"])
    info = path.stat()
    assert (
        info.st_size == ref["bytes"]
        and f"{stat.S_IMODE(info.st_mode):04o}" == ref["mode"]
    )
    data = lc.read_ref(ref, max(ref["bytes"], lc.CONTROL_BYTES))
    refs[str(path)] = ref
    return data


def document(ref):
    return json.loads(read(ref))


def measured(values):
    if not values:
        return {
            "n": 0,
            "min": None,
            "median": None,
            "p95": None,
            "max": None,
            "mean": None,
        }
    values = sorted(values)
    n = len(values)
    mid = (values[(n - 1) // 2] + values[n // 2]) / 2
    return {
        "n": n,
        "min": values[0],
        "median": mid,
        "p95": values[math.ceil(0.95 * n) - 1],
        "max": values[-1],
        "mean": math.fsum(values) / n,
    }


class Aggregate:
    def __init__(self):
        self.counts = collections.Counter()
        self.stops = collections.Counter()
        self.reasons = collections.Counter()
        self.failures = collections.Counter()
        self.depths = []
        self.caller = []
        self.thinking = []
        self.slack = []
        self.drain = []
        self.terminal = collections.Counter()
        self.snapshot = collections.Counter()
        self.terminal_present = collections.Counter()
        self.snapshot_present = collections.Counter()
        self.terminal_null = collections.Counter()
        self.lmr_terminal = collections.Counter()
        self.lmr_snapshot = collections.Counter()
        self.tt = collections.Counter()
        self.tt_peaks = collections.Counter()
        self.namespaces = set()

    def observe(self, obs, engine):
        self.counts["observations"] += 1
        self.counts["accepted"] += int(obs["accepted"])
        self.counts["not_accepted"] += int(not obs["accepted"])
        self.counts["failure"] += int(obs["failure"] is not None)
        self.counts["engine_error"] += int(obs["engine_error"] is not None)
        if obs["failure"] is not None:
            self.failures[str(obs["failure"])] += 1
        if obs["engine_error"] is not None:
            self.failures["engine:" + str(obs["engine_error"])] += 1
        self.stops[str(obs["stop"])] += 1
        c = obs["counters"]
        self.reasons[str(c.get("selection_reason"))] += 1
        fallback = c.get("selection_reason") == "legal_fallback_no_completed_iteration"
        self.counts["zero_completed_fallback"] += int(fallback)
        depth = obs["completed_depth"]
        if depth is not None:
            self.depths.append(depth)
        else:
            self.counts["null_completed_depth"] += 1
        for field, values in [
            ("caller_seconds", self.caller),
            ("thinking_seconds", self.thinking),
        ]:
            if obs.get(field) is not None:
                values.append(obs[field])
        receipt, deadline = c.get("authority_receipt_ns"), obs.get("deadline_ns")
        if type(receipt) is int and type(deadline) is int:
            self.counts["receipt_clock_recorded"] += 1
            self.counts["receipt_late_or_equal"] += int(receipt >= deadline)
            self.slack.append((deadline - receipt) / 1e6)
            self.drain.append((obs["returned_ns"] - receipt) / 1e6)
        self.counts["matching_terminal_collected"] += int(
            c.get("matching_terminal_collected") is True
        )
        self.counts["inflight_zero_recorded"] += int(c.get("inflight_after_drain") == 0)
        self.counts["reserve_stop_not_user_cancel"] += int(
            c.get("reserve_stop_is_not_user_cancel") is True
        )
        self.counts["first_receipt_or_control_error"] += int(
            c.get("first_receipt_or_control_error") is not None
        )
        method = c.get("actual_search_namespace")
        if method is not None:
            assert type(c.get("actual_lmr_enabled")) is bool and c[
                "actual_lmr_enabled"
            ] == engine.get("lmr", False)
            self.counts["actual_method_recorded"] += 1
            self.namespaces.add(json.dumps(method, sort_keys=True))
        for counters, total, present, nulls in [
            (
                c.get("whole_search"),
                self.terminal,
                self.terminal_present,
                self.terminal_null,
            ),
            (
                obs.get("completed_iteration_counters"),
                self.snapshot,
                self.snapshot_present,
                None,
            ),
        ]:
            if counters is None:
                continue
            for name, value in counters.items():
                if type(value) is int and not name.endswith(
                    ("bytes", "generation", "peak")
                ):
                    total[name] += value
                    present[name] += 1
                elif value is None and nulls is not None:
                    nulls[name] += 1
        for key, total in [
            ("lmr_work_terminal", self.lmr_terminal),
            ("lmr_work_completed", self.lmr_snapshot),
        ]:
            if c.get(key) is not None:
                for name, value in c[key].items():
                    assert type(value) is int and value >= 0
                    total[name] += value

    def profile(self, profile, observations):
        assert profile["actual_lmr_enabled"] in (False, True)
        totals = collections.Counter()
        for obs in observations:
            for name, value in (obs["counters"].get("lmr_work_terminal") or {}).items():
                totals[name] += value
        assert profile["lmr_attempts"] == totals["attempts"]
        assert (
            profile["lmr_full_depth_confirmations"]
            == totals["full_depth_confirmations"]
        )
        assert profile["lmr_full_window_researches"] == totals["full_window_researches"]
        for name, value in profile.items():
            if type(value) in (int, float):
                if name.endswith("peak") or name in {
                    "requested_tt_entries",
                    "effective_tt_slots",
                    "persistent_tt_byte_cap",
                    "shared_evaluator_bytes",
                }:
                    self.tt_peaks[name] = max(self.tt_peaks[name], value)
                else:
                    self.tt[name] += value

    def output(self):
        return {
            "counts": dict(self.counts),
            "stops": dict(self.stops),
            "selection_reasons": dict(self.reasons),
            "failure_kinds": dict(self.failures),
            "observed_selected_depth": measured(self.depths),
            "selected_depth_histogram": dict(collections.Counter(self.depths)),
            "caller_seconds": {"sum": math.fsum(self.caller), **measured(self.caller)},
            "selected_iteration_thinking_seconds": {
                "sum": math.fsum(self.thinking),
                **measured(self.thinking),
            },
            "deadline_minus_actual_receipt_ms": measured(self.slack),
            "returned_minus_actual_receipt_ms": measured(self.drain),
            "terminal_work": dict(self.terminal),
            "terminal_field_denominators": dict(self.terminal_present),
            "terminal_null_unknown_fields": dict(self.terminal_null),
            "selected_snapshot_work_nested_not_added": dict(self.snapshot),
            "snapshot_field_denominators": dict(self.snapshot_present),
            "lmr_terminal_work": dict(self.lmr_terminal),
            "lmr_selected_work_nested_not_added": dict(self.lmr_snapshot),
            "persistent_TT_profile_additive": dict(self.tt),
            "persistent_TT_profile_peaks_not_added": dict(self.tt_peaks),
            "actual_namespaces": [json.loads(s) for s in sorted(self.namespaces)],
        }


intake = json.loads((OWN / "intake.json").read_text())
for record in intake:
    document(record["ref"])
plan = intake[1]["data"]
schedule = document(plan["schedule"])
if isinstance(schedule, dict):
    schedule = schedule.get("slots", schedule.get("schedule"))
assert len(schedule) == 128 and len({s["slot"] for s in schedule}) == 128
selected = json.loads((OWN / "scout.json").read_text())["records"]
global_games = []
batches = []
methods = collections.defaultdict(Aggregate)
validation = collections.Counter()
for saved in selected:
    batch = saved["batch"]
    cfgref = plan["batches"][batch]["config"]
    config = document(cfgref)
    manifest = saved["manifest"]
    expected_build = document(manifest["build_manifest"])
    assert (
        expected_build["status"] == "PASS"
        and expected_build["artifact"]["sha256"]
        == "66c0daac3102a52a8a11e062e50be4a3d7b52c35f3b1305c057c479899b5d536"
    )
    files = {
        next(
            name
            for name, suffix in {
                "journal": "completed.jsonl.gz",
                "result": "result.json",
                "native_manifest": "manifest.json",
            }.items()
            if ref["path"].endswith("/" + suffix)
        ): ref
        for ref in manifest["data"]["files"]
    }
    values = {name: read(ref) for name, ref in files.items()}
    report = lc.arena_reference_report(config, files, values, expected_build)
    summary = report["arena_summary"]
    bs = [Aggregate(), Aggregate()]
    wdl = collections.Counter({"wins": 0, "draws": 0, "losses": 0, "unknown": 0})
    colour_wdl = {0: collections.Counter(), 1: collections.Counter()}
    family_scores = collections.defaultdict(list)
    status_counts = collections.Counter()
    slots = {s["local_game"]: s for s in schedule if s["batch"] == batch}
    assert len(slots) == config["games"] == 16
    for row in report["outcomes"]:
        lc.arena_observation(config, row)
        local = row["game"]
        slot = slots[local]
        family = config["arena"]["book"]["openings"][local // 2]
        family_id = family["reference"]["settings"]["family_id"]
        assert (
            family_id == slot["family_id"]
            and row["candidate_color"] == slot["candidate_color"]
        )
        native_pair = next(
            p for p in summary["pairs"] if p["lineage"] == family["lineage"]
        )
        assert row["family"] == native_pair["family"]
        assert slot["matchup"] == batch
        # Native statuses are authoritative; max-ply/unknown/error are never draws.
        if row["status"] == "draw":
            kind, score = "draws", 0.5
        elif row["status"] in {"goal", "forfeit"} and row["winner"] is not None:
            kind = "wins" if row["winner"] == row["candidate_color"] else "losses"
            score = 1.0 if kind == "wins" else 0.0
        else:
            kind, score = "unknown", None
        wdl[kind] += 1
        colour_wdl[row["candidate_color"]][kind] += 1
        status_counts[row["status"] + ":" + str(row["reason"])] += 1
        family_scores[family_id].append(score)
        for i, engine in enumerate(config["engines"]):
            obs = [o for o in row["observations"] if o["engine_index"] == i]
            condition = f"{engine['kind']}/{engine['ordering_profile']}/{'ON' if engine.get('lmr', False) else 'OFF'}"
            for o in obs:
                expected_side = (
                    row["candidate_color"] if i == 0 else row["candidate_color"] ^ 1
                )
                assert o["side"] == expected_side
                bs[i].observe(o, engine)
                methods[condition].observe(o, engine)
            profile = row["persistent_tt"][i]
            assert profile["actual_lmr_enabled"] == engine.get("lmr", False)
            assert profile["requested_tt_entries"] == config["arena"]["tt_entries"]
            bs[i].profile(profile, obs)
            methods[condition].profile(profile, obs)
        global_games.append(
            {
                "slot": slot["slot"],
                "batch": batch,
                "local_game": local,
                "family_id": family_id,
                "family": row["family"],
                "candidate_colour": row["candidate_color"],
                "candidate_engine": 0,
                "status": row["status"],
                "winner": row["winner"],
                "reason": row["reason"],
                "plies": row["plies"],
                "started": row["started"],
                "failure": row["failure"],
                "observations": len(row["observations"]),
                "source_journal": files["journal"],
            }
        )
        validation["games_existing_consumer_pass"] += 1
        validation["observations_existing_consumer_pass"] += len(row["observations"])
    fs = []
    for family_id in plan["family_ids"]:
        scores = family_scores[family_id]
        assert len(scores) == 2
        value = sum(scores) / 2 if all(s is not None for s in scores) else None
        recorded = next(
            p["score"]
            for p in summary["pairs"]
            if p["lineage"] == f"original355-family-{family_id}"
        )
        assert recorded == value
        fs.append({"family_id": family_id, "score_left": value})
    assert (
        sum(wdl.values()) == 16 and summary["census"]["unknown_games"] == wdl["unknown"]
    )
    assert summary["census"]["complete_pairs"] == sum(
        f["score_left"] is not None for f in fs
    )
    batches.append(
        {
            "batch": batch,
            "config": cfgref,
            "engines": config["engines"],
            "tt_entries": config["arena"]["tt_entries"],
            "resource_roles": {
                "AI_cores": config["cpu_cores"],
                "main": config["management_cpu_core"],
            },
            "lifecycle_status_original": manifest["status"],
            "saved_validation_scope": "SAVED_DATA_VALIDATED separate from original FAILED"
            if batch == 0
            else "original PASS data",
            "wdl_left": dict(wdl),
            "by_left_colour": {str(k): dict(v) for k, v in colour_wdl.items()},
            "native_status_reason": dict(status_counts),
            "native_census": summary["census"],
            "family_scores": fs,
            "native_bootstrap_not_recomputed": summary["bootstrap"],
            "mean_family_score_left": summary["complete_pair_mean"],
            "left_observations": bs[0].output(),
            "right_observations": bs[1].output(),
            "native_wall_seconds": report["wall_seconds"],
            "native_single_peak_rss_B": report["peak_rss"],
            "journal": files["journal"],
            "native_summary": files["result"],
            "native_manifest": files["native_manifest"],
            "runtime_execution": saved["data"]["manifest.json"]["binding"]["execution"],
        }
    )
    del report, values
assert sorted(g["slot"] for g in global_games) == list(range(128))
assert len({g["slot"] for g in global_games}) == 128
for ref in refs.values():
    lc.read_ref(ref, max(ref["bytes"], lc.CONTROL_BYTES))
result = {
    "planned_original_games": 128,
    "observed_original_unique_games": 128,
    "complete_pairs": sum(b["native_census"]["complete_pairs"] for b in batches),
    "unknown_games": sum(b["wdl_left"]["unknown"] for b in batches),
    "batches": batches,
    "method_exposures_not_independent": {k: v.output() for k, v in methods.items()},
    "validation": dict(validation),
    "native_calls_new": 0,
    "bootstrap_new": 0,
    "all_search_time_physical_forward_continuous_RSS_peak": "UNKNOWN; recorded terminal/profile/caller scalars have their stated narrower scopes",
    "important_adoption": "Root and related reviewer own; conditional fixed8-family descriptive result only",
}
(OWN / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
(OWN / "game-index.json").write_text(
    json.dumps(global_games, ensure_ascii=False, indent=2) + "\n"
)
(OWN / "selectedrefs.json").write_text(
    json.dumps(list(refs.values()), ensure_ascii=False, indent=2) + "\n"
)
print(
    json.dumps(
        {
            "games": len(global_games),
            "complete_pairs": result["complete_pairs"],
            "unknown": result["unknown_games"],
            "validation": result["validation"],
            "scientific_calls": 0,
        }
    )
)
