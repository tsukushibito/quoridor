"""Source semantics and compact human report from already collected saved facts."""

import hashlib
import json
import resource
import stat
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
source_refs = []
snippets = {}
for name in ["cheap_static_ordering.rs", "alphabeta.rs"]:
    path = MAIN / "crates/quoridor-ai/src" / name
    raw = path.read_bytes()
    info = path.stat()
    source_refs.append(
        {
            "path": str(path),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "mode": f"{stat.S_IMODE(info.st_mode):04o}",
        }
    )
    text = raw.decode()
    if name == "cheap_static_ordering.rs":
        snippets[name] = text
    else:
        rows = text.splitlines()
        selected = set()
        for i, line in enumerate(rows):
            if any(
                key in line
                for key in [
                    "context.parent_wall_distances",
                    "wall_distances_for_both",
                    "cheap_static_ordering::",
                    "pub fn set_lmr",
                    "pub fn lmr_enabled",
                    "LMR_METHOD",
                    "ordering_parent_maps",
                    "CheapStaticControl =>",
                    "CombinedSignedCheapStatic =>",
                ]
            ):
                selected.update(range(max(0, i - 5), min(len(rows), i + 20)))
        snippets[name] = "\n".join(f"{i + 1}: {rows[i]}" for i in sorted(selected))
for ref in source_refs:
    raw = Path(ref["path"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ref["sha256"]
(OWN / "source-semantics.json").write_text(
    json.dumps(
        {
            "refs_before_after": source_refs,
            "selected_text": snippets,
            "status": "SOURCE_ONLY_NO_BUILD_OR_FORWARD",
            "geometry_model_native_Search_calls": 0,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
result = json.loads((OWN / "result.json").read_text())
index = json.loads((OWN / "game-index.json").read_text())
for condition, record in result["method_exposures_not_independent"].items():
    record["game_exposures"] = 32
    record["game_exposure_meaning"] = (
        "Each condition occurs in two16-game contrasts on the same8families; exposures/moves are not independent samples"
    )
result["source_semantics_ref"] = {
    "path": str(OWN / "source-semantics.json"),
    "sha256": hashlib.sha256((OWN / "source-semantics.json").read_bytes()).hexdigest(),
    "bytes": (OWN / "source-semantics.json").stat().st_size,
    "mode": "0644",
}
(OWN / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
rows = [
    "# LMRとControl/Cheapの固定128局：保存結果の解釈",
    "",
    "同じ8開幕family・各2色の承認済み128局は、全128局がgoal、64色pairが完成し、対局UNKNOWN・draw・forfeitは0だった。最初の16局は原lifecycle manifestがFAILEDのまま、別SAVED_DATA_VALIDATEDにより保存棋譜を解釈する。後続112局は七つの正常manifestに属する。追加対局・探索・モデル評価・bootstrapは0。",
    "",
    "## 対照ごとの勝分負",
    "",
    "左条件から見た結果。区間は保存されたnative family-pair bootstrap95%をそのまま引用し、再計算していない。全対照で同じfamilyを再使用しており、8件の独立な新book標本や128独立標本とは扱わない。条件固定book内・exchangeable family仮定の区間で、Elo/非劣性/正式棋力ではない。",
    "",
    "|評価|左 vs 右|勝-分-負-UNKNOWN|左family平均|保存95%区間|",
    "|---|---|---:|---:|---:|",
]
for batch in result["batches"]:
    left, right = batch["engines"]

    def label(e):
        return e["ordering_profile"].capitalize() + (
            " ON" if e.get("lmr", False) else " OFF"
        )

    w = batch["wdl_left"]
    ci = batch["native_bootstrap_not_recomputed"]["percentile_95"]
    rows.append(
        f"|{'NNUE/BEST43' if left['kind'] == 'nnue' else '固定D(0,8tanh)'}|{label(left)} vs {label(right)}|{w['wins']}-{w['draws']}-{w['losses']}-{w['unknown']}|{batch['mean_family_score_left']:.4f}|[{ci[0]:.4f}, {ci[1]:.4f}]|"
    )
rows += [
    "",
    "NNUEではControl OFFがCheap OFFに14勝2敗、ON同士でも10勝6敗だった。LMR追加そのものはControlで8勝8敗、CheapでOFF側10勝6敗。固定DではControlのLMR ON側9勝7敗、CheapのON側7勝9敗。DのControl ON対Cheap ONはCheap側11勝5敗となり、NNUEと同じ結論へ移植できない。いずれも有限の同book観測で、一般的なLMR/Cheapの有効・無効や採否を確定しない。特に二つの区間が0.5を含まないことも、複数対照・再使用familyを補正した検定ではない。最終採否/strength解釈はRootと関連reviewerが所有する。",
    "",
    "## 8familyのpair score",
    "",
    "各scoreは左条件の2色平均。0/0.5/1はそれぞれ0/1/2勝（今回draw0）。",
    "",
    "|対照batch|23|29|34|46|64|93|105|108|",
    "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
]
for batch in result["batches"]:
    rows.append(
        "|"
        + str(batch["batch"])
        + "|"
        + "|".join(str(f["score_left"]) for f in batch["family_scores"])
        + "|"
    )
rows += [
    "",
    "batch0..3はNNUE、4..7はD、各々Control OFF/ON、Cheap OFF/ON、Control OFF/Cheap OFF、Control ON/Cheap ONの順。global slot/local game/family/candidate色/勝者/原journalはgame-index.json、各Config・model/evaluator・method・TT・CPU・source refsはresult.jsonとselectedrefs.jsonへ対応させた。原family名とbook opening IDは異なるので、native summaryのlineage＋plan/configの実family IDで結び、単なる文字列一致を仮定していない。",
    "",
    "## 実選択とterminal work",
    "",
    "全6765観測がacceptedで、zero-completed合法fallback、engine error、受理失敗、deadline以上receipt、未回収terminal、残inflight、first receipt/control errorは0。全6765件で実namespace/LMR getter・main/AI core・matching terminal chronologyを既存consumerが検証した。stop=cancelledは14件あるが全てreserve_stop_is_not_user_cancel=trueかつ有効な完成snapshotを選択しており、ユーザー取消や未完成対局として数えない。原因の未記録部分は推測しない。",
    "",
    "下表は各条件が二対照に登場した32game exposuresのmove集計。局面・手数・軌跡が違い独立標本でも同work対照でもない。深さは選択された完成snapshotのnominal depthで、LMR ONは全幅depthの証明ではない。nodes/evals/LMRは各手のterminal whole_search/lmr_work_terminalの総和だけ。内包されたselected snapshotやpersistent TT集計を加算していない。",
    "",
    "|方法|accepted手|選択depth min/中央値/max|terminal nodes|static evals|LMR試行/全depth確認/全window再探索|",
    "|---|---:|---:|---:|---:|---:|",
]
for condition, rec in result["method_exposures_not_independent"].items():
    d, work, lmr = (
        rec["observed_selected_depth"],
        rec["terminal_work"],
        rec["lmr_terminal_work"],
    )
    rows.append(
        f"|{condition}|{rec['counts']['accepted']}|{d['min']}/{d['median']:g}/{d['max']}|{work.get('nodes', 'UNKNOWN'):,}|{work.get('static_evaluations', 'UNKNOWN'):,}|{lmr.get('attempts', 0)}/{lmr.get('full_depth_confirmations', 0)}/{lmr.get('full_window_researches', 0)}|"
    )
rows += [
    "",
    "PVS/TT probes・hits・cutoff・replacement・context等の実scalarとそれぞれの記録件数、selected snapshotの別総和、TT容量・namespace reset・初期化、clock slack/drain/callerの記録分母はmachine resultに保存した。terminal LMR総和と原persistent TTの三work総和は各game/engineで一致を確認。OFFのLMR三workは全0。全terminalでphysical_nn_calls/leaf_countはnullのためUNKNOWN。native nn_calls=0をNNUE forwardが無かった証拠にしない。search invocation/成功result elapsed/callerは保存された該当範囲の実時間で、全検索時間・部位費・連続RSS peakではない。",
    "",
    "## 設定と残る仮説",
    "",
    "全対照はsame image66c0daac/Buildde4、同じ100ms authority receiptと5ms reserve、200ply、設定depth64/node安全上限1M。NNUEはBEST43・TT4096、Dは(0,8tanh)・TT1048576で別stratum。AI2/6、main4、scalar、既存goal-first/true三fold/fullhistoryを保存設定と実executionに対応させた。source-semantics.jsonは現Cheap係数・正本parent map経路・LMR/method設定の小さいsource参照であり、新しい実測やsourceclearの再認定ではない。",
    "",
    "Cheapは既存signed keyへの整数静的項を同じ正本係数で加える。fixedDでparent accumulatorが無い場合は正本位置から既存距離マップを計算する経路を使用し、偽mapや別Cheap式は使用しない。map生成費・採点費・LMR確認費の部位別分離は未記録でUNKNOWN。Control/Cheap・ON/OFFで実namespaceは分離され、TT/historyのmethod混用を避け、recorded namespace resetは別scalarとして保持する。",
    "",
    "LMRは実nominal選択depthを上げる傾向があるが、今回のmove平均/中央値と勝敗は別の観測。Cheapの低nodesを時間短縮や棋力利益へ置換しない。最小の次判断材料は、Rootの別96call同設定探索費解析と本family対照を並べ、NNUE/Dを分けて確認すること。追加試合・parameter tuning・追試・学習・新bootstrapをここから発行しない。",
    "",
    "## 保存検証と停止",
    "",
    "原設定/plan/schedule/Config/Experiment/Build/manifest/compressed journal/resultをSHA-size-mode beforeparse/afterで照合し、既存arena_reference_reportとarena_observationを再使用した。global128slotの重複・欠測0、native census・family scoreと直接WDLの算術が一致。最初の16局のFAILED原manifest・別saved validation、七つの正常manifestを維持し、再finalize・原RAW書換え・再ゲームは0。",
    "",
    "通知のLC SHAと実whole-file SHAに相違があったため入場前拒否を保存し、current LCと指定immutableGit2001f68がbyte一致する1b1a9445を実確認して使用した。元のsaved validation相対pathの不足と、自分のfamily ID文字列同一という誤仮定の失敗・NULL returned guardian/capturefalseは原記録のまま保持し、必要なmetadata修正後の解析PASSと区別する。source/test/model/native成功の再演は0。",
    "",
    "reader STOP、実guard/directwait/reap/handles、fresh original identities、TMP撤去、返却とpersisted masks、beforeafter refsと対象usageはcompletion.jsonに保存する。ordinary storageNone、対象OWNのみ一回usage、global actual/peakはUNKNOWN。混合・learner全準備/全pipelineと323 USERPAUSE、models/defaults/seals/oldfits96/旧RAW・FAILED・費・UNKNOWNは維持する。",
]
(OWN / "report.md").write_text("\n".join(rows) + "\n")
print(
    json.dumps(
        {
            "report": "report.md",
            "source_files": len(source_refs),
            "additional_scientific_calls": 0,
        }
    )
)
