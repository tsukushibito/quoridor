"""Bounded initial saved-metadata intake; no native or model entry."""

import hashlib
import json
import resource
import stat
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
TEAM = ROOT / ".artifacts/research-team/integration324/lmr400-v1"
paths = [
    TEAM / "arena128-v4/settings.json",
    TEAM / "arena128-v4/plan.json",
    TEAM / "arena128-v4/settings-unentered1-7-v1.json",
    TEAM / "arena128-v4/STOP-unentered1-7-v1.json",
    TEAM / "saved-batch0-validation-v3/result.json",
    TEAM / "saved-batch0-validation-v3/STOP.json",
    TEAM / "review-arena-consumer-acceptance.json",
    ROOT
    / ".worktree/assets/perf/lmr400-arena128-v4/execution-unentered1-7-v1/result.json",
    ROOT
    / ".worktree/assets/perf/lmr400-arena128-v4/execution-v1/arena-000/operation/manifest.json",
]


def reference(path):
    info = path.stat()
    assert stat.S_ISREG(info.st_mode) and info.st_size < 16 * 1024**2, path
    raw = path.read_bytes()
    assert len(raw) == info.st_size
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }, raw


records = []
for path in paths:
    binding, raw = reference(path)
    data = json.loads(raw)
    records.append({"ref": binding, "data": data})
for record in records:
    assert reference(Path(record["ref"]["path"]))[0] == record["ref"]
(OWN / "intake.json").write_text(
    json.dumps(records, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps({"bound_saved_metadata": len(records), "science_calls": 0}))
