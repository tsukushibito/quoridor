"""Inspect only bound arena data layout and the existing saved consumers."""

import ast
import gzip
import hashlib
import json
import resource
import stat
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
bindings = []


def load(path, expected=None):
    path = Path(path)
    s = path.stat()
    assert s.st_size < 32 * 1024**2 and stat.S_ISREG(s.st_mode)
    raw = path.read_bytes()
    ref = {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(s.st_mode):04o}",
    }
    if expected is not None:
        assert ref == expected, (ref, expected)
    bindings.append(ref)
    return json.loads(raw)


intake = json.loads((OWN / "intake.json").read_text())
for record in intake:
    load(record["ref"]["path"], record["ref"])
plan = intake[1]["data"]
sequence = intake[7]["data"]
manifests = [(0, intake[8]["data"])]
for operation in sequence["operations"]:
    manifests.append(
        (operation["index"], load(operation["manifest"]["path"], operation["manifest"]))
    )
records = []
for batch, manifest in manifests:
    data = {}
    for ref in manifest["data"]["files"]:
        if ref["path"].endswith(".json"):
            data[Path(ref["path"]).name] = load(ref["path"], ref)
    experiment = load(manifest["experiment"]["path"], manifest["experiment"])
    cfgref = plan["batches"][batch]["config"]
    config = load(cfgref["path"], cfgref)
    journal = next(
        ref for ref in manifest["data"]["files"] if ref["path"].endswith(".gz")
    )
    path = Path(journal["path"])
    raw = path.read_bytes()
    assert (
        hashlib.sha256(raw).hexdigest() == journal["sha256"]
        and len(raw) == journal["bytes"]
    )
    assert f"{stat.S_IMODE(path.stat().st_mode):04o}" == journal["mode"]
    bindings.append(journal)
    first = None
    with gzip.open(path, "rt") as stream:
        first = json.loads(stream.readline(2 * 1024**2))
    records.append(
        {
            "batch": batch,
            "manifest": manifest,
            "experiment": experiment,
            "config": config,
            "data": data,
            "first_record": first,
        }
    )
path = MAIN / "scripts/dev/research-lifecycle.py"
raw = path.read_bytes()
assert (
    hashlib.sha256(raw).hexdigest()
    == "1b1a94450a577b4957a7e1cdf2c9bf49bf510343f6c261480d40f317c8b895da"
)
lines = raw.decode().splitlines()
functions = {}
for node in ast.parse(raw).body:
    if isinstance(node, ast.FunctionDef) and node.name in {
        "arena_reference_report",
        "arena_observation",
        "scientific_journal",
        "arena_plan_check",
    }:
        functions[node.name] = "\n".join(lines[node.lineno - 1 : node.end_lineno])
(OWN / "scout.json").write_text(
    json.dumps(
        {"records": records, "bindings": bindings, "consumer_functions": functions},
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps({"batches": len(records), "bindings": len(bindings), "science_calls": 0})
)
