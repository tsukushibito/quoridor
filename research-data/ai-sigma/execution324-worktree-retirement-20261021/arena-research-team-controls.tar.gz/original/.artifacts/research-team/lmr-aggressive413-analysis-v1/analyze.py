"""Bounded saved-only interpretation of original413 games; no new bootstrap."""

import ast
import collections
import copy
import datetime
import hashlib
import json
import math
import os
import resource
import sys
import time
import zlib
from pathlib import Path

OWN = Path(__file__).resolve().parent
OLD = OWN.parent / "lmr-adaptive408-analysis-v1"
sys.path.insert(0, str(OLD))
from saved_reader import ORIGINS, lc  # noqa: E402

ROOT = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-aggressive413-v1/arena384-v1"
)
SELECTED = {}
GAUGES = {"tt_generation", "tt_retained_bytes"}


def ref(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(65536):
            h.update(block)
    stat = path.stat()
    return dict(
        path=str(path),
        sha256=h.hexdigest(),
        bytes=stat.st_size,
        mode=f"{stat.st_mode & 0o777:04o}",
    )


def bound(expected):
    assert ref(expected["path"]) == expected, expected["path"]
    SELECTED[expected["path"]] = expected
    return Path(expected["path"])


def document(expected):
    path = bound(expected)
    assert expected["bytes"] < 2 * 1024**2
    return json.loads(path.read_bytes())


def local(path):
    return document(ref(path))


def rows(path, content, publication, count, cap):
    """Stream the maintained gzip-single-member/raw-hash/record contract."""
    raw_h, prefix_h = hashlib.sha256(), hashlib.sha256()
    raw_n = prefix_n = line_n = 0
    decoder = zlib.decompressobj(31)
    pending = b""
    assert content["encoding"] == "gzip-single-member-v1"
    assert 0 < content["raw_bytes"] <= count * (cap + 1)
    with path.open("rb") as stream:
        while block := stream.read(65536):
            raw = decoder.decompress(block, count * (cap + 1) - raw_n + 1)
            assert not decoder.unused_data and not decoder.unconsumed_tail
            raw_h.update(raw)
            raw_n += len(raw)
            assert raw_n <= content["raw_bytes"]
            pending += raw
            while b"\n" in pending:
                line, pending = pending.split(b"\n", 1)
                line += b"\n"
                assert len(line) <= cap + 1
                if line_n < publication["journal_count"]:
                    prefix_h.update(line)
                    prefix_n += len(line)
                row = json.loads(line)
                if line_n >= publication["journal_count"]:
                    assert row["started"] is False and row["status"] == "unknown"
                line_n += 1
                yield line_n, row
            assert len(pending) <= cap
    assert decoder.eof and not pending
    assert raw_n == content["raw_bytes"] and raw_h.hexdigest() == content["raw_sha256"]
    assert line_n == count
    assert prefix_n == publication["journal_bytes"]
    assert prefix_h.hexdigest() == publication["journal_sha256"]


# Reuse the former owner's aggregation definitions without executing old analysis.
old_ref = ref(OLD / "analyze.py")
tree = ast.parse(bound(old_ref).read_text())
definitions = [
    node
    for node in tree.body
    if isinstance(node, (ast.FunctionDef, ast.ClassDef))
    and node.name in {"measured", "Aggregate"}
]
assert len(definitions) == 2
exec(
    compile(
        ast.Module(body=definitions, type_ignores=[]), str(OLD / "analyze.py"), "exec"
    )
)

Aggregate = globals()["Aggregate"]

CANDIDATES = ["depth_rank_late_one", "depth_rank_deep_two", "depth_rank_early_one"]


def condition_key(batch, engine):
    return (
        str(batch)
        + ":"
        + engine["kind"]
        + ":"
        + engine["ordering_profile"]
        + ":"
        + engine["lmr_method"]
    )


PriorAggregate = Aggregate


class Aggregate(PriorAggregate):
    def __init__(self):
        super().__init__()
        self.extra_scalar_sums = collections.Counter()
        self.extra_scalar_n = collections.Counter()
        self.observation_shapes = set()

    def observe(self, obs, engine, profile, color, final_ply):
        super().observe(obs, engine, profile, color, final_ply)
        counters = obs["counters"]
        self.observation_shapes.add(tuple(sorted(counters)))
        for key, value in counters.items():
            if ("lmr" in key.lower() or "additional" in key.lower()) and type(
                value
            ) in (int, float):
                self.extra_scalar_sums[key] += value
                self.extra_scalar_n[key] += 1

    def output(self):
        out = super().output()
        out["additional_direct_scalar_sums"] = dict(self.extra_scalar_sums)
        out["additional_direct_scalar_n"] = dict(self.extra_scalar_n)
        out["observation_counter_field_sets"] = [
            list(keys) for keys in sorted(self.observation_shapes)
        ]
        return out


start = time.monotonic()
settings_ref = dict(
    path=str(ROOT / "settings.json"),
    sha256="afdcf64074351b8ebf5a721ba857a40898e160cdb62bee6f7991c1b771b444de",
    bytes=6200,
    mode="0644",
)
settings = document(settings_ref)
sequence_ref = ref(Path(settings["output"]) / "result.json")
sequence = document(sequence_ref)
assert (
    sequence["status"] == "PASS"
    and sequence["completed_operations"] == sequence["selected_operations"] == 12
)
assert sequence["cleanup_complete"] and not sequence["remaining"]
plan = document(settings["arena"]["template"]["approved_plan"])
schedule = document(plan["schedule"])
families = plan["family_ids"]
assert families == [14, 16, 23, 27, 37, 38, 39, 44, 64, 74, 82, 86, 103, 109, 118, 124]
assert len(families) == len(set(families)) == 16
assert len(schedule) == plan["planned_slots"] == 384
assert [slot["slot"] for slot in schedule] == list(range(384))
artifact = settings["arena"]["template"]["artifact"]
assert (
    artifact["sha256"]
    == "b9d515e77661dd1e6ce866684644735731d83eeb966b11300326a4b73115a2eb"
)
aggregates, contrasts, games, global_seen = {}, [], [], set()
manifests = []
for op in sequence["operations"]:
    batch_index = op["index"]
    batch = plan["batches"][batch_index]
    config = document(batch["config"])
    manifest = document(op["manifest"])
    manifests.append(op["manifest"])
    assert manifest["status"] == manifest["data"]["status"] == "PASS"
    assert (
        not manifest["primary"]
        and not manifest["remaining"]
        and manifest["cleanup_complete"]
    )
    assert (
        manifest["build_manifest"]["sha256"]
        == "1af3ad9e337e35d94e1aec8eb85bb34f18e4059e36c89f4fa717e8d806a8bcd5"
    )
    experiment = document(manifest["experiment"])
    assert experiment["config"] == batch["config"]
    matchup = plan["matchups"][batch["matchup"]]
    assert config["engines"] == matchup["engines"]
    assert [e["lmr_method"] for e in config["engines"]] == [
        CANDIDATES[batch_index % 3],
        "depth_rank",
    ]
    assert (
        config["games"] == 32
        and config["cpu_cores"] == [2, 6]
        and config["management_cpu_core"] == 4
    )
    assert config["max_plies"] == 200
    assert (
        config["arena"]["tt_entries"] == 1048576
        and config["arena"]["return_reserve_ms"] == 5
    )
    assert config["arena"]["search_artifact_sha256"] == [artifact["sha256"]] * 2
    assert all(
        e["lmr"]
        and e["depth"] == 64
        and e["max_nodes"] == 1000000
        and e["time_ms"] == 100
        and e["ordering_profile"]
        == ("control" if (batch_index // 3) % 2 == 0 else "cheap")
        for e in config["engines"]
    )
    files = {Path(r["path"]).name: r for r in manifest["data"]["files"]}
    pub = document(files["result.json"])
    native = document(files["manifest.json"])
    report, summary = pub["report"], native["summary"]
    assert native["result"] == pub and report["outcomes"] == []
    assert report["planned"] == pub["outcome_count"] == 32
    assert report["stopped"] is None and pub["failure_attribution"] is None
    assert report["all_workers_joined"] and native["cleanup"]["archive_closed_verified"]
    serialized = copy.deepcopy(config)
    for flag in ("disable_continuation_static_ordering", "decision_only"):
        if serialized["arena"].get(flag) is False:
            del serialized["arena"][flag]
    assert native["binding"]["config"] == serialized
    assert native["binding"]["executable_sha256"] == artifact["sha256"]
    execution = native["binding"]["execution"]
    assert execution["main_pid"] == execution["main_tid"] == report["process_id"]
    assert execution["management_core"] == execution["management_core_observed"] == 4
    assert execution["AI_cores"] == [2, 6] and execution["AI_workers"] == 2
    assert execution["simultaneous_games"] == 1 and execution["inference_pump"] is False
    for name in ("result.json", "completed.jsonl.gz"):
        assert native["artifacts"][name] == {
            k: files[name][k] for k in ("sha256", "bytes", "mode")
        }
    assert pub["archive"]["compressed"] == files["completed.jsonl.gz"]
    for engine in config["engines"]:
        key = condition_key(batch_index, engine)
        assert key not in aggregates
        aggregates[key] = Aggregate()
    wdl, statuses, reasons = (
        collections.Counter(),
        collections.Counter(),
        collections.Counter(),
    )
    family_scores = collections.defaultdict(list)
    seen = set()
    cap = (
        config["arena"].get("retained_outcome_bytes")
        or config["max_plies"] * 16384 + 16384
    )
    archive = bound(files["completed.jsonl.gz"])
    for line, row in rows(archive, pub["archive"], pub, 32, cap):
        lc.arena_observation(config, row)
        game = row["game"]
        assert type(game) is int and game not in seen and 0 <= game < 32
        seen.add(game)
        slot = schedule[batch["slots"][game]]
        assert slot["batch"] == batch_index and slot["local_game"] == game
        assert slot["candidate_color"] == row["candidate_color"]
        assert slot["slot"] not in global_seen
        global_seen.add(slot["slot"])
        opening = config["arena"]["book"]["openings"][game // 2]
        assert (
            opening["reference"]["settings"]["family_id"]
            == slot["family_id"]
            == families[game // 2]
        )
        statuses[row["status"]] += 1
        reasons[str(row["reason"])] += 1
        if row["status"] in {"goal", "forfeit"} and row["winner"] in (0, 1):
            score = float(row["winner"] == row["candidate_color"])
            outcome = "W" if score else "L"
        elif row["status"] == "draw" and row["winner"] is None:
            score, outcome = 0.5, "D"
        else:
            score, outcome = None, "UNKNOWN"
        wdl[outcome] += 1
        family_scores[slot["family_id"]].append(score)
        counts = collections.Counter(o["engine_index"] for o in row["observations"])
        for i, engine in enumerate(config["engines"]):
            profile = row["persistent_tt"][i]
            assert profile["search_invocations"] == counts[i]
            aggregates[condition_key(batch_index, engine)].profile(
                profile, row["candidate_color"] ^ i
            )
        for obs in row["observations"]:
            i = obs["engine_index"]
            assert i == (0 if obs["side"] == row["candidate_color"] else 1)
            c = obs["counters"]
            if obs["accepted"]:
                assert (
                    c["authority_tid"] == report["process_id"]
                    and c["authority_core"] == 4
                )
                assert (
                    c["AI_worker_core"] == [2, 6][i]
                    and c["AI_worker_tid"] != report["process_id"]
                )
                assert c["matching_terminal_collected"] is True
                assert (
                    c["AI_terminal_finished_ns"]
                    <= c["terminal_collected_ns"]
                    <= obs["returned_ns"]
                )
            e = config["engines"][i]
            aggregates[condition_key(batch_index, e)].observe(
                obs, e, row["persistent_tt"][i], obs["side"], row["plies"]
            )
        games.append(
            dict(
                global_slot=slot["slot"],
                batch=batch_index,
                local_game=game,
                family_id=slot["family_id"],
                candidate_color=row["candidate_color"],
                started=row["started"],
                status=row["status"],
                winner=row["winner"],
                reason=row["reason"],
                failure=row["failure"],
                candidate_result=outcome,
                candidate_score=score,
                plies=row["plies"],
                observations=len(row["observations"]),
                run_id=config["run_id"],
                candidate_method=config["engines"][0]["lmr_method"],
                evaluator=config["engines"][0]["kind"],
                profile=config["engines"][0]["ordering_profile"],
                archive_line=line,
            )
        )
    assert seen == set(range(32))
    scores = [
        dict(
            family_id=f,
            candidate_scores=family_scores[f],
            candidate_score=(
                math.fsum(family_scores[f]) / 2
                if all(v is not None for v in family_scores[f])
                else None
            ),
            reference_score=(
                1 - math.fsum(family_scores[f]) / 2
                if all(v is not None for v in family_scores[f])
                else None
            ),
        )
        for f in families
    ]
    assert all(len(s["candidate_scores"]) == 2 for s in scores)
    assert [
        s["candidate_score"] for s in scores if s["candidate_score"] is not None
    ] == [s["score"] for s in summary["pairs"]]
    valid_pair_scores = [
        s["candidate_score"] for s in scores if s["candidate_score"] is not None
    ]
    assert (
        math.fsum(valid_pair_scores) / len(valid_pair_scores)
        if valid_pair_scores
        else None
    ) == summary["complete_pair_mean"]
    contrasts.append(
        dict(
            batch=batch_index,
            evaluator=config["engines"][0]["kind"],
            profile=config["engines"][0]["ordering_profile"],
            left_candidate=config["engines"][0]["lmr_method"],
            right_reference=config["engines"][1]["lmr_method"],
            WDL_candidate=dict(wdl),
            statuses=dict(statuses),
            reasons=dict(reasons),
            family_scores=scores,
            mean_candidate_score=summary["complete_pair_mean"],
            mean_reference_score=(
                1 - summary["complete_pair_mean"]
                if summary["complete_pair_mean"] is not None
                else None
            ),
            native_candidate_interval=summary["bootstrap"],
            native_summary=summary,
            manifest=op["manifest"],
            files=files,
            archive_raw_bytes=pub["archive"]["raw_bytes"],
            archive_raw_sha256=pub["archive"]["raw_sha256"],
            native_report_wall_seconds=report["wall_seconds"],
            native_peak_rss=report["peak_rss"],
            general_nn_calls=report["nn_calls"],
            execution=execution,
            declared_model_identity=matchup["evaluator_sha256"],
        )
    )
    del row, native, pub

assert global_seen == set(range(384)) and len(games) == 384
methods = {key: a.output() for key, a in aggregates.items()}
assert len(methods) == 24 and all(
    len(m["actual_method_ids"]) == len(m["actual_namespace"]) <= 1
    for m in methods.values()
)
total = collections.Counter()
for method in methods.values():
    total.update(method["counts"])
for expected in SELECTED.values():
    assert ref(expected["path"]) == expected
reader_stop = datetime.datetime.now(datetime.UTC).isoformat()
result = dict(
    issue="quoridor-4lc.413.4",
    scope="original384 saved analysis",
    census=dict(
        planned=384,
        unique=384,
        entered=sum(g["started"] for g in games),
        returned=len(games),
        complete_pairs=sum(
            c["native_summary"]["census"]["complete_pairs"] for c in contrasts
        ),
        unknown=sum(c["WDL_candidate"].get("UNKNOWN", 0) for c in contrasts),
        shared_canonical_starts=16,
    ),
    contrasts=contrasts,
    methods=methods,
    observation_census=dict(total),
    games=games,
    settings=settings_ref,
    sequence=sequence_ref,
    manifests=manifests,
    image_declared_only=artifact,
    saved_reader_sources=ORIGINS,
    aggregation_source=old_ref,
    reader_STOP=reader_stop,
    costs=dict(
        analysis_wall_seconds=time.monotonic() - start,
        self_ru_maxrss_B=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024,
        worker_affinity=sorted(os.sched_getaffinity(0)),
        continuous_family_peak="UNKNOWN",
    ),
    limitations=[
        "four evaluator/profile strata separate; same16 starts shared across12contrasts",
        "native family interval quoted without bootstrap rerun",
        "selective nominal depth; different trajectories and terminal mix",
        "terminal work and selected snapshot nested/nonadditive; TT bytes gauges",
        "physical forwards/isolated cost/continuous RSS/all-process Search time UNKNOWN",
        "no old408 RAW, no new games/Search/model/bootstrap",
        "existing default choice independent from finite strength evidence",
    ],
    new_science=0,
)
(OWN / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n"
)
(OWN / "selected-refs.json").write_text(
    json.dumps(list(SELECTED.values()), indent=2) + "\n"
)
print(
    json.dumps(
        dict(
            census=result["census"],
            contrasts=[
                {
                    k: c[k]
                    for k in (
                        "evaluator",
                        "WDL_candidate",
                        "mean_reference_score",
                        "native_candidate_interval",
                    )
                }
                for c in contrasts
            ],
            methods={
                k: dict(
                    depth={
                        f: m["selected_completed_depth"][f]
                        for f in ["n", "median", "mean"]
                    },
                    accepted=m["counts"].get("accepted", 0),
                )
                for k, m in methods.items()
            },
            reader_STOP=reader_stop,
            costs=result["costs"],
        )
    )
)
