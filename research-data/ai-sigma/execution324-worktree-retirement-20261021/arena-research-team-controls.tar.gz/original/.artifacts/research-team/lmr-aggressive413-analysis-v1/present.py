"""Original413 saved arithmetic/presentation only, no RAW or Search replay."""

import collections
import datetime
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-aggressive413-v1"
)
SELECTED = json.loads((OWN / "selected-refs.json").read_bytes())
NAMES = dict(
    depth_rank="A",
    depth_rank_late_one="B",
    depth_rank_deep_two="C",
    depth_rank_early_one="D",
)


def file_ref(path):
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def document(path):
    before = file_ref(path)
    assert before["bytes"] < 2 * 1024**2
    data = json.loads(path.read_bytes())
    assert file_ref(path) == before
    SELECTED.append(before)
    return data, before


result = json.loads((OWN / "result.json").read_bytes())
summary, summary_ref = document(BASE / "cost192-presentation-v1/summary.json")
roots, roots_ref = document(BASE / "cost192-presentation-v1/roots.json")
cost_report_ref = file_ref(BASE / "cost192-presentation-v1/report-ja.md")
SELECTED.append(cost_report_ref)
assert summary["original"] == roots["original"]
assert file_ref(Path(summary["original"]["path"])) == summary["original"]
SELECTED.append(
    summary["original"]
)  # Bind collected scalar authority; never re-decode calls.
assert summary["calls"] == 192 and summary["sessions"] == 96
assert summary["nodes"] == summary["node_cap"] == 576000000
assert summary["COMPLETE"] == 0 and summary["UNKNOWN"] == 192
assert len(summary["table"]) == 16 and len(roots["rows"]) == 96
assert sum(2 * row["work"]["nodes"] for row in roots["rows"]) == 576000000
assert all(
    row["status"] == "UNKNOWN"
    and row["same_method_nonclock_exact"]
    and 5 <= row["completed_depth"] <= 7
    and row["request"]["depth"] == 8
    and row["request"]["node_cap"] == row["work"]["nodes"]
    and row["request"]["diagnostic"] is False
    and row["request"]["observe_completed_depths"] is False
    and row["request"]["time_limit_ms"] is None
    and row["request"]["warmup"] is False
    for row in roots["rows"]
)
baseline = {
    (row["evaluator"], row["profile"]): row
    for row in summary["table"]
    if row["method"] == "depth_rank"
}
for row in summary["table"]:
    assert len(row["whole_seconds"]) == 2
    assert sum(row["whole_seconds"]) / 2 == row["whole_median_seconds"]
    assert (
        row["whole_median_seconds"]
        / baseline[(row["evaluator"], row["profile"])]["whole_median_seconds"]
        == row["ratio_to_A_same_stratum"]
    )
    assert row["aggregate_work_two_passes"]["nodes"] == 36000000
assert (
    sum(row["aggregate_work_two_passes"]["nodes"] for row in summary["table"])
    == 576000000
)
for path in [
    BASE / "cost192-v3/collection-v3/STOP.json",
    BASE / "arena384-v1/collection-v1/STOP.json",
    BASE / "arena-collection-guard-v1/STOP.json",
    BASE / "arena384-v1/prepared.json",
]:
    document(path)

validation = []
for contrast in result["contrasts"]:
    batch = contrast["batch"]
    assert contrast["right_reference"] == "depth_rank"
    assert (
        contrast["left_candidate"] in NAMES and NAMES[contrast["left_candidate"]] != "A"
    )
    assert sum(contrast["WDL_candidate"].values()) == 32
    assert len(contrast["family_scores"]) == 16
    assert all(len(pair["candidate_scores"]) == 2 for pair in contrast["family_scores"])
    for pair in contrast["family_scores"]:
        if pair["candidate_score"] is not None:
            assert pair["reference_score"] == 1 - pair["candidate_score"]
    assert contrast["native_summary"]["census"]["complete_pairs"] == 16
    for engine_index, method in enumerate([contrast["left_candidate"], "depth_rank"]):
        key = f"{batch}:{contrast['evaluator']}:{contrast['profile']}:{method}"
        data = result["methods"][key]
        counts = data["counts"]
        depth = data["selected_completed_depth"]
        assert counts["game_exposures"] == 32
        assert sum(depth["histogram"].values()) == depth["n"]
        assert (
            depth["n"] + counts.get("accepted_without_completed_depth", 0)
            == counts["accepted"]
        )
        assert (
            counts["receipt_deadline_n"]
            == counts["accepted"]
            == counts["inflight_zero"]
            == counts["matching_terminal_collected_true"]
        )
        assert data["gauges"]["effective_tt_slots"] == [1048576]
        assert data["gauges"]["retained_bytes_peak"] == [83886128]
        assert data["gauges"]["AI_worker_core"] == [[2, 6][engine_index]]
        profile = data["persistent_profile_sums"]
        assert profile["search_invocations"] == counts["observations"]
        for name in [
            "attempts",
            "additional_reductions",
            "full_depth_confirmations",
            "full_window_researches",
        ]:
            assert data["LMR_views"]["terminal"][name] == profile["lmr_" + name]
            assert (
                data["LMR_views"]["terminal"][name]
                >= data["LMR_views"]["selected"][name]
            )
        if method == "depth_rank":
            assert data["LMR_views"]["terminal"]["additional_reductions"] == 0
        assert profile["probes"] == data["work_views"]["terminal"]["tt_probes"]
        data["role"] = "left_candidate" if engine_index == 0 else "right_reference_A"
        data["contrast_batch"] = batch
        data["candidate_code"] = NAMES[contrast["left_candidate"]]
        data["requested_method"] = method
    validation.append(
        dict(
            batch=batch,
            families=16,
            complete_pairs=16,
            LEFT=NAMES[contrast["left_candidate"]],
            RIGHT="A",
            native_CI_preserved=True,
            extra_terminal_profile_scalar_match=True,
            receipt_drain_ownership=True,
            TT_gauges_match=True,
        )
    )
statuses = collections.Counter()
for contrast in result["contrasts"]:
    statuses.update(contrast["statuses"])
assert (
    result["census"]["planned"]
    == result["census"]["unique"]
    == result["census"]["entered"]
    == result["census"]["returned"]
    == 384
)
assert result["census"]["complete_pairs"] == 192 and result["census"]["unknown"] == 0
assert statuses == dict(goal=383, draw=1)
assert (
    result["observation_census"]["observations"]
    == result["observation_census"]["accepted"]
    == 19804
)
result["fixed_cost"] = dict(
    summary_ref=summary_ref,
    roots_ref=roots_ref,
    report_ref=cost_report_ref,
    original=summary["original"],
    calls=192,
    sessions=96,
    node_cap=576000000,
    nodes=576000000,
    COMPLETE=0,
    UNKNOWN=192,
    table=summary["table"],
    same_method_two_repetitions_nonclock_exact=True,
    original_outer_seconds=summary["outer_seconds"],
    counter_meaning="LMR_additional_reductions counts started extra-reduced scout calls including interrupted; not total removed plies or benefit",
    scope="cap-limited distinct selective work, not D8 completion/same-work speedup",
    original_collector_errors="v1 request key error and v2 prettyJSON1MiB refusal retained; v3 compact same cap, no scientific replay",
)
result["validation"] = dict(
    contrasts=validation,
    global_slot_join_unique=True,
    histograms_and_denominators_match=True,
    cost_saved_arithmetic=True,
    terminal_selected_nested_nonadditive=True,
    extra_counter_actual_started_scout=True,
    bootstrap_runs=0,
)
result["presentation_reader_STOP"] = datetime.datetime.now(datetime.UTC).isoformat()
result["original_arena_outer_seconds"] = 1989.2591725599923
for expected in SELECTED:
    assert file_ref(Path(expected["path"])) == expected
(OWN / "result.json").write_text(
    json.dumps(result, ensure_ascii=False, separators=(",", ":")) + "\n"
)
(OWN / "selected-refs.json").write_text(json.dumps(SELECTED, indent=2) + "\n")
(OWN / "validation.json").write_text(json.dumps(result["validation"], indent=2) + "\n")

lines = [
    "# 413：原384局と固定192探索費の保存解析",
    "",
    "原384局は384 unique/entered/returned、192 complete colour pairs、383 goal・1 threefold draw、UNKNOWN0だった。候補をLEFT、基準AをRIGHTとして12対照を別々に保存した。全12の未補正family区間は50%を含むか端点で接しており、今回の有限探索的データから候補の一般優越・Elo・非劣性や確定順位を認定しない。候補の保持/撤去・Main変更はRoot判断で、本解析は追加候補/比較/ゲームを発行しない。",
    "",
    "A=depth_rank、B=depth_rank_late_one、C=depth_rank_deep_two、D=depth_rank_early_one。NNUE BEST43/固定D(0,8,tanh)×Control/Cheapの4層に、各B/C/D対Aの3対照。各対照は同じ16 family×2色32局。旧412のLEFT=A/RIGHT=Bへ反転せず、nativeのLEFT候補得点と区間をそのまま引用した。",
    "",
    "## 対Aの保存対局成績",
    "",
    "|層|候補|候補W/D/L/UNKNOWN|候補得点|保存native 95%区間|",
    "|---|---|---:|---:|---|",
]
for contrast in result["contrasts"]:
    wdl = contrast["WDL_candidate"]
    lo, hi = contrast["native_candidate_interval"]["percentile_95"]
    lines.append(
        f"|{contrast['evaluator']}/{contrast['profile']}|{NAMES[contrast['left_candidate']]}|{wdl.get('W', 0)}/{wdl.get('D', 0)}/{wdl.get('L', 0)}/{wdl.get('UNKNOWN', 0)}|{contrast['mean_candidate_score']:.6f}|[{lo:.6f},{hi:.6f}]|"
    )
lines += [
    "",
    "各区間の単位はcomplete family pair、元native 10,000 resamples/seed41320261015。新bootstrap0。固定book/config条件付きで、家族交換可能性・lineage依存未補正・多重対照/候補選択依存という限界がある。384独立標本でも、B/C/Dの直接対戦でもない。対Aの得点のみを用いた候補間の確定順位は作らない。旧408/412/400の結果を混合・再集計していない。",
    "",
    "family順は14,16,23,27,37,38,39,44,64,74,82,86,103,109,118,124。全12×16 familyの二色個別score/平均/参照A平均、slot/run/batch/local game/色/圧縮journal行をresult.jsonへ保存した。1 drawはNNUE Control C対Aのthreefold_draw。maxply/forfeit/未回収/UNKNOWNは0で、上限やエラーをdrawへ変換していない。",
    "",
    "## accepted completed snapshot depth",
    "",
    "|層/対照|側|完成n|中央値|平均|p95|最大|",
    "|---|---|---:|---:|---:|---:|---:|",
]
for key, data in result["methods"].items():
    parts = key.split(":")
    depth = data["selected_completed_depth"]
    lines.append(
        f"|{parts[1]}/{parts[2]}/{data['candidate_code']}対A|{NAMES[data['requested_method']]}|{depth['n']}|{depth['median']:g}|{depth['mean']:.6f}|{depth['p95']}|{depth['max']}|"
    )
lines += [
    "",
    "全19,804 accepted手で完成snapshotあり、fallback0。各表行は32 game exposuresの実手数分母で、両色nと全histogramはmachine resultへ保存。Aも相手候補ごとに異なる軌跡であり、3対照を同じ局面の繰返しへ置換しない。LMR ONの深さはselective nominal、全幅資格ではない。設定上限64と実到達深さを区別する。",
    "",
    "終端前20記録plyとそれ以前のn/中央値/平均も各方法の別viewに保存した。これは実手数proxyで、wall-stock/parent属性は未記録UNKNOWN。軌跡・終盤比・手数・深い尾部の差は平均を膨らませ得るため、中央値/mean/workを勝因や孤立探索性能へ変換しない。",
    "",
    "## 192探索：cap-limited wholeと追加削減",
    "",
    "原192calls/96sessions/576Mcapは全192 UNKNOWN NodeLimit、実576,000,000nodes、requested D8完了0、completed5..7。同methodの二反復は保存された全root/request/status/depth/valuebits/action/PV/nonclockworkで一致。ABCDDCBA、各既存6root/coldwarm履命・5×2M+1×8Mを維持した元subjectを引用し、新callやcap増加を行っていない。",
    "",
    "|層|方法|whole中央値s|対A比|二pass追加scout実発動|completed深さ|",
    "|---|---|---:|---:|---:|---|",
]
for row in summary["table"]:
    lines.append(
        f"|{row['evaluator']}/{row['profile']}|{NAMES[row['method']]}|{row['whole_median_seconds']:.9f}|{row['ratio_to_A_same_stratum']:.6f}|{row['aggregate_work_two_passes']['LMR_additional_reductions']}|{row['completed_depths']}|"
    )
lines += [
    "",
    "wholeはsetup/dropを含む保存scope。TT/gauge・nested clocksを加算しない。NNUE Controlで各候補のwhole中央値はAより小さく、固定Dでは両profileの全候補がAより大きかった。ただし全件D8未完了で、同じnode capでも評価回数・選択木・value/PV等が異なる。従って同仕事speedupやD8完成時間の短縮を意味しない。",
    "",
    "LMR追加counterは「追加削減したscoutを実際に開始した回数」で、途中割込みを含む。削減した総ply数・回避仕事・利益ではない。Cはこのcap-limited6rootsで208–210回/二passと少ないが、arenaでは別の手数/深さ/状態分布になり、cap-limited値から実対局での発動頻度を推定しない。source閾値/係数の調整や追加候補は発行しない。",
    "",
    "cost192-presentation-v1/{summary.json,roots.json,report-ja.md}と元collection-v3を参照し、保存scalarの192/96/cap/nodes/96反復行/16条件の算術のみ照合。元call RAWは再decodeせず、元collector v1 requestキー誤記・v2 prettyJSON1MiB拒否・v3同cap compact化を維持する。科学再演0。",
    "",
    "## 対局terminal work・LMR",
    "",
    "|層/対照|側|terminal n|nodes|static evals|delta|追加scout|LMR trial/通常深さ確認/fullwindow|PVS|",
    "|---|---|---:|---:|---:|---:|---:|---|---:|",
]
for key, data in result["methods"].items():
    parts = key.split(":")
    work = data["work_views"]["terminal"]
    lmr = data["LMR_views"]["terminal"]
    lines.append(
        f"|{parts[1]}/{parts[2]}/{data['candidate_code']}対A|{NAMES[data['requested_method']]}|{data['counts']['terminal_counters_n']}|{work['nodes']}|{work['static_evaluations']}|{work['delta_updates']}|{lmr.get('additional_reductions', 'UNKNOWN')}|{lmr['attempts']}/{lmr['full_depth_confirmations']}/{lmr['full_window_researches']}|{work['pvs_researches']}|"
    )
lines += [
    "",
    "全TT/scalarとselected snapshot側のwork/LMR、各field present/null分母、persistent profile sum/gaugeをresult.jsonへ保存した。terminal totalsは最後の未完了iterationの仕事も含み、selected完成snapshotはそのnested viewなので両方を加算しない。追加scoutを含むLMR terminal totalsとpersistent profileを一致照合し、基準Aの追加scoutは0。TT probesも両記録が一致した。",
    "",
    "TT requested/effective slotsは全色1,048,576、各色persistent TT retained/capは83,886,128B。これはgaugeでRSSではない。実actual method ID/namespace/reduction_rule/requested nameをnative profileと各accepted手で一致確認した。PythonのID/suffix builderはない。image b9d515e7/Build1af3ad9e/source qualificationを再審査せず、model/image payloadは開いていない。",
    "",
    "## receipt・drain・終了",
    "",
    "100ms main authority receipt/5ms reserve、node safety1M/depth64/maxply200、AI2+6/main4。全19,804 acceptedでreceipt<caller start+100ms、合法、matching terminal回収、inflight=0。receipt late/equal0、failure/engine_error/forfeit/fallback/first receipt-control error/completed snapshot validation error0。terminal returnがdeadline以上1,491件、commitがdeadline以上1,675件は、receiptの遅延と区別して保持する。",
    "",
    "各方法のreceipt slack/terminal drain/caller/thinking時間、停止reason、reserve_stop_is_not_user_cancel（全件true）をmachine resultへ保存。cancelledというsearch stopをuser cancelへ変換しない。全native all_workers_joined、main PID/TID/管理core4・各AI core/TID、terminal→collection→return順を元記録で照合した。",
    "",
    "物理NNforward、continuous family RSS、孤立eval/LMR費、all-process Search CPU、全作業費はUNKNOWN。general nn_calls=0やstatic_evaluationsを物理forward数へ読み替えない。native peak RSSは原scopeで保持し、連続family peakと呼ばない。",
    "",
    "## 参照・検証・費用・STOP",
    "",
    "settings afdcf640/6200、plan/schedule、12config/Experiments/manifests、12組publication/native manifest/RAWをparse前後のSHA-size-modeで束縛。各gzipはbounded streamingで1対局ずつ読み、単一member/rawSHA/bytes/改行・record上限・元journal prefixSHA/bytesを照合。既存arena_observationを再用し、geometry/Searchを再実行していない。原384journalのdecodeは一度。",
    "",
    f"保存arena reader STOP {result['reader_STOP']}、小cost/metadata reader STOP {result['presentation_reader_STOP']}。directwait/reap/fresh exact IDs/no_new_privs/handles/TMP/owned[]はSTOP.json、全FileRefsはselected-refs.json/completion.json、OWN affected usageはusage.json。",
    "",
    f"今回arena解析child wall {result['costs']['analysis_wall_seconds']:.9f}s、self ru_maxrss {result['costs']['self_ru_maxrss_B']}B。原arena outer1989.2591725599923s、原cost outer{summary['outer_seconds']:.12f}sは別の実行scopeであり、nested時間を重複加算しない。guard/controller/captureの費とreturned対disk masksを別receiptに保持する。",
    "",
    "CPU10/guardian14、child960MiB+controller64MiB=family1GiB/GPU0/hostreserve4GiB、AS capなし。fresh topology/allowed cpuset/readback/no_new_privs=1はcontrollerと実launch receiptへ保存。affinityだけで公平timingを認定しない。新source/build/数学jobを発行せず、維持されたfiniteexecuteで保存helperのみを走らせた。",
    "",
    "本人leafはwrapper ready/showで実ID413.4/assignee01a11062を確認（実statusはopen、更新はRoot-only）。Main/Git/index/Cargo/Beads/status/backup/closeは324所有。元414/412/413draftを変更・再送していない。新Search/対局/モデル/forward/solver/52suite/新bootstrap/追加sampling/fit/scale/cap調整0。Rootだけが同関連maxへ必要結果を配分し、作者reviewdispatch0。",
    "",
    "全mixed/learnerALLprep/pipelineと323 USERPAUSE、productgeneratorenableOFF、models/defaults/weights/seals/oldfits96/foreign/全旧RAWFAILED費UNKNOWNとdecimal50GBを保持する。",
]
(OWN / "report.md").write_text("\n".join(lines) + "\n")
print(
    json.dumps(
        dict(
            census=result["census"],
            statuses=dict(statuses),
            accepted=result["observation_census"]["accepted"],
            cost_calls=summary["calls"],
            cost_UNKNOWN=summary["UNKNOWN"],
            cost_nodes=summary["nodes"],
            presentation_reader_STOP=result["presentation_reader_STOP"],
        ),
        ensure_ascii=False,
    )
)
