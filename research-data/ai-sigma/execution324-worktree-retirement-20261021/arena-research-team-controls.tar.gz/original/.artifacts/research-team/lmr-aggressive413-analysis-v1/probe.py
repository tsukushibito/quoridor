import hashlib
import json
from pathlib import Path

BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-aggressive413-v1"
)


def local(p):
    b = p.read_bytes()
    print("REF", str(p), hashlib.sha256(b).hexdigest(), len(b))
    return json.loads(b)


s = local(BASE / "arena384-v1/settings.json")
assert (
    hashlib.sha256((BASE / "arena384-v1/settings.json").read_bytes()).hexdigest()
    == "afdcf64074351b8ebf5a721ba857a40898e160cdb62bee6f7991c1b771b444de"
)
p = local(Path(s["arena"]["template"]["approved_plan"]["path"]))
print(
    "PLAN",
    json.dumps(
        {
            k: v
            for k, v in p.items()
            if k not in ("matchups", "batches", "models", "inputs")
        }
    ),
)
print(
    "MATCHUPS",
    [
        (
            i,
            m["id"] if "id" in m else "",
            [(e["kind"], e["ordering_profile"], e["lmr_method"]) for e in m["engines"]],
        )
        for i, m in enumerate(p["matchups"])
    ],
)
print("BATCH", p["batches"][0])
seq = local(Path(s["output"]) / "result.json")
print("SEQ", json.dumps(seq))
m = local(Path(seq["operations"][0]["manifest"]["path"]))
print("MANIFEST", json.dumps(m)[:18000])
for r in m["data"]["files"]:
    if Path(r["path"]).name == "manifest.json":
        n = local(Path(r["path"]))
        print("NATIVE_SUMMARY", json.dumps(n["summary"]))
        print("BINDING_KEYS", list(n["binding"]))
        print("CONFIG", json.dumps(n["binding"]["config"]["engines"]))
        print("CLOCK", json.dumps(n["clock_contract"]) if "clock_contract" in n else "")
for name in ["summary.json", "roots.json"]:
    x = local(BASE / "cost192-presentation-v1" / name)
    print("COST", name, json.dumps(x)[:19000])
