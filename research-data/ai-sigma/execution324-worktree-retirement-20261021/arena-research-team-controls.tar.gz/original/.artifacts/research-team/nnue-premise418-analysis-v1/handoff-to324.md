# 418.1 completed read-only integrated analysis

本人thread01a13ff2-5740-7a91-a3e2-b9a84a41f77b / gpt-6-astra / high / Main / danger-full-access / approvalPolicy never。初回・再開actualを確認。418.2 compact report/facts/refsの配布SHAを前後確認し、同じ独立upstream reportへ統合した。本人418.1は分析検証後close/backup、親418/Main/Git/findingsの受入れは324。

私有成果は `/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-premise418-analysis-v1/` の `report-ja.md`、`verification.json`、`facts4182-receipt.json`、`upstream-refs.json` / `upstream-more-refs.json` / `upstream-lineage-refs.json`、`upstream-selected-tree.json`、`upstream-historical-data-trees.json`、`upstream-data-blob-continuity.json`、`weighting-illustration.json`、`STOP.json`、`usage.json`。歴史版source refsは`historical-source-v1/full.log`にも原URL/shaを保持。最終publication候補hashは`publication-refs.json`。

主な結果：

- 実arenaはfresh353/046fe・46ec・96a5/physical BEST epoch43。43NPZ数・Sigma cycle43ではない。実Tの1..20は5,719,421/8,413,949=67.9754655%、世代quality/recency weightなし。43epochでこの範囲245,935,103 row露出。raw original1..20=68.0091%とは分母を分ける。
- fix43はrandom初期からの43世代や最終scratch321の全学習史ではない。43番公開時84cfb8dの実sourceはmodels_9x9/best.pt→data_9x9_fix/30cycle/.92。固定head改修記録はlegacy359の継続修正bufferを同heads warm教師学習へ再利用したと報告。各shardの実生成checkpoint・strength・game/historyはなおUNKNOWN。
- 固定a7a91e5の原作者履歴はbrowser bestをscratch321へ交換したと明記。固定best.onnx blobf23802a8/11,663,428Bは既arena参照に対応する。fixed README30とfixed train.py default60/.99、歴史default30/.92を区別した。headsは同fix bufferを30/.92→50/1.0→30/.92でも使って改善した記録があり、全buffer不良という断定への反証。
- `verification.json`で実local43 manifestとfixed API treeの全43blob/size一致、さらに全43blobが公開時84cfとfixed751186で同一を確認。NPZ再hash/decodeなし。データ番号をmodel cycleへ339加算する案は個数が合うだけで採用しない。
- zは採用された自己対局方策の実勝敗で、raw value/rootmean/最適WDLではない。同入力別±1は破損の証拠ではなく、z0除外後の条件付き目標とrow/game weightを区別。MCTS由来がαβ教師不適とする結論は出さない。
- BEST train MSE .42658は固定8192診断、V .42387とfullT generalization gapを作らない。saturation48.54%はabs(v)>=.9で、.99ではない。有限native parityは大きな取り違えへの反対材料だが万能証明ではない。旧naiveLR半分は実訓練されず、corrected onlineLR。
- 358同深さでの負け越しは速度差だけの説明に反する。383の楽観rootと壁迂回例を実失敗の起点として再用し、searched rootを静的NN飽和へ読み替えない。415は同evaluator内LMR比較でありNNUE対Dではない。進行417の結論を先取りしない。

重要な単独原因確定は0。優先する競合説明は生成方策/採用重み/探索葉分布、容量/最適化、分割評価、探索条件。各項に反証と最小観測案を付けた。古いデータ除去・新fit/forward/arena・模型変更・paused学習再開を自動採用しない。重要原因の採用が別途必要になる場合だけ、その主張へ限定した既存独立確認とする。

Ruff format/check/lint、Prettier実write/check、small metadata/算術self-check PASS。CPU8/guardian12別physical/child960MiB+controller余裕64MiB/GPU0、全guard直接wait/reap/handles閉鎖・fresh exact identity absence・TMP/owned[]をSTOPに記録。初期管理費/continuous peak/all-session費UNKNOWN。最初Prettier ignoreで処理なしを実ignore-path指定へ訂正、HTTP404候補と全原RAW/FAILED/費UNKNOWNを保全。

一度の対象usageのみ、全target再課金・削除/refundなし。decimal50GB/latest conservative49,278,775,296/globalactualUNKNOWNを維持。新科学実行0、models/weights/defaults/seals/旧fits96/foreign、mixed/learner ALLprep/pipeline・323 USERPAUSEを維持。Main publication・親closeの通常統合をお願いします。返信ACKは不要です。
