"""Check only small saved metadata and arithmetic; never open science payloads."""

import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
FACTS = (
    ROOT
    / ".worktree/learning-million/.artifacts/research-team/nnue-premise418-facts-v1"
)


def read_json(path):
    return json.loads(path.read_text())


facts = read_json(FACTS / "facts.json")
for ref in read_json(OWN / "facts4182-receipt.json")["refs"]:
    data = Path(ref["path"]).read_bytes()
    assert len(data) == ref["bytes"]
    assert hashlib.sha256(data).hexdigest() == ref["sha256"]

source_ref = facts["upstream_locators"]["all43_manifest"]
data = Path(source_ref["path"]).read_bytes()
assert hashlib.sha256(data).hexdigest() == source_ref["sha256"]
manifest = json.loads(data)
tree = read_json(OWN / "upstream-selected-tree.json")
blobs = {item["path"]: item for item in tree["selected"]}
assert len(manifest["files"]) == 43
assert manifest["revision"] == "751186344fc52ad0c29bc65922e62c6fa915f006"
for entry in manifest["files"]:
    remote = blobs[entry["path"]]
    assert (entry["sha"], entry["size"]) == (remote["sha"], remote["size"])
assert sum(item["rows"] for item in manifest["files"]) == 18_914_078

historical = read_json(OWN / "upstream-historical-data-trees.json")
last_publication = next(
    item for item in historical if item["revision"].startswith("84cfb8d")
)
historical_blobs = {
    "runs/" + item["path"]: item["sha"]
    for item in last_publication["selected"]
    if item["path"].startswith("data_9x9_fix/")
}
assert len(historical_blobs) == 43
assert all(blobs[path]["sha"] == sha for path, sha in historical_blobs.items())

inputs = facts["inputs"]
assert inputs["train"] * 43 == 361_799_807
assert inputs["train"] * 46 == 387_041_654
assert 5_719_421 * 43 == 245_935_103
assert 5_719_421 / inputs["train"] == 0.6797546550377237
assert (
    inputs["train"]
    + inputs["opened_selectorV"]
    + inputs["sealed_metadata_rows"]
    + inputs["old_opened_quarantine_rows"]
    == inputs["native_eligible_decisive"]
)
assert inputs["native_eligible_decisive"] + 45_642 + 156_320 == 9_457_039
assert facts["identity"]["best"]["train_scope"] == "fixed_diagnostic_subset"
assert facts["metric_cautions"]["saturation_threshold_this_run"] == 0.9
assert facts["identity"]["model"]["weights"]["sha256"].startswith("046fe926")

result = {
    "scope": "small metadata, existing facts binding, source blob links, arithmetic",
    "facts_refs_unchanged": True,
    "local43_manifest_matches_fixed_remote_tree": True,
    "all43_same_blob_at_84cf_and_fixed751186": True,
    "denominators_and_exposure_arithmetic": "PASS",
    "model_payload_or_npz_or_labels_read": False,
    "scientific_runs": 0,
    "causal_identification": "UNKNOWN; no unique mechanism established",
}
(OWN / "verification.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
