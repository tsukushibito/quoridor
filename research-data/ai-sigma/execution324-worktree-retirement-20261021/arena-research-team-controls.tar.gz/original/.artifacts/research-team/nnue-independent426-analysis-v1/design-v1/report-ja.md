426の結果を見る前に、凍結W BEST118対BEST43だけを、新しい192 canonical開始family・各両色384局で確認する。元423の72勝56敗、旧保存区間、R operationFAILED、W/Dの5UNKNOWN、全旧費用はそのscopeに保持する。今回の設計担当は数値入場0であり、426.1は元A/B保存分析までin_progressとする。

| 固定項目 | 解決値 |
| --- | --- |
| 一度のrules-only候補 | 2048 requests、追加pool/seed/補充なし |
| prefix seed / 長さ | 42620261017 / 4,8,12,16を元request ordinalでround-robin |
| canonical owner seed | 42620261018、返るT/Vラベルは使用しない |
| 選択 | ALL候補＋既知除外をnative正本で分類し、予定順の最初の非blocked memberを各family一つ、そこから先頭192 |
| arena RNG | 42620261019 |
| 固定対照 / 順序 | W対BEST43のみ、family0..191の各色0/1を隣接、連続16family＝32slotを12操作 |
| node上限 | 各操作250M、計3G、未使用quotaの貸借なし |
| main CI | family単位10000 resamples、seed42620261016、PCG64、95% percentile・linear |
| B | 422と同じ7状態、新Wのみ最大28 canonical logical heads |

canonical分類は既存quoridor_data::terminal::partition_familiesのLR prefix extension・同LR endpoint・推移閉包を使う。Pythonで分類を複製しない。長さごとの採択数は衝突除外後の実数を残し、事後の層quota補充はしない。合法・非終端の完全prefix、実STM・双方在庫・壁・fullhistoryとsource ordinal/group対応を入力ownerが保存する。2048は独立family数ではない。192未達はgenuine shortfallであり、別seedや結果選別で埋めない。

除外する実bookは次の5冊、計528 prefix entriesである。full SHA/size/modeはresolved-settings.jsonとknown-old-books.jsonへ束縛した。355全128が旧408/412/413等の基礎bookを覆い、421/423は生成側も評価側も全件を除外する。既知383/411/422との限定対応は426.2の入力証拠へ結ぶ。これは公開全域の未知game provenanceや任意の過去全局面まで分離したという主張ではない。

| 正本book | 参照数 | SHA先頭 |
| --- | ---: | --- |
| strength355実families | 128 | a6abde1f |
| 421 generation | 64 | f64a817a |
| 421 evaluation | 16 | 0889cb36 |
| 423 prospective generation | 256 | 867a2ea2 |
| 423 evaluation | 64 | fda4e717 |

355のold_open8_prefixesは実families外の歴史的provenanceで、空prefixを含む。固定Git1a622423の正本はstarts_withによって空prefixを全履歴の祖先として一つのcomponentへ結ぶ。これを黙って追加bookとして投入すると全候補がblockedになる。今回は正本が消費する5冊の実memberを固定し、独自empty-prefix classifierや「全過去と独立」という新資格を作らない。既存412の原cost-prefix記録は限定した対応確認資料であり、別の新family判定器ではない。

Wは保存BEST118、typed8a8eb7fb87035f03c4cfa6b45ca1aa5d2f1b144c6fa1298dd11b82975307953d。BEST43は96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875。W descriptor fbf0beb8/weights ab073fb1、BEST43 descriptor46ec2c47/weights046fe926の全FileRefを保存metadataから解決した。payloadを読み直さず、再fit・再選択・資格sweepもしない。同じ旧image35e47e65、Build9bf66048を通常Root admission下で再用する。新しいprepared book/config/Experiment/runtimeは実作成までnullである。

共通Control/PVS/TT1048576、LMR ON-depth_rank、SIMD false、100ms authority receipt・5ms reserve、1M nodes/手、名目depth64、prefix込み200ply、近似/safe leafOFF。未対応のOFF JSON fieldを新設せず、正本の省略/typed reset規則に従って実engine metadataを保存する。12操作に固有run IDとglobal slot/family/colour対応を与え、表示名が局所で繰り返されても同じfamilyへ誤集約しない。各gameは既存の固有二session/TTを使う。新しいwarmupやclock条件は足さない。

retained_outcome_bytesは一局630784B。384局のこの上限だけで242221056B、whole384MiBとの差は160432128Bだが、raw＋archive＋失敗＋metadata＋serial TMPの合成は別である。二重に最悪量を保持すればwholeを超えるため、384完成を保存上限から保証しない。正規native forecastと既存whole guardで実保存を合成し、8MiB/一局の誤scopeや12個のoutput ceilingをそのまま予約量として扱わない。見込み時間をkill期限にしない。全global actual・将来quiet・全費用はUNKNOWNを保持する。

main scoreは真のglobal familyごとの二色candidate得点平均を、192familyで非加重平均したもの。W=1/D=.5/L=0なのでfamily scoreは0,.25,.5,.75,1。384局全完成・192family全完了の場合だけ、集約95%区間下限>.5を固定book/同時間/同条件での改善支持の基準とする。一般棋力・Elo・非劣性・モデル昇格の基準ではない。423の点推定/CIは合算せず、12操作のnative CIも平均/連結しない。

欠測時は予定384/実started/返却/終局/UNKNOWN、完了game score、complete-family scoreを別に残す。観測game得点総和S、予定未確定Kについてplanned算術boundsは[S/384,(S+K)/384]であり、CIでも補完結果でもない。complete-family bootstrapを出す場合は条件付きと明記し、全完成criterionは適用しない。元の個別UNKNOWN分類、global cap停止、未入場を混ぜず、残quota/欠測を別操作へ移さない。

family_bootstrap426.pyは今回の小さい実統計本体であり、現在はRuff/ASTだけ、実行・bootstrap0。後日、真のglobal family ID順のcomplete-pair入力を作り、このファイル自体を実行する。実際のchoice/mean/quantile本体FileRef、input FileRef、seed、Python実executable/version、NumPy version、出力FileRefと直接wait/STOPを同じ実行へ結合する。一般guardだけを統計実行bodyの証拠にしない。423 O1と原値は不変で、旧CIの再計算は行わない。

旧423の20両勝ち/32片勝ち/12両負けという分散を計画にだけ借りると、192familyの正規近似95%半幅は約4.96pt、family scoreの最大分散を使う幅は約7.07ptになる。交換可能性や同分散は保証されず、192という件数も効果検出・強さ・十分性の保証ではない。新しいCIやpower simulationはまだ計算していない。

Bは静的422の3親＋4endpointを全て同じ完全prefix・実local STM・壁/在庫/fullhistoryで再用し、新Wだけを評価する。oldNNUE/Sigma/Dは保存値とbitsを使い再forwardしない。表にはW/oldのpre/post・delta・符号・abs(post)>=.99という事前の飽和目安を載せる。三回同一・goalの正本admissionを保ち、static値をsearched root snapshotへ読み替えない。endpointを元親視点で比較する場合は実STMが元親と異なる場合だけ符号反転し、local STM表と分ける。4endpointは全合法候補ではなく、7値からfull-root argmaxや真WDLを再構成しない。Sigma/D一致を正解ラベルにもせず、新Wの新7値だけで旧敗因を認定しない。AとBの実数値を重ねず、一方の実native＋collection STOP後に他方を入れる。

Aでは色別・両勝ち/片勝ち/両負けとdraw内訳、完全/不完全family、fallback/error/receipt late、accepted完成depth分布、仕事/charged nodesと費を保存分母とともに読む。selected/terminal/TT gaugeと内包時計は加算しない。Bと併せて高残壁coverage不足、公開V trade-off、Fのtrain/V乖離を競合仮説として残す。次の設計はまず高残壁coverage/抽出の一軸に絞り、今回から新fit/q+z/architecture/NNUE自己対局は発行しない。

実sourceはCPU5と別physical guardian9、family1GiB/controller込み、GPU0/hostreserve4GiB。既存guardのfresh topology/RSS/identity/directwait/reap/handles/TMP/leases/owned STOPを残し、Aのactual timing通知でsubstantial helper/IOを停止境界へ渡す。元契約、初動turn_context、readrefs、整形/算術と一回のOWN usageをcompletionへ結ぶ。Main/Git/Cargo/Beads parent/数値入場/最終publicationは324所有。423/421等CLOSEDとlegacy342.17/323 USERPAUSE/defaults/models/seals/RAWFAILED費は不変である。
