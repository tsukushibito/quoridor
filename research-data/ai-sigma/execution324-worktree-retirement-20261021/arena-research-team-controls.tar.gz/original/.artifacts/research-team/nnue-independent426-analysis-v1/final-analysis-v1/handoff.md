Beads issue: quoridor-4lc.426.1
Task cwd: /workspaces/quoridor

SAME original Sol6.1/max analyst: original finite A/B saved analysis COMPLETE, ready for owner acceptance. Original claimant/in_progress retained; no source/model/numerical dispatch or reviewer assignment.

A: 384/384 GOAL, 192 complete true global families, W183/0D/201L, score0.4765625. Sole prescribed 10000/PCG64/42620261016/linear family bootstrap CI[0.4296875,0.5234375], lower>.5 criterion NOT_MET. Pair39 both wins/105 split/48 both losses; colour92W/100L and91W/101L. 1,640,581,337 charged<3G; disjoint quotas/no lending/refill. Native16-family CIs retained separately; old423 not pooled.

B: actual7 COMPLETE, constructorhead0/context7/head7; exact original fullhistory/features/distance bits. All7 signs unchanged and three |post|>=.99 remain three; logits shrink modestly. D/Sigma not WDL truth, seven samples not argmax/old-loss causation. Typed caller retirement maps historical executed Main sources to retained immutable caller6540; missing retired current path is not executed-source loss.

All12 original archives each streamed once with CRC/raw-line SHA and before/after compressed refs, 384 records/16,733 accepted-completed observations. Fallback/error/forfeit/authorityillegal/receiptlate0. Reserve cancellations48 preserve completed selections and are not UNKNOWN/user pause. Return/commit after deadline retained separately. W/BEST depth median8/8 and trajectory-conditioned work are not fullwidth/strength or same-work speedup. Selected snapshots and terminal work not added; TT gauges not RSS. Physical NN/continuous RSS/fullfees UNKNOWN.

Known original A+Bfailed+Btyped outer subtotal1695.948371785984s once; nested not added. Original B zero-head setupFAILED, 423 R/arenaFAILED5UNKNOWN/O1, caller/software failures, private pre-bootstrap CLI repair failure all retained.

Next proposal only: high-stock coverage via2ply starts, same Sigma64sim/outcomez and extraction<=8/game/stock stratum. OldTstock18..20=0, cap increase alone creates no coverage. Prospective ceiling256 requests, match3763 distinct/118updates if representable and adequate, existing-family owner/no fill; exact global-match support still ordinary future inlet question. No new generation/fit/forward/game/q+z/selfplay/architecture/default grant; insufficient-data and low-stock saturation limits explicit.

Source/RAW/bootstrap/plot/formatter readers directwait/reaped, fresh exactPID/start/boot absent/different, handles closed/TMPgone/leases[]/owned substantive readers[]. CPU5/guardian9 distinctphysical/family1GiB/G0/reserve4GiB; no idle lease/futurequiet claim. Small metadata publication/delivery has separate actual receipts. Scoped Ruff/Prettier/figure visual/XML and arithmetic PASS, normal Beads backup exit0; own directed FINAL usage once, shared holdings not recharged/globalactual UNKNOWN. Keep426.1 in_progress for ordinary acceptance; Root owns integration/publication and independent426.4 question, no ACK gate.

Frozen completion FileRef: {"path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1/completion.json", "sha256": "e98476ccf446407fa74cb8c062da0cc4cd97a32f4abed858af9e1192990b1851", "bytes": 11007, "mode": "0644"}

report-ja.md: {"path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1/report-ja.md", "sha256": "f4a6a5b713833e92fea6d63f63402f81eacf9089825241ba24155653e623c09c", "bytes": 15445, "mode": "0644"}

result.json: {"path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1/result.json", "sha256": "95039f772d8fd352e33be6f343b3f9c371bbfd621663993e676eb85008e13041", "bytes": 63872, "mode": "0644"}

checks.json: {"path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1/checks.json", "sha256": "e2deb9cbcdc805ae815104485d16941cb9b5b59d264272424de6d181ff948baf", "bytes": 1562, "mode": "0644"}

STOP.json: {"path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1/STOP.json", "sha256": "1a89e53ac8f19dc7cefb03492776e96c969d7ccf4e88d02d4e4f8a6e8d3292e3", "bytes": 31011, "mode": "0644"}

usage.json: {"path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1/usage.json", "sha256": "42754ba7495ed6edae61b1d36fb26be23ccfea9e84d773e477c4a17b033c5dc9", "bytes": 795, "mode": "0644"}

final-owner-admin.json: {"path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1/final-owner-admin.json", "sha256": "595792ce0c0f43dfcf4dbee50686565de46913ae8a94e746fb4dd9bf407b752c", "bytes": 1175, "mode": "0644"}

Packet writer actual directwait/reap 2026-10-16T23:29:58.215510+00:00; receipt {"path": "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1/A-v1/freeze-final-packet-receipt.json", "sha256": "6e407dd86ddcb122c3f4c36780e3fc867cbf3d6feed4dcd23cd821b944beb8be", "bytes": 3020, "mode": "0644"}. Final metadata delivery receipt is separate at /workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1/A-v1/final-packet-delivery-receipt.json after direct return, not a new source/science lifetime.
