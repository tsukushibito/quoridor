"""Freeze the completed original 426 saved-analysis packet; no scientific work."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

FINAL = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/nnue-independent426-analysis-v1/final-analysis-v1"
)
A = FINAL / "A-v1"
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
OWNER = "codex:01a118a1-aef1-7252-b21b-42f07dd5b1e6"
PRETTIER = "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier"
PRETTIER_CONFIG = "/workspaces/quoridor/tools/research-quality/.prettierrc.json"


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def ref(path):
    path = Path(path)
    before = path.stat()
    assert stat.S_ISREG(before.st_mode) and before.st_size < 2 * 1024**2
    data = path.read_bytes()
    after = path.stat()
    assert (before.st_size, before.st_mtime_ns, before.st_ino) == (
        after.st_size,
        after.st_mtime_ns,
        after.st_ino,
    )
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(after.st_mode):04o}",
    }


def write_json(path, obj):
    with path.open("x") as file:
        json.dump(obj, file, ensure_ascii=False, indent=2)
        file.write("\n")


def format_paths(paths, log):
    with (FINAL / log).open("x") as output:
        for action in ("--write", "--check"):
            subprocess.run(
                [PRETTIER, "--config", PRETTIER_CONFIG, action, *map(str, paths)],
                check=True,
                stdout=output,
                stderr=subprocess.STDOUT,
            )


def fresh(identity):
    try:
        value = (
            Path(f"/proc/{identity['pid']}/stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19]
        )
    except (FileNotFoundError, ProcessLookupError):
        return {"original": identity, "fresh_state": "absent"}
    match = BOOT == identity["boot_id"] and value == identity["start_ticks"]
    return {"original": identity, "fresh_state": "SAME" if match else "different"}


receipts = []
identities = {}
for path in sorted(A.glob("*-receipt.json")):
    value = json.loads(path.read_text())
    assert value["directwait_reaped"] and value["handles_closed"]
    assert value["owned_children_TMP_leases_remaining"] == []
    assert value["guard_refusal"] is None
    expected = 1 if path.name == "join-A-and-freeze-bootstrap-body-receipt.json" else 0
    assert value["returncode"] == expected, (path.name, value["returncode"])
    receipts.append(
        {
            "FileRef": ref(path),
            "returncode": value["returncode"],
            "directwait_reaped": True,
            "handles_closed": True,
            "actual_guard_complete_after_direct_reap": value[
                "guard_complete_after_direct_reap"
            ],
        }
    )
    for identity in (
        value["guardian_identity"],
        value["child_identity"],
        *(x["original"] for x in value["fresh_exact_identities"]),
    ):
        identities[(identity["pid"], identity["start_ticks"], identity["boot_id"])] = (
            identity
        )
fresh_states = [fresh(value) for value in identities.values()]
assert all(value["fresh_state"] != "SAME" for value in fresh_states)
assert not (FINAL / "plot-TMP-v1").exists()
selected = json.loads((FINAL / "selectedrefs-final.json").read_text())
assert selected["selected_small_source_count"] == 58
stop = {
    "issue": "quoridor-4lc.426.1",
    "scope": "Completed original A/B selected evidence, sole bootstrap, sole RAW streams, plots, formatters and Beads backup; packet publication and delivery are separate metadata-only lifetimes.",
    "frozen_at": now(),
    "last_selected_source_read_completed_utc": selected[
        "last_selected_read_completed_utc"
    ],
    "latest_completed_metadata_reader_actual_direct_reap": "2026-10-16T23:28:45.302081+00:00",
    "sole_actual_bootstrap_STOP": "2026-10-16T23:08:39.327750+00:00",
    "sole_original12_RAW_stream_STOP": "2026-10-16T23:11:49.571963+00:00",
    "resource": {
        "worker_CPU": 5,
        "guardian_CPU": 9,
        "physical_worker": [0, 2],
        "physical_guardian": [0, 4],
        "family_including_controller_B": 1073741824,
        "GPU": 0,
        "host_reserve_B": 4294967296,
        "no_new_privs": True,
        "AS_controller_cap": None,
        "lease": None,
        "future_quiet_claim": False,
    },
    "completed_receipts": receipts,
    "fresh_original_exact_identities": fresh_states,
    "original_private_CLI_literal_repair_failure": "Preserved return1 before bootstrap/RAW entry; successful CSV artifact reused. All return1 stdout/stderr/receipt retained.",
    "directwait_reaped": True,
    "handles_closed": True,
    "TMP_remaining": [],
    "readers_remaining": [],
    "scientific_jobs_created_by_analyst": [],
    "owned_completed_scope_children": [],
    "leases": [],
    "packet_writer_lifetime": "This STOP is written by a separate bounded metadata-only packet helper. Its actual post-reap receipt is added after it returns; no claim that an active writer has already exited.",
}
write_json(FINAL / "STOP.json", stop)
format_paths([FINAL / "STOP.json"], "packet-stop-format.log")

# This is the sole directed final-subtree usage walk. No shared assets/targets or global inventory.
logical = 0
allocated = 0
files = 0
directories = 0
for parent, children, names in os.walk(FINAL, followlinks=False):
    directory = Path(parent)
    info = directory.lstat()
    allocated += info.st_blocks * 512
    directories += 1
    for name in names:
        path = directory / name
        info = path.lstat()
        assert not path.is_symlink()
        logical += info.st_size
        allocated += info.st_blocks * 512
        files += 1
usage = {
    "measured_at": now(),
    "scope": str(FINAL),
    "directed_own_subtree_walks": 1,
    "regular_files": files,
    "directories": directories,
    "logical_file_bytes_at_snapshot": logical,
    "allocated_files_and_directories_bytes_at_snapshot": allocated,
    "snapshot_tail": "This usage record and subsequent tiny completion/handoff/delivery/formatter receipts are not yet present at the snapshot; tail is not claimed zero.",
    "shared_models_assets_targets_recharged_B": 0,
    "global_actual_usage": "UNKNOWN",
    "shared_retention_refund_B": 0,
    "new_advance_storage_reservation_B": 0,
    "existing_whole426_support_B": 402653184,
    "decimal_global_cap_B": 50000000000,
}
write_json(FINAL / "usage.json", usage)
format_paths([FINAL / "usage.json"], "packet-usage-format.log")
targets = [
    "report-ja.md",
    "result.json",
    "checks.json",
    "control.json",
    "selectedrefs-final.json",
    "next-learning-proposal.json",
    "static-seven-table.json",
    "static-seven.csv",
    "evidence426.svg",
    "evidence426.png",
    "accepted-depth426.svg",
    "accepted-depth426.png",
    "plot_saved426.py",
    "finalize_packet.py",
    "STOP.json",
    "usage.json",
]
completion = {
    "issue": "quoridor-4lc.426.1",
    "status": "ORIGINAL_FINITE426_A_B_ANALYSIS_COMPLETE_READY_FOR_OWNER_ACCEPTANCE",
    "owner": OWNER,
    "Beads_status": "in_progress",
    "model": "gpt-6.1-sol",
    "effort": "max",
    "cwd": "/workspaces/quoridor",
    "sandbox": "danger-full-access",
    "approvalPolicy": "never",
    "actual_context_verified_at": "2026-10-16T23:28:20.613Z",
    "outcome": {
        "A": "384 GOAL / 192 complete colour families / W183 D0 L201 / score0.4765625 / CI[0.4296875,0.5234375] / improvement criterion NOT_MET",
        "B": "7 COMPLETE / exact original histories and feature bits / signs unchanged / three abs(post)>=0.99 remain three",
        "adoption": "No superiority, inferiority, equivalence, WDL oracle, causal loss or model/default promotion.",
    },
    "artifacts": {name: ref(FINAL / name) for name in targets},
    "actual_statistical_execution": {
        "original_frozen_source": ref(
            FINAL.parent / "design-v1/family_bootstrap426.py"
        ),
        "executed_bounded_CLI_source": ref(A / "family_bootstrap426_bounded.py"),
        "input": ref(A / "bootstrap-input.json"),
        "output": ref(A / "bootstrap-result.json"),
        "binding": ref(A / "statistical-execution-binding.json"),
        "actual_lifetime": ref(A / "original192-family-bootstrap-once-receipt.json"),
        "count": 1,
        "frozen_statistic_function_AST": "MATCH",
        "old423_CI_recomputation_or_pooling": False,
    },
    "original_RAW_once": {
        "summary": ref(A / "raw-observation-summary.json"),
        "example": ref(A / "first-family-observations.json"),
        "actual_lifetime": ref(A / "original12-RAW-stream-once-receipt.json"),
        "each_archive_decodes": 1,
        "CRC_and_raw_line_hash_and_before_after_compressed_SHA": "MATCH",
        "payload_copies": 0,
    },
    "faileds_UNKNOWN_costs": "Original scientific, source, software, setup and private helper failures retained; original outer clocks once, nested excluded. All source/LLM/admin full fees, continuous RSS and physical NN UNKNOWN.",
    "next_learning_proposal": "One high-stock coverage axis, proposal only; no generated input, seed, model, fit, forward, game or runtime grant.",
    "owner_acceptance_and_independent_assessment": "Current324 only; same426.4 independently assesses important conclusions. Author does not dispatch reviewers.",
    "backup": {
        "normal_wrapper_exit": 0,
        "actual_receipt": ref(A / "final-refs-format-Beads-backup-receipt.json"),
    },
    "publication_writer": "Actual writer receipt is appended after this bounded metadata helper exits; delivery lifetime remains separate.",
    "all_legacy_pauses_defaults_models_seals": "UNCHANGED",
}
write_json(FINAL / "completion.json", completion)
format_paths([FINAL / "completion.json"], "packet-completion-format.log")
handoff = (
    "Beads issue: quoridor-4lc.426.1\nTask cwd: /workspaces/quoridor\n\n"
    "SAME original Sol6.1/max analyst: original finite A/B saved analysis COMPLETE, ready for owner acceptance. Original claimant/in_progress retained; no source/model/numerical dispatch or reviewer assignment.\n\n"
    "A: 384/384 GOAL, 192 complete true global families, W183/0D/201L, score0.4765625. Sole prescribed 10000/PCG64/42620261016/linear family bootstrap CI[0.4296875,0.5234375], lower>.5 criterion NOT_MET. Pair39 both wins/105 split/48 both losses; colour92W/100L and91W/101L. 1,640,581,337 charged<3G; disjoint quotas/no lending/refill. Native16-family CIs retained separately; old423 not pooled.\n\n"
    "B: actual7 COMPLETE, constructorhead0/context7/head7; exact original fullhistory/features/distance bits. All7 signs unchanged and three |post|>=.99 remain three; logits shrink modestly. D/Sigma not WDL truth, seven samples not argmax/old-loss causation. Typed caller retirement maps historical executed Main sources to retained immutable caller6540; missing retired current path is not executed-source loss.\n\n"
    "All12 original archives each streamed once with CRC/raw-line SHA and before/after compressed refs, 384 records/16,733 accepted-completed observations. Fallback/error/forfeit/authorityillegal/receiptlate0. Reserve cancellations48 preserve completed selections and are not UNKNOWN/user pause. Return/commit after deadline retained separately. W/BEST depth median8/8 and trajectory-conditioned work are not fullwidth/strength or same-work speedup. Selected snapshots and terminal work not added; TT gauges not RSS. Physical NN/continuous RSS/fullfees UNKNOWN.\n\n"
    "Known original A+Bfailed+Btyped outer subtotal1695.948371785984s once; nested not added. Original B zero-head setupFAILED, 423 R/arenaFAILED5UNKNOWN/O1, caller/software failures, private pre-bootstrap CLI repair failure all retained.\n\n"
    "Next proposal only: high-stock coverage via2ply starts, same Sigma64sim/outcomez and extraction<=8/game/stock stratum. OldTstock18..20=0, cap increase alone creates no coverage. Prospective ceiling256 requests, match3763 distinct/118updates if representable and adequate, existing-family owner/no fill; exact global-match support still ordinary future inlet question. No new generation/fit/forward/game/q+z/selfplay/architecture/default grant; insufficient-data and low-stock saturation limits explicit.\n\n"
    "Source/RAW/bootstrap/plot/formatter readers directwait/reaped, fresh exactPID/start/boot absent/different, handles closed/TMPgone/leases[]/owned substantive readers[]. CPU5/guardian9 distinctphysical/family1GiB/G0/reserve4GiB; no idle lease/futurequiet claim. Small metadata publication/delivery has separate actual receipts. Scoped Ruff/Prettier/figure visual/XML and arithmetic PASS, normal Beads backup exit0; own directed FINAL usage once, shared holdings not recharged/globalactual UNKNOWN. Keep426.1 in_progress for ordinary acceptance; Root owns integration/publication and independent426.4 question, no ACK gate.\n\n"
)
handoff += (
    "Frozen completion FileRef: "
    + json.dumps(ref(FINAL / "completion.json"), ensure_ascii=False)
    + "\n\n"
)
for name in ("report-ja.md", "result.json", "checks.json", "STOP.json", "usage.json"):
    handoff += name + ": " + json.dumps(ref(FINAL / name), ensure_ascii=False) + "\n\n"
with (FINAL / "handoff.md").open("x") as file:
    file.write(handoff)
format_paths([FINAL / "handoff.md"], "packet-handoff-format.log")
print(
    json.dumps(
        {
            "status": completion["status"],
            "completion": ref(FINAL / "completion.json"),
            "report": ref(FINAL / "report-ja.md"),
            "STOP": ref(FINAL / "STOP.json"),
            "usage_allocated_at_snapshot": allocated,
            "usage_walks": 1,
            "completed_receipt_count": len(receipts),
            "fresh_identities": len(fresh_states),
            "owned_completed_scope": [],
        },
        ensure_ascii=False,
    )
)
