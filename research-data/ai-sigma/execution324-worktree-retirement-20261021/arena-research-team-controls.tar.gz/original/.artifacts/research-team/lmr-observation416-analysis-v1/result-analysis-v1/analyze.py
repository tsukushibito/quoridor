"""Deterministic arithmetic and identity checks on the frozen 416 result only."""

import csv
import datetime as dt
import hashlib
import json
import math
import os
import struct
import time
from collections import Counter, defaultdict
from pathlib import Path

OWN = Path(__file__).resolve().parent
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-limited-observation416-v1"
)
RESULT = BASE / "diagnostic108-v1/collection-v1/result.json"
SETTINGS = BASE / "diagnostic108-v1/settings.json"
INPUTS = BASE / "inputs-v1/twelve-prefixes.json"
REFS = [
    (
        OWN.parent / "design-ja.md",
        "c2e3102ab2304efe4070ef6407848d297ae77ae2bfebbe178c0179e0ff2930b2",
        7192,
    ),
    (
        OWN.parent / "verification.json",
        "4393a542626f39763fbc9ade1156ef09dfa680c568a415b9c12edf8918e19075",
        1939,
    ),
    (RESULT, "2b76e52991fef63dc9abcd1a02fbc394853ba2a54cfdbb07f64fecf1a3387218", 806151),
    (
        BASE / "diagnostic108-v1/collection-v1/STOP.json",
        "7a59ea135e09c99a32efe6a10296a76525a19cb0fb712f4f59c01c84c1c19377",
        2064,
    ),
    (SETTINGS, "9b78446c9ff554f97a5dcad2647306b766a51bfd42a25d956607e09acb0b598c", 12556),
    (INPUTS, "75e417572078a3d20c5d3c0b8e46afad46790dd18ac2e5c925098cd8c5a75c1a", 35281),
]


def file_refs():
    refs = []
    for path, sha, size in REFS:
        data = path.read_bytes()
        assert len(data) == size and hashlib.sha256(data).hexdigest() == sha
        mode = format(path.stat().st_mode & 0o777, "04o")
        assert mode == "0644"
        refs.append({"path": str(path), "sha256": sha, "bytes": size, "mode": mode})
    return refs


def f32(bits):
    return struct.unpack("<f", struct.pack("<I", bits))[0]


def next_bits(bits):
    value = f32(bits)
    assert math.isfinite(value)
    if value == 0:
        return 1
    return bits - 1 if value < 0 else bits + 1


def bound(value_bits, window):
    value, alpha, beta = f32(value_bits), f32(window[0]), f32(window[1])
    assert math.isfinite(value) and alpha < beta
    return "Upper" if value <= alpha else "Lower" if value >= beta else "Exact"


def dump_json(name, data):
    (OWN / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def dump_csv(name, rows):
    with (OWN / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


began = dt.datetime.now(dt.UTC).isoformat()
started = time.monotonic()
before = file_refs()
data = json.loads(RESULT.read_text())
settings = json.loads(SETTINGS.read_text())
inputs = json.loads(INPUTS.read_text())["roots"]
assert len(inputs) == 12 and len({r["id"] for r in inputs}) == 12
input_by_id = {row["id"]: row for row in inputs}
fixed_groups = {
    ("distance", "B_favourable"): {1, 5, 7},
    ("distance", "B_unfavourable"): {3, 20, 21},
    ("nnue", "B_favourable"): {1, 2, 5},
    ("nnue", "B_unfavourable"): {8, 12, 20},
}
for group, families in fixed_groups.items():
    assert {
        r["family_id"] for r in inputs if (r["evaluator"], r["selection_group"]) == group
    } == families
assert all(row["opening_bound"]["prefix_len"] == 4 for row in inputs)
assert sum(row["old_fallback_retained"] for row in inputs) == 1
artifact_refs = [measurement["artifact"] for measurement in settings["measurements"]]
assert artifact_refs[0] == artifact_refs[1]
assert artifact_refs[0]["sha256"] == (
    "85a7c2b9db0061cc066010cd8458906a3e41a7f53c490da726d4268ca30efa2b"
)

roots, branches, probes, coverage = [], [], [], []
counts = Counter()
work = defaultdict(Counter)
warm_cold = defaultdict(Counter)
origin = Counter()
counter_names = (
    "opportunities",
    "first_completed",
    "first_fail_low",
    "normal_confirmations_started",
    "full_windows_started",
)
for oi, op in enumerate(data["operations"]):
    evaluator = op["evaluator"]
    assert len(op["rows"]) == 6
    for ri, row in enumerate(op["rows"]):
        selected = input_by_id[row["root_id"]]
        assert selected["evaluator"] == evaluator == row["evaluator"]
        observation = row["measurement"]["lmr_observation"]
        measurement = row["measurement"]
        request = row["request"]
        assert request["depth"] == 5 and request["node_cap"] == 1_000_000
        assert request["time_limit_ms"] is None and request["observe_lmr"]
        assert not request["diagnostic"] and not request["warmup"]
        assert not request["observe_completed_depths"]
        assert measurement["status"] == "COMPLETE"
        assert measurement["stop"] == "DepthComplete"
        assert measurement["completed_depth"] == 5 and measurement["parent_unchanged"]
        assert not measurement["zero_stock_approx_permitted"]
        assert not measurement["zero_stock_safe_race"]
        assert measurement["lmr_method_requested"] == "depth_rank"
        assert row["root"] == observation["root_fullhistory"]
        assert row["root"]["ply"] == len(selected["prefix"])
        assert row["root"]["ply"] == selected["expected_total_ply"]
        for key in (
            "opening_bound",
            "expected_divergence_board",
            "source_example",
            "original_A_raw",
            "original_B_raw",
        ):
            assert observation["input"][key] == selected[key]
        assert not observation["refill"] and observation["finished"]
        assert observation["selected_branches"] == 4
        assert len(observation["branches"]) == 4
        assert observation["cold_child_calls"] == 8
        assert observation["cold_common_invocations"] == 8
        assert observation["complete_cold_scouts"] == 8
        assert observation["unknown_or_unperformed_cold_scouts"] == 0
        assert measurement["work"]["nodes"] <= 1_000_000
        bucket = []
        per_root_nodes = per_root_evals = 0
        unique_branches = set()
        for bi, branch in enumerate(observation["branches"]):
            hyp = branch["hypothesis"]
            depth, q, rank = (
                branch["parent_depth"],
                branch["quantum"],
                branch["distinct_rank"],
            )
            assert branch["eligible"] and not branch["protected_by_saved_ranking"]
            assert depth in (3, 4) and branch["parent_ply"] > 0
            assert branch["parent_ply"] == len(branch["path_action_colour"])
            assert branch["parent"]["ply"] == row["root"]["ply"] + branch["parent_ply"]
            assert branch["parent_stm"] == (selected["expected_side"] + branch["parent_ply"]) % 2
            assert branch["path_action_colour"][0][0] == selected["expected_side"]
            key = (
                hyp,
                branch["parent"]["root_key"],
                tuple(tuple(x) for x in branch["parent"]["history_counts"]),
                branch["action"],
            )
            assert key not in unique_branches
            unique_branches.add(key)
            if branch["parent_ply"] == 1:
                parent_counts = Counter(dict(row["root"]["history_counts"]))
                parent_counts[branch["parent"]["root_key"]] += 1
                assert parent_counts == Counter(dict(branch["parent"]["history_counts"]))
            if hyp == "H0":
                assert q == 0 and 4 <= rank <= 8
                bucket.append((hyp, depth))
                reduced_depth = depth - 2
                assert branch["stage_order"][0] == "normal_scout"
            else:
                assert hyp == "H+" and q > 0
                bucket.append((hyp, min(q, 2)))
                reduced_depth = depth - 1 - q
                assert branch["stage_order"][0] == "shallow"
            stages = branch["stages"]
            first = stages[0]
            assert first["completed"] and not first["interrupted"]
            alpha_bits = branch["post_TT_pre_child_alpha_beta_bits"][0]
            window = [alpha_bits, next_bits(alpha_bits)]
            assert first["window_bits"] == window
            assert first["child_depth"] == (depth - 1 if hyp == "H0" else reduced_depth)
            if hyp == "H+":
                assert first["bound"] == "Upper" and all(s is None for s in stages[1:])
            for stage in stages:
                if stage is not None:
                    assert stage["bound"] == bound(stage["value_bits"], stage["window_bits"])
            pair = {p["kind"]: p for p in branch["cold_probes"]}
            assert set(pair) == {"reduced", "normal"}
            pointer = f"/operations/{oi}/rows/{ri}/measurement/lmr_observation/branches/{bi}"
            for kind, probe in pair.items():
                expected_depth = reduced_depth if kind == "reduced" else depth - 1
                assert probe["status"] == "COMPLETE" and probe["stop"] == "DepthComplete"
                assert probe["child_called"] and probe["common_invocation_started"]
                assert probe["requested_child_depth"] == expected_depth
                assert probe["completed_depth"] == expected_depth
                assert probe["window_bits"] == window
                assert probe["parent_ply"] == branch["parent_ply"]
                assert probe["parent_stm"] == branch["parent_stm"]
                assert probe["TT_initial_entries"] == 0
                assert probe["node_cap"] == 100_000 and probe["time_limit_ms"] is None
                assert probe["bound"] == bound(probe["value_bits"], window)
                assert probe["value"] == f32(probe["value_bits"])
                assert probe["action"] == branch["action"] and probe["PV"] == [branch["action"]]
                assert not probe["zero_stock_approx_permitted"]
                assert not probe["zero_stock_safe_race"]
                assert probe["work"]["nodes"] <= 100_000
                per_root_nodes += probe["work"]["nodes"]
                per_root_evals += probe["work"]["evaluations"]
                for field in ("nodes", "evaluations", "LMR_attempts", "TT_hits"):
                    work[(evaluator, hyp, kind)][field] += probe["work"][field]
                probes.append(probe)
            outcome = pair["reduced"]["bound"] + "/" + pair["normal"]["bound"]
            counts[(evaluator, hyp, outcome)] += 1
            origin[(evaluator, selected["selection_group"], hyp, outcome)] += 1
            comparable = pair["reduced" if hyp == "H+" else "normal"]
            warm_cold[(evaluator, hyp)]["n"] += 1
            warm_cold[(evaluator, hyp)]["same_bits"] += (
                first["value_bits"] == comparable["value_bits"]
            )
            warm_cold[(evaluator, hyp)]["same_bound"] += first["bound"] == comparable["bound"]
            record = {
                "root_id": row["root_id"],
                "evaluator": evaluator,
                "family": selected["family_id"],
                "origin_group": selected["selection_group"],
                "hypothesis": hyp,
                "iteration_depth": branch["iteration_depth"],
                "parent_depth": depth,
                "parent_ply": branch["parent_ply"],
                "parent_stm": branch["parent_stm"],
                "rank": rank,
                "q": q,
                "visit_serial": branch["eligible_visit_serial"],
                "action": branch["action"],
                "alpha": f32(alpha_bits),
                "alpha_bits": alpha_bits,
                "scout_beta_bits": window[1],
                "original_first_phase": branch["stage_order"][0],
                "original_first_depth": first["child_depth"],
                "original_first_bound": first["bound"],
                "original_first_value": f32(first["value_bits"]),
                "original_first_bits": first["value_bits"],
                "outcome": outcome,
                "warm_cold_same_bound": first["bound"] == comparable["bound"],
                "warm_cold_same_bits": first["value_bits"] == comparable["value_bits"],
                "original_full_window_present": any(
                    phase == "full_window" and stage is not None
                    for phase, stage in zip(branch["stage_order"], stages, strict=True)
                ),
                "canonical_pointer": pointer,
            }
            for kind, probe in pair.items():
                for field in ("bound", "value", "value_bits", "requested_child_depth"):
                    record[kind + "_" + field] = probe[field]
                for field in ("nodes", "evaluations"):
                    record[kind + "_" + field] = probe["work"][field]
            branches.append(record)
        assert set(bucket) == {("H0", 3), ("H0", 4), ("H+", 1), ("H+", 2)}
        assert per_root_nodes == observation["cold_recorded_nodes"]
        assert per_root_evals == observation["cold_recorded_evaluations"]
        root_record = {
            "root_id": row["root_id"],
            "evaluator": evaluator,
            "family": selected["family_id"],
            "origin_group": selected["selection_group"],
            "divergence_ply": row["root"]["ply"],
            "root_action": measurement["action"],
            "root_value_bits": measurement["value_bits"],
            "depth": measurement["completed_depth"],
            "root_nodes": measurement["work"]["nodes"],
            "root_evaluations": measurement["work"]["evaluations"],
            "probe_nodes": per_root_nodes,
            "probe_evaluations": per_root_evals,
            "root_Search_call_seconds": measurement["Search_call_seconds"],
            "original_fallback_retained": selected["old_fallback_retained"],
        }
        for hyp, key in (("H0", "parent_depth"), ("H+", "q")):
            for branch in branches[-4:]:
                if branch["hypothesis"] == hyp:
                    root_record[f"{hyp}_{branch[key]}"] = branch["outcome"]
        roots.append(root_record)
        axes = observation["coverage_axes"]
        assert axes == {
            "depth": [3, 4],
            "distinct_rank": ["4..8", "9..15", "16..31", "32+"],
            "quantum": ["0", "1", "2+"],
        }
        for di, d in enumerate(axes["depth"]):
            for rki, r in enumerate(axes["distinct_rank"]):
                for qi, quantum in enumerate(axes["quantum"]):
                    cell = observation["coverage"][di][rki][qi]
                    assert (
                        cell["first_fail_low"] <= cell["first_completed"] <= cell["opportunities"]
                    )
                    assert (
                        cell["normal_confirmations_started"]
                        <= cell["first_completed"] - cell["first_fail_low"]
                    )
                    coverage.append(
                        {
                            "root_id": row["root_id"],
                            "evaluator": evaluator,
                            "depth": d,
                            "rank_band": r,
                            "q_band": quantum,
                            **cell,
                        }
                    )

assert len(roots) == 12 and len(branches) == 48 and len(probes) == 96
assert {r["root_id"] for r in roots} == set(input_by_id)
root_nodes = sum(r["root_nodes"] for r in roots)
probe_nodes = sum(p["work"]["nodes"] for p in probes)
probe_evals = sum(p["work"]["evaluations"] for p in probes)
assert root_nodes == data["census"]["root_recorded_nodes"] == 4_062_877
assert probe_nodes == data["census"]["recorded_nodes"] == 22_445
assert probe_evals == data["census"]["recorded_evaluations"] == 17_313
assert root_nodes + probe_nodes == data["recorded_total_nodes"] == 4_085_322
assert len(roots) + len(probes) == data["total_common_invocations"] == 108
assert not data["nested_costs_added"] and data["parent_restore_all"]
assert data["unknown_work_invocations"] == 0
assert counts == Counter(
    {
        (x["evaluator"], x["hypothesis"], x["reduced_normal_bounds"]): x["n"]
        for x in data["outcomes"]
    }
)
outcomes = [
    {
        "evaluator": e,
        "hypothesis": h,
        **{
            b: counts[(e, h, b)]
            for b in ["Upper/Upper", "Lower/Upper", "Lower/Lower", "Upper/Lower"]
        },
    }
    for e in ("distance", "nnue")
    for h in ("H0", "H+")
]
coverage_summary = []
for evaluator in ("distance", "nnue"):
    for depth in (3, 4):
        for quantum in ("0", "1", "2+"):
            selected_cells = [
                c
                for c in coverage
                if c["evaluator"] == evaluator and c["depth"] == depth and c["q_band"] == quantum
            ]
            coverage_summary.append(
                {
                    "evaluator": evaluator,
                    "depth": depth,
                    "q_band": quantum,
                    **{key: sum(c[key] for c in selected_cells) for key in counter_names},
                }
            )
summary = {
    "outcomes": outcomes,
    "work_by_evaluator_hypothesis_kind": [
        {"evaluator": e, "hypothesis": h, "kind": k, **v} for (e, h, k), v in work.items()
    ],
    "warm_cold_same_depth": [
        {"evaluator": e, "hypothesis": h, "cold_kind": "reduced" if h == "H+" else "normal", **v}
        for (e, h), v in warm_cold.items()
    ],
    "origin_groups_descriptive_only": [
        {"evaluator": e, "origin_group": g, "hypothesis": h, "bounds": b, "n": n}
        for (e, g, h, b), n in sorted(origin.items())
    ],
    "coverage_by_depth_quantum": coverage_summary,
    "selected_ranks": dict(
        Counter(str((b["hypothesis"], b["parent_depth"], b["q"], b["rank"])) for b in branches)
    ),
    "selected_parent_plies": dict(Counter(b["parent_ply"] for b in branches)),
    "root_nodes": root_nodes,
    "root_evaluations": sum(r["root_evaluations"] for r in roots),
    "probe_nodes": probe_nodes,
    "probe_evaluations": probe_evals,
    "original_outer_seconds": data["outer_seconds"],
    "operation_clocks_not_additive_to_outer": [
        {k: op[k] for k in ("evaluator", "whole_seconds", "setup_seconds", "drop_seconds")}
        for op in data["operations"]
    ],
    "probe_internal_seconds_sum_separate_scope": sum(
        p["Search_internal_elapsed_seconds"] for p in probes
    ),
    "probe_whole_seconds_sum_separate_scope": sum(
        p["whole_including_local_setup_drop_seconds"] for p in probes
    ),
    "artifact_ref_from_saved_settings_only": artifact_refs[0],
    "native_input_admission_reused_not_replayed": data["native_input_admission"],
}
dump_csv("branches.csv", branches)
dump_csv("roots.csv", roots)
dump_csv("coverage.csv", coverage)
dump_json("summary.json", summary)
after = file_refs()
assert before == after
dump_json(
    "verification.json",
    {
        "issue": "quoridor-4lc.416.4",
        "before": before,
        "after": after,
        "all_selected_refs_unchanged": True,
        "checks": [
            "12 fixed identities/groups and preserved fallback",
            "48 branches/96 COMPLETE probes",
            "request caps and no refill",
            "fullhistory/path/ply metadata correspondence without rule replay",
            "independent cold recorded conditions",
            "depth/STM/window/f32 bound classification",
            "within-hypothesis dedup",
            "root/probe/coverage arithmetic",
            "recomputed 4 outcome rows agree with collection",
        ],
        "not_checked": [
            "native source or binary",
            "model payload or evaluation",
            "original 392 RAW",
            "legal replay or collector replay",
            "first eligible rule implementation; reused independent source review",
        ],
        "reader_started_utc": began,
        "reader_stopped_utc": dt.datetime.now(dt.UTC).isoformat(),
        "helper_seconds": time.monotonic() - started,
        "reader_pid": os.getpid(),
        "reader_start_ticks": Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()[19],
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "GPU": 0,
    },
)
print(
    json.dumps(
        {
            "outcomes": outcomes,
            "warm_cold": summary["warm_cold_same_depth"],
            "work": summary["work_by_evaluator_hypothesis_kind"],
            "coverage": coverage_summary,
            "selected_ranks": summary["selected_ranks"],
            "plies": summary["selected_parent_plies"],
            "roots": roots,
            "clocks": {k: v for k, v in summary.items() if "seconds" in k},
        },
        ensure_ascii=False,
        indent=2,
    )
)
