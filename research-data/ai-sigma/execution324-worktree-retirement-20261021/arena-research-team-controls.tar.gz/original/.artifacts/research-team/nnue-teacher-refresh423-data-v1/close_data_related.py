import datetime
import hashlib
import json
import os
import resource
from pathlib import Path

OWN = Path(__file__).resolve().parent
OUT = OWN / "data-related-v1"
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


def absent(identity):
    try:
        start = (
            Path(f"/proc/{identity['pid']}/stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19]
        )
        same = BOOT == identity["boot_id"] and str(start) == str(
            identity["start_ticks"]
        )
    except FileNotFoundError:
        same = False
    assert not same, identity
    return dict(identity=identity, fresh_absent_or_different=True)


receipts = []
stages = [
    p
    for p in sorted(OWN.iterdir())
    if p.is_dir()
    and p.name.startswith("data-related-")
    and (p / "command.process.json").is_file()
]
for stage in stages:
    process = stage / "command.process.json"
    p = json.loads(process.read_bytes())
    c = json.loads((stage / "controller.json").read_bytes())
    assert (
        p["direct_child_reaped"]
        and p["cleanup_complete"]
        and p["handle_closes_complete"]
    )
    assert p["remaining"] == [] and not (stage / "TMP").exists()
    receipts.append(
        dict(
            stage=stage.name,
            process=ref(process),
            returned=ref(stage / "return.json"),
            child=absent(p["child"]),
            controller=absent(c),
            seconds=p["wall_seconds"],
            exit_code=p["exit_code"],
            TMP_absent=True,
            disk_mask=p["signal_mask_restoration"],
            disk_persist=p["final_record_persist"],
        )
    )
binding_ref = ref(OUT / "source-binding.json")
binding = json.loads((OUT / "source-binding.json").read_bytes())
for key in [
    "before",
    "post",
    "forward",
    "inverse",
    "proof",
    "parent_binding",
    "review",
    "review_control",
]:
    assert ref(Path(binding[key]["path"])) == binding[key], key
assert ref(OUT / "source-binding.json") == binding_ref
files = set()
for directory in [OUT, *stages]:
    files.update(p for p in directory.rglob("*") if p.is_file() and not p.is_symlink())
files.update(
    OWN / name
    for name in [
        "prepare_data_related.py",
        "freeze_data_related.py",
        "close_data_related.py",
    ]
)
usage = dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope="ONLY new data-related-v1 repair, its named guard stages and three helpers",
    files=len(files),
    bytes=sum(p.stat().st_size for p in files),
    allocated_bytes=sum(p.stat().st_blocks * 512 for p in files),
    meaning="one directed retained affected-scope observation, not global actual or all new allocation",
    excludes="later STOP/completion/usage/delivery/admin bookkeeping; old packets/OWN holdings not recharged",
    global_actual="UNKNOWN",
    no_global_assets_target_walk_or_refund=True,
)
(OUT / "usage.json").write_text(json.dumps(usage, indent=2) + "\n")
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
stop = dict(
    issue="quoridor-4lc.423.3",
    phase="data-v2 C1/C2 related source repair only",
    actual_source_STOP=now,
    receipts=receipts,
    owned_readers_writers_children_jobs_handles_TMP_leases=[],
    remaining=[],
    Main_canonical_hardware_leases=0,
    CPU=8,
    guardian_CPU=12,
    child_memory_limit_bytes=960 * 1024**2,
    GPU=0,
    hostreserve_bytes=4 * 1024**3,
    actual_source_refs_exact=True,
    child_wall_seconds_sum_once=sum(r["seconds"] for r in receipts),
    cost_scope="entered scoped helper/formatter/admin children once; excludes controller/LLM/full task, no scientific execution",
    original_masks="returned and disk originals retained without promotion",
    unrecorded_plain_tool_controller_identity_handles="UNKNOWN",
    continuous_family_peak_globalactual_totalfees="UNKNOWN",
    metadata_writer=dict(
        pid=os.getpid(),
        start_ticks=Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()[19],
        boot_id=BOOT,
        affinity=sorted(os.sched_getaffinity(0)),
        maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        scope="small ordinary metadata writer exits after write; separate from stopped source readers",
    ),
)
(OUT / "source-STOP.json").write_text(json.dumps(stop, indent=2) + "\n")
completion = dict(
    issue="quoridor-4lc.423.3",
    status="thin related source repair frozen; Root acceptance/close separate",
    binding=binding_ref,
    parent_binding=binding["parent_binding"],
    forward=binding["forward"],
    inverse=binding["inverse"],
    post=binding["post"],
    proof=binding["proof"],
    report=ref(OUT / "report-ja.md"),
    STOP=ref(OUT / "source-STOP.json"),
    usage=ref(OUT / "usage.json"),
    new_test_definitions=0,
    changed_test_filters=binding["required_software"],
    software="UNBUILT/UNTYPED/UNRUN",
    source_clear="SAME423.4 pending, not inferred",
    Main_Git_Cargo_native_tests_models_forward_Search_games=0,
    future_image=None,
    future_Build=None,
    original_negative_review_source_payloads_errors_STOP_fees="preserved",
    old_pauses_defaults_models_weights_seals="unchanged",
)
(OUT / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
print(
    json.dumps(
        dict(
            completion=ref(OUT / "completion.json"),
            STOP=completion["STOP"],
            actual_source_STOP=now,
            usage=usage,
            owned=[],
        )
    )
)
