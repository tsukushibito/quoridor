# 423 原arena160のmetadata/settings準備

| 対照            | 役割                  | 元評価family | 二色games / pairs | 独立node quota |
| --------------- | --------------------- | ------------ | ----------------- | -------------- |
| W / BEST43      | primary               | 既存順の全64 | 128 / 64          | 800,000,000    |
| W / D(0,8,tanh) | secondary exploratory | 同じ先頭16   | 32 / 16           | 200,000,000    |

二つの通常config/plan/schedule/RUN-templateを作成した。合計160games/80pairs/1G上限、quotaの貸借・per-pair reset・補充はない。主対照のfamily CIは64全組、副対照は16全組でnativeが一度集計する。本人はbootstrapを実行していない。共通16familyと二色を独立標本へ増やさず、旧408/412/421の成績と混ぜない。

## 保存入力とcarrier

評価用collectionからrequested64/accepted64/missing0/Search0を確認し、元prefix-book fda4e717、schedule b1e90b69、partition28026680、config405c71e6を束縛した。元configはprospective256・旧355・421生成/評価bookを既に除外しており、今回新たな除外判定やprefix生成を行っていない。最終256もこの同じprospective入力に束縛される。

ArenaInputBook用carrierはcomplete/rules/familiesと既存strict Familyだけ。global family_id・request ID・prefix・root_key・history_counts・accepted attempt_idを元scheduleから保持する。64個すべてで保存accepted attemptは実0だった。これは元データとの照合結果であり、0を補ったものではない。元rootのboard/side/stock等はscheduleのJSON pointerで追える。root/historyの再生成・rules replay・新たな合法性資格は行っていない。

Family.seedとopening.original_seedには共有生成batchのprefix_seed42320261017を明示して対応させる。seed_scope=shared_generator_batch_prefix_seed、per-family RNG stateはUNKNOWN。arena RNG42320261026とnative bootstrap42320261027を別に記録し、個別seedからの再生成可能性を主張しない。元順・元refsは変更0。

## モデル・image・探索条件

Wはchanged-weights-entry-v2の実metadataからweights ab073fb1、descriptor fbf0beb8、typed8a8eb7fbをそのまま引用した。BEST43は元normal421 planからdescriptor46ec/weights046fe/typed96a5を引用。Dはoriginal-distance-a0-b8-tanh、models=[]/model=nullで、既存の真正D configが宣言したevaluator識別子を引用し、新hashは導出していない。

image35e47e65/Build9bf66048は既存arena-receiver build manifest参照。モデル・library・image payloadの読取り、重み対応/旧software/suiteの再実行は0。これらのmetadata引用を新たなnative資格へ昇格しない。

Control/PVS/TT1048576、LMR ON depth_rank、旧approx/safeRace OFF、nominal depth64、各Search1M、100ms authority receipt、5ms reserve、total200plyを維持。namespace/typed method IDの合成はせず、実sessionが正本である。PVSは既存arena factoryの意味として記録し、新しいJSON selectorは追加していない。未来のactual method/namespace、clock/receipt/terminal/drain/UNKNOWNはRoot実結果で確認する。

## 通常callerとの対応と未確定項目

旧421真正Buildのimmutable Git7e9537c6から、同じcaller499724deのarena_plan_check/planned_game_slice/arena_model_checkと参照helperをメモリ内で再用した。二つともpure metadata check PASS、128+32 slot/64+16 pair、元prefix/root/history/attemptと14選択refsの前後一致を確認。checkerのための必要fieldだけのprojectionをメモリに作ったが、Experimentファイルは生成していない。現Main sourceの読者・canonical leaseは不要だった。current caller bindingはRootが最終的に行う。

既存planned_game_sliceは一つのplanで全matchupに同family数を要求する。このため二つの通常planを使う。連続順はprimary→secondary、各operation内は全pairを通常native入口で継続する。新scheduler/registryやper-pair LLM入口はない。Rootはこの二つの通常RUNを既存の有限連続実行経路に束縛できる。

RUN-templateのExperiment/env/argv/runtime/support/actual output/current callerはnullのNOT_READY。config.outputは予定path文字列であり、実出力FileRefではない。未来のPID/physical quiet/forecast/数値資格を作っていない。candidate native cores2/6+main4/family4GiBは候補で、Rootがentryで実確認する。

config.max_output_bytes=128MiB、retained_outcome_bytes=8MiBはper-operation ceilingにすぎず、二つの追加予約や2×128MiBの保存許可ではない。旧423全RAW/fit/失敗を含むwhole128MiBとglobaldecimal50GBのまま、実残量・output forecast/supportはRootがentry前に確定する。足りるという主張はしていない。出力quotaやnode quotaを結果後に転用しない。

## source-only終了

私有PythonはRuff、手書きJSON/configはproject Prettierで整形し、依存FileRefs/source_shaだけを順序通り更新した。preformat recoveryとformat-bind-proofを保存し、選択・生成を再実行していない。native/compiler/Cargo/モデル/forward/Search/game/fit/新review dispatchは0、Main/Git/index/source変更0（immutable Gitの読取りのみ）。

通常の補助失敗として、対象名のないrg exit1と最終settings組立てのduplicate use_pvs TypeErrorを保存した。後者では既存carrier/config/plan/scheduleを維持し、未生成settingsだけを完成した。actualcontext確認前のpwd一回もbootstrapへ手順逸脱として記録した。旧原FAILED/Roperation/NULL-vs-disk/費UNKNOWNは変更しない。

CPU10/G14の既存guardでsource/metadataを処理し、topology/affinity/no_new_privs/host reserve/child960MiB+controller64MiB契約、directwait/reap/handles/TMPと既知identity fresh absenceを保存する。瞬間occupancy・未記録controller/continuous family peak・全作業費をfuture quietや0費へ読み替えない。sourceSTOP/owned[]、一回のOWN usage、completionと本reportをcurrent324へ一度渡す。423.1の後の保存解析、Root通常admissionと実arenaを待つが、親close/返答ACKは入口にしない。元323/342 pause・defaults/models/seals/旧RAW/FAILED/feesは維持する。
