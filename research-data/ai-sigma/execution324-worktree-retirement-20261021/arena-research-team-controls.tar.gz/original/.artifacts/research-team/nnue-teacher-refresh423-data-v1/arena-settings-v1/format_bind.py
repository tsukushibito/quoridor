"""Format and rebind the already selected private metadata; no input selection."""

import gzip
import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parent
FORMATTER = Path(
    "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier"
)
names = [
    "arena-book.json",
    "carrier-provenance.json",
    "model-identities.json",
    "primary-W-vs-BEST43/schedule.json",
    "secondary-W-vs-D/schedule.json",
    "primary-W-vs-BEST43/config.json",
    "secondary-W-vs-D/config.json",
    "primary-W-vs-BEST43/plan.json",
    "secondary-W-vs-D/plan.json",
    "primary-W-vs-BEST43/RUN-template.json",
    "secondary-W-vs-D/RUN-template.json",
    "settings.json",
]


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


changed = {}
proof = []
old_carrier = ref(OWN / "arena-book.json")["sha256"]
new_carrier = None


def rebind(value):
    if isinstance(value, list):
        return [rebind(v) for v in value]
    if not isinstance(value, dict):
        return value
    if set(value) == {"path", "sha256", "bytes", "mode"} and value["path"] in changed:
        return changed[value["path"]]
    result = {k: rebind(v) for k, v in value.items()}
    if result.get("source_sha256") == old_carrier and new_carrier is not None:
        result["source_sha256"] = new_carrier
    return result


for name in names:
    path = OWN / name
    before = ref(path)
    raw = path.read_bytes()
    recovery = OWN / "preformat-recovery" / (name + ".gz")
    recovery.parent.mkdir(parents=True, exist_ok=True)
    recovery.write_bytes(gzip.compress(raw, mtime=0))
    value = rebind(json.loads(raw))
    result = subprocess.run(
        [str(FORMATTER), "--ignore-path", "/dev/null", "--stdin-filepath", str(path)],
        input=json.dumps(value, ensure_ascii=False).encode(),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**os.environ, "NODE_OPTIONS": "--max-old-space-size=128"},
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout) == value
    path.write_bytes(result.stdout)
    after = ref(path)
    changed[str(path)] = after
    proof.append(
        dict(
            name=name,
            before=before,
            after=after,
            formatter_exit=0,
            directwait=True,
            stderr=result.stderr.decode(),
            allowed_change="whitespace and exact existing private FileRef/source_sha rebinding only",
        )
    )
    if name == "arena-book.json":
        new_carrier = after["sha256"]
(OWN / "format-bind-proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(
    json.dumps(
        dict(
            formatted=len(proof),
            selection_replayed=False,
            science_calls=0,
            settings=ref(OWN / "settings.json"),
        )
    )
)
