from pathlib import Path

OWN = Path(__file__).resolve().parent
REL = "crates/quoridor-runner/src/runtime.rs"
POST = OWN / "native-repair-v1/post" / REL
POST.parent.mkdir(parents=True)
original = (OWN / "post" / REL).read_text()


def repair(s):
    old = """    run_owned(config, mode, Some(backend))
}"""
    new = """    if config.common_study.is_some() {
        return Err("common MCTS requires the maintained CPU ORT factory; supplied backend refused before admission".into());
    }
    run_owned(config, mode, Some(backend))
}"""
    assert s.count(old) == 1
    s = s.replace(old, new)
    old = """            o.failure = Some(crate::arena_clock::failure_from_reason(&reason));
            o.reason = Some(reason.clone());"""
    new = """            // Keep a known originating per-game cause ahead of this secondary
            // publication error, including the later cancellation attribution pass.
            if self.stopped.is_none() && let Some(prior) = &o.reason {
                *self.stopped = Some(prior.clone());
            }
            o.failure.get_or_insert_with(|| crate::arena_clock::failure_from_reason(&reason));
            o.reason.get_or_insert_with(|| reason.clone());"""
    assert s.count(old) == 1
    return s.replace(old, new)


POST.write_text(repair(original))
# This derivative is unfinished private work, not the frozen native-v2 target.
p = OWN / "old-q-source-v1/post" / REL
p.write_text(repair(p.read_text()))
print(
    "R1/C1 related delta prepared; original v2 unchanged, unfinished old-q rebased on repair"
)
