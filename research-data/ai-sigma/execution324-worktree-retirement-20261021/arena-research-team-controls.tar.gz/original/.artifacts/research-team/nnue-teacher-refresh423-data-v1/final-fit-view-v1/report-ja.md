# 423 最終fit-viewの限定receiver差分

元pilot32とsuffix224のRAW・native config・元splitを変更せず、最終256入力の割当をcompact samplingへ明示する私有差分を用意した。対象は `crates/quoridor-data/src/terminal_cache.rs` 一ファイル。Main/Git/Cargo、native/テスト/モデル/forward/対局/fitの実行は行っていない。新4定義はUNBUILT/UNTYPED/UNRUNであり、source clearや成功conversionは主張しない。

## 入力と対応

既存 `--input-binding` のJSONへ、`input-binding-fragment.json` の `final_fit_view` BoundJsonを加える。参照先 `final-view-config.json` は既存common Config形式で、実prospective schedule `33ea6d00`・partition `42c2fea8`、families=256、batch_start=0、batch_count=256を束縛する。これはsampling用の別configであり、元producer configの代用品ではない。fragment単独は実行用input-bindingではなく、元の実model_scale_authorityを保持した通常bindingへ合成する。

小さい保存metadata照合で、4pilot+28suffixの32元sliceがID0..255を一度ずつ連続して覆い、元と最終のrequest ID/全prefix/family/各schedule slotが一致した。元203T/53V、最終204T/52V、変更はID18 validation→trainのみ。分類器・split算出・geometry・RAW/row bodyの実行/読取りは行っていない。このmetadata照合は完全履歴の合法性やoutcomeの資格ではなく、実conversionで正本ownerが検証する。

## native receiver

元の各common configへ `validate_inputs`、各元rowへvalidate/raw/元schedule・family・split・全prefix開始・chronological terminal block検証を従来通り適用する。その後だけ、対応済み最終splitをWriterのprivate引数へ渡す。TeacherRowはimmutableのままで、sampling.binのsplit、sampling families、eligible split集計だけが最終viewとなる。z/q/geometry/row ID/STM/適格性/保存元は変えない。

最終configも同じcanonical ownerでvalidate_inputsを行う。元sliceと最終viewの相違をfamilies/schedule/partition/batch範囲だけへ限定し、その他seed・prefix長・policy・excluded booksは一致必須。各global request・prefix・familyを照合し、欠測/duplicate assignment/alias/順序/範囲gapを拒否する。実rowのgame blockも各元slice全slotを順に満たす必要があり、欠落を成功viewへ昇格しない。元config refsと全対応表、source/view split、changed_global_idsをmanifestのfinal_fit_viewへ保存する。

view未指定時は既存MCTS strict mergeを保持。Alpha route、元MctsSourceのmodel/sims/raw検査、canonical game名、geometry/labels、Writer.finish、publicationのpartial/失敗kernelは保全。codec/schema/CLI/Cargo依存の追加はない。

## Rootが持つreceiver対応

現在のPython `common_cache_config` は既存range unionと最終common configを受け入れる一方、追加の `final_fit_view` metadataを検査しない。arityやsampling codecの変更は不要だが、使用するならRoot側でこの任意fieldをinput_binding内の実BoundJsonと結び、対応表のglobal_id/game/request/source_index、元slice区間、family/prefix/source_split/view_split、changed IDsおよび最終sampling splitの整合を限定検査する必要がある。元native configs・schedule/partitionとの対応はnative側でも全検証される。Python/publisherは本人の所有外なので変更していない。view無しは従来のまま扱う。

## 検証と引渡し

Rustfmt、私有PythonのRuff、JSON整形、GNU patch --fuzz=0の順・逆exact-byte復元、保護body一致を確認した。strict patchは一回のみ実行。元mergeは整形による空白とtrailing commaを除いて同一、その他の保護部分はexact bytes。新4定義のexact名とRoot必要scopeはverification-plan.jsonにある。旧成功suite/52fixture/solver再演は0。

元の補助reader SyntaxError、source置換assertion、保護proofの整形差assertionは各FAILED captureを保存し修復した。native/testは入場していない。Prettierによる最終configのbyte変化はformat-binding-note.jsonに前後SHAを区別し、fragmentを新SHAへ束縛した。対応照合は同一JSON値を使い再演していない。

source-binding.json、completion.json、source-STOP.json、selectedrefs-after.jsonをRoot324へ渡す。source/metadataのみの有限完了で、実conversion・software・同423.4の変更split/view確認はRootが担当する。過去のRAW/partial/FAILED/NULL-vs-disk/費UNKNOWN、128MiB・decimal50GB、旧342/323 pause、models/defaults/sealsは維持する。各guardのdirectwait/reap/handles/cleanupと既知identity fresh absenceを保存し、未記録controller peak/全作業費はUNKNOWNとする。
