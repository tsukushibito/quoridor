#[cfg(test)]
mod common_mcts_codec_tests {
    use super::*;
    use crate::{
        Split, Teacher,
        terminal::{TerminalProvenance, Termination, attach_terminal_targets},
        terminal_stream::BoundJson,
    };

    fn row(id: usize, raw: f32) -> TeacherRow {
        let context = SigmaContext::from_prefix(&[]).unwrap();
        TeacherRow::from_context(
            format!("row-{id}"),
            format!("game-{id}"),
            "a".repeat(64),
            Split::Train,
            vec![],
            &context,
            Some(13),
            Teacher::Mcts {
                root_mean: raw,
                root_nn: Some(0.25),
                root_visits: 64,
                nn_calls: 1,
                edges: vec![],
            },
            "b".repeat(64),
        )
        .unwrap()
    }

    #[test]
    fn common_mcts_raw_requires_model_complete_visits_and_finite_head_without_z_mask() {
        let policy = MctsSource {
            model_sha256: "b".repeat(64),
            completed_simulations: 64,
        };
        let mut r = row(0, -0.0);
        assert_eq!(policy.raw(&r).unwrap().to_bits(), (-0.0f32).to_bits());
        r.model_sha = "c".repeat(64);
        assert!(policy.raw(&r).is_err());
        r.model_sha = "b".repeat(64);
        for teacher in [
            Teacher::InputOnly,
            Teacher::Mcts {
                root_mean: 0.1,
                root_nn: Some(0.2),
                root_visits: 63,
                nn_calls: 1,
                edges: vec![],
            },
            Teacher::Mcts {
                root_mean: f32::NAN,
                root_nn: Some(0.2),
                root_visits: 64,
                nn_calls: 1,
                edges: vec![],
            },
            Teacher::Mcts {
                root_mean: 0.1,
                root_nn: None,
                root_visits: 64,
                nn_calls: 1,
                edges: vec![],
            },
        ] {
            r.teacher = teacher;
            assert!(policy.raw(&r).is_err());
        }
        r = row(1, 1.0);
        r.z = Some(-1.0); // Opposite outcome does not filter or rewrite MCTS q.
        assert_eq!(policy.raw(&r).unwrap(), 1.0);
    }

    #[test]
    fn common_mcts_v3_codec_preserves_raw_unknown_mask_and_chronological_blocks() {
        let root = std::env::temp_dir().join(format!("mcts-common-codec-{}", std::process::id()));
        fs::create_dir(&root).unwrap();
        let reference = BoundJson {
            path: root.join("unexecuted-input.json"),
            sha256: "0".repeat(64),
        };
        let common = crate::common_corpus::Config {
            families: 2,
            prefix_seed: 1,
            prefix_lengths: vec![4],
            split_seed: 2,
            root_value_policy: crate::common_corpus::RootValuePolicy::OutcomeOnly,
            schedule: reference.clone(),
            partition: reference,
            batch_start: 0,
            batch_count: 2,
            excluded_books: vec![],
        };
        let output = root.join("cache");
        let mut writer = Writer::new_common(&output, common).unwrap();
        writer.mcts_source = Some(MctsSource {
            model_sha256: "b".repeat(64),
            completed_simulations: 64,
        });
        let moves = vec![13, 75, 22, 66, 31, 57, 40, 48, 49, 39, 58, 30, 67, 21, 76];
        let context = SigmaContext::from_prefix(&moves).unwrap();
        let goal =
            TerminalProvenance::from_context(&context, moves, Termination::Goal, "goal".into())
                .unwrap();
        let context = SigmaContext::from_prefix(&[13]).unwrap();
        let unknown = TerminalProvenance::from_context(
            &context,
            vec![13],
            Termination::Unknown,
            "row_cap".into(),
        )
        .unwrap();
        for (id, q, provenance) in [(0, -0.0, &goal), (1, 1.0, &unknown)] {
            let mut r = row(id, q);
            attach_terminal_targets(std::slice::from_mut(&mut r), provenance).unwrap();
            writer.push(&r, None).unwrap();
        }
        writer
            .finish("c".repeat(64), false, serde_json::Map::new())
            .unwrap();
        assert_eq!(
            fs::read(output.join("completed-root-raw.f32")).unwrap(),
            [(-0.0f32).to_le_bytes(), 1.0f32.to_le_bytes()].concat()
        );
        assert_eq!(
            fs::read(output.join("common-eligible.u8")).unwrap(),
            vec![1, 0]
        );
        let value: serde_json::Value =
            serde_json::from_reader(std::fs::File::open(output.join("cache.json")).unwrap())
                .unwrap();
        assert_eq!(value["common_corpus"]["rootmean_is_raw"], true);
        assert_eq!(value["sampling"]["games"].as_array().unwrap().len(), 2);
        assert_eq!(value["sampling"]["games"][1]["start"], 1);
        assert_eq!(value["sampling"]["families"].as_array().unwrap().len(), 1);
        fs::remove_dir_all(root).unwrap();
    }
}
