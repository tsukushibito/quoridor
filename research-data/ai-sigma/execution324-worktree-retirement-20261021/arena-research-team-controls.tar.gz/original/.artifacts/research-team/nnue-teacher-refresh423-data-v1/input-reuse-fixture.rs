#[test]
fn input_schedule_reuse_keeps_original_attempts_missing_slots_and_repartitions_only() {
    let root = std::env::temp_dir().join(format!("input-schedule-reuse-{}", std::process::id()));
    std::fs::create_dir(&root).unwrap();
    let mut slots = vec![input_slot(0, &[13]), input_slot(1, &[5])];
    for (id, slot) in slots.iter_mut().enumerate() {
        slot.request_id = format!("fixed-d-family-{id:06}");
    }
    slots[1].prefix = None;
    slots[1].root = None;
    slots[1].canonical_prefix = None;
    slots[1].scheduled_failure = Some("original_missing".into());
    slots[1].attempts[0].rejection = Some("original_missing".into());
    let master = root.join("master.json");
    std::fs::write(
        &master,
        serde_json::to_vec(
            &serde_json::json!({"generator_version":quoridor_data::common_corpus::VERSION,
            "prefix_seed":7,"prefix_lengths":[1],"scheduled":slots}),
        )
        .unwrap(),
    )
    .unwrap();
    let c = InputConfig {
        families: 1,
        prefix_seed: 7,
        prefix_lengths: vec![1],
        split_seed: 23,
        excluded_books: vec![],
        unique_families: false,
        output: root.join("pilot"),
        reuse_schedule: Some(BoundJson {
            sha256: quoridor_data::file_sha(&master).unwrap(),
            path: master,
        }),
    };
    let report = prepare_inputs(&c).unwrap();
    let schedule: BoundJson = serde_json::from_value(report["schedule"].clone()).unwrap();
    assert_eq!(
        schedule.read().unwrap()["scheduled"],
        serde_json::to_value(&slots[..1]).unwrap()
    );
    let mut all = c.clone();
    all.families = 2;
    all.output = root.join("all");
    let report = prepare_inputs(&all).unwrap();
    let schedule: BoundJson = serde_json::from_value(report["schedule"].clone()).unwrap();
    assert_eq!(
        schedule.read().unwrap()["scheduled"],
        serde_json::to_value(&slots).unwrap()
    );
    assert_eq!(report["missing_slots"], 1);
    let mut wrong = c.clone();
    wrong.prefix_seed = 8;
    wrong.output = root.join("wrong");
    assert!(prepare_inputs(&wrong).is_err());
    assert!(!wrong.output.exists());
    wrong = c.clone();
    wrong.prefix_lengths = vec![2];
    wrong.output = root.join("wrong-length");
    assert!(prepare_inputs(&wrong).is_err());
    std::fs::remove_dir_all(root).unwrap();
}
