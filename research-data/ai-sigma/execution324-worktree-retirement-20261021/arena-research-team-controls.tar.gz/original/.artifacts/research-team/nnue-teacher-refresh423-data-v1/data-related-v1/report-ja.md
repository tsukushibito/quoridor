data-source-v2のC1/C2だけを修復した。今回のforwardは凍結data-source-v2へ一度適用する薄いterminal_cache.rs差分であり、元の累積patchを再適用しない。元post/bindingとsource_clear=false/ordinary2のレビュー、FAILED/費/原STOPは保持する。

C1: production receiverが使う小さいprivate mcts_game_idで、数値解析後に元文字列がgame-{id}と一致することを要求する。game-0とgame-00、game-1とgame-01、符号・空白表記を同一assignmentの別game blockとして通さない。実batch範囲、canonical family/prefix/split、Writerのseen-game/chronology、原row IDsの検査はそのままである。実際に重複datasetを観測した主張ではない。既存の新raw-policy定義へ同じproduction parserの正規表記とalias拒否を追加し、別のfixture定義は増やしていない。

C2: 二つの新codec定義が共用するpositive row helperのedgesを、合法なaction13/visits63/prior1.0の一辺へ修正した。sum(visits)+root1=64で、既存のroot_visits64と対応する。maintained TeacherRow validator、eligibility、count/source検査や意図的negative casesは緩めていない。source上のfixture不整合の修復であり、元fixtureがnativeで実際に失敗したという記録にはしない。

新定義0、既存新定義2の変更だけで、UNBUILT/UNTYPED/UNRUN。作者はcompiler/Cargo/native/test/model/forward/Search/ゲームを実行しない。対象Rustfmt、helper Ruff、report整形と厳密fuzz0 forward/inverseのbefore/post byte一致を確認する。元の他data subject、入力・nativeの独立clear、MCTS数学/codec列/producer publication owner/Python consumerは変更しない。

実guardのCPU8/別physical guardian12、child960MiB+普通controller、GPU0/reserve4GiBを使用する。過去の421STOPは観測されたreleaseで、futurequiet/idle leaseではない。今回のreader/child/directwait/reap/handles/TMP/fresh identity/STOPと一度の修復対象usageは別保存する。LLM/controller全費、連続family peak/globalactualはUNKNOWN。Main/Git/index/Cargo/science・再帰dispatch・review dispatchは0、全旧pause/default/model/weight/seal/RAWFAILEDと費を保持する。
