import shutil
from pathlib import Path

OWN = Path(__file__).resolve().parent
OUT = OWN / "data-source-v2"
OUT.mkdir()
POST = OUT / "post/crates/quoridor-data/src"
POST.mkdir(parents=True)
for name in ["terminal_cache.rs", "terminal_stream.rs", "bin/terminal-cache.rs"]:
    p = POST / name
    p.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(OWN / "post/crates/quoridor-data/src" / name, p)

p = POST / "terminal_stream.rs"
s = p.read_text()
start = s.index("pub fn write_cache(")
end = s.index("\n}", start) + 2
function = s[start:end]
shell_at = function.index("    fs::create_dir(output)?;")
materialize_at = function.index("        let mut batches = Vec::new();")
finish_at = function.index("        let manifest =")
materialize = function[materialize_at:finish_at]
materialize = materialize.replace('writer.as_mut().ok_or("cache writer")?', "writer")
old = function[shell_at:]
shell = old.replace("    fs::create_dir(output)?;", "    fs::create_dir(output)?;", 1)
a = shell.index("        let mut batches = Vec::new();")
b = shell.index("        let manifest =", a)
shell = (
    shell[:a]
    + '        let (dataset_sha, extra) = materialize(writer.as_mut().ok_or("cache writer")?)?;\n'
    + shell[b:]
)
helper = (
    """/// Shared existing incomplete-marker-last publication for two source codecs.
/// Each source retains its own actual metadata and validation, not a fake stream.
pub(crate) fn publish_common_cache(
    output: &Path,
    common: crate::common_corpus::Config,
    inputs: &[PathBuf],
    materialize: impl FnOnce(&mut Writer) -> Result<(String, serde_json::Map<String, Value>)>,
) -> Result<TensorCache> {
"""
    + shell
)
replacement = (
    function[:shell_at]
    + "    publish_common_cache(output, common.clone(), inputs, |writer| {\n"
    + materialize
    + "        Ok((dataset_sha, extra))\n    })\n}"
)
s = s[:start] + helper + "\n\n" + replacement + s[end:]
p.write_text(s)

p = POST / "terminal_cache.rs"
s = p.read_text()
start = s.index(
    "    let mut writer = Writer::new_common(output, common)?;",
    s.index("pub fn write_common_mcts("),
)
end = s.index("\n}", start)
body = s[start:end]
a = body.index("        for (input, common, partition) in &runs {")
b = body.index("        Ok(())\n    })();", a)
scan = body[a:b]
extra_at = body.index("    let mut extra = serde_json::Map::new();")
extra_end = body.index("    writer.finish(", extra_at)
extra = body[extra_at:extra_end]
extra = extra.replace(
    "serde_json::to_value(datasets)?", "serde_json::to_value(&datasets)?"
)
additional = """
    extra.insert("schedule_sha256".into(), serde_json::json!(common.schedule.sha256));
    extra.insert("family_partition_sha256".into(), serde_json::json!(common.partition.sha256));
    let bindings = datasets.iter().map(|d| serde_json::json!({
        "path":PathBuf::from(d["dataset"].as_str().unwrap()).join("manifest.json"),
        "sha256":d["manifest_sha256"]})).collect::<Vec<_>>();
    extra.insert("source_binding".into(), serde_json::to_value(&bindings)?);
    extra.insert("source_content".into(), serde_json::json!(bindings.iter().map(|r|
        serde_json::json!({"encoding":"native-teacher-dataset-shards-v1","manifest":r})).collect::<Vec<_>>()));
    extra.insert("stream_intake".into(),serde_json::json!({"status":"complete","scope":"common-corpus",
        "publication_protocol":"incomplete-marker-last-v1","batches":runs.iter().zip(&references).map(|((_,c,_),r)|
            serde_json::json!({"batch_start":c.batch_start,"batch_count":c.batch_count,"config":r})).collect::<Vec<_>>()}));
"""
replacement = (
    "    terminal_stream::publish_common_cache(output, common.clone(), inputs, |writer| {\n        writer.mcts_source = Some(model.clone());\n        let mut datasets = Vec::new();\n"
    + scan
    + extra
    + additional
    + "        Ok((file_sha(&configs.path)?, extra))\n    })"
)
s = s[:start] + replacement + s[end:]
# The already new codec definition now covers the shared authoritative failure
# path as well. It is a definition only, not executed by this author.
s = s.replace(
    "let mut writer = Writer::new_common(&output, common).unwrap();",
    "let mut writer = Writer::new_common(&output, common.clone()).unwrap();",
)
anchor = "        fs::remove_dir_all(root).unwrap();"
test_at = s.index(
    "fn common_mcts_v3_codec_preserves_raw_unknown_mask_and_chronological_blocks"
)
a = s.index(anchor, test_at)
s = (
    s[:a]
    + """        let failed = root.join("failed");
        assert!(crate::terminal_stream::publish_common_cache(&failed, common, &[], |_| {
            Err("original MCTS source failure".into())
        }).is_err());
        assert!(!failed.join("cache.json").exists());
        assert!(failed.join(".intake.partial").is_dir());
"""
    + s[a:]
)
p.write_text(s)
print(
    "existing publication shell shared; Alpha scanner preserved, actual dataset source metadata retained"
)
