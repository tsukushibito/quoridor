import datetime
import hashlib
import json
import os
import resource
from pathlib import Path

OWN = Path(__file__).resolve().parent
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


def absent(i):
    try:
        start = Path(f"/proc/{i['pid']}/stat").read_text().rsplit(")", 1)[1].split()[19]
        same = i["boot_id"] == BOOT and str(i["start_ticks"]) == str(start)
    except FileNotFoundError:
        same = False
    assert not same, i
    return dict(identity=i, fresh_absent_or_different=True)


receipts = []
for stage in sorted(OWN.iterdir()):
    path = stage / "command.process.json"
    if not path.is_file():
        continue
    p = json.loads(path.read_text())
    c = json.loads((stage / "controller.json").read_text())
    assert (
        p["direct_child_reaped"]
        and p["cleanup_complete"]
        and p["handle_closes_complete"]
    )
    assert p["remaining"] == [] and not (stage / "TMP").exists()
    receipts.append(
        dict(
            stage=stage.name,
            process=ref(path),
            returned=ref(stage / "return.json"),
            child=absent(p["child"]),
            controller=absent(c),
            exit_code=p["exit_code"],
            seconds=p["wall_seconds"],
            TMP_absent=True,
            disk_mask=p["signal_mask_restoration"],
            disk_persist=p["final_record_persist"],
        )
    )
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
stop = dict(
    issue="quoridor-4lc.423.3",
    phase="all original source/settings slices frozen; no science",
    actual_source_STOP=now,
    receipts=receipts,
    owned_source_readers_writers_children_jobs_handles_TMP_leases=[],
    remaining=[],
    canonical_Main_hardware_leases=0,
    child_CPU=8,
    guardian_CPU=12,
    child_memory_limit_bytes=960 * 1024**2,
    GPU=0,
    hostreserve_bytes=4 * 1024**3,
    guard_scope="existing guard no_new_privs/affinity/topology/RAM/ownership/directwait/cleanup; no future quiet claim",
    sum_child_command_seconds_once=sum(r["seconds"] for r in receipts),
    cost_scope="source/helper/format/admin/send children once; controller+LLM/full task cost UNKNOWN; not scientific/native runtime",
    failures=[r["stage"] for r in receipts if r["exit_code"] != 0],
    masks="original NULL returned vs disk pending/attempted refs preserved",
    unrecorded_ordinary_tool_controller_identity_handles="UNKNOWN for earlier plain tool calls; no inferred zero cost",
    continuous_family_peak_and_global_actual="UNKNOWN",
    final_metadata_writer=dict(
        pid=os.getpid(),
        start_ticks=Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()[19],
        boot_id=BOOT,
        affinity=sorted(os.sched_getaffinity(0)),
        maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        scope="ordinary small metadata writer exits after write; distinct from stopped source readers",
    ),
)
(OWN / "source-STOP-v2.json").write_text(json.dumps(stop, indent=2) + "\n")
validation = json.loads((OWN / "final-validation-v2.json").read_text())
completion = dict(
    issue="quoridor-4lc.423.3",
    status="all private source/settings prepared; in_progress pending Root acceptance/software; no launch",
    source_packets=validation["packets"],
    report=ref(OWN / "report-v2-ja.md"),
    validation=ref(OWN / "final-validation-v2.json"),
    usage=ref(OWN / "usage-v2.json"),
    STOP=ref(OWN / "source-STOP-v2.json"),
    drafts=[ref(p) for p in sorted((OWN / "fixed-drafts-v1").glob("*.json"))],
    repair_completion=ref(OWN / "native-repair-v2/completion.json"),
    required_software="new12 unique definitions total, existing successful invariant scopes not replayed; named filters per packet",
    software="UNBUILT/UNTYPED/UNRUN",
    source_clear="related reviewer/Root only",
    native_science=0,
    current_dependencies=[
        "SAME learner/Root common_cache_config MCTS dataset metadata admission branch; preserve old Alpha gzip branch, no fabricated Content",
        "Root sparse composition/necessary compile+Clippy+genuine image and SAME changed-boundary review",
        "actual canonical input/model/ORT/physical allocations in null-bearing drafts",
        "actual pilot count/cost one-time scale resolution before suffix/fits",
        "learner/Root final native partition fit-view correspondence preserving pilot/suffix original RAW",
    ],
    future_image=None,
    future_Build=None,
    future_Experiments=None,
    all_pauses_defaults_models_raw_errors_fees="preserved",
)
(OWN / "completion-v2.json").write_text(json.dumps(completion, indent=2) + "\n")
print(
    json.dumps(
        dict(
            completion=ref(OWN / "completion-v2.json"),
            STOP=completion["STOP"],
            source_STOP=now,
            usage=completion["usage"],
            source_children_owned=[],
        )
    )
)
