from pathlib import Path

OWN = Path(__file__).resolve().parent
POST = OWN / "old-q-source-v1/post/crates/quoridor-runner/src"
POST.mkdir(parents=True)


def replace(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)


config = (OWN / "post/crates/quoridor-runner/src/config.rs").read_text()
config = replace(
    config,
    "    pub common_study: Option<quoridor_data::common_corpus::Config>,",
    """    pub common_study: Option<quoridor_data::common_corpus::Config>,
    /// A one-pass bounded MCTS input observation; absent keeps the live four-repeat benchmark.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub benchmark_repetitions: Option<u8>,""",
)
config = replace(
    config,
    "impl Config {",
    """impl Config {
    pub(crate) fn bounded_mcts(&self) -> bool {
        self.engines.len() == 1 && self.engines[0].kind == "mcts"
            && self.inference.as_ref().is_some_and(|i| i.logical_row_limit.is_some())
    }""",
)
config = replace(
    config,
    "        } else if self.common_study.is_none()",
    "        } else if !self.bounded_mcts()",
)
config = replace(
    config,
    "        if let Some(common) = &self.common_study {",
    """        if self.bounded_mcts() {
            let i = self.inference.as_ref().unwrap();
            if self.ruleset != Ruleset::Standard2pThreefold
                || self.workers != 1 || self.active_games != 1 || self.max_batch != 1
                || self.cpu_cores.len() != 1 || self.inference_cpu_core.is_some()
                || self.arena.is_some() || self.cycle.is_some() || self.engines[0].time_ms.is_some()
                || i.backend != "ort" || i.cuda_graph || i.device != 0 || i.library.is_none()
                || i.logical_row_limit.is_none_or(|n| n == 0)
            { return Err("bounded MCTS requires one CPU ORT batch1 owner and positive explicit quota".into()); }
        }
        if let Some(repetitions) = self.benchmark_repetitions {
            if repetitions != 1 || !self.bounded_mcts() || self.common_study.is_some()
                || self.games != self.openings.len() || self.openings.is_empty()
            { return Err("one-pass MCTS benchmark requires exact full-prefix inputs and bounded inference".into()); }
        }
        if let Some(common) = &self.common_study {""",
)
(POST / "config.rs").write_text(config)

runtime = (OWN / "post/crates/quoridor-runner/src/runtime.rs").read_text()
runtime = replace(
    runtime,
    '    if config.common_study.is_some() && mode != "selfplay" {',
    '    if config.benchmark_repetitions.is_some() {\n        return Err("benchmark repetitions belong to benchmark".into());\n    }\n    if config.common_study.is_some() && mode != "selfplay" {',
)
runtime = replace(
    runtime,
    "    let admission = if config.common_study.is_some() {",
    "    let admission = if config.bounded_mcts() {",
)
# Both pump admissions now refer to the same actual explicit MCTS budget; the
# normal product path, with no quota, remains unchanged.
runtime = replace(
    runtime,
    "                if config.common_study.is_some()\n                    && let Err(error) = admit_mcts_rows(",
    "                if config.bounded_mcts()\n                    && let Err(error) = admit_mcts_rows(",
)
runtime = replace(
    runtime,
    "                let result = if config.common_study.is_some() && result.is_ok() {",
    "                let result = if config.bounded_mcts() && result.is_ok() {",
)
start = runtime.index("fn benchmark_impl(")
head, tail = runtime[:start], runtime[start:]
tail = replace(
    tail,
    '    config.validate().map_err(|e| format!("config: {e}"))?;',
    '    config.validate().map_err(|e| format!("config: {e}"))?;\n    if config.common_study.is_some() { return Err("common training inputs belong to selfplay".into()); }',
)
tail = replace(
    tail,
    "                    for repeat in 0..4 {",
    "                    for repeat in 0..u64::from(config.benchmark_repetitions.unwrap_or(4)) {",
)
tail = replace(
    tail,
    "                        let clock = Instant::now();",
    "                        let clock = Instant::now();\n                        let mut mcts_work = None;",
)
tail = replace(
    tail,
    "                            loop {\n                                if let Some(reason) = guard",
    "                            let mut root_nn = None;\n                            loop {\n                                if let Some(reason) = guard",
)
tail = replace(
    tail,
    "                                        let output = b.infer(&[*features])?;",
    """                                        if config.bounded_mcts() {
                                            admit_mcts_rows(b.counters(), config.inference.as_ref().unwrap().logical_row_limit.unwrap(), 1)?;
                                        }
                                        let output = b.infer(&[*features]);
                                        let output = if config.bounded_mcts() && output.is_ok() {
                                            admit_mcts_rows(b.counters(), config.inference.as_ref().unwrap().logical_row_limit.unwrap(), 0).and(output)?
                                        } else { output? };""",
)
tail = replace(
    tail,
    "                                        search.supply(token, &output[0].logits, output[0].value)?;",
    """                                        if root_nn.is_none() { root_nn = Some(output[0].value); }
                                        search.supply(token, &output[0].logits, output[0].value)?;""",
)
tail = replace(
    tail,
    "                            let s = search.snapshot();\n                            (",
    """                            let s = search.snapshot();
                            if config.benchmark_repetitions.is_some() && s.root_visits != config.simulations {
                                return Err("MCTS input observation incomplete simulations".into());
                            }
                            mcts_work = Some(serde_json::json!({"root_visits":s.root_visits,"root_mean":s.root_mean as f32,
                                "root_mean_bits":(s.root_mean as f32).to_bits(),"root_nn":root_nn,"nn_calls":s.nn_calls,
                                "terminal_no_nn":s.terminal_no_nn,"allocated_nodes":s.nodes,
                                "prefix":p.opening,"ruleset":config.ruleset.id(),"total_ply":context.total_ply(),
                                "side":context.position().turn,"stocks":context.position().walls_remaining}));
                            (""",
)
tail = replace(
    tail,
    '"warm":repeat==0,',
    '"warm":repeat==0 && config.benchmark_repetitions.is_none(),"mcts_work":mcts_work,',
)
tail = replace(
    tail,
    '"warm_separate":true,',
    '"warm_separate":config.benchmark_repetitions.is_none(),"benchmark_repetitions":config.benchmark_repetitions,',
)
(POST / "runtime.rs").write_text(head + tail)
print(
    "additive old-q source prepared over frozen native posts; no source packet mutation/native execution"
)
