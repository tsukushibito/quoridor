from pathlib import Path

OWN = Path(__file__).resolve().parent
POST = OWN / "post/crates/quoridor-data/src"


def replace(text, before, after):
    assert text.count(before) == 1, before[:100]
    return text.replace(before, after)


p = POST / "terminal_stream.rs"
s = p.read_text()
start = s.index("    let scale = input_binding\n", s.index("pub fn write_cache("))
end = s.index("    fs::create_dir(output)?;", start)
expression = s[start:end]
helper = expression.replace(
    "    let scale = input_binding\n        .as_ref()", "    input_binding"
)
assert helper.endswith(".transpose()?;\n")
helper = helper.removesuffix(".transpose()?;\n") + ".transpose()\n"
definition = (
    "pub(crate) fn model_scale_authority(input_binding: Option<&Value>) -> Result<Option<Value>> {\n"
    + helper
    + "}\n\n"
)
s = (
    s[:start]
    + "    let scale = model_scale_authority(input_binding.as_ref())?;\n"
    + s[end:]
)
s = replace(
    s,
    "/// Materialize actual complete streams",
    definition + "/// Materialize actual complete streams",
)
p.write_text(s)

p = POST / "terminal_cache.rs"
s = p.read_text()
s = replace(
    s,
    "    common: Option<crate::common_corpus::Config>,",
    "    common: Option<crate::common_corpus::Config>,\n    mcts_source: Option<MctsSource>,",
)
s = replace(
    s,
    "            common,\n            common_eligible",
    "            common,\n            mcts_source: None,\n            common_eligible",
)
s = replace(
    s,
    """                let raw = crate::common_corpus::raw_completed_d6(
                    r,
                    evidence.as_ref().ok_or("missing D6 evidence")?,
                )?;""",
    """                let raw = if let Some(source) = &self.mcts_source {
                    source.raw(r)?
                } else {
                    crate::common_corpus::raw_completed_d6(
                        r, evidence.as_ref().ok_or("missing D6 evidence")?,
                    )?
                };""",
)
s = replace(
    s, '"rootmean_is_raw":false,', '"rootmean_is_raw":self.mcts_source.is_some(),'
)
s = replace(
    s,
    "pub fn write(dataset: &Path, output: &Path, allow_test: bool) -> Result<TensorCache> {",
    (OWN / "mcts-cache-functions.rs").read_text()
    + "\n\npub fn write(dataset: &Path, output: &Path, allow_test: bool) -> Result<TensorCache> {",
)
p.write_text(s)

p = POST / "bin/terminal-cache.rs"
s = p.read_text()
s = replace(
    s,
    "    binding: Option<BoundJson>,",
    "    binding: Option<BoundJson>,\n    mcts_configs: Option<BoundJson>,",
)
s = replace(
    s,
    "    let mut sha = None;",
    "    let mut sha = None;\n    let mut mcts_path = None;\n    let mut mcts_sha = None;",
)
s = replace(
    s,
    '            "--input" =>',
    '            "--mcts-configs" if mcts_path.is_none() => mcts_path = Some(PathBuf::from(value)),\n            "--mcts-configs-sha256" if mcts_sha.is_none() => mcts_sha = Some(value.clone()),\n            "--input" =>',
)
s = replace(
    s,
    "    if inputs.is_empty() {",
    """    let mcts_configs = match (mcts_path, mcts_sha) {
        (Some(path), Some(sha256)) => Some(BoundJson { path, sha256 }),
        (None, None) => None,
        _ => return Err("MCTS native config list path and SHA must be supplied together".into()),
    };
    if inputs.is_empty() {""",
)
s = replace(
    s, "        binding,\n    })", "        binding,\n        mcts_configs,\n    })"
)
s = replace(
    s,
    """    let cache =
        quoridor_data::terminal_stream::write_cache(&a.inputs, &a.output, a.binding.as_ref())?;""",
    """    let cache = if let Some(configs) = &a.mcts_configs {
        quoridor_data::terminal_cache::write_common_mcts(&a.inputs, &a.output, configs, a.binding.as_ref())?
    } else {
        quoridor_data::terminal_stream::write_cache(&a.inputs, &a.output, a.binding.as_ref())?
    };""",
)
s = replace(
    s,
    "[--input-binding PATH --binding-sha256 SHA]",
    "[--input-binding PATH --binding-sha256 SHA] [--mcts-configs CONFIG_LIST --mcts-configs-sha256 SHA]",
)
p.write_text(s)
print("three private data source subjects prepared; no converter/test/native execution")
