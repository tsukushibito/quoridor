import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
OUT = OWN / "fixed-drafts-v1"
OUT.mkdir()
selected = []


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


def read(path, expected=None):
    before = ref(path)
    if expected is not None:
        for key, value in expected.items():
            assert before[key] == value, (path, key)
    data = json.loads(path.read_bytes())
    assert ref(path) == before
    selected.append(before)
    return data


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + "\n")


base = OWN.parent / "nnue-teacher-refresh423-analysis-v1"
spec = read(
    base / "spec.json",
    dict(
        sha256="c919d92bea060ebb73d205801581f34a4751b5b33bf9decf72c2aa25ee65e359",
        bytes=17309,
        mode="0644",
    ),
)
q = read(
    base / "old-q-inputs.json",
    dict(
        sha256="ddedbafc7606235238ce4cea7c7ae535ba43358ab7cc1cdc0161cc6054924794",
        bytes=75239,
        mode="0644",
    ),
)
seeds = spec["seeds"]
assert len(q["states"]) == q["actual_selected_states"] == 28
assert len({s["state_id"] for s in q["states"]}) == 28
assert all(len(s["full_prefix_actions"]) == s["ply"] for s in q["states"])

books = []
old421 = (
    ROOT
    / ".artifacts/research-team/integration324/nnue-diverse421-v1/input-preparation-v1"
)
for name in ["generation-config.json", "evaluation-config.json"]:
    config = read(old421 / name)
    # Reuse actual original exclusions rather than assigning meaning to a guessed ID.
    for r in config["excluded_books"]:
        p = Path(r["path"])
        b = ref(p)
        assert b["sha256"] == r["sha256"]
        if b not in books:
            books.append(b)
            selected.append(b)
    p = Path(config["output"]) / "prefix-book.json"
    b = ref(p)
    if b not in books:
        books.append(b)
        selected.append(b)

bulk = 128 * 1024**2
write(
    "input-config-drafts.json",
    dict(
        status="NOT_READY: future native image/input refs must be resolved by Root; no author preparation execution",
        spec=ref(base / "spec.json"),
        prospective_generation=dict(
            families=256,
            prefix_seed=seeds["generation_prefix"],
            prefix_lengths=[4, 8, 12, 16],
            split_seed=seeds["whole_family_split"],
            excluded_books=[],
            unique_families=False,
            output=None,
            reuse_schedule=None,
        ),
        pilot_from_prospective=dict(
            families=32,
            prefix_seed=seeds["generation_prefix"],
            prefix_lengths=[4, 8, 12, 16],
            split_seed=seeds["whole_family_split"],
            excluded_books=[],
            unique_families=False,
            output=None,
            reuse_schedule=None,
        ),
        evaluation=dict(
            families=64,
            prefix_seed=seeds["evaluation_prefix"],
            prefix_lengths=[4, 8, 12, 16],
            split_seed=seeds["whole_family_split"],
            excluded_books=books,
            unique_families=True,
            output=None,
        ),
        unresolved=dict(
            prospective_master_schedule=None,
            prospective_master_prefix_book_to_append_to_eval_exclusions=None,
            pilot_actual_schedule_partition=None,
            final_N=None,
            final_schedule_partition=None,
            actual_image=None,
            actual_Build=None,
        ),
        semantics="256 here is a rules-only prospective maximum draft, not a numeric launch or resolved main scale. Missing/colliding slots remain missing; native owner supplies qualification and canonical split. No Python family reconstruction.",
    ),
)

common = dict(
    ruleset="standard_2p_threefold",
    simulations=64,
    max_plies=200,
    workers=1,
    active_games=1,
    max_batch=1,
    temperature=0.0,
    opening_plies=0,
    openings=[],
    train_games=None,
    validation_games=None,
    engines=[dict(kind="mcts")],
    wall_seconds=None,
    deadline_unix_ms=0,
    pause_file=None,
    cpu_cores=None,
    management_cpu_core=None,
    inference_cpu_core=None,
    host_ram_reserve=4 * 1024**3,
    max_memory_bytes=None,
    max_output_bytes=bulk,
    inference=dict(
        backend="ort",
        model=None,
        model_sha=spec["generation"]["teacher_ONNX_sha256"],
        library=None,
        device=0,
        cuda_graph=False,
        logical_row_limit=60000,
    ),
    output=None,
)
slices = []
for item, seed in zip(
    spec["generation"]["pilot"], seeds["pilot_MCTS_slice_seeds"], strict=True
):
    ids = item["request_ids"]
    c = dict(
        common,
        run_id=f"nnue-teacher-refresh423-pilot-{item['slice']:02}",
        games=len(ids),
        seed=seed,
        common_study=dict(
            families=32,
            prefix_seed=seeds["generation_prefix"],
            prefix_lengths=[4, 8, 12, 16],
            split_seed=seeds["whole_family_split"],
            root_value_policy="outcome_only",
            batch_start=ids[0],
            batch_count=len(ids),
            excluded_books=[],
            schedule=None,
            partition=None,
        ),
    )
    slices.append(
        dict(request_ids=ids, config_draft=c, input_binding=None, actual_operation=None)
    )
assert [i for s in slices for i in s["request_ids"]] == list(range(32))
assert (
    sum(s["config_draft"]["inference"]["logical_row_limit"] for s in slices) == 240000
)
write(
    "pilot-native-drafts.json",
    dict(
        status="NOT_READY; null unresolved fields are not native config/operation refs",
        slices=slices,
        actual_worker_width=None,
        aggregate_family_bytes=4 * 1024**3,
        GPU=0,
        whole_bulk_bytes=bulk,
        whole_trial_rows=2000000,
        pilot_no_lending_no_refill=True,
        final_scale_fixed=False,
        image=None,
        Build=None,
        actual_ORT_library_ref=None,
        model_ref=None,
        warning="Per-process output ceilings are subordinate to ONE shared whole128MiB owner; do not sum them into an allocation or bypass actual forecast. Root chooses actual1..4 physical workers and controller-inclusive RAM at entry.",
    ),
)

oldq = dict(
    common,
    run_id="nnue-teacher-refresh423-old-q",
    games=len(q["states"]),
    seed=seeds["old_q"],
    openings=[s["full_prefix_actions"] for s in q["states"]],
    benchmark_repetitions=1,
    common_study=None,
    inference=dict(common["inference"], logical_row_limit=10000),
)
write(
    "old-q-native-draft.json",
    dict(
        status="NOT_READY; no author numerical execution",
        fixed_inputs=ref(base / "old-q-inputs.json"),
        config_draft=oldq,
        mapping=[
            dict(
                request_id=i,
                state_id=s["state_id"],
                full_prefix_SHA256=s["prefix_actions_sha256"],
                source_position_record=s["source_position_record"],
            )
            for i, s in enumerate(q["states"])
        ],
        image=None,
        Build=None,
        result=None,
        source_static422_values=None,
        limits="28 actual states, one64-completed-sim request each; whole old-q+necessary Sigma boundary10k within global2M; no fixture/repeat/refill; saved422 successful7 static values reused separately",
    ),
)

write(
    "arena-resolved-recipe.json",
    dict(
        status="NOT_READY: final actual eval families/checkpoints/image/caller remain null",
        seed=seeds["arena"],
        bootstrap_seed=seeds["native_family_interval"],
        conditions=[
            dict(
                left="W",
                right="frozen BEST43",
                role="primary",
                families="first64 actual available canonical eval families",
                maximum_games=128,
                node_quota=800000000,
            ),
            dict(
                left="W",
                right="fixedD(0,8,tanh)",
                role="secondary exploratory",
                families="first16 of same eval families",
                maximum_games=32,
                node_quota=200000000,
            ),
        ],
        node_quota_rule="Disjoint result-blind800M/200M shares proportional to128/32 games, sum1G; no transfers/refill.",
        policy=dict(
            ordering_profile="control",
            use_pvs=True,
            tt_entries=1048576,
            lmr=True,
            lmr_method="depth_rank",
            zero_stock_approx_min_root_walls=None,
            zero_stock_safe_race=False,
            depth=64,
            max_nodes=1000000,
            time_ms=100,
            return_reserve_ms=5,
            max_plies=200,
        ),
        max_games=160,
        max_pairs=80,
        shared_families="primary/secondary dependent; retain native per-family interval, no batch interval averaging or new bootstrap here",
        actual_eval_book=None,
        actual_W_weights=None,
        actual_frozen_model_refs=None,
        actual_image=None,
        actual_Build=None,
        actual_caller=None,
        actual_Experiments=None,
        actual_core_allocation=None,
        actual_output_forecast=None,
        policy_note="Typed actual AI factory owns method/namespace IDs; this recipe does not build IDs. Nominal LMR depth is selective, not full-width proof. R/U,W/U,W/F have no arena contrast.",
    ),
)
for r in selected:
    assert ref(Path(r["path"])) == r
write(
    "selectedrefs.json",
    dict(
        before_parse_and_after_exact=selected,
        labels="Only fixed-spec/input/config and named existing book metadata; no old RAW/model payload/native",
        future_refs="null; not submitted",
        original_421_configs_and_books_unchanged=True,
    ),
)
print(
    json.dumps(
        dict(
            output=str(OUT),
            pilot_slots=32,
            old_q=len(q["states"]),
            existing_excluded_books=len(books),
            source_only=True,
            final_N=None,
        )
    )
)
