#[cfg(test)]
mod common_mcts_tests {
    use super::*;

    fn teacher(visits: u32) -> Teacher {
        Teacher::Mcts {
            root_mean: -0.0,
            root_nn: Some(0.25),
            root_visits: visits,
            nn_calls: 1,
            edges: Vec::new(),
        }
    }

    #[test]
    fn common_mcts_row_quota_accounts_warm_failed_physical_unknown_and_overflow() {
        let mut c = InferenceCounters {
            logical_rows: 63,
            executed_rows: 63,
            failed_rows: 63, // Already included in logical/executed.
            capture_rows: Some(0),
            ..Default::default()
        };
        assert!(admit_mcts_rows(c, 64, 1).is_ok());
        assert!(admit_mcts_rows(c, 63, 1).is_err());
        c.warm_rows = 1;
        c.failed_warm_rows = 1;
        assert!(admit_mcts_rows(c, 64, 1).is_err());
        assert!(admit_mcts_rows(c, 64, 0).is_ok());
        c.capture_rows = None;
        assert!(admit_mcts_rows(c, u64::MAX, 0).is_err());
        c.capture_rows = Some(0);
        c.logical_rows = u64::MAX;
        assert!(admit_mcts_rows(c, u64::MAX, 1).is_err());
        c.logical_rows = 0;
        c.executed_rows = u64::MAX;
        assert!(admit_mcts_rows(c, u64::MAX, 1).is_err());
    }

    #[test]
    fn common_mcts_requires_completed_visits_without_rewriting_raw_values() {
        let t = teacher(64);
        assert!(require_completed_mcts(&t, 64).is_ok());
        assert!(require_completed_mcts(&t, 63).is_err());
        assert!(require_completed_mcts(&teacher(63), 64).is_err());
        assert!(require_completed_mcts(&Teacher::InputOnly, 64).is_err());
        let Teacher::Mcts {
            root_mean, root_nn, ..
        } = t
        else {
            unreachable!()
        };
        assert_eq!(root_mean.to_bits(), (-0.0f32).to_bits());
        assert_eq!(root_nn, Some(0.25));
    }

    #[test]
    fn common_mcts_terminal_attachment_uses_goal_threefold_and_unknown_not_q() {
        let plan = Planned {
            id: 17,
            candidate_color: 0,
            opening: vec![],
            family: "family".into(),
            split: Split::Train,
        };
        let context = SigmaContext::from_prefix(&[]).unwrap();
        let row = TeacherRow::from_context(
            "row".into(),
            "game-17".into(),
            plan.family.clone(),
            Split::Train,
            vec![],
            &context,
            Some(13),
            teacher(64),
            "a".repeat(64),
        )
        .unwrap();
        let goal = vec![13, 75, 22, 66, 31, 57, 40, 48, 49, 39, 58, 30, 67, 21, 76];
        let repetition = vec![13, 67, 4, 76, 13, 67, 4, 76];
        for (moves, status, winner, z) in [
            (goal, "goal", Some(0), Some(1.0)),
            (repetition, "draw", None, Some(0.0)),
            (vec![13], "unknown", None, None),
        ] {
            let mut o = unknown(&plan, "ply_cap".into());
            o.moves = moves;
            o.status = status.into();
            o.winner = winner;
            let mut rows = vec![row.clone()];
            rows[0].z = Some(-1.0); // Old finish label must not supply provenance.
            attach_common_mcts_outcome(&o, &mut rows).unwrap();
            assert_eq!(rows[0].z, z);
            assert_eq!(rows[0].eligible, z.is_some());
            let Teacher::Mcts {
                root_mean, root_nn, ..
            } = rows[0].teacher
            else {
                unreachable!()
            };
            assert_eq!(root_mean.to_bits(), (-0.0f32).to_bits());
            assert_eq!(root_nn, Some(0.25));
        }
        let mut false_complete = unknown(&plan, "synthetic_completion".into());
        false_complete.status = "goal".into();
        false_complete.moves = vec![13];
        assert!(attach_common_mcts_outcome(&false_complete, &mut [row]).is_err());
    }

    #[test]
    fn common_mcts_frozen_slice_keeps_global_ids_missing_slots_and_family_split() {
        use quoridor_data::{common_corpus, terminal, terminal_stream::BoundJson};
        let root = std::env::temp_dir().join(format!("common-mcts-plan-{}", std::process::id()));
        std::fs::create_dir(&root).unwrap();
        let write = |name: &str, value: serde_json::Value| {
            let path = root.join(name);
            std::fs::write(&path, serde_json::to_vec(&value).unwrap()).unwrap();
            BoundJson {
                sha256: quoridor_data::file_sha(&path).unwrap(),
                path,
            }
        };
        let mut c: Config =
            serde_json::from_str(include_str!("../tests/fixtures/sigma-clock-config.json"))
                .unwrap();
        let roots = vec![
            ("fixed-d-family-000000".into(), vec![13, 67, 22, 58]),
            ("fixed-d-family-000002".into(), vec![5, 75, 6, 74]),
        ];
        let partition = terminal::partition_families(&roots, 31).unwrap();
        let common: common_corpus::Config = serde_json::from_value(serde_json::json!({
            "families":3,"prefix_seed":29,"prefix_lengths":[4],"split_seed":31,
            "root_value_policy":"outcome_only","batch_start":1,"batch_count":2,
            "excluded_books":[],
            "schedule":write("schedule.json",serde_json::json!({"scheduled":[
                {"game":0,"request_id":roots[0].0,"requested_prefix_length":4,"prefix":roots[0].1,"scheduled_failure":null},
                {"game":1,"request_id":"fixed-d-family-000001","requested_prefix_length":4,"prefix":null,"scheduled_failure":"missing"},
                {"game":2,"request_id":roots[1].0,"requested_prefix_length":4,"prefix":roots[1].1,"scheduled_failure":null}
            ]})),
            "partition":write("partition.json",serde_json::to_value(&partition).unwrap())
        })).unwrap();
        c.common_study = Some(common);
        c.games = 1;
        let plans = planned(&c).unwrap();
        assert_eq!(plans.len(), 1);
        assert_eq!(plans[0].id, 2);
        assert_eq!(plans[0].opening, roots[1].1);
        assert_eq!(plans[0].family, partition.assignments[1].family);
        assert_eq!(plans[0].split, partition.assignments[1].split);
        c.games = 2; // Missing slot is never silently regenerated.
        assert!(planned(&c).is_err());
        std::fs::remove_dir_all(root).unwrap();
    }
}
