from pathlib import Path

OWN = Path(__file__).resolve().parent
POST = OWN / "post/crates/quoridor-runner/src"


def replace(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)


config = (POST / "config.rs").read_text()
config = replace(
    config,
    "    pub openings: Vec<Vec<u16>>,",
    """    pub openings: Vec<Vec<u16>>,
    /// Input-only canonical family partition, shared across bounded MCTS slices.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub common_study: Option<quoridor_data::common_corpus::Config>,""",
)
config = replace(
    config,
    "        } else if self\n            .inference\n",
    "        } else if self.common_study.is_none() && self\n            .inference\n",
)
config = replace(
    config,
    "        self.split_counts()?;",
    """        if let Some(common) = &self.common_study {
            common.validate_shape().map_err(|e| e.to_string())?;
            let inference = self.inference.as_ref().ok_or("common MCTS inference required")?;
            if self.ruleset != Ruleset::Standard2pThreefold
                || self.arena.is_some()
                || self.cycle.is_some()
                || self.engines.len() != 1
                || self.engines[0].kind != "mcts"
                || self.engines[0].time_ms.is_some()
                || self.workers != 1 || self.active_games != 1 || self.max_batch != 1
                || self.cpu_cores.len() != 1 || self.inference_cpu_core.is_some()
                || self.temperature != 0.0
                || !self.openings.is_empty()
                || self.train_games.is_some() || self.validation_games.is_some()
                || inference.backend != "ort" || inference.cuda_graph || inference.device != 0
                || inference.library.is_none()
                || inference.logical_row_limit.is_none_or(|n| n == 0)
            {
                return Err("common MCTS requires frozen inputs, one serial game/CPU ORT batch1 owner, greedy completed simulations and explicit row quota".into());
            }
        }
        self.split_counts()?;""",
)
(POST / "config.rs").write_text(config)

runtime = (POST / "runtime.rs").read_text()
runtime = replace(
    runtime,
    "fn planned(config: &Config) -> Result<Vec<Planned>> {",
    """fn planned(config: &Config) -> Result<Vec<Planned>> {
    if let Some(common) = &config.common_study {
        common.validate_inputs()?;
        let schedule = common.schedule.read()?;
        let slots = schedule["scheduled"].as_array().ok_or("scheduled inputs")?;
        let partition: quoridor_data::terminal::FamilyPartition =
            serde_json::from_value(common.partition.read()?)?;
        let requests = common.global_requests()?;
        let mut out = Vec::new();
        for id in common.batch_range()? {
            if slots[id]["prefix"].is_null() {
                continue; // Bound missing slot remains missing: no new attempt/refill.
            }
            let assignment = partition.assignments.iter()
                .find(|a| a.game == requests[id].0).ok_or("missing family assignment")?;
            out.push(Planned {
                id,
                candidate_color: 0,
                opening: assignment.prefix.clone(),
                family: assignment.family.clone(),
                split: assignment.split.clone(),
            });
        }
        if out.len() != config.games {
            return Err("games must equal actual bound nonmissing slice slots".into());
        }
        return Ok(out);
    }""",
)
runtime = replace(
    runtime,
    ") -> Result<()> {\n    let row = if game.record_teacher {",
    """ ) -> Result<()> {
    if config.common_study.is_some() {
        require_completed_mcts(&teacher, config.simulations)?;
    }
    let row = if game.record_teacher {""",
)
runtime = replace(
    runtime,
    "fn commit_action(\n",
    """fn require_completed_mcts(teacher: &Teacher, simulations: u32) -> Result<()> {
    if !matches!(teacher, Teacher::Mcts { root_visits, .. } if *root_visits == simulations) {
        return Err("common MCTS requires every configured simulation completed before commit".into());
    }
    Ok(())
}
fn commit_action(
""",
)
runtime = replace(
    runtime,
    '    config.validate().map_err(|e| format!("config: {e}"))?;\n    if (config.games as u64)',
    '    config.validate().map_err(|e| format!("config: {e}"))?;\n    if config.common_study.is_some() && mode != "selfplay" {\n        return Err("common MCTS inputs belong to selfplay".into());\n    }\n    if (config.games as u64)',
)
runtime = replace(
    runtime,
    "    let admission = if evaluation {",
    """    let admission = if config.common_study.is_some() {
        // Existing worker and inference pump alternate on one admitted CPU.
        // Independent processes own their own backend, queue and row quota.
        let mut admission = crate::resources::admit(
            1, &config.cpu_cores, false, config.host_ram_reserve, config.max_memory_bytes,
        )?;
        admission.inference_core = Some(admission.worker_cores[0]);
        admission
    } else if evaluation {""",
)
runtime = replace(
    runtime,
    "                let t = Instant::now();\n                let result = b.infer(&input);",
    """                if config.common_study.is_some()
                    && let Err(error) = admit_mcts_rows(
                        b.counters(), config.inference.as_ref().unwrap().logical_row_limit.unwrap(), n as u64,
                    )
                {
                    pump.sigma_row_budget_refused_rows += n as u64;
                    deliver_inference(requests, Err(error), &mut stopped, &cancel);
                    continue;
                }
                let t = Instant::now();
                let result = b.infer(&input);
                // CPU ORT has no hidden warm/capture/retry Run. Check actual counters too;
                // preserve an original backend error if the call itself failed.
                let result = if config.common_study.is_some() && result.is_ok() {
                    admit_mcts_rows(b.counters(), config.inference.as_ref().unwrap().logical_row_limit.unwrap(), 0)
                        .and(result)
                } else { result };""",
)
runtime = replace(
    runtime,
    "pub struct PumpProfile {",
    """pub struct PumpProfile {
    /// Requests refused before backend entry; excluded from actual backend row work.
    #[serde(default, skip_serializing_if = "is_zero_u64")]
    pub sigma_row_budget_refused_rows: u64,""",
)
# No hidden head, warmup, retry or capture is added to the canonical CPU backend.
runtime = replace(
    runtime,
    "fn deliver_inference(\n",
    """fn is_zero_u64(value: &u64) -> bool { *value == 0 }
fn admit_mcts_rows(c: InferenceCounters, limit: u64, next: u64)
    -> std::result::Result<(), quoridor_inference::InferenceError>
{
    // Failed rows are already subsets, not extra work to add a second time.
    let logical = c.logical_rows.checked_add(c.warm_rows).and_then(|n| n.checked_add(next));
    let physical = c.physical_rows().and_then(|n| n.checked_add(next));
    if logical.is_none_or(|n| n > limit) || physical.is_none_or(|n| n > limit) {
        Err(quoridor_inference::InferenceError("Sigma MCTS row quota exhausted or counter unknown/overflow".into()))
    } else { Ok(()) }
}
fn deliver_inference(
""",
)
runtime = replace(
    runtime,
    "    fn record(&mut self, mut o: Outcome, r: Vec<TeacherRow>) {\n        let record_start = Instant::now();",
    """    fn record(&mut self, mut o: Outcome, mut r: Vec<TeacherRow>) {
        let record_start = Instant::now();
        if self.config.common_study.is_some() && !r.is_empty()
            && let Err(error) = attach_common_mcts_outcome(&o, &mut r)
        {
            let reason = format!("terminal_targets:{error}");
            o.status = "unknown".into();
            o.winner = None;
            o.failure = Some(crate::arena_clock::failure_from_reason(&reason));
            o.reason = Some(reason.clone());
            for row in &mut r { row.z = None; row.eligible = false; }
            record_publication_failure(self.pump, self.stopped, Some(o.game), reason);
            self.cancel.store(true, Ordering::Relaxed);
        }""",
)
runtime = replace(
    runtime,
    "struct CompletionPublication<'a> {",
    """fn attach_common_mcts_outcome(o: &Outcome, rows: &mut [TeacherRow]) -> Result<()> {
    use quoridor_data::terminal::{TerminalProvenance, Termination, attach_terminal_targets};
    let context = SigmaContext::from_prefix(&o.moves).map_err(|e| format!("{e:?}"))?;
    let reason = if o.status == "unknown" {
        Termination::Unknown
    } else if context.position().winner.is_some() {
        Termination::Goal
    } else if context.is_repetition_draw() {
        Termination::Threefold
    } else {
        return Err("completed MCTS game without true terminal outcome".into());
    };
    let provenance = TerminalProvenance::from_context(
        &context, o.moves.clone(), reason,
        o.reason.clone().unwrap_or_else(|| o.status.clone()),
    )?;
    if provenance.winner.map(|w| w - 1) != o.winner {
        return Err("MCTS terminal winner differs from canonical replay".into());
    }
    // finish's legacy z is replaced by the same canonical provenance owner used
    // by the compact converter. Raw root_mean/root_nn/visits stay untouched.
    for row in rows.iter_mut() { row.z = None; }
    attach_terminal_targets(rows, &provenance)
}
struct CompletionPublication<'a> {""",
)
(POST / "runtime.rs").write_text(runtime)
print("private native two-file source prepared; no compile/test/inference")
