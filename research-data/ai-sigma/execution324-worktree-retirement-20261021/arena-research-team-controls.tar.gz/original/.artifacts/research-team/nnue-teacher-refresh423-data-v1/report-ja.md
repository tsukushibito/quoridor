423.3 の私有source/settingsを固定した。生成・変換・旧状態評価・学習・対局は作者から一度も実行していない。Main/Git/index/Cargoの変更もない。採用、必要compile/Clippy/真正image、変更境界の同関連レビューと実入場は324が所有する。元native-v2の失敗判定と費用を成功へ書き換えない。

| packet           | 対象と適用順                                                     | 必要な新定義                                  |
| ---------------- | ---------------------------------------------------------------- | --------------------------------------------- |
| native-source-v2 | 元のconfig/runtime累積差分。既に配送した凍結源泉                 | 5、UNBUILT/UNTYPED/UNRUN                      |
| native-repair-v1 | そのruntimeへR1/C1だけ。既に一度配送・accepted                   | 2、UNBUILT/UNTYPED/UNRUN                      |
| old-q-source-v2  | 上記2段の後へconfig/runtime/mainの疎差分                         | 新1＋R1定義1の関連拡張、UNBUILT/UNTYPED/UNRUN |
| data-source-v1   | 7cd6b405のterminal_cache/terminal_stream/terminal-cache CLIへ3件 | 新3、UNBUILT/UNTYPED/UNRUN                    |
| input-source-v1  | 同じ7cd6b405のteacher_pilot/depth6だけ                           | 新1、UNBUILT/UNTYPED/UNRUN                    |

全体で新12定義。既にRootが成功させた不変の定義を再演する指示ではない。各bindingに正確なfilterがある。old-q-source-v1は未配送の私有中間版として残し、v2を最終対象とする。v2は原native累積パッチの再適用ではない。7件の後続subjectはbefore最小gzip・post・forward/inverseを束縛し、fuzz0の往復とbyte exactを確認した。新production file/Cargo依存はない。

R1/C1修復は別reportとSTOPを参照する。旧状態MCTS側でもquotaを使うsupplied backendを入場前に拒否する。既存public run(None)とCPU ORT factoryを使い、別MCTS/推論loopは作らない。common modeはoutcome_onlyに限定する。

旧状態入口は既存benchmarkの明示benchmark_repetitions=1だけを追加した。未指定時の従来warm1+steady3、既存alpha評価と既存成功fixtureを保持する。新one-passでは28件の実full-prefixを一度ずつ再生し、64 completed simulationsと10kのlogical/physical上限を既存ownerで検査する。最初の既存headをroot_nnとして保存し、root_mean/visits/実counter/fullprefixを同じrecordへ残す。追加headやstatic oracleは作らない。実seedはspecのold_qにfixture indexを加え、保存する。失敗時は元partial/errorを残す。common selfplayと明示one-pass benchmarkのCLIは保存先と小summaryを返す。元の通常CLI出力は保持する。

compact変換は既存v3 codec/geometry.stocks/sampling.games/chronological row_game_codesを維持する。SHA-boundの実native config列と入力datasetを同じ順で受け、MCTS型/model/完了visits/finite raw値、全prefix・canonical family/splitとchronological game blocks、manifest行数/hashを検査する。zはcanonical terminal outcomeだけで、raw q値で行を除外しない。UNKNOWNのmaskは0、q/root_nn/visitsは勝敗にしない。データ列追加はない。既存Alpha D6 receiverのheader/search等のtop-level関数はexactで、scale bindingの同じ式だけを既存module内の小helperへ移した。途中失敗は既存abortを使い、成功cacheへ昇格しない。

変換CLIは通常terminal-cacheへ `--mcts-configs PATH --mcts-configs-sha256 SHA` を足すだけで、PATHは実native ConfigのBoundJson列である。既存の反復 `--input` と同順で、sliceは重複・gapなしで同一common bindingを持つ必要がある。元pilotとsuffixは元RAW/splitを保持した別bankとして保存する。最終cohortのfamily/splitはsuffixによって変わり得るため、最終fit-viewはspecのsplit-correspondenceに従いglobal game IDからnative最終partitionへ対応させる必要がある。作者はPython側のfamily分類・registry・旧RAW書換えを実装していない。この最終viewの実結合は学習担当/Rootの必要inletであり、native生成の全source完了待ち条件ではない。

入力は既存canonical rules-only generator/filter/partitionを再用する。新InputConfig.reuse_scheduleはSHA-bound scheduleの先頭N件を読み、seed/length/order/global ID/完全rootを検査する。元32attemptsとmissingを保持し、別候補で補充しない。最大256のprospective rules-only masterを先に用意する案と、その先頭32/pilot・後の最終Nへの再partitionをdraftとして示した。これは256 MCTS実行や必要標本数の決定ではない。実master作成はRootの通常入力入場であり、未作成のmaster/partition/imageには偽refを作っていない。masterより長いreuseは拒否するため、Rootがこの再利用案を採る場合はprospective範囲を入力時に固定する。評価はold355と実421生成・評価bookに加え、実prospective master bookを正本ownerで除外する。既存3bookは実SHAを照合したが、作者は全履歴native資格をJSONから認定していない。

fixed-drafts-v1は通常形式のreview用未解決draftであり、そのままsubmitできない。CPU割当/model path/ORT library/image/Build/actual schedule/partition/output/Experimentsはnullで、Rootが本物の値を結ぶ。4×8 pilot slot/4×60kの無貸借、200ply、64simulation、greedy0、実spec seedを保存した。whole trialは最大256requests/2M Sigma rows、old-q10kを含み、最終Nは実pilot後に一度だけ解決する。32だけでfour-fit/arenaへ自動接続しない。4M NNUEとwhole128MiB/decimal50GBは別上限で、未使用枠を追加実験に転用しない。

arena recipeはW/BEST43の先頭最大64family/128gamesを主対照、W/Dの同じ先頭16family/32gamesを副対照にした。1G nodesを事前に800M/200Mへ分け、結果による移管・refillをしない案である。各上限は完了保証ではなく、actual output forecast/whole guardはRootの入場時に必要である。共有familyは独立に水増しせず、既存family区間を使う。R/U,W/U,W/Fの対局は発行しない。LMR nominal depth、未知の物理forward/RSS/費や棋力は別のままである。

対象Rustfmt/Ruff、手書きreportのPrettier、生成draftのJSON parse/固定slot算術だけを実施した。source_clear/software/numeric/性能/棋力を主張しない。原管理読取のsubstring探索失敗、初回format失敗、context探索不足、returned NULLとdisk pending/attempted、元FAILED/capture/費UNKNOWNを残す。新しい通常管理の冒頭pwdが実context再読取より先だった事実も残した。全body編集とformatはその後のactual Sol6.1/high/Main/fullnever確認・CPU8/guardian12既存guardで行った。

全成果のrefs、実sourceSTOP、original child/controllerのfresh identity不在・directwait/reap/handles/TMP/owned[]と一回のOWN使用量はcompletionで結ぶ。LLM/controller全費、連続family peak/globalactualはUNKNOWN。旧342/323/mixed/learnerのpause、製品/generator defaults、models/weights/seals/旧RAW/FAILEDと費は変更しない。
