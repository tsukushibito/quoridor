import difflib
import gzip
import hashlib
import json
import re
import stat
from pathlib import Path

OWN = Path(__file__).resolve().parent
REL = Path("crates/quoridor-data/src/terminal_cache.rs")
before = gzip.decompress((OWN / "before/terminal_cache.rs.gz").read_bytes())
post = (OWN / "post" / REL).read_bytes()
assert (Path("/workspaces/quoridor") / REL).read_bytes() == before
a, b = before.decode(), post.decode()
forward = "".join(
    difflib.unified_diff(
        a.splitlines(True),
        b.splitlines(True),
        fromfile="a/" + str(REL),
        tofile="b/" + str(REL),
    )
)
inverse = "".join(
    difflib.unified_diff(
        b.splitlines(True),
        a.splitlines(True),
        fromfile="a/" + str(REL),
        tofile="b/" + str(REL),
    )
)
(OWN / "forward.patch").write_text(forward)
(OWN / "inverse.patch").write_text(inverse)
# Strict patch roundtrip already succeeded in verification-v1; retain its capture.
captures = json.loads((OWN / "strict-patch-proof.json").read_bytes())
assert len(captures) == 2 and all(c["returncode"] == 0 for c in captures)


def between(s, first, last):
    return s[s.index(first) : s.index(last, s.index(first))]


protected = {}
ranges = {
    "MctsSource_raw_and_canonical_game_id": (
        "struct MctsSource {",
        "/// Normal selfplay datasets only.",
    ),
    "Writer_geometry_and_original_labels": (
        "        let context = SigmaContext::from_prefix(&r.prefix)?;",
        "        if let Some((raw, eligible, _target))",
    ),
    "Writer_finish": ("    pub(crate) fn finish(", "struct MctsSource {"),
    "existing_configured_outcome_fixtures": (
        "mod configured_outcome_codec_tests {",
        "#[cfg(test)]\nmod common_mcts_codec_tests",
    ),
}
for name, (first, last) in ranges.items():
    left = between(a, first, last)
    right = between(b, first, last)
    if name == "MctsSource_raw_and_canonical_game_id":
        right = right[: right.index("// Explicit optional final sampling view")]
    # Exact old portion, excluding adjacent whitespace added before the new helper.
    assert left.rstrip() == right.rstrip(), name
    protected[name] = dict(
        sha256=hashlib.sha256(left.rstrip().encode()).hexdigest(),
        bytes=len(left.rstrip().encode()),
        exact=True,
    )
old_merge = between(
    a[a.index("pub fn write_common_mcts") :],
    "        if let Some(total) = &mut combined {",
    "        let partition:",
)
new_merge = between(
    b[b.index("pub fn write_common_mcts") :],
    "            if let Some(total) = &mut combined {",
    "        runs.push(",
)
new_merge = new_merge[: new_merge.rfind("        }")]
assert re.sub(r"\s+", "", old_merge).replace(",)", ")") == re.sub(
    r"\s+", "", new_merge
).replace(",)", ")")
protected["nonview_original_strict_merge"] = dict(exact_tokens=True)
(OWN / "protected-proof.json").write_text(json.dumps(protected, indent=2) + "\n")

target_path = OWN / "final-view-config.json"
target = json.loads(target_path.read_bytes())
fragment_path = OWN / "input-binding-fragment.json"
fragment = json.loads(fragment_path.read_bytes())
old_target_sha = fragment["final_fit_view"]["sha256"]
fragment["final_fit_view"]["sha256"] = hashlib.sha256(
    target_path.read_bytes()
).hexdigest()
fragment_path.write_text(json.dumps(fragment, indent=2) + "\n")
(OWN / "format-binding-note.json").write_text(
    json.dumps(
        dict(
            prior_pretty_target_sha256=old_target_sha,
            formatted_target_sha256=fragment["final_fit_view"]["sha256"],
            semantic_config_unchanged=True,
            source_correspondence_replayed=False,
        ),
        indent=2,
    )
    + "\n"
)
selected = []
for file in [
    "intake-refs.json",
    "related-intake-refs.json",
    "final-lineage-intake-refs.json",
    "binding-metadata-refs.json",
    "correspondence-selectedrefs.json",
]:
    entries = json.loads((OWN / file).read_bytes())
    if isinstance(entries, dict):
        entries = list(entries.values()) if "path" not in entries else [entries]
    for ref in entries:
        if not isinstance(ref, dict) or "path" not in ref:
            continue
        if ref["path"] == str(target_path):
            continue  # Explicit formatting-only derivation above; original read receipt retained.
        selected.append(ref)
unique = {ref["path"]: ref for ref in selected}
for path, ref in unique.items():
    data = Path(path).read_bytes()
    assert hashlib.sha256(data).hexdigest() == ref["sha256"], path
    assert len(data) == ref["bytes"], path
    assert f"{stat.S_IMODE(Path(path).stat().st_mode):04o}" == ref["mode"], path
(OWN / "selectedrefs-after.json").write_text(
    json.dumps(list(unique.values()), indent=2) + "\n"
)
new_defs = re.findall(r"#\[test\]\s+fn (final_fit_view_\w+)", b)
assert len(new_defs) == 4
(OWN / "verification-plan.json").write_text(
    json.dumps(
        dict(
            source_only=True,
            native_state="UNBUILT_UNTYPED_UNRUN",
            new_definitions=new_defs,
            root_scope=[
                "new four final_fit_view tests only",
                "necessary quoridor-data compile/Clippy/current converter build",
                "same423.4 changed split/view question",
            ],
            private_static=[
                "Rustfmt parse/format",
                "Ruff check",
                "strict forward/inverse exact bytes",
                "saved metadata correspondence only",
            ],
            author_native_tests=0,
            author_WDL_or_geometry_execution=0,
            preserved=[
                "original RAW/native config/split/cache",
                "non-view strict merge",
                "Alpha route",
                "raw q/outcome/STM/full-prefix/terminal/simulation validators",
                "publication failure kernel",
            ],
        ),
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        dict(
            strict_patch="PASS",
            protected=list(protected),
            selected_refs=len(unique),
            new_definitions=new_defs,
        )
    )
)
