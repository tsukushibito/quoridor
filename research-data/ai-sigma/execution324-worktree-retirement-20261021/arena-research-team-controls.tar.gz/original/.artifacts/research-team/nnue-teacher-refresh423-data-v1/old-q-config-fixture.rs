#[cfg(test)]
mod bounded_mcts_benchmark_config_tests {
    use super::*;
    #[test]
    fn bounded_mcts_one_pass_requires_exact_inputs_quota_and_preserves_default() {
        let mut c: Config =
            serde_json::from_str(include_str!("../tests/fixtures/sigma-clock-config.json"))
                .unwrap();
        c.ruleset = Ruleset::Standard2pThreefold;
        c.arena = None;
        c.cycle = None;
        c.engines = vec![serde_json::from_value(serde_json::json!({"kind":"mcts"})).unwrap()];
        c.workers = 1;
        c.active_games = 1;
        c.max_batch = 1;
        c.management_cpu_core = None;
        c.inference_cpu_core = None;
        c.cpu_cores = vec![8];
        c.common_study = None;
        c.openings = vec![vec![13]];
        c.games = 1;
        c.benchmark_repetitions = Some(1);
        c.inference = Some(
            serde_json::from_value(serde_json::json!({"backend":"ort",
            "model":"/fixture/model.onnx","model_sha":"a".repeat(64),"library":"/fixture/lib.so",
            "device":0,"cuda_graph":false,"logical_row_limit":64}))
            .unwrap(),
        );
        c.validate().unwrap(); // Shape only: no backend or numerical invocation.
        for case in 0..5 {
            let mut bad = c.clone();
            match case {
                0 => bad.benchmark_repetitions = Some(0),
                1 => bad.benchmark_repetitions = Some(2),
                2 => bad.games = 2, // Existing openings modulo must not duplicate a fixed request.
                3 => bad.inference.as_mut().unwrap().logical_row_limit = None,
                _ => bad.engines[0].kind = "distance".into(),
            }
            assert!(bad.validate().is_err(), "case {case}");
        }
        c.benchmark_repetitions = None;
        c.inference.as_mut().unwrap().logical_row_limit = None;
        c.validate().unwrap();
        assert!(
            serde_json::to_value(c)
                .unwrap()
                .get("benchmark_repetitions")
                .is_none()
        );
    }
}
