R1/C1 の関連修復だけを凍結した。元 native-source-v2 の config/runtime、binding、失敗レビューは変更していない。今回の forward/inverse はその凍結 runtime 一件にだけ適用する。元の累積パッチを再適用しない。

R1: 公開 run_with_backend は common_study がある場合、run_owned、入力検査、backend metadata、資源入場、infer の前で拒否する。通常の run は従来どおり None で maintained CPU ORT factory に入る。non-common embedding API、MCTS 数学、factory 本体は保持した。

C1: terminal target 付与失敗時も既存 Outcome.reason/failure を優先し、terminal_targets の二次失敗を既存 publication_failures に別保存する。先行する全体 stopped は保持する。先行全体理由が別にあっても、この枝で元 Outcome cause が確認できた場合は後段の cancellation attribution で置換しない。元 cause がなければ従来どおり二次失敗を使う。UNKNOWN、winner=None、行の z=None/ineligible、取消と最初の停止理由の維持は変えない。

新しい定義は2件。外部 backend の infer/metadata と出力入場へ到達しない境界、および真正 goal prefix を持つ UNKNOWN/cancelled と先行別停止理由がある場合の元 cause/二次 publication failure の分離を対象にする。定義名は binding に記載した。UNBUILT/UNTYPED/UNRUN であり、作者は Cargo、compile、test、model、forward、Search、ゲームを実行していない。

対象 Rustfmt、helper Ruff、fuzz=0 の forward→post→inverse→before の exact byte 照合を行った。19個の必要な既存関数を byte exact で保護した。新 production file はない。Root が合成・必要 software と同じ関連 reviewer の限定確認を行う。作者の修復は source_clear や科学成功の資格ではない。

元の管理/context探索・capture・returned 対 disk mask の区別、原 FAILED と費 UNKNOWN を保持する。今回継続の冒頭に pwd を context 再読取より先に実行した事実も残す。source 編集はその後の実 context 照合と guard 入場で行った。全 source/analysis 費と連続 family peak は UNKNOWN、command elapsed は各子の一回だけを STOP に記録する。既存 paused mixed/learner/323、defaults、models、seals、旧 RAW は変更していない。
