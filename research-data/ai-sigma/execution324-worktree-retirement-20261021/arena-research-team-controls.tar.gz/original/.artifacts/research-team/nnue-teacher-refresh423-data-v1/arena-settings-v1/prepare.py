"""Prepare only the two original 423 arena operations from frozen metadata."""

import copy
import hashlib
import json
import stat
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
BASE = ROOT / ".artifacts/research-team/integration324"
B423 = BASE / "nnue-teacher-refresh423-v1"
B421 = BASE / "nnue-diverse421-v1"
EXAMPLE = B421 / "science-v1/arena128-entry-v2"
PERF = ROOT / ".worktree/assets/perf/nnue-teacher-refresh423-v1/arena160-v1"
SELECTED = {}


def ref(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def read(path, expected=None):
    path = Path(path).resolve()
    before = ref(path)
    if expected:
        for key in ("path", "sha256", "bytes", "mode"):
            if key in expected:
                assert before[key] == expected[key], (path, key)
    value = json.loads(path.read_bytes())
    assert ref(path) == before
    SELECTED[str(path)] = before
    return value, before


def put(name, value):
    path = OWN / name
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


def main():
    recipe, recipe_ref = read(OWN.parent / "fixed-drafts-v1/arena-resolved-recipe.json")
    assert recipe["seed"] == 42320261026
    assert recipe["bootstrap_seed"] == 42320261027
    assert [c["node_quota"] for c in recipe["conditions"]] == [800000000, 200000000]
    ec, ec_ref = read(
        B423 / "input-preparation-evaluation-v3/evaluation-collection.json"
    )
    assert (
        ec["result"]["accepted_slots"]
        == ec["result"]["requested_slots"]
        == ec["result"]["unique_family_count"]
        == 64
    )
    assert ec["result"]["missing_slots"] == ec["result"]["search_calls"] == 0
    book, book_ref = read(
        ec["files"]["prefix_book"]["path"], ec["files"]["prefix_book"]
    )
    schedule, schedule_ref = read(
        ec["files"]["schedule"]["path"], ec["files"]["schedule"]
    )
    partition, partition_ref = read(
        ec["files"]["partition"]["path"], ec["files"]["partition"]
    )
    input_config, input_config_ref = read(ec["config"]["path"], ec["config"])
    assert input_config == ec["config_value"]
    assert input_config["prefix_seed"] == schedule["prefix_seed"] == 42320261017
    assert input_config["families"] == 64
    assert book["schedule"] == ec["result"]["schedule"]
    assignments = {a["game"]: a for a in partition["assignments"]}
    slots = {s["request_id"]: s for s in schedule["scheduled"]}
    assert len(assignments) == len(slots) == len(book["openings"]) == 64
    families, provenance = [], []
    for i, opening in enumerate(book["openings"]):
        slot = slots[opening["id"]]
        assignment = assignments[opening["id"]]
        assert slot["game"] == i
        assert opening["id"] == assignment["game"] == slot["request_id"]
        assert opening["prefix"] == slot["prefix"] == assignment["prefix"]
        assert slot["scheduled_failure"] is None and slot["root"] is not None
        accepted = [
            a
            for a in slot["attempts"]
            if a["rejection"] is None and a["prefix"] == opening["prefix"]
        ]
        assert len(accepted) == 1
        root = slot["root"]
        family = dict(
            family_id=slot["game"],
            id=opening["id"],
            seed=input_config["prefix_seed"],
            prefix=opening["prefix"],
            root_key=root["state_key"],
            history_counts=root["history"],
            attempt_id=accepted[0]["attempt"],
        )
        families.append(family)
        provenance.append(
            dict(
                global_id=slot["game"],
                request_id=opening["id"],
                canonical_family=assignment["family"],
                attempt_id=accepted[0]["attempt"],
                source_schedule=schedule_ref,
                root_pointer=f"/scheduled/{i}/root",
                seed_scope="shared_generator_batch_prefix_seed",
                per_family_rng_state=None,
                native_root_history_unchanged=True,
            )
        )
    assert [f["family_id"] for f in families] == list(range(64))
    assert len({p["canonical_family"] for p in provenance}) == 64
    carrier_ref = put(
        "arena-book.json",
        dict(
            complete=True,
            rules="research-standard-2p-threefold-goal-first-v1",
            families=families,
        ),
    )
    provenance_ref = put(
        "carrier-provenance.json",
        dict(
            source_prefix_book=book_ref,
            source_schedule=schedule_ref,
            source_partition=partition_ref,
            source_preparation=ec_ref,
            input_config=input_config_ref,
            input_prefix_seed=42320261017,
            arena_rng_seed=42320261026,
            bootstrap_seed=42320261027,
            per_family_rng_state="UNKNOWN",
            exclusions=input_config["excluded_books"],
            families=provenance,
            new_inputs_or_rules_replays=0,
            chronology_authority="original normal native preparation; Root arena admission replays original full prefixes",
        ),
    )

    build, build_ref = read(B421 / "arena-receiver-build-v1/operation-v1/manifest.json")
    assert build["status"] == "PASS"
    artifact = build["artifact"]
    assert (
        artifact["sha256"]
        == "35e47e65effdb04763e7f7b38475514490915f6a97bfa285bfeb2dbe4cf449a2"
    )
    assert artifact["bytes"] == 9459656
    changed, changed_ref = read(
        B423 / "science-v1/changed-weights-entry-v2/collection.json"
    )
    w = changed["models"]["W"]
    assert (
        w["typed_evaluator_sha256"]
        == "8a8eb7fb87035f03c4cfa6b45ca1aa5d2f1b144c6fa1298dd11b82975307953d"
    )
    assert (
        w["weights"]["sha256"]
        == "ab073fb138b84710c0d244c1459aebc016a74743ecabee5e949321a00ec81b99"
    )
    assert (
        w["descriptor"]["sha256"]
        == "fbf0beb86fdf7f42f5bdd88893df215423ca86873da04308ed5029128edaf70a"
    )
    w_model = dict(
        descriptor=w["descriptor"],
        weights=w["weights"],
        evaluator_sha256=w["typed_evaluator_sha256"],
    )
    old_plan, old_plan_ref = read(EXAMPLE / "plan.json")
    old_config, old_config_ref = read(
        old_plan["batches"][0]["config"]["path"], old_plan["batches"][0]["config"]
    )
    d_config, d_config_ref = read(
        old_plan["batches"][2]["config"]["path"], old_plan["batches"][2]["config"]
    )
    best = old_plan["models"][0]
    assert (
        best["evaluator_sha256"]
        == "96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875"
    )
    assert best["weights"]["sha256"].startswith("046fe926") and best["descriptor"][
        "sha256"
    ].startswith("46ec2c47")
    d_id = d_config["arena"]["evaluator_sha256"][1]
    assert (
        d_config["engines"][1]["kind"] == "distance"
        and d_config["engines"][1]["model"] is None
    )
    identity_ref = put(
        "model-identities.json",
        dict(
            W=dict(
                **w_model,
                authority=changed_ref,
                identity_owner=w["typed_identity_owner"],
            ),
            BEST43=dict(**best, authority=old_plan_ref),
            D=dict(
                native_method="original-distance-a0-b8-tanh",
                model=None,
                models=[],
                evaluator_sha256=d_id,
                identity_from_existing_config=d_config_ref,
            ),
            image=artifact,
            Build=build_ref,
            model_or_library_or_image_payload_reads=0,
            new_identity_hash_derivations=0,
        ),
    )

    shared_engine = dict(
        distance_a=0.0,
        distance_b=8.0,
        depth=64,
        max_nodes=1000000,
        time_ms=100,
        simd=False,
        ordering_profile="control",
        lmr=True,
        lmr_method="depth_rank",
        zero_stock_approx_min_root_walls=None,
        zero_stock_safe_race=False,
    )
    models = dict(W=w_model, BEST43=best, D=None)

    def engine(label):
        model = models[label]
        return dict(
            kind="distance" if model is None else "nnue",
            model=None if model is None else model["descriptor"]["path"],
            **shared_engine,
        )

    operations = []
    for index, (name, right, n, quota) in enumerate(
        [
            ("primary-W-vs-BEST43", "BEST43", 64, 800000000),
            ("secondary-W-vs-D", "D", 16, 200000000),
        ]
    ):
        chosen = families[:n]
        colors = [i % 2 for i in range(n)]
        native_openings = []
        for family in chosen:
            settings = dict(
                family,
                seed_scope="shared_generator_batch_prefix_seed",
                per_family_rng_state=None,
                native_root_pointer=f"/scheduled/{family['family_id']}/root",
            )
            native_openings.append(
                dict(
                    id=family["id"],
                    cohort="main",
                    lineage="423-evaluation:" + family["id"],
                    siblings=[],
                    original_seed=family["seed"],
                    reference=dict(
                        source_sha256=carrier_ref["sha256"],
                        model_sha256=None,
                        settings=settings,
                        q_definition=None,
                        q_perspective=None,
                        q_aggregation=None,
                        q=None,
                    ),
                    selection_reason="Original frozen evaluation ID order, all64 primary/first16 secondary; no outcome/time/refill selection",
                    candidate_pool_size=32,
                    prefix=family["prefix"],
                )
            )
        config = copy.deepcopy(old_config)
        config.update(
            run_id="423-" + name + "-control-depth-rank",
            output=str(PERF / f"batch-{index:03d}/data"),
            games=2 * n,
            seed=recipe["seed"],
            engines=[engine("W"), engine(right)],
            max_output_bytes=128 * 1024**2,
        )
        config["arena"].update(
            book=dict(
                id="nnue-teacher-refresh423-fixed-evaluation64",
                usage="main",
                frozen_before_candidate_results=True,
                independence="Same first16 of primary64 reused in secondary; colours paired, fixed-book intervals per contrast.",
                openings=native_openings,
            ),
            max_total_nodes=quota,
            bootstrap_seed=recipe["bootstrap_seed"],
            first_candidate_colors=colors,
            evaluator_sha256=[
                w_model["evaluator_sha256"],
                d_id if right == "D" else best["evaluator_sha256"],
            ],
            search_artifact_sha256=[artifact["sha256"]] * 2,
            retained_outcome_bytes=8 * 1024**2,
        )
        assert config["cpu_cores"] == [2, 6] and config["management_cpu_core"] == 4
        config_ref = put(name + "/config.json", config)
        game_schedule = []
        for i, family in enumerate(chosen):
            for offset, color in enumerate((colors[i], 1 - colors[i])):
                game_schedule.append(
                    dict(
                        slot=2 * i + offset,
                        batch=0,
                        matchup=0,
                        local_game=2 * i + offset,
                        family_id=family["family_id"],
                        candidate_color=color,
                    )
                )
        game_schedule_ref = put(name + "/schedule.json", game_schedule)
        used_models = [w_model] + ([best] if right == "BEST43" else [])
        inputs = [
            carrier_ref,
            book_ref,
            schedule_ref,
            partition_ref,
            input_config_ref,
            ec_ref,
            changed_ref,
            provenance_ref,
            identity_ref,
        ]
        plan = dict(
            schema="quoridor.research.arena-plan.v1",
            phase="arena",
            comparison="whole_wall_time",
            rules=old_plan["rules"],
            distance_units=old_plan["distance_units"],
            value_perspective=old_plan["value_perspective"],
            book=carrier_ref,
            inputs=inputs,
            models=used_models,
            schedule=game_schedule_ref,
            family_ids=[f["family_id"] for f in chosen],
            matchups=[
                dict(
                    id=0,
                    engines=config["engines"],
                    evaluator_sha256=config["arena"]["evaluator_sha256"],
                    inference=None,
                )
            ],
            batches=[
                dict(batch=0, matchup=0, config=config_ref, slots=list(range(2 * n)))
            ],
            planned_slots=2 * n,
        )
        plan_ref = put(name + "/plan.json", plan)
        # Normal RUN shape only: actual Experiment/caller/support/runtime/path binding is Root-owned.
        run = dict(
            schema="quoridor.research.lifecycle-intent.v1",
            kind="run",
            owner=str(ROOT),
            writer="codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            cwd=str(ROOT),
            output=None,
            env=None,
            limits=dict(
                family_B=4 * 1024**3,
                controller_B=64 * 1024**2,
                host_reserve_B=4 * 1024**3,
                owned_B=128 * 1024**2,
                free_B=0,
                log_B=2 * 1024**2,
                worker_cpu=2,
                guardian_cpu=4,
            ),
            support=None,
            approved_plan=plan_ref,
            artifact=artifact,
            experiment=None,
            caller_sources=None,
            child_cpu_cores=[2, 4, 6],
            data_root=None,
            owned_outputs=None,
            TMP=None,
            finalizers=[],
            data=None,
            argv=None,
        )
        run_ref = put(name + "/RUN-template.json", run)
        operations.append(
            dict(
                index=index,
                name=name,
                left="W",
                right=right,
                role="primary" if index == 0 else "secondary exploratory",
                families=n,
                family_ids=plan["family_ids"],
                games=2 * n,
                colourpairs=n,
                node_quota=quota,
                config=config_ref,
                schedule=game_schedule_ref,
                plan=plan_ref,
                RUN_template=run_ref,
                actual_Experiment=None,
                actual_runtime=None,
                actual_output=None,
                actual_output_forecast=None,
                actual_support=None,
                actual_physical_allocation=None,
                actual_caller=None,
                status="NOT_READY_ROOT_FINAL_BINDING_AND_FORECAST",
            )
        )
    put(
        "settings.json",
        dict(
            issue="quoridor-4lc.423.3",
            scope="original423 arena metadata/settings only",
            seed=recipe["seed"],
            bootstrap_seed=recipe["bootstrap_seed"],
            input_prefix_seed=42320261017,
            image=artifact,
            Build=build_ref,
            models=identity_ref,
            carrier=carrier_ref,
            provenance=provenance_ref,
            original_recipe=recipe_ref,
            operations=operations,
            continuous_order=[o["name"] for o in operations],
            maximum_games=160,
            maximum_pairs=80,
            whole_node_cap=1000000000,
            disjoint_node_quotas=[800000000, 200000000],
            quota_transfer_refill_reset=False,
            shared_first16_dependence=True,
            one_plan_per_operation_reason="Maintained planned_game_slice requires equal family counts across matchups in one plan",
            existing_sequence="Two existing normal RUN operations in this fixed order; no per-pair launches/new scheduler",
            normal_RUN_submission=False,
            policy=dict(
                **recipe["policy"],
                PVS_authority="unchanged qualified arena factory; no new JSON selector",
            ),
            output_ceiling_note="Native per-operation128MiB and retained8MiB are ceilings, not additional reservations. Whole original423128MiB remains shared with all retained original work. Root must resolve actual forecast/remaining support before entry; no enough-space claim.",
            whole_bulk_cap=128 * 1024**2,
            global_cap_decimal_bytes=50000000000,
            original_science_reexecuted=0,
            native_or_model_or_image_payload_reads=0,
            old_FAILED_fees_unknowns_and_pauses_preserved=True,
        ),
    )
    for path, before in SELECTED.items():
        assert ref(path) == before, path
    put("selectedrefs.json", list(SELECTED.values()))
    print(
        json.dumps(
            dict(
                status="DRAFT_FROZEN_NOT_SUBMITTED",
                families=[64, 16],
                games=[128, 32],
                node_quotas=[800000000, 200000000],
                attempt_ids=sorted({f["attempt_id"] for f in families}),
                actual_Experiments=None,
                actual_runtime=None,
            )
        )
    )


if __name__ == "__main__":
    main()
