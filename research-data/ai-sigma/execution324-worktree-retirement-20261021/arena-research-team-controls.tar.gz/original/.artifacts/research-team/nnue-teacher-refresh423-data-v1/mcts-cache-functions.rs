#[derive(Clone, serde::Serialize)]
struct MctsSource {
    model_sha256: String,
    completed_simulations: u32,
}
impl MctsSource {
    fn raw(&self, row: &TeacherRow) -> Result<f32> {
        let crate::Teacher::Mcts {
            root_mean,
            root_nn,
            root_visits,
            ..
        } = &row.teacher
        else {
            return Err("configured common MCTS row required".into());
        };
        if row.model_sha != self.model_sha256
            || *root_visits != self.completed_simulations
            || !root_mean.is_finite()
            || root_mean.abs() > 1.0
            || root_nn.is_none_or(|q| !q.is_finite() || q.abs() > 1.0)
        {
            return Err("MCTS model/completed simulations/finite raw values differ".into());
        }
        Ok(*root_mean)
    }
}

/// Normal selfplay datasets only. Each actual native config is SHA-bound and
/// corresponds to one input dataset in the same global slice order.
pub fn write_common_mcts(
    inputs: &[PathBuf],
    output: &Path,
    configs: &crate::terminal_stream::BoundJson,
    binding: Option<&crate::terminal_stream::BoundJson>,
) -> Result<TensorCache> {
    use crate::{common_corpus, terminal, terminal_stream};
    let references: Vec<terminal_stream::BoundJson> = serde_json::from_value(configs.read()?)?;
    if inputs.is_empty() || references.len() != inputs.len() || !output.is_absolute() {
        return Err("ordered native datasets/configs and fresh absolute output required".into());
    }
    let mut unique = BTreeSet::new();
    let mut runs = Vec::new();
    let mut combined: Option<common_corpus::Config> = None;
    let mut model: Option<MctsSource> = None;
    for (input, reference) in inputs.iter().zip(&references) {
        if !input.is_absolute() || !unique.insert(input.clone()) {
            return Err("repeated or relative MCTS dataset".into());
        }
        let config = reference.read()?;
        let common: common_corpus::Config = serde_json::from_value(config["common_study"].clone())?;
        common.validate_inputs()?;
        if !matches!(
            &common.root_value_policy,
            common_corpus::RootValuePolicy::OutcomeOnly
        ) {
            return Err("common MCTS conversion uses outcome-only eligibility".into());
        }
        let simulations = u32::try_from(config["simulations"].as_u64().ok_or("MCTS simulations")?)?;
        let sha = config["inference"]["model_sha"]
            .as_str()
            .ok_or("MCTS model SHA")?;
        if sha.len() != 64
            || !sha
                .bytes()
                .all(|c| c.is_ascii_digit() || (b'a'..=b'f').contains(&c))
            || simulations == 0
            || config["temperature"].as_f64() != Some(0.0)
            || config["engines"].as_array().is_none_or(|e| {
                e.len() != 1 || e[0]["kind"] != "mcts" || !e[0]["time_ms"].is_null()
            })
            || config["inference"]["backend"] != "ort"
            || config["inference"]["cuda_graph"] != false
            || config["inference"]["logical_row_limit"]
                .as_u64()
                .is_none_or(|n| n == 0)
            || input
                != &PathBuf::from(config["output"].as_str().ok_or("native output path")?)
                    .join("dataset")
        {
            return Err("actual bounded greedy CPU MCTS native configuration required".into());
        }
        let source = MctsSource {
            model_sha256: sha.into(),
            completed_simulations: simulations,
        };
        if let Some(expected) = &model {
            if expected.model_sha256 != source.model_sha256
                || expected.completed_simulations != simulations
            {
                return Err("MCTS model/simulation setting differs across slices".into());
            }
        } else {
            model = Some(source.clone());
        }
        if let Some(total) = &mut combined {
            let mut expected = total.clone();
            expected.batch_start = common.batch_start;
            expected.batch_count = common.batch_count;
            if serde_json::to_value(expected)? != serde_json::to_value(&common)?
                || common.batch_start
                    != total
                        .batch_start
                        .checked_add(total.batch_count)
                        .ok_or("batch sum")?
            {
                return Err("MCTS global input settings differ or slices overlap/gap/order".into());
            }
            total.batch_count = total
                .batch_count
                .checked_add(common.batch_count)
                .ok_or("batch sum")?;
        } else {
            combined = Some(common.clone());
        }
        let partition: terminal::FamilyPartition =
            serde_json::from_value(common.partition.read()?)?;
        runs.push((input, common, partition));
    }
    let common = combined.ok_or("MCTS common config")?;
    common.validate_shape()?;
    let model = model.ok_or("MCTS source")?;
    let input_binding = binding.map(terminal_stream::BoundJson::read).transpose()?;
    let scale = terminal_stream::model_scale_authority(input_binding.as_ref())?;
    let mut writer = Writer::new_common(output, common)?;
    writer.mcts_source = Some(model.clone());
    let mut datasets = Vec::new();
    let converted = (|| -> Result<()> {
        for (input, common, partition) in &runs {
            let manifest_path = input.join("manifest.json");
            let manifest_sha = file_sha(&manifest_path)?;
            let requests = common.global_requests()?;
            let mut game: Option<String> = None;
            let mut previous: Option<u16> = None;
            let mut final_prefix: Option<Vec<u16>> = None;
            let mut actual_rows = 0usize;
            for_each_row(input, false, |row| {
                row.validate()?;
                model.raw(row)?;
                let id: usize = row
                    .game
                    .strip_prefix("game-")
                    .ok_or("MCTS global game ID")?
                    .parse()?;
                if !common.batch_range()?.contains(&id) {
                    return Err("MCTS row outside actual configured slice".into());
                }
                let assignment = partition
                    .assignments
                    .iter()
                    .find(|a| a.game == requests[id].0)
                    .ok_or("MCTS game has no canonical input family")?;
                if row.family != assignment.family
                    || row.split != assignment.split
                    || !row.prefix.starts_with(&assignment.prefix)
                {
                    return Err("MCTS row prefix/family/split differs from canonical input".into());
                }
                let provenance = &row
                    .terminal_targets
                    .as_ref()
                    .ok_or("MCTS terminal provenance")?
                    .provenance;
                if game.as_deref() != Some(row.game.as_str()) {
                    if previous
                        .is_some_and(|p| usize::from(p) + 1 != final_prefix.as_ref().unwrap().len())
                    {
                        return Err("MCTS previous game block incomplete".into());
                    }
                    if row.prefix != assignment.prefix {
                        return Err("MCTS first row differs from scheduled full prefix".into());
                    }
                    game = Some(row.game.clone());
                    previous = None;
                    final_prefix = Some(provenance.final_prefix.clone());
                }
                if previous.is_some_and(|p| p.checked_add(1) != Some(row.ply))
                    || final_prefix.as_ref() != Some(&provenance.final_prefix)
                {
                    return Err("MCTS rows not one complete chronological game".into());
                }
                previous = Some(row.ply);
                writer.push(row, None)?;
                actual_rows += 1;
                Ok(())
            })?;
            if previous.is_some_and(|p| usize::from(p) + 1 != final_prefix.as_ref().unwrap().len())
            {
                return Err("MCTS final game block incomplete".into());
            }
            let manifest: crate::DatasetManifest =
                serde_json::from_reader(std::fs::File::open(input.join("manifest.json"))?)?;
            if actual_rows != manifest.rows || file_sha(&manifest_path)? != manifest_sha {
                return Err("MCTS dataset row census/hash differs".into());
            }
            datasets.push(serde_json::json!({"dataset":input,"manifest_sha256":manifest_sha,"rows":actual_rows}));
        }
        configs.read()?;
        for reference in &references {
            reference.read()?;
        }
        Ok(())
    })();
    if let Err(error) = converted {
        let cleanup = writer.abort();
        return Err(format!("MCTS conversion primary:{error};close:{cleanup:?}").into());
    }
    let mut extra = serde_json::Map::new();
    extra.insert("mcts_datasets".into(), serde_json::to_value(datasets)?);
    extra.insert("mcts_source".into(), serde_json::to_value(model)?);
    extra.insert("mcts_native_configs".into(), serde_json::to_value(configs)?);
    if let Some(binding) = binding {
        extra.insert("input_binding".into(), serde_json::to_value(binding)?);
    }
    if let Some(scale) = scale {
        extra.insert("model_scale_authority".into(), scale);
    }
    writer.finish(file_sha(&configs.path)?, false, extra)
}
