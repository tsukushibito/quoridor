from pathlib import Path

OWN = Path(__file__).resolve().parent
PATH = OWN / "input-source-v1/post/crates/quoridor-runner/src/teacher_pilot/depth6.rs"
s = PATH.read_text()


def replace(old, new):
    global s
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)


replace(
    "    pub prefix_lengths: Vec<u16>,\n    pub split_seed: u64,",
    """    pub prefix_lengths: Vec<u16>,
    pub split_seed: u64,
    /// Reuse the exact prefixes/attempts of a SHA-bound prospective input schedule.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub reuse_schedule: Option<quoridor_data::terminal_stream::BoundJson>,""",
)
replace(
    "    let slots = global_schedule(c.families, c.prefix_seed, &c.prefix_lengths)?;",
    """    let slots = if let Some(reference) = &c.reuse_schedule {
        validate_schedule_shape(c.families, &c.prefix_lengths)?;
        let source = reference.read()?;
        if source["generator_version"] != quoridor_data::common_corpus::VERSION
            || source["prefix_seed"].as_u64() != Some(c.prefix_seed)
            || source["prefix_lengths"] != serde_json::to_value(&c.prefix_lengths)?
        { return Err("reused input schedule generator/seed/lengths differ".into()); }
        let all: Vec<ScheduledGame> = serde_json::from_value(source["scheduled"].clone())?;
        if all.len() < c.families { return Err("reused schedule shorter than configured cohort".into()); }
        let selected = all.into_iter().take(c.families).collect::<Vec<_>>();
        for (id, slot) in selected.iter().enumerate() {
            if slot.game != id || slot.request_id != format!("fixed-d-family-{id:06}")
                || slot.requested_prefix_length != c.prefix_lengths[id % c.prefix_lengths.len()]
            { return Err("reused input request/order differs".into()); }
            if let Some(prefix) = &slot.prefix {
                slot.root.as_ref().ok_or("reused input full history absent")?.audit(prefix)?;
                if prefix.len() != usize::from(slot.requested_prefix_length) {
                    return Err("reused input prefix length differs".into());
                }
            } else if slot.scheduled_failure.is_none() {
                return Err("missing reused slot without original failure".into());
            }
        }
        selected
    } else {
        global_schedule(c.families, c.prefix_seed, &c.prefix_lengths)?
    };""",
)
replace(
    '&serde_json::json!({"generator_version":quoridor_data::common_corpus::VERSION,"scheduled":slots}),',
    '&serde_json::json!({"generator_version":quoridor_data::common_corpus::VERSION,"prefix_seed":c.prefix_seed,\n            "prefix_lengths":c.prefix_lengths,"reused_schedule":c.reuse_schedule,"scheduled":slots}),',
)
start = s.index("    if families == 0", s.index("pub fn global_schedule("))
end = s.index("    let requests =", start)
shape = s[start:end]
assert shape.endswith("    }\n")
s = s[:start] + "    validate_schedule_shape(families, lengths)?;\n" + s[end:]
helper = (
    "fn validate_schedule_shape(families: usize, lengths: &[u16]) -> Result<()> {\n"
    + shape
    + "    Ok(())\n}\n\n"
)
s = s.replace(
    "/// Called once by normal global preparation",
    helper + "/// Called once by normal global preparation",
    1,
)
PATH.write_text(s)
print(
    "SHA-bound schedule reuse added to existing input owner; no generator/native execution"
)
