import gzip
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent
REL = Path("crates/quoridor-data/src/terminal_cache.rs")
before = Path("/workspaces/quoridor") / REL
raw = gzip.decompress((OWN / "before/terminal_cache.rs.gz").read_bytes())
assert before.read_bytes() == raw
s = raw.decode()


def replace(old, new):
    global s
    assert s.count(old) == 1, (old[:100], s.count(old))
    s = s.replace(old, new)


replace(
    "fn sampling_code(&mut self, r: &TeacherRow) -> Result<u32>",
    "fn sampling_code(&mut self, r: &TeacherRow, split: &crate::Split) -> Result<u32>",
)
replace(
    "|| !matches!(r.split, crate::Split::Train | crate::Split::Validation)",
    "|| !matches!(r.split, crate::Split::Train | crate::Split::Validation)\n            || !matches!(split, crate::Split::Train | crate::Split::Validation)",
)
replace("if f.split != r.split {", "if &f.split != split {")
replace("split: r.split.clone(),", "split: split.clone(),")
replace(
    "        // Pure raw/provenance checks precede geometry or any row publication.",
    """        self.push_with_sampling_split(r, evidence, None)
    }

    // Original TeacherRow remains immutable; only compact sampling metadata may use a view.
    fn push_with_sampling_split(
        &mut self,
        r: &TeacherRow,
        evidence: Option<serde_json::Value>,
        sampling_split: Option<&crate::Split>,
    ) -> Result<()> {
        let split = sampling_split.unwrap_or(&r.split);
        // Pure raw/provenance checks precede geometry or any row publication.""",
)
replace("Some(self.sampling_code(r)?)", "Some(self.sampling_code(r, split)?)")
replace(
    "u8::from(r.split == crate::Split::Validation)",
    "u8::from(*split == crate::Split::Validation)",
)
replace(
    "let key = if r.split == crate::Split::Train {",
    "let key = if *split == crate::Split::Train {",
)

helpers = r"""
// Explicit optional final sampling view, bound through the existing input-binding inlet.
// This does not revise any producer config, row, source split or source publication.
struct MctsFitView {
    reference: crate::terminal_stream::BoundJson,
    common: crate::common_corpus::Config,
    partition: crate::terminal::FamilyPartition,
}

#[derive(serde::Serialize)]
struct MctsFitAssignment {
    global_id: usize,
    game: String,
    request_id: String,
    source_index: usize,
    family: String,
    prefix: Vec<u16>,
    source_split: crate::Split,
    view_split: crate::Split,
}

fn fit_assignment<'a>(
    partition: &'a crate::terminal::FamilyPartition,
    request: &str,
) -> Result<&'a crate::terminal::FamilyAssignment> {
    let mut matches = partition.assignments.iter().filter(|a| a.game == request);
    let value = matches.next().ok_or("fit-view missing canonical assignment")?;
    if matches.next().is_some() {
        return Err("fit-view duplicate canonical assignment".into());
    }
    Ok(value)
}

fn fit_view_game(cursor: &mut usize, id: usize, end: usize) -> Result<()> {
    if id != *cursor || id >= end {
        return Err("fit-view realized game block reordered, repeated, missing or outside slice".into());
    }
    *cursor = cursor.checked_add(1).ok_or("fit-view realized game overflow")?;
    Ok(())
}

impl MctsFitView {
    fn read(binding: Option<&serde_json::Value>) -> Result<Option<Self>> {
        let Some(value) = binding.and_then(|b| b.get("final_fit_view")) else {
            return Ok(None);
        };
        let reference: crate::terminal_stream::BoundJson = serde_json::from_value(value.clone())?;
        if !reference.path.is_absolute() {
            return Err("fit-view absolute bound config required".into());
        }
        let common: crate::common_corpus::Config = serde_json::from_value(reference.read()?)?;
        common.validate_inputs()?;
        if common.batch_start != 0 || common.batch_count != common.families
            || !matches!(common.root_value_policy, crate::common_corpus::RootValuePolicy::OutcomeOnly)
        {
            return Err("fit-view must bind one complete canonical outcome-only input set".into());
        }
        let partition = serde_json::from_value(common.partition.read()?)?;
        Ok(Some(Self { reference, common, partition }))
    }

    fn append_source(
        &self,
        source: &crate::common_corpus::Config,
        partition: &crate::terminal::FamilyPartition,
        source_index: usize,
        assignments: &mut Vec<MctsFitAssignment>,
    ) -> Result<()> {
        // Only these explicit input-set/view fields may differ. All other actual settings match.
        let mut expected = self.common.clone();
        expected.families = source.families;
        expected.schedule = source.schedule.clone();
        expected.partition = source.partition.clone();
        expected.batch_start = source.batch_start;
        expected.batch_count = source.batch_count;
        let range = source.batch_range()?;
        if serde_json::to_value(&expected)? != serde_json::to_value(source)?
            || source.families > self.common.families
            || range.start != assignments.len()
            || u64::try_from(range.end)? > self.common.families
        {
            return Err("fit-view source settings or contiguous ordered global slots differ".into());
        }
        let requests = source.global_requests()?;
        let final_requests = self.common.global_requests()?;
        for id in range {
            if requests[id] != final_requests[id] {
                return Err("fit-view global request identity/length differs".into());
            }
            let original = fit_assignment(partition, &requests[id].0)?;
            let target = fit_assignment(&self.partition, &final_requests[id].0)?;
            if original.family != target.family || original.prefix != target.prefix
                || !matches!(original.split, crate::Split::Train | crate::Split::Validation)
                || !matches!(target.split, crate::Split::Train | crate::Split::Validation)
            {
                return Err("fit-view source/final prefix or family differs or split is not T/V".into());
            }
            assignments.push(MctsFitAssignment {
                global_id: id,
                game: format!("game-{id}"),
                request_id: requests[id].0.clone(),
                source_index,
                family: original.family.clone(),
                prefix: original.prefix.clone(),
                source_split: original.split.clone(),
                view_split: target.split.clone(),
            });
        }
        Ok(())
    }
}

impl MctsFitAssignment {
    fn check_source_row(&self, row: &TeacherRow) -> Result<()> {
        if row.game != self.game || row.family != self.family
            || row.split != self.source_split || !row.prefix.starts_with(&self.prefix)
        {
            return Err("fit-view row differs from validated original source assignment".into());
        }
        Ok(())
    }
}

"""
replace(
    "/// Normal selfplay datasets only.", helpers + "/// Normal selfplay datasets only."
)
replace(
    "    let mut unique = BTreeSet::new();",
    """    let input_binding = binding.map(terminal_stream::BoundJson::read).transpose()?;
    let fit_view = MctsFitView::read(input_binding.as_ref())?;
    let mut view_assignments = Vec::new();
    let mut unique = BTreeSet::new();""",
)
# Original equality/contiguity block is preserved verbatim within the no-view branch.
start = s.index(
    "        if let Some(total) = &mut combined {", s.index("pub fn write_common_mcts")
)
end = s.index("        runs.push((input, common, partition));", start)
old = s[start:end]
merge = old[: old.index("        let partition:")]
replace(
    old,
    """        let partition: terminal::FamilyPartition =
            serde_json::from_value(common.partition.read()?)?;
        if let Some(view) = &fit_view {
            view.append_source(&common, &partition, runs.len(), &mut view_assignments)?;
        } else {
"""
    + merge
    + """        }
""",
)
replace(
    '    let common = combined.ok_or("MCTS common config")?;',
    """    let common = if let Some(view) = &fit_view {
        if u64::try_from(view_assignments.len())? != view.common.families {
            return Err("fit-view source slot census incomplete".into());
        }
        view.common.clone()
    } else {
        combined.ok_or("MCTS common config")?
    };""",
)
# Only old second occurrence remains now.
replace(
    "    let input_binding = binding.map(terminal_stream::BoundJson::read).transpose()?;\n    let scale",
    "    let scale",
)
replace(
    "        let mut datasets = Vec::new();",
    "        let mut datasets = Vec::new();\n        let mut realized = 0usize;",
)
replace(
    "                    game = Some(row.game.clone());",
    """                    if fit_view.is_some() {
                        fit_view_game(&mut realized, id, common.batch_range()?.end)?;
                    }
                    game = Some(row.game.clone());""",
)
replace(
    "                writer.push(row, None)?;",
    """                if fit_view.is_some() {
                    let assignment = view_assignments.get(id).ok_or("fit-view row slot")?;
                    assignment.check_source_row(row)?;
                    writer.push_with_sampling_split(row, None, Some(&assignment.view_split))?;
                } else {
                    writer.push(row, None)?;
                }""",
)
replace(
    "            let manifest: crate::DatasetManifest =",
    """            if fit_view.is_some() && realized != common.batch_range()?.end {
                return Err("fit-view source has missing realized game slots".into());
            }
            let manifest: crate::DatasetManifest =""",
)
replace(
    "        configs.read()?;",
    """        if let Some(view) = &fit_view {
            if u64::try_from(realized)? != view.common.families {
                return Err("fit-view realized slot census incomplete".into());
            }
            view.reference.read()?;
            view.common.schedule.read()?;
            view.common.partition.read()?;
            for (_, original, _) in &runs {
                original.schedule.read()?;
                original.partition.read()?;
            }
        }
        if let Some(binding) = binding {
            binding.read()?;
        }
        configs.read()?;""",
)
replace(
    '        extra.insert("mcts_datasets".into(),',
    """        if let Some(view) = &fit_view {
            extra.insert("final_fit_view".into(), serde_json::json!({
                "config": view.reference,
                "scope": "sampling-only-original-source-validated",
                "realized_games": realized,
                "changed_global_ids": view_assignments.iter()
                    .filter(|a| a.source_split != a.view_split)
                    .map(|a| a.global_id).collect::<Vec<_>>(),
                "assignments": view_assignments,
            }));
        }
        extra.insert("mcts_datasets".into(),""",
)
post = OWN / "post" / REL
post.parent.mkdir(parents=True)
post.write_text(s)
(OWN / "before-ref.json").write_text(
    json.dumps(
        dict(
            path=str(before),
            sha256=hashlib.sha256(raw).hexdigest(),
            bytes=len(raw),
            mode=oct(before.stat().st_mode & 0o777),
        ),
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        dict(before_bytes=len(raw), post_bytes=len(s.encode()), private_post=str(post))
    )
)
