import difflib
import gzip
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parent
TMP = Path(os.environ["TMPDIR"])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=sha(data),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n")


def top_functions(s):
    result = {}
    for m in re.finditer(r"(?m)^(?:pub(?:\([^)]*\))? )?fn ([a-zA-Z0-9_]+)\(", s):
        end = re.search(r"(?m)^}", s[m.start() :])
        assert end
        result[m[1]] = s[m.start() : m.start() + end.end()]
    return result


def freeze(out, subjects, tests, parent):
    records, forward, inverse = [], [], []
    protected = []
    for rel, before, recovery, post in subjects:
        after = post.read_bytes()
        target = TMP / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(before)
        records.append(
            dict(
                subject=rel,
                before_sha256=sha(before),
                before_bytes=len(before),
                recovery=ref(recovery),
                post=ref(post),
                new_absence="existing production subject",
            )
        )
        for pieces, a, b in [(forward, before, after), (inverse, after, before)]:
            pieces.extend(
                difflib.unified_diff(
                    a.decode().splitlines(True),
                    b.decode().splitlines(True),
                    fromfile="a/" + rel,
                    tofile="b/" + rel,
                )
            )
        a, b = top_functions(before.decode()), top_functions(after.decode())
        for name in sorted(a.keys() & b.keys()):
            if a[name] == b[name]:
                protected.append(
                    dict(
                        subject=rel,
                        function=name,
                        sha256=sha(a[name].encode()),
                        bytes=len(a[name].encode()),
                    )
                )
    for name, patch, post_mode in [
        ("forward.patch", forward, True),
        ("inverse.patch", inverse, False),
    ]:
        (out / name).write_text("".join(patch))
        result = subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "-p1",
                "-d",
                str(TMP),
                "-i",
                str(out / name),
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        (out / (name + ".log")).write_text(result.stdout + result.stderr)
        assert result.returncode == 0
        for record in records:
            assert sha((TMP / record["subject"]).read_bytes()) == (
                record["post"]["sha256"] if post_mode else record["before_sha256"]
            )
    for rel, *_ in subjects:
        (TMP / rel).unlink()
    for p in sorted(TMP.rglob("*"), key=lambda p: len(p.parts), reverse=True):
        if p.is_dir():
            p.rmdir()
    proof = dict(
        strict_forward_inverse=True,
        protected_top_level_functions=protected,
        new_production_files=[],
        author_Main_Git_Cargo_native_models_Search_games=0,
        tests=tests,
        status="UNBUILT/UNTYPED/UNRUN",
    )
    write(out / "static-proof.json", proof)
    binding = dict(
        issue="quoridor-4lc.423.3",
        parent_source=parent,
        subjects=records,
        forward=ref(out / "forward.patch"),
        inverse=ref(out / "inverse.patch"),
        proof=ref(out / "static-proof.json"),
        fixed_spec=json.loads((OWN / "fixed-spec-refs.json").read_text()),
        required_software=tests,
        software="UNBUILT/UNTYPED/UNRUN",
        future_image=None,
        future_Build=None,
        author_review_verdict="not asserted",
    )
    write(out / "source-binding.json", binding)
    print(
        json.dumps(
            dict(
                out=out.name,
                binding=ref(out / "source-binding.json"),
                patch=ref(out / "forward.patch"),
                tests=len(tests),
            )
        )
    )


repair = json.loads((OWN / "native-repair-v1/source-binding.json").read_text())
assert ref(Path(repair["post"]["path"])) == repair["post"]
frozen = json.loads((OWN / "native-source-v2/source-binding.json").read_text())
for subject in frozen["subjects"]:
    assert ref(Path(subject["post"]["path"])) == subject["post"]

data_out = OWN / "data-source-v1"
data_out.mkdir(exist_ok=True)
data = []
for record in json.loads((OWN / "data-before-refs.json").read_text())["subjects"]:
    rel = record["subject"]
    recovery = OWN / "before" / (rel + ".gz")
    before = gzip.decompress(recovery.read_bytes())
    assert sha(before) == record["sha256"] and len(before) == record["bytes"]
    data.append((rel, before, recovery, OWN / "post" / rel))
stream_before = data[2][1].decode()
stream_after = data[2][3].read_text()
for name, body in top_functions(stream_before).items():
    if name != "write_cache":
        assert top_functions(stream_after)[name] == body, name
freeze(
    data_out,
    data,
    [
        "common_mcts_codec_tests::common_mcts_raw_requires_model_complete_visits_and_finite_head_without_z_mask",
        "common_mcts_codec_tests::common_mcts_v3_codec_preserves_raw_unknown_mask_and_chronological_blocks",
        "mcts_config_list_tests::configured_mcts_converter_requires_bound_list_pair_and_preserves_source_order",
    ],
    dict(
        git="7cd6b40549069145cd0b80574ca9a5648b4da47d",
        scale_owner="existing terminal_stream model_scale_authority extraction only; Alpha receiver bodies exact",
    ),
)

out = OWN / "old-q-source-v2"
oldq = []
for name in ["config.rs", "runtime.rs", "main.rs"]:
    rel = "crates/quoridor-runner/src/" + name
    if name == "runtime.rs":
        before_path = OWN / "native-repair-v1/post" / rel
        before = before_path.read_bytes()
    elif name == "config.rs":
        before_path = OWN / "post" / rel
        before = before_path.read_bytes()
    else:
        before_path = OWN / "before" / (rel + ".gz")
        before = gzip.decompress(before_path.read_bytes())
        expected = json.loads((OWN / "old-q-cli-before.json").read_text())
        assert sha(before) == expected["sha256"]
    recovery = out / ("before-" + name + ".gz")
    recovery.write_bytes(gzip.compress(before, mtime=0))
    oldq.append((rel, before, recovery, out / "post" / rel))
a, b = top_functions(oldq[1][1].decode()), top_functions(oldq[1][3].read_text())
for name in [
    "arena_alpha_namespace",
    "arena_alpha_session",
    "make_backend",
    "worker",
    "commit_action",
    "finish",
    "planned",
    "admit_mcts_rows",
    "attach_common_mcts_outcome",
    "attach_primary_failure",
]:
    assert a[name] == b[name], name
start = "struct CompletionPublication<'a>"
end = "pub(crate) fn attach_primary_failure"
assert (
    oldq[1][1].decode().split(start, 1)[1].split(end, 1)[0]
    == oldq[1][3].read_text().split(start, 1)[1].split(end, 1)[0]
)
freeze(
    out,
    oldq,
    [
        "bounded_mcts_benchmark_config_tests::bounded_mcts_one_pass_requires_exact_inputs_quota_and_preserves_default",
        "common_mcts_admission_cause_tests::common_mcts_supplied_backend_refused_before_metadata_inputs_or_admission (extended bounded benchmark refusal; same original definition)",
    ],
    dict(
        native_repair_binding=ref(OWN / "native-repair-v1/source-binding.json"),
        main_git="7cd6b40549069145cd0b80574ca9a5648b4da47d",
        instruction="apply ONLY after native-v2 + native-repair-v1; no duplicate original whole patch",
    ),
)

out = OWN / "input-source-v1"
record = json.loads((OWN / "input-before-refs.json").read_text())
rel = record["subject"]
recovery = OWN / "before" / (rel + ".gz")
before = gzip.decompress(recovery.read_bytes())
assert sha(before) == record["sha256"]
after = (out / "post" / rel).read_text()
a, b = top_functions(before.decode()), top_functions(after)
for name in ["filter_input_slots", "global_partition"]:
    assert a[name] == b[name], name
assert (
    a["global_schedule"].split("    let requests =", 1)[1]
    == b["global_schedule"].split("    let requests =", 1)[1]
)
freeze(
    out,
    [(rel, before, recovery, out / "post" / rel)],
    [
        "tests::input_schedule_reuse_keeps_original_attempts_missing_slots_and_repartitions_only"
    ],
    dict(
        git=record["git"],
        owner="same canonical rules-only generator/filter/partition; exact actual schedule subset, no new prefix generation by author",
    ),
)
