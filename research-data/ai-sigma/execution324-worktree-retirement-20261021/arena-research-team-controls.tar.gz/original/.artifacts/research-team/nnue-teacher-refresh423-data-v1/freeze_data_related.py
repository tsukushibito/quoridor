import difflib
import gzip
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parent
OUT = OWN / "data-related-v1"
REL = "crates/quoridor-data/src/terminal_cache.rs"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=sha(data),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


def functions(source):
    found = {}
    for match in re.finditer(
        r"(?m)^(?:pub(?:\([^)]*\))? )?fn ([A-Za-z0-9_]+)\(", source
    ):
        end = re.search(r"(?m)^}", source[match.start() :])
        assert end
        found[match[1]] = source[match.start() : match.start() + end.end()]
    return found


parent_path = OWN / "data-source-v2/source-binding.json"
parent_ref = ref(parent_path)
assert (
    parent_ref["sha256"]
    == "f42476614b4725c59493708c5c84f6911f153a4aadd8c183e5a849a79589d48f"
)
parent = json.loads(parent_path.read_bytes())
for subject in parent["subjects"]:
    assert ref(Path(subject["post"]["path"])) == subject["post"]
before_path = OWN / "data-source-v2/post" / REL
post_path = OUT / "post" / REL
before, post = before_path.read_bytes(), post_path.read_bytes()
recovery = OUT / "before-terminal_cache.rs.gz"
recovery.write_bytes(gzip.compress(before, mtime=0))
tmp = Path(os.environ["TMPDIR"])
target = tmp / REL
target.parent.mkdir(parents=True)
target.write_bytes(before)
for name, first, second in [
    ("forward.patch", before, post),
    ("inverse.patch", post, before),
]:
    (OUT / name).write_text(
        "".join(
            difflib.unified_diff(
                first.decode().splitlines(True),
                second.decode().splitlines(True),
                fromfile="a/" + REL,
                tofile="b/" + REL,
            )
        )
    )
    result = subprocess.run(
        [
            "patch",
            "--batch",
            "--fuzz=0",
            "--no-backup-if-mismatch",
            "-p1",
            "-d",
            str(tmp),
            "-i",
            str(OUT / name),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    (OUT / (name + ".log")).write_text(result.stdout + result.stderr)
    assert result.returncode == 0 and target.read_bytes() == second
target.unlink()
for directory in sorted(tmp.rglob("*"), key=lambda p: len(p.parts), reverse=True):
    if directory.is_dir():
        directory.rmdir()
old, new = functions(before.decode()), functions(post.decode())
protected = []
for name, body in old.items():
    if name != "write_common_mcts":
        assert new[name] == body, name
        protected.append(
            dict(function=name, sha256=sha(body.encode()), bytes=len(body.encode()))
        )
original_parse = """                let id: usize = row
                    .game
                    .strip_prefix("game-")
                    .ok_or("MCTS global game ID")?
                    .parse()?;"""
assert (
    old["write_common_mcts"].replace(
        original_parse, "                let id = mcts_game_id(&row.game)?;"
    )
    == new["write_common_mcts"]
)
assert post.decode().count("fn common_mcts_") == before.decode().count(
    "fn common_mcts_"
)
write(
    "static-proof.json",
    dict(
        strict_forward_inverse=True,
        frozen_data_v2_exact=True,
        protected_functions=protected,
        receiver_change="only numeric parse replaced with canonical spelling owner; remaining receiver body exact",
        fixture_change="shared positive row only: action13/visits63/prior1; negative policy cases unchanged; canonical aliases exercised by same new test",
        static_visit_sum="63+1=64, not a native/test execution",
        new_production_files=[],
        new_test_definitions=0,
        software="UNBUILT/UNTYPED/UNRUN",
        Main_Git_Cargo_native_models_forward_Search_games=0,
    ),
)
review = Path(
    "/workspaces/quoridor/.worktree/learning-million/.artifacts/research-team/nnue-teacher-refresh423-review-v1/data-v2/review.md"
)
review_ref = ref(review)
assert (
    review_ref["sha256"]
    == "1773e6e524b3fdcfb6d77674fcd7b6c9769b6f5ba046adcb332b1eccda369a68"
)
control = review.parent / "control.json"
control_ref = ref(control)
assert (
    control_ref["sha256"]
    == "9f9b11933c6eb6ef396f79400082d2b7b73a0973ea48948571250fd98ffee824"
)
assert ref(parent_path) == parent_ref
write(
    "source-binding.json",
    dict(
        issue="quoridor-4lc.423.3",
        phase="data-v2 C1/C2 related delta only",
        parent_binding=parent_ref,
        review=review_ref,
        review_control=control_ref,
        subject=REL,
        before=ref(before_path),
        recovery=ref(recovery),
        post=ref(post_path),
        forward=ref(OUT / "forward.patch"),
        inverse=ref(OUT / "inverse.patch"),
        proof=ref(OUT / "static-proof.json"),
        new_test_definitions=0,
        required_software=[
            "common_mcts_codec_tests::common_mcts_raw_requires_model_complete_visits_and_finite_head_without_z_mask",
            "common_mcts_codec_tests::common_mcts_v3_codec_preserves_raw_unknown_mask_and_chronological_blocks",
        ],
        software="UNBUILT/UNTYPED/UNRUN; no native/test execution by author",
        source_clear="SAME423.4 pending; not asserted",
        future_image=None,
        future_Build=None,
    ),
)
print(
    json.dumps(
        dict(
            binding=ref(OUT / "source-binding.json"), forward=ref(OUT / "forward.patch")
        )
    )
)
