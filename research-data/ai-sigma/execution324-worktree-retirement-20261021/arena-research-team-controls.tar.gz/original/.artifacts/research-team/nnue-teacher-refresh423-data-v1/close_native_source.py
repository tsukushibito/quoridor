import datetime
import hashlib
import json
import os
import resource
from pathlib import Path

OWN = Path(__file__).resolve().parent
OUT = OWN / "native-source-v2"
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


def absence(identity):
    path = Path(f"/proc/{identity['pid']}/stat")
    try:
        start = path.read_text().rsplit(")", 1)[1].split()[19]
        present = BOOT == identity["boot_id"] and start == identity["start_ticks"]
    except FileNotFoundError:
        present = False
    assert not present, identity
    return dict(identity=identity, fresh_absent_or_different=True)


receipts = []
elapsed = 0.0
for stage in sorted(OWN.iterdir()):
    process = stage / "command.process.json"
    controller = stage / "controller.json"
    if not process.is_file():
        continue
    p = json.loads(process.read_text())
    c = json.loads(controller.read_text())
    assert p["direct_child_reaped"] and p["cleanup_complete"]
    assert p["handle_closes_complete"] and p["remaining"] == []
    assert not (stage / "TMP").exists()
    elapsed += p["wall_seconds"]
    receipts.append(
        dict(
            stage=stage.name,
            process=ref(process),
            returned=ref(stage / "return.json"),
            child=absence(p["child"]),
            controller=absence(c),
            exit_code=p["exit_code"],
            disk_signal_mask=p["signal_mask_restoration"],
            disk_final_persist=p["final_record_persist"],
            TMP_absent=True,
        )
    )
binding = json.loads((OUT / "source-binding.json").read_text())
for subject in binding["subjects"]:
    actual = ref(Path(subject["post"]["path"]))
    assert actual == subject["post"]
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
stop = dict(
    issue="quoridor-4lc.423.3",
    phase="native source slice only",
    actual_source_stop=now,
    receipts=receipts,
    owned_source_children=[],
    owned_readers=[],
    owned_writers=[],
    jobs=[],
    handles=[],
    TMP=[],
    leases=[],
    remaining=[],
    native_compile_tests_models_search_games=0,
    command_wall_seconds_sum=elapsed,
    wall_scope="sum of entered scoped commands once; excludes controller/LLM/full-task cost",
    original_returned_vs_disk_masks="both original refs retained; no pending/attempted disk mask rewritten",
    metadata_controller=dict(
        pid=os.getpid(),
        affinity=sorted(os.sched_getaffinity(0)),
        maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        scope="ordinary light final metadata writer; exits after this write; no source subprocess",
    ),
    global_actual_and_continuous_family_peak="UNKNOWN",
    affected_usage="one final task-directed usage pending; no global/asset scan",
)
(OUT / "source-STOP.json").write_text(json.dumps(stop, indent=2) + "\n")
completion = dict(
    issue="quoridor-4lc.423.3",
    status="native private source slice frozen; overall task in_progress",
    source_binding=ref(OUT / "source-binding.json"),
    patch=ref(OUT / "forward.patch"),
    inverse=ref(OUT / "inverse.patch"),
    report=ref(OUT / "report-ja.md"),
    proof=ref(OUT / "static-proof.json"),
    STOP=ref(OUT / "source-STOP.json"),
    new_tests=5,
    software="UNBUILT/UNTYPED/UNRUN",
    current_dependencies=[
        "SAME423.1 final spec/seeds/actual input refs",
        "Root normal composition/software/changed-boundary review/native admission",
    ],
    later_source=[
        "MCTS v3 compact receiver",
        "old-state bounded MCTS",
        "arena resolved allocation",
    ],
    future_image=None,
    future_Build=None,
    future_Experiment=None,
    pauses_defaults_models_raw_failures="unchanged",
)
(OUT / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
print(
    json.dumps(
        dict(
            completion=ref(OUT / "completion.json"),
            STOP=completion["STOP"],
            source_STOP=now,
        )
    )
)
