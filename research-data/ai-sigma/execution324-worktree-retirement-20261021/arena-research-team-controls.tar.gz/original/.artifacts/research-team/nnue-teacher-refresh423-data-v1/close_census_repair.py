import datetime
import hashlib
import json
import os
import resource
from pathlib import Path

OWN = Path(__file__).resolve().parent
OUT = OWN / "native-repair-v2"
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


def absent(identity):
    try:
        start = (
            Path(f"/proc/{identity['pid']}/stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19]
        )
        present = BOOT == identity["boot_id"] and str(start) == str(
            identity["start_ticks"]
        )
    except FileNotFoundError:
        present = False
    assert not present, identity
    return dict(identity=identity, fresh_absent_or_different=True)


receipts = []
for stage in sorted(OWN.iterdir()):
    if not (stage / "command.process.json").is_file():
        continue
    if not (
        stage.name.startswith("census-")
        or stage.name
        in ["related-census-repair-edit-v1", "related-census-review-intake-v1"]
    ):
        continue
    p = json.loads((stage / "command.process.json").read_text())
    c = json.loads((stage / "controller.json").read_text())
    assert (
        p["direct_child_reaped"]
        and p["cleanup_complete"]
        and p["handle_closes_complete"]
        and p["remaining"] == []
    )
    assert not (stage / "TMP").exists()
    receipts.append(
        dict(
            stage=stage.name,
            process=ref(stage / "command.process.json"),
            returned=ref(stage / "return.json"),
            child=absent(p["child"]),
            controller=absent(c),
            exit_code=p["exit_code"],
            seconds=p["wall_seconds"],
            TMP_absent=True,
        )
    )
binding = json.loads((OUT / "source-binding.json").read_text())
for key in ["before", "post", "forward", "inverse", "proof", "original_v2_binding"]:
    assert ref(Path(binding[key]["path"])) == binding[key], key
stop = dict(
    issue="quoridor-4lc.423.3",
    phase="C1 final census/C2 required trait related repair",
    actual_source_STOP=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    receipts=receipts,
    owned_readers=[],
    owned_writers=[],
    children=[],
    jobs=[],
    handles=[],
    TMP=[],
    leases=[],
    remaining=[],
    source_CPU=8,
    guardian_CPU=12,
    child_limit_bytes=960 * 1024**2,
    GPU=0,
    source_software_native_models_Search_games=0,
    child_command_seconds_sum=sum(r["seconds"] for r in receipts),
    cost_scope="entered child commands once only; excludes controller/LLM/full task",
    masks="original returned and disk refs retained without rewriting",
    continuous_family_peak_and_global_actual="UNKNOWN",
    usage="one final OWN affected usage pending",
    metadata_controller=dict(
        pid=os.getpid(),
        affinity=sorted(os.sched_getaffinity(0)),
        maxrss_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        scope="ordinary small final metadata writer; exit follows write",
    ),
)
(OUT / "source-STOP.json").write_text(json.dumps(stop, indent=2) + "\n")
completion = dict(
    issue="quoridor-4lc.423.3",
    status="related source repair frozen; overall in_progress",
    binding=ref(OUT / "source-binding.json"),
    forward=ref(OUT / "forward.patch"),
    inverse=ref(OUT / "inverse.patch"),
    post=binding["post"],
    proof=ref(OUT / "static-proof.json"),
    census_path_proof=ref(OUT / "census-path-proof.json"),
    report=ref(OUT / "report-ja.md"),
    STOP=ref(OUT / "source-STOP.json"),
    new_tests=0,
    changed_tests=2,
    software="UNBUILT/UNTYPED/UNRUN",
    source_clear="SAME reviewer pending",
    original_v2_unchanged=True,
    pending_original_source=[
        "MCTS compact receiver",
        "old-q one-pass inlet",
        "canonical schedule reuse and actual fixed-spec drafts",
    ],
    future_image=None,
    future_Build=None,
)
(OUT / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
print(
    json.dumps(
        dict(
            completion=ref(OUT / "completion.json"),
            STOP=completion["STOP"],
            actual_source_STOP=stop["actual_source_STOP"],
        )
    )
)
