from pathlib import Path

OWN = Path(__file__).resolve().parent
REL = "crates/quoridor-data/src/terminal_cache.rs"
OUT = OWN / "data-related-v1"
POST = OUT / "post" / REL
POST.parent.mkdir(parents=True)
source = (OWN / "data-source-v2/post" / REL).read_text()
old = """                let id: usize = row
                    .game
                    .strip_prefix("game-")
                    .ok_or("MCTS global game ID")?
                    .parse()?;"""
assert source.count(old) == 1
source = source.replace(old, "                let id = mcts_game_id(&row.game)?;")
anchor = "/// Normal selfplay datasets only."
assert source.count(anchor) == 1
helper = """// Producer spelling is part of the global ID, not an arbitrary numeric alias.
fn mcts_game_id(game: &str) -> Result<usize> {
    let id = game.strip_prefix("game-").ok_or("MCTS global game ID")?.parse::<usize>()?;
    if game != format!("game-{id}") {
        return Err("noncanonical MCTS global game ID spelling".into());
    }
    Ok(id)
}

"""
source = source.replace(anchor, helper + anchor)
test_at = source.index("mod common_mcts_codec_tests")
head, tests = source[:test_at], source[test_at:]
row_at = tests.index("    fn row(id:")
row_end = tests.index("\n    #[test]", row_at)
row = tests[row_at:row_end]
old = "                edges: vec![],"
assert row.count(old) == 1
row = row.replace(
    old,
    "                edges: vec![crate::Visit { action: 13, visits: 63, prior: 1.0 }],",
)
tests = tests[:row_at] + row + tests[row_end:]
anchor = "    fn common_mcts_raw_requires_model_complete_visits_and_finite_head_without_z_mask() {\n"
assert tests.count(anchor) == 1
tests = tests.replace(
    anchor,
    anchor
    + """        assert_eq!(mcts_game_id("game-0").unwrap(), 0);
        assert_eq!(mcts_game_id("game-10").unwrap(), 10);
        for alias in ["game-00", "game-01", "game-+0", "game--0", "game- 0", "0"] {
            assert!(mcts_game_id(alias).is_err(), "{alias}");
        }
""",
)
POST.write_text(head + tests)
print(
    "two related boundaries prepared; frozen data-source-v2 and all other subjects unchanged"
)
