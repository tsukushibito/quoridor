"""Check only frozen arena metadata with the existing immutable caller functions."""

import ast
import hashlib
import json
import math
import os
import stat
import subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
COMMIT = "7e9537c6a095a869c12fdb97b728dc12da699ca2"
source = subprocess.run(
    ["git", "show", COMMIT + ":scripts/dev/research-lifecycle.py"],
    check=True,
    capture_output=True,
).stdout
source_ref = json.loads((OWN / "immutable-caller-ref.json").read_bytes())
assert (
    hashlib.sha256(source).hexdigest()
    == source_ref["sha256"]
    == "499724de67874b53756d13ff1cc51fabd4f7750dc12bfe38299d64eefa93b7eb"
)
tree = ast.parse(source)
names = {
    "Refused",
    "require",
    "sha",
    "bound",
    "read_ref",
    "document",
    "arena_model_check",
    "planned_game_slice",
    "arena_plan_check",
}
nodes = [
    n
    for n in tree.body
    if (isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in names)
    or (
        isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "CONTROL_BYTES" for t in n.targets)
    )
]
ns = dict(json=json, math=math, hashlib=hashlib, os=os, stat=stat, Path=Path)
exec(
    compile(
        ast.Module(body=nodes, type_ignores=[]),
        "immutable:" + COMMIT + ":scripts/dev/research-lifecycle.py",
        "exec",
    ),
    ns,
)


def read(path):
    return json.loads(path.read_bytes())


settings = read(OWN / "settings.json")
carrier = read(OWN / "arena-book.json")
source_preparation = read(
    Path(read(OWN / "carrier-provenance.json")["source_preparation"]["path"])
)
source_schedule = read(Path(source_preparation["files"]["schedule"]["path"]))
source_book = read(Path(source_preparation["files"]["prefix_book"]["path"]))
assert len(carrier["families"]) == 64
assert [f["id"] for f in carrier["families"]] == [
    o["id"] for o in source_book["openings"]
]
for f, s in zip(carrier["families"], source_schedule["scheduled"]):
    assert f["family_id"] == s["game"]
    assert f["prefix"] == s["prefix"]
    assert f["root_key"] == s["root"]["state_key"]
    assert f["history_counts"] == s["root"]["history"]
    accepted = [
        a
        for a in s["attempts"]
        if a["rejection"] is None and a["prefix"] == s["prefix"]
    ]
    assert len(accepted) == 1 and f["attempt_id"] == accepted[0]["attempt"]
    assert f["seed"] == source_schedule["prefix_seed"] == 42320261017

records = []
for operation in settings["operations"]:
    plan = ns["document"](operation["plan"])
    # Metadata-only projection used by this pure check; never serialized as an Experiment.
    projection = dict(
        phase="arena",
        argv=[
            settings["image"]["path"],
            "arena",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ],
        rules=plan["rules"],
        distance_units=plan["distance_units"],
        value_perspective=plan["value_perspective"],
        inputs=plan["inputs"],
        models=plan["models"],
        schedule=plan["schedule"],
        config=operation["config"],
        planned_slots=plan["planned_slots"],
        batch=0,
    )
    planned, config = ns["arena_plan_check"](projection, plan)
    assert len(planned) == operation["games"]
    assert (
        len({(s["family_id"], s["candidate_color"]) for s in planned})
        == operation["games"]
    )
    assert config["arena"]["max_total_nodes"] == operation["node_quota"]
    assert config["arena"]["bootstrap_seed"] == 42320261027
    assert config["seed"] == 42320261026
    assert config["arena"]["tt_entries"] == 1048576
    assert config["arena"]["return_reserve_ms"] == 5
    assert config["max_plies"] == 200
    for engine in config["engines"]:
        assert engine["ordering_profile"] == "control"
        assert engine["lmr"] is True and engine["lmr_method"] == "depth_rank"
        assert engine["max_nodes"] == 1000000 and engine["depth"] == 64
        assert engine["time_ms"] == 100
        assert engine["zero_stock_safe_race"] is False
        assert engine["zero_stock_approx_min_root_walls"] is None
    assert (
        operation["actual_Experiment"]
        is operation["actual_runtime"]
        is operation["actual_support"]
        is None
    )
    records.append(
        dict(
            name=operation["name"],
            pure_arena_plan_check="PASS",
            slots=len(planned),
            pairs=len(planned) // 2,
            family_ids=plan["family_ids"],
            node_quota=operation["node_quota"],
        )
    )
assert [r["slots"] for r in records] == [128, 32]
assert sum(r["node_quota"] for r in records) == 1000000000
assert records[1]["family_ids"] == records[0]["family_ids"][:16]
selected = read(OWN / "selectedrefs.json")
for ref in selected:
    assert ns["bound"](ref["path"])[0] == ref, ref["path"]
(OWN / "metadata-check.json").write_text(
    json.dumps(
        dict(
            status="PURE_SAVED_METADATA_CHECK_PASS",
            immutable_caller=source_ref,
            normal_functions_reused=sorted(names),
            operations=records,
            actual_Experiment_files_created=0,
            native_or_model_payload_reads=0,
            new_inputs_or_rules_replays_or_games_or_Search_or_bootstrap=0,
            before_after_selectedrefs_exact=len(selected),
            grant="metadata correspondence only; Root current caller/Experiment/forecast/admission remain pending",
        ),
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        dict(
            status="PASS",
            operations=[r["slots"] for r in records],
            original_attempt_ids=sorted({f["attempt_id"] for f in carrier["families"]}),
            selectedrefs_exact=len(selected),
            science_calls=0,
        )
    )
)
