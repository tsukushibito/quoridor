import difflib
import gzip
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parent
OUT = OWN / "native-source-v2"
OUT.mkdir()
TMP = Path(os.environ["TMPDIR"])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=sha(data),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + "\n")


subjects = []
forward = []
inverse = []
sources = {}
for name in ["config.rs", "runtime.rs"]:
    rel = "crates/quoridor-runner/src/" + name
    recovery = OWN / "before" / (rel + ".gz")
    before = gzip.decompress(recovery.read_bytes())
    post = OWN / "post" / rel
    after = post.read_bytes()
    sources[name] = (before.decode(), after.decode())
    target = TMP / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(before)
    subjects.append(
        dict(
            subject=rel,
            before_sha256=sha(before),
            before_bytes=len(before),
            recovery=ref(recovery),
            post=ref(post),
            new_absence="existing subject; no new production files",
        )
    )
    forward.extend(
        difflib.unified_diff(
            before.decode().splitlines(True),
            after.decode().splitlines(True),
            fromfile="a/" + rel,
            tofile="b/" + rel,
        )
    )
    inverse.extend(
        difflib.unified_diff(
            after.decode().splitlines(True),
            before.decode().splitlines(True),
            fromfile="a/" + rel,
            tofile="b/" + rel,
        )
    )
(OUT / "forward.patch").write_text("".join(forward))
(OUT / "inverse.patch").write_text("".join(inverse))
for patch, expected in [
    ("forward.patch", "post"),
    ("inverse.patch", "before_sha256"),
]:
    result = subprocess.run(
        ["patch", "--batch", "--fuzz=0", "-p1", "-d", str(TMP), "-i", str(OUT / patch)],
        capture_output=True,
        text=True,
        check=False,
    )
    (OUT / (patch + ".log")).write_text(result.stdout + result.stderr)
    assert result.returncode == 0
    for subject in subjects:
        expected_sha = (
            subject["post"]["sha256"] if expected == "post" else subject[expected]
        )
        assert sha((TMP / subject["subject"]).read_bytes()) == expected_sha
for subject in subjects:
    (TMP / subject["subject"]).unlink()
for path in sorted(TMP.rglob("*"), key=lambda p: len(p.parts), reverse=True):
    if path.is_dir():
        path.rmdir()


def function(text, name):
    start = re.search(r"(?m)^(?:pub(?:\([^)]*\))? )?fn " + name + r"\(", text)
    assert start, name
    # Function end is the next unindented closing brace. These named functions
    # are normal top-level bodies; this is only a byte protection comparison.
    end = re.search(r"(?m)^}", text[start.start() :])
    assert end
    return text[start.start() : start.start() + end.end()]


old, new = sources["runtime.rs"]
protected = []
for name in [
    "inference_work",
    "arena_alpha_namespace",
    "arena_alpha_session",
    "make_backend",
    "evaluator",
    "new_game",
    "guard",
    "finish",
    "commit_action",
    "worker",
    "deliver_inference",
]:
    a, b = function(old, name), function(new, name)
    assert a == b, name
    protected.append(dict(function=name, sha256=sha(a.encode()), bytes=len(a)))
old_planned = function(old, "planned")
new_planned = function(new, "planned")
suffix = old_planned[old_planned.index("    let (train, validation)") :]
assert new_planned.endswith(suffix)
protected.append(
    dict(function="planned original default branch", sha256=sha(suffix.encode()))
)
write(
    "static-proof.json",
    dict(
        strict_forward_inverse=True,
        protected_functions=protected,
        new_production_files=[],
        main_git_index_cargo_mutations=0,
        source_scope="two private runner subjects only",
        native_compile_tests_inference_search_games=0,
        tests="five new definitions UNBUILT/UNTYPED/UNRUN",
    ),
)
write(
    "source-binding.json",
    dict(
        issue="quoridor-4lc.423.3",
        base=json.loads((OWN / "base.json").read_text()),
        subjects=subjects,
        forward=ref(OUT / "forward.patch"),
        inverse=ref(OUT / "inverse.patch"),
        contract=json.loads((OWN / "contract-ref.json").read_text()),
        correction=json.loads((OWN / "size-correction-ref.json").read_text()),
        exact_spec="pending SAME423.1; no guessed seeds or future input/image/cache refs",
        required_software=[
            "common_mcts_config_tests::common_mcts_config_requires_one_greedy_bounded_cpu_ort_owner",
            "common_mcts_tests::common_mcts_row_quota_accounts_warm_failed_physical_unknown_and_overflow",
            "common_mcts_tests::common_mcts_requires_completed_visits_without_rewriting_raw_values",
            "common_mcts_tests::common_mcts_terminal_attachment_uses_goal_threefold_and_unknown_not_q",
            "common_mcts_tests::common_mcts_frozen_slice_keeps_global_ids_missing_slots_and_family_split",
        ],
        software_status="UNBUILT/UNTYPED/UNRUN; no source_clear or scientific success claim",
        later_scope="MCTS compact source acceptance; old-state bounded MCTS; arena settings. No new physical compact columns identified.",
        affected_usage="one final task-directed check pending; no advance ordinary storage budget",
    ),
)
print(
    json.dumps(
        dict(binding=ref(OUT / "source-binding.json"), patch=ref(OUT / "forward.patch"))
    )
)
