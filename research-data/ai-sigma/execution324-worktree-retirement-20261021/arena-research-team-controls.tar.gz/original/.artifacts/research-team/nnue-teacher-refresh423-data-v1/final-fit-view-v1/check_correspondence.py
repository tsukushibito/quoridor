import hashlib
import json
import stat
from pathlib import Path

OWN = Path(__file__).resolve().parent
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-teacher-refresh423-v1"
)
refs = []


def read(path, expected=None):
    path = Path(path)
    data = path.read_bytes()
    ref = dict(
        path=str(path.resolve()),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )
    if expected:
        for key in ("sha256", "bytes", "mode"):
            if key in expected:
                assert ref[key] == expected[key], (path, key)
    refs.append(ref)
    return json.loads(data)


suffix = read(BASE / "science-v1/suffix224-v1/entry-binding.json")
pilot_ref = next(r for r in suffix["refs"] if "pilot32-v1/entry-binding" in r["path"])
pilot = read(pilot_ref["path"], pilot_ref)
final = read(OWN / "final-view-config.json")
target_partition = read(final["partition"]["path"], final["partition"])
target_schedule = read(final["schedule"]["path"], final["schedule"])
target = {a["game"]: a for a in target_partition["assignments"]}
assert len(target) == len(target_partition["assignments"]) == 256
assert len(target_schedule["scheduled"]) == 256
changed = []
cursor = 0
source_counts = {}
target_counts = {}
slices = []
for slice_index, entry in enumerate(pilot["configs"] + suffix["configs"]):
    config = read(entry["config"]["path"], entry["config"])["common_study"]
    original_partition = read(config["partition"]["path"], config["partition"])
    original_schedule = read(config["schedule"]["path"], config["schedule"])
    assignments = {a["game"]: a for a in original_partition["assignments"]}
    assert len(assignments) == len(original_partition["assignments"])
    expected = dict(final)
    for key in ("families", "schedule", "partition", "batch_start", "batch_count"):
        expected[key] = config[key]
    assert config == expected
    assert config["batch_start"] == cursor
    ids = list(range(cursor, cursor + config["batch_count"]))
    assert entry["requested_ids"] == ids
    for global_id in ids:
        request = f"fixed-d-family-{global_id:06}"
        original, view = assignments[request], target[request]
        assert original["prefix"] == view["prefix"]
        assert original["family"] == view["family"]
        assert (
            original_schedule["scheduled"][global_id]
            == target_schedule["scheduled"][global_id]
        )
        for assignment, counts in ((original, source_counts), (view, target_counts)):
            counts[assignment["split"]] = counts.get(assignment["split"], 0) + 1
        if original["split"] != view["split"]:
            changed.append(
                dict(
                    global_id=global_id,
                    request_id=request,
                    family=original["family"],
                    prefix=original["prefix"],
                    source_split=original["split"],
                    view_split=view["split"],
                )
            )
    slices.append(
        dict(
            source_index=slice_index,
            config=entry["config"],
            batch_start=cursor,
            batch_count=len(ids),
        )
    )
    cursor += config["batch_count"]
assert cursor == 256
assert [r["global_id"] for r in changed] == [18]
assert (
    changed[0]["source_split"] == "validation" and changed[0]["view_split"] == "train"
)
# Verify each immutable selected reference again after the bounded metadata join.
for ref in refs:
    path = Path(ref["path"])
    assert hashlib.sha256(path.read_bytes()).hexdigest() == ref["sha256"]
    assert path.stat().st_size == ref["bytes"]
    assert f"{stat.S_IMODE(path.stat().st_mode):04o}" == ref["mode"]
(OWN / "correspondence-check.json").write_text(
    json.dumps(
        dict(
            status="STATIC_SAVED_INPUT_METADATA_EXACT",
            slots=cursor,
            sources=len(slices),
            original_source_splits=source_counts,
            final_view_splits=target_counts,
            changed=changed,
            slices=slices,
            original_rows_read=0,
            native_tests_run=0,
            chronology_and_outcome_admission="Root current native receiver required; metadata is not a chronology certificate",
        ),
        indent=2,
    )
    + "\n"
)
unique = {r["path"]: r for r in refs}
(OWN / "correspondence-selectedrefs.json").write_text(
    json.dumps(list(unique.values()), indent=2) + "\n"
)
fragment = {
    "final_fit_view": {
        "path": str((OWN / "final-view-config.json").resolve()),
        "sha256": hashlib.sha256(
            (OWN / "final-view-config.json").read_bytes()
        ).hexdigest(),
    }
}
(OWN / "input-binding-fragment.json").write_text(json.dumps(fragment, indent=2) + "\n")
print(
    json.dumps(
        dict(
            slots=cursor,
            sources=len(slices),
            original=source_counts,
            final=target_counts,
            changed=[r["global_id"] for r in changed],
        )
    )
)
