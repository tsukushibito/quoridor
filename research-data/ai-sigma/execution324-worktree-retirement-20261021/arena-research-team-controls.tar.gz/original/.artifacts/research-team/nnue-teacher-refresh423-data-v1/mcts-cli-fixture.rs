#[cfg(test)]
mod mcts_config_list_tests {
    use super::*;
    #[test]
    fn configured_mcts_converter_requires_bound_list_pair_and_preserves_source_order() {
        let mut argv = [
            "--input",
            "/b/dataset",
            "--input",
            "/a/dataset",
            "--output",
            "/fresh",
        ]
        .map(str::to_owned)
        .to_vec();
        assert!(parse(&argv).unwrap().mcts_configs.is_none());
        argv.extend(["--mcts-configs".into(), "/list.json".into()]);
        assert!(parse(&argv).is_err());
        argv.extend(["--mcts-configs-sha256".into(), "a".repeat(64)]);
        let args = parse(&argv).unwrap();
        assert_eq!(
            args.inputs,
            vec![PathBuf::from("/b/dataset"), PathBuf::from("/a/dataset")]
        );
        assert_eq!(args.mcts_configs.unwrap().path, PathBuf::from("/list.json"));
        argv.extend(["--mcts-configs".into(), "/different.json".into()]);
        assert!(parse(&argv).is_err());
    }
}
