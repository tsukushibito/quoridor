import difflib
import gzip
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parent
OUT = OWN / "native-repair-v1"
REL = "crates/quoridor-runner/src/runtime.rs"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=sha(data),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + "\n")


frozen = OWN / "native-source-v2/source-binding.json"
binding = json.loads(frozen.read_text())
for subject in binding["subjects"]:
    assert ref(Path(subject["post"]["path"])) == subject["post"]
before_path = OWN / "post" / REL
after_path = OUT / "post" / REL
before, after = before_path.read_bytes(), after_path.read_bytes()
(OUT / "before-runtime.rs.gz").write_bytes(gzip.compress(before, mtime=0))
tmp = Path(os.environ["TMPDIR"])
target = tmp / REL
target.parent.mkdir(parents=True)
target.write_bytes(before)
for name, a, b in [("forward.patch", before, after), ("inverse.patch", after, before)]:
    patch = "".join(
        difflib.unified_diff(
            a.decode().splitlines(True),
            b.decode().splitlines(True),
            fromfile="a/" + REL,
            tofile="b/" + REL,
        )
    )
    (OUT / name).write_text(patch)
    result = subprocess.run(
        ["patch", "--batch", "--fuzz=0", "-p1", "-d", str(tmp), "-i", str(OUT / name)],
        capture_output=True,
        text=True,
        check=False,
    )
    (OUT / (name + ".log")).write_text(result.stdout + result.stderr)
    assert result.returncode == 0 and target.read_bytes() == b
target.unlink()
for p in sorted(tmp.rglob("*"), key=lambda p: len(p.parts), reverse=True):
    if p.is_dir():
        p.rmdir()


def function(s, name):
    start = re.search(r"(?m)^(?:pub(?:\([^)]*\))? )?fn " + name + r"\(", s)
    assert start, name
    end = re.search(r"(?m)^}", s[start.start() :])
    assert end
    return s[start.start() : start.start() + end.end()]


old, new = before.decode(), after.decode()
protected = []
for name in [
    "inference_work",
    "arena_alpha_namespace",
    "arena_alpha_session",
    "make_backend",
    "evaluator",
    "new_game",
    "guard",
    "finish",
    "commit_action",
    "worker",
    "deliver_inference",
    "planned",
    "run",
    "run_owned",
    "run_inner",
    "attach_primary_failure",
    "record_publication_failure",
    "admit_mcts_rows",
    "attach_common_mcts_outcome",
]:
    a, b = function(old, name), function(new, name)
    assert a == b, name
    protected.append(dict(function=name, sha256=sha(a.encode()), bytes=len(a.encode())))
assert new.index("supplied backend refused before admission") < new.index(
    "run_owned(config, mode, Some(backend))"
)
assert new.count("mod common_mcts_admission_cause_tests") == 1
write(
    "static-proof.json",
    dict(
        strict_forward_inverse=True,
        protected_functions=protected,
        modified_production_bodies=[
            "run_with_backend",
            "CompletionPublication::record",
        ],
        new_production_files=[],
        frozen_v2_exact=True,
        new_tests=2,
        software="UNBUILT/UNTYPED/UNRUN",
        Main_Git_Cargo_native_models_Search_games=0,
    ),
)
write(
    "source-binding.json",
    dict(
        issue="quoridor-4lc.423.3",
        phase="R1/C1 related repair only",
        original_v2_binding=ref(frozen),
        original_review_report=dict(
            path="/workspaces/quoridor/.worktree/learning-million/.artifacts/research-team/nnue-teacher-refresh423-review-v1/review.md",
            sha256="51977dec4fd1de3716c1c3c3c93ba5b2b4055d9558c7af0936fc68c4e0f7ec53",
        ),
        subject=REL,
        before=ref(before_path),
        recovery=ref(OUT / "before-runtime.rs.gz"),
        post=ref(after_path),
        forward=ref(OUT / "forward.patch"),
        inverse=ref(OUT / "inverse.patch"),
        proof=ref(OUT / "static-proof.json"),
        required_software=[
            "common_mcts_admission_cause_tests::common_mcts_supplied_backend_refused_before_metadata_inputs_or_admission",
            "common_mcts_admission_cause_tests::common_mcts_secondary_terminal_failure_keeps_cancelled_outcome_and_publication_detail",
        ],
        software="UNBUILT/UNTYPED/UNRUN",
        source_clear="pending SAME reviewer; author does not certify",
        usage="one final directed OWN check pending",
    ),
)
print(
    json.dumps(
        dict(binding=ref(OUT / "source-binding.json"), patch=ref(OUT / "forward.patch"))
    )
)
