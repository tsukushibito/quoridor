import datetime
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent


def ref(path):
    b = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o7777:04o}",
    )


selected = []
packets = []
for name in [
    "native-source-v2",
    "native-repair-v1",
    "native-repair-v2",
    "data-source-v2",
    "old-q-source-v3",
    "input-source-v1",
]:
    path = OWN / name / "source-binding.json"
    before = ref(path)
    binding = json.loads(path.read_bytes())
    assert ref(path) == before
    selected.append(before)
    subjects = binding.get("subjects", [dict(post=binding.get("post"))])
    for subject in subjects:
        expected = subject["post"]
        assert ref(Path(expected["path"])) == expected
        selected.append(expected)
    for key in ["forward", "inverse", "proof"]:
        if key in binding:
            expected = binding[key]
            assert ref(Path(expected["path"])) == expected
            selected.append(expected)
    packets.append(before)
for path in sorted((OWN / "fixed-drafts-v1").glob("*.json")):
    before = ref(path)
    json.loads(path.read_bytes())
    assert ref(path) == before
    selected.append(before)
for r in json.loads((OWN / "fixed-drafts-v1/selectedrefs.json").read_text())[
    "before_parse_and_after_exact"
]:
    assert ref(Path(r["path"])) == r
    selected.append(r)
for r in selected:
    assert ref(Path(r["path"])) == r
result = dict(
    issue="quoridor-4lc.423.3",
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    all_selected_exact=selected,
    packets=packets,
    private_subjects_after_native_repair=7,
    original_native_v2_unchanged=True,
    source_syntax_and_arithmetic_only=True,
    new_definition_total=12,
    software="UNBUILT/UNTYPED/UNRUN",
    native_compile_tests_models_geometry_Search_games_forward=0,
    future_refs="null, no submitted config/image/Experiment",
)
(OWN / "final-validation-v2.json").write_text(json.dumps(result, indent=2) + "\n")
# One directed OWN walk. It measures retained holdings, not a new-growth delta.
# The final STOP/completion/delivery bookkeeping is written afterward and is
# explicitly outside this observation; no global/assets/target walk or refund.
files = [p for p in OWN.rglob("*") if p.is_file() and not p.is_symlink()]
usage = dict(
    at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope=str(OWN),
    regular_files=len(files),
    bytes=sum(p.stat().st_size for p in files),
    allocated_bytes=sum(p.stat().st_blocks * 512 for p in files),
    meaning="directed retained OWN holdings, includes frozen/preliminary/errors; not all newly allocated this repair and not global actual",
    excludes="later final STOP/completion/delivery bookkeeping; no outside assets/shared target/RAW/model scan",
    global_actual="UNKNOWN",
    prior_budgets="ordinary no advance reservation; Root retains whole128MiB science/global decimal50GB accounting; no decrease refund",
)
(OWN / "usage-v2.json").write_text(json.dumps(usage, indent=2) + "\n")
print(json.dumps(dict(validation=ref(OWN / "final-validation-v2.json"), usage=usage)))
