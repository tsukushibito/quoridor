#[cfg(test)]
mod common_mcts_config_tests {
    use super::*;
    #[test]
    fn common_mcts_config_requires_one_greedy_bounded_cpu_ort_owner() {
        let mut c: Config =
            serde_json::from_str(include_str!("../tests/fixtures/sigma-clock-config.json"))
                .unwrap();
        c.ruleset = Ruleset::Standard2pThreefold;
        c.arena = None;
        c.cycle = None;
        c.engines = vec![serde_json::from_value(serde_json::json!({"kind":"mcts"})).unwrap()];
        c.workers = 1;
        c.active_games = 1;
        c.max_batch = 1;
        c.cpu_cores = vec![8];
        c.management_cpu_core = None;
        c.inference_cpu_core = None;
        c.temperature = 0.0;
        c.openings.clear();
        c.train_games = None;
        c.validation_games = None;
        c.inference = Some(
            serde_json::from_value(serde_json::json!({"backend":"ort",
            "model":"/fixture/model.onnx","model_sha":"a".repeat(64),"library":"/fixture/lib.so",
            "device":0,"cuda_graph":false,"logical_row_limit":60}))
            .unwrap(),
        );
        c.common_study = Some(
            serde_json::from_value(serde_json::json!({
            "families":3,"prefix_seed":29,"prefix_lengths":[4],"split_seed":31,
            "root_value_policy":"outcome_only","batch_start":1,"batch_count":2,"excluded_books":[],
            "schedule":{"path":"/fixture/schedule","sha256":"a".repeat(64)},
            "partition":{"path":"/fixture/partition","sha256":"b".repeat(64)}}))
            .unwrap(),
        );
        c.validate().unwrap(); // Shape only; this test never loads a backend or input file.
        for case in 0..9 {
            let mut bad = c.clone();
            match case {
                0 => bad.workers = 2,
                1 => bad.max_batch = 2,
                2 => bad.temperature = 0.5,
                3 => bad.cpu_cores.push(9),
                4 => bad.inference.as_mut().unwrap().logical_row_limit = None,
                5 => bad.inference.as_mut().unwrap().logical_row_limit = Some(0),
                6 => bad.inference.as_mut().unwrap().cuda_graph = true,
                7 => bad.train_games = Some(1),
                _ => bad.inference.as_mut().unwrap().backend = "aoti".into(),
            }
            assert!(bad.validate().is_err(), "case {case}");
        }
        c.common_study = None;
        assert!(c.validate().is_err()); // No accidental unbounded/general MCTS quota mode.
    }
}
