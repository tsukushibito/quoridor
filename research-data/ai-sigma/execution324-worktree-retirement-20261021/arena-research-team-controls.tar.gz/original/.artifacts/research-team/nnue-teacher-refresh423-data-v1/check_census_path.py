import json
from pathlib import Path

OWN = Path(__file__).resolve().parent
REL = "post/crates/quoridor-runner/src/runtime.rs"
before = (OWN / "native-repair-v1" / REL).read_text()
after = (OWN / "native-repair-v2" / REL).read_text()


def function(source, name):
    start = source.index("fn " + name + "(")
    start = source.rfind("\n", 0, start) + 1
    end = source.index("\n}", start) + 2
    return source[start:end]


old = """        if let Some(reason) = &stopped {
            for o in &mut outcomes {
                attach_primary_failure(o, reason);
            }
        }"""
new = "        attach_final_primary_failures(config, &pump, &mut outcomes, stopped.as_deref());"
assert function(before, "run_inner").replace(old, new) == function(after, "run_inner")
assert function(before, "run_with_backend") == function(after, "run_with_backend")
assert function(before, "attach_primary_failure") == function(
    after, "attach_primary_failure"
)
assert after.count("attach_final_primary_failures(") == 3
proof = dict(
    run_inner_only_final_loop_extracted=True,
    same_final_function_called_by_production_and_fixture=True,
    R1_body_exact=True,
    old_noncommon_single_attribution_helper_exact=True,
    new_public_API_schema_framework=False,
    software="UNBUILT/UNTYPED/UNRUN",
)
(OWN / "native-repair-v2/census-path-proof.json").write_text(
    json.dumps(proof, indent=2) + "\n"
)
print(proof)
