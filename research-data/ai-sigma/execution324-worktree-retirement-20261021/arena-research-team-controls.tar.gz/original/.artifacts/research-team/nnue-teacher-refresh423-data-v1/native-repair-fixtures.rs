#[cfg(test)]
mod common_mcts_admission_cause_tests {
    use super::*;

    fn config() -> Config {
        let mut c: Config =
            serde_json::from_str(include_str!("../tests/fixtures/sigma-clock-config.json"))
                .unwrap();
        c.common_study = Some(
            serde_json::from_value(serde_json::json!({"families":1,
            "prefix_seed":1,"prefix_lengths":[4],"split_seed":2,"root_value_policy":"outcome_only",
            "batch_start":0,"batch_count":1,"excluded_books":[],
            "schedule":{"path":"/unread/schedule","sha256":"a".repeat(64)},
            "partition":{"path":"/unread/partition","sha256":"b".repeat(64)}}))
            .unwrap(),
        );
        c
    }

    #[test]
    fn common_mcts_supplied_backend_refused_before_metadata_inputs_or_admission() {
        struct MustNotEnter;
        impl InferenceBackend for MustNotEnter {
            fn infer(
                &mut self,
                _: &[[f32; 648]],
            ) -> std::result::Result<Vec<NetworkOutput>, quoridor_inference::InferenceError>
            {
                panic!("supplied inference must not be entered");
            }
            fn metadata(&self) -> &quoridor_inference::BackendMetadata {
                panic!("supplied metadata must not be accepted as owner authority");
            }
        }
        let mut c = config();
        c.output =
            std::env::temp_dir().join(format!("common-supplied-refusal-{}", std::process::id()));
        assert!(!c.output.exists());
        let error = run_with_backend(&c, "selfplay", Box::new(MustNotEnter)).unwrap_err();
        assert!(
            error
                .to_string()
                .contains("supplied backend refused before admission")
        );
        assert!(!c.output.exists());
    }

    #[test]
    fn common_mcts_secondary_terminal_failure_keeps_cancelled_outcome_and_publication_detail() {
        let c = config();
        let plan = Planned {
            id: 0,
            candidate_color: 0,
            opening: vec![],
            family: "family".into(),
            split: Split::Train,
        };
        let mut o = unknown(&plan, "cancelled".into());
        o.moves = vec![13, 75, 22, 66, 31, 57, 40, 48, 49, 39, 58, 30, 67, 21, 76];
        o.failure = Some(crate::arena_clock::Failure::Cancelled);
        let context = SigmaContext::from_prefix(&[]).unwrap();
        let row = TeacherRow::from_context(
            "row".into(),
            "game-0".into(),
            "family".into(),
            Split::Train,
            vec![],
            &context,
            Some(13),
            Teacher::Mcts {
                root_mean: 0.0,
                root_nn: Some(0.0),
                root_visits: 64,
                nn_calls: 1,
                edges: vec![],
            },
            "a".repeat(64),
        )
        .unwrap();
        let mut pump = PumpProfile::default();
        let mut stopped = Some("earlier_backend_failure".to_owned());
        let cancel = AtomicBool::new(false);
        let mut dataset_writer = None;
        let mut row_count = 0;
        let mut outcomes = Vec::new();
        CompletionPublication {
            config: &c,
            mode: "selfplay",
            pump: &mut pump,
            stopped: &mut stopped,
            cancel: &cancel,
            dataset_writer: &mut dataset_writer,
            row_count: &mut row_count,
            outcomes: &mut outcomes,
            start: Instant::now(),
        }
        .record(o, vec![row]);
        assert_eq!(outcomes[0].reason.as_deref(), Some("cancelled"));
        assert_eq!(
            outcomes[0].failure,
            Some(crate::arena_clock::Failure::Cancelled)
        );
        assert_eq!(stopped.as_deref(), Some("earlier_backend_failure"));
        assert_eq!(pump.publication_failures.len(), 1);
        assert!(
            pump.publication_failures[0]
                .reason
                .starts_with("terminal_targets:")
        );
        assert_eq!(row_count, 0);
        assert!(cancel.load(Ordering::Relaxed));
    }
}
