# 393：保存した下降接続による距離差分候補（固定Source）

393の一候補として、各playerの最短経路の下降方向を4本のu128で保存し、共通のWallEdgesも保存する方式を実装した。現段階はMain64541a6の対象bytesに対する固定した私有patchであり、Mainへの適用、Rust型検査、nativeテスト、実測は未実施。392の実BUILDのSTOP通知後、fresh physical/quiet/canonical EXNB/environment SHの下で対象を取り込み、対象限定Rustfmtとcheck、GNU patchの逆向き・順向き適用による全before/postimage byte照合と新file不在を確認した。先のcanonical EXNB拒否は原記録513fとして保持する。

## 保存を含む費用比較

| 方式 | 追加情報本体 | 作成・更新・copyの仕事 | 主な限界 |
|---|---:|---|---|
| 距離から下降接続を都度導出 | 0B | 変更edgeの周囲と旧DAGの依存元について隣接距離・開通edgeを再判定。壁edgeの生成も必要 | 保存の初期費用を省くが、依存伝播時の判定を繰り返す |
| u8で4bit/cell | 162B | BFS層で保存できる。cell単位でsupportを消し、依存元を検査。162要素の保存・copy | cellごとの処理。4方向の集合演算を直接使えない |
| 4×u128/player | 128B | BFSの隣接層から4方向を作成。伝播frontierに対しshift/ANDで依存元と残存supportを処理。8本のu128をcopy | WallEdgesを壁一覧から作る仕事は残る |
| 上記＋WallEdges | 160B | 上記に加えてsouth/eastの2本をcopy。一枚追加では既存with_wallで2segmentをORし、壁一覧再走査を省く | full作成時の方向mask生成、保持・cloneの追加費用がある |

選んだのは最後の方式。現在のNNUEのimmutable wall cacheとbit-frontier BFSに直接つなげられ、一枚追加で壁一覧の生成と旧DAG依存元のcell別探索を置換できるためである。情報本体160Bには既存のwall key・距離表、struct padding、Arc header、allocation、stackを含めていない。実sizeof/align、copy費用、hit率、BFS回避回数、CPU利益はUNKNOWN。byte数だけで速度を認定しない。

parent-afterとchild-afterの既存exact hitではArc共有を優先し、候補の生成・copy自体を実行しない。新wall keyでは、距離が同じrowでも塞いだ下降edgeを消した新geometryを作る。Dの通常距離計算へNNUE cacheの利益を転用しない。

## 更新の厳密性と境界

WallDistanceGeometryのfieldをprivateにし、真正なwall keyとcanonical BFSからだけ初期化する。public mutable Featuresや外部の生距離配列をtrusted parentにしない。NNUEではafterに一致するparent、afterに一致する再利用child、beforeに一致する真正parentの順を維持する。stale childはtrue parentにならず、非一枚追加はcanonical経路へ戻る。

一枚H/V追加の両segmentを同時に消し、正距離のcellが全下降supportを失ったときだけmarkする。goal0とunreachable81には下降supportがない。旧距離が厳密に減るDAGの依存元をbit集合で伝播し、代替supportが残れば止める。

markedが40cellを超えたrowは同じcanonical BFSを使用する、という事前固定の一条件を置いた。部分修復には81本のu128 bucket初期化と各marked cellの境界・下降接続検査があるため、半盤超ではfull bit-frontier処理を選ぶという静的判断である。40は測定済みの交差点ではなく、探索・調整した値でもない。

部分修復ではunmarkedの確定距離を境界とし、異なるseed距離を最小距離bucketから順に取り出す。unordered FIFOや古い距離の反復緩和は使わない。修復したmarked cellだけで下降接続を生成する。canonical full構築でも既存BFSの隣接層から方向maskを同時に作り、距離完成後の追加81cell走査を置かない。

unmarkedからmarkedへの旧下降edgeは失効伝播で消える。markedの旧最短経路がすべて失われた以上、修復後の有限距離は旧距離より大きい。壁削除はないのでunmarked距離は減らず、修復後にunmarkedからmarkedへの新しい下降edgeは生じない。この境界接続の理由を、独立queue距離と全方向maskの照合対象にする。

FTの加算順序、feature ID/コピー、モデル同一性、shape・finite・遷移・legal validation、一般Features経路、parent restorationは変更対象外。失敗で途中まで書かれたchildは評価せず、正常な次回呼出しで全体を上書きする。cacheの存在はaccumulatorの正当性を証明しない。

## 変更と必要な検証

現役のNNUE callerをopaque geometryへ移し、不要になる生距離をtrusted parentとして渡す旧内部経路を撤去する。core libの変更は新型のexportと既存独立queue oracleをprivate unit testから使うcfg(test) self-crate aliasだけ。core/NNUE以外、392のAI/runner/data/publisherには変更しない。

新private core5、旧APIの機械的なowning test移行3、NNUE private map境界の移行1とtoy FT/error/undo2、合計11定義を選ぶ。期待値は既存の独立cell queue、実open edgeと比較する。二edge同時作用、alternate、異なる境界seed、両row変化、goal/border/unreachable、広域fallback、削除/置換/multi拒否、親不変、stale key、general feature、数値途中失敗・foreign model拒否・undo後の上書きを対象とする。公開モデル、head、実Search、以前の成功suiteは実行しない。

before/postimage refsと原before gzipはsource-preparation-v1/result.jsonが束縛する。実source reader STOPは08:27:40.464224Z、caller/environment reader STOPは08:27:40.574455Z、canonical releaseは08:27:40.577248Z。すべて2026-10-14。各commandのreturned guardianとpersisted process receiptは別々に保存し、directreap/handles/cleanup/fullcaptureを確認した。親helperと全formatter/patch childのfresh exact identity不在、temporary source/TMP撤去、owned[]はhandoff STOPで確認する。native定義はすべてUNBUILT/UNTYPED/UNRUN。Rootの限定確認はsupport invariant、marked修復・境界、private key lineage、error/model所有だけで足りる。

実測はRootの既存ONNO24入口で、392の実timing STOP後にのみ行う。作成・copy・更新・setup/dropを含むwhole費用と同一結果を評価し、不支持なら候補だけ戻す。一般最適性、棋力、defaultの変更は本候補から主張しない。Mixed342.17および323のUSERPAUSE、旧RAW/FAILED/費用/UNKNOWNを維持する。


source controller wholeは1.164587492999999sを一度だけ数える。内側formatter/patchのwallを加算しない。continuous family RAM peak、child worker UTC STOPはUNKNOWN（directwaitとsource reader STOPは実記録）。検証計画はverification-plan.json、固定patchはdistance-map-delta393.patch。compiler/testのPASSを意味しない。
