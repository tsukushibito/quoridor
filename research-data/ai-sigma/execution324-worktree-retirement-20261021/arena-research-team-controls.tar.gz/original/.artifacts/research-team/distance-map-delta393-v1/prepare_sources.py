"""Current Main scoped source transforms, formatting, and exact patch roundtrip."""

import difflib
import gzip
import importlib.util
import json
import os
import re
import resource
import shutil
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (448 * 1024**2, 448 * 1024**2))
MAIN = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
OUT = OWN / "source-preparation-v1"
loader = importlib.util.spec_from_file_location(
    "lc", MAIN / "scripts/dev/research-lifecycle.py"
)
lc = importlib.util.module_from_spec(loader)
loader.loader.exec_module(lc)


def ref(path):
    return lc.bound(path, 128 * 1024**2)[0]


def replace_once(text, before, after):
    lc.require(text.count(before) == 1, "one exact owning source anchor")
    return text.replace(before, after, 1)


root_refs = ref(
    MAIN
    / ".artifacts/research-team/integration324/distance-map-delta393-v1/current-source-refs.json"
)
subjects = lc.document(root_refs)
bindings = {
    r["relative"]: {k: r[k] for k in ("path", "sha256", "bytes", "mode")}
    for r in subjects["refs"]
}
paths = [
    "crates/quoridor-core/src/position.rs",
    "crates/quoridor-core/src/lib.rs",
    "crates/quoridor-core/tests/wall_map391.rs",
    "crates/quoridor-nnue/src/features.rs",
    "crates/quoridor-nnue/src/lib.rs",
]
before = {}
for path in paths:
    lc.require(
        path not in subjects["actual392_source_paths"], "disjoint actual392 source"
    )
    binding = bindings.get(path) or ref(MAIN / path)
    before[path] = lc.read_ref(binding).decode()
    bindings[path] = binding
lc.read_ref(bindings["crates/quoridor-core/tests/support/queue_reference.rs"])
new_paths = {
    "crates/quoridor-core/src/distance_geometry.rs": "distance_geometry.rs",
    "crates/quoridor-core/src/distance_geometry_tests.rs": "distance_geometry_tests.rs",
    "crates/quoridor-nnue/src/distance_delta393_tests.rs": "distance_delta393_tests.rs",
}
for path in new_paths:
    lc.require(not os.path.lexists(MAIN / path), "actual new Main subject absent")
post = dict(before)
path = paths[0]
text = replace_once(
    post[path],
    "use std::fmt;\n",
    'use std::fmt;\n\n#[path = "distance_geometry.rs"]\nmod distance_geometry;\npub use distance_geometry::WallDistanceGeometry;\n',
)
start = text.index(
    "    /// Reuse exact parent rows after strictly one H/V wall-bit addition."
)
end = text.index("    pub fn legal_pawn_mask", start)
text = (
    text[:start]
    + """    /// Immutable wall-keyed distances and shortest-path descents for cached callers.
    /// Unlike checked(), this constructs wall-only geometry, not game validity.
    pub fn wall_distance_geometry(self) -> WallDistanceGeometry {
        WallDistanceGeometry::of(self)
    }
"""
    + text[end:]
)
text = replace_once(
    text,
    "#[derive(Clone, Copy)]\nstruct WallEdges",
    "#[derive(Clone, Copy, Debug, PartialEq, Eq)]\nstruct WallEdges",
)
start = text.index("    fn retains_distances(")
end = text.index("    fn with_wall(", start)
text = text[:start] + text[end:]
start = text.index(
    "    // One reverse BFS implementation for both full rebuild and changed rows."
)
end = text.index("    fn with_wall(", start)
text = (
    text[:start]
    + """    // One reverse BFS implementation; plain callers need no saved descent data.
    fn distance_map(&self, player: usize) -> [u8; 81] {
        self.distance_map_with_descent(player, None)
    }
    fn distance_map_with_descent(
        &self,
        player: usize,
        mut descent: Option<&mut [u128; 4]>,
    ) -> [u8; 81] {
        if let Some(links) = descent.as_deref_mut() {
            *links = [0; 4];
        }
        let mut result = [81u8; 81];
        let mut frontier = if player == 0 { 0x1ffu128 << 72 } else { 0x1ff };
        let mut previous = 0;
        let mut reached = frontier;
        let mut distance = 0;
        while frontier != 0 {
            if let Some(links) = descent.as_deref_mut() {
                // Only adjacent BFS layers can be shortest-path descents.
                links[0] |= frontier & ((previous & !self.south) << 9);
                links[1] |= frontier & (previous >> 9) & !self.south;
                links[2] |= frontier & (previous >> 1) & !self.east & !WALL_COL8;
                links[3] |= frontier & ((previous & !self.east & !WALL_COL8) << 1);
            }
            let mut cells = frontier;
            while cells != 0 {
                result[cells.trailing_zeros() as usize] = distance;
                cells &= cells - 1;
            }
            previous = frontier;
            frontier = self.expand(frontier) & !reached;
            reached |= frontier;
            distance += 1;
        }
        result
    }
"""
    + text[end:]
)
old_const = """        const COL8: u128 = (1u128 << 8)
            | (1u128 << 17)
            | (1u128 << 26)
            | (1u128 << 35)
            | (1u128 << 44)
            | (1u128 << 53)
            | (1u128 << 62)
            | (1u128 << 71)
            | (1u128 << 80);
"""
text = replace_once(text, old_const, "")
text = text.replace("!COL8", "!WALL_COL8")
constant = old_const.replace("        const COL8", "const WALL_COL8").replace(
    "            |", "    |"
)
text = replace_once(
    text,
    "/// Source cells of blocked south/east edges;",
    constant + "\n/// Source cells of blocked south/east edges;",
)
post[path] = text
post[paths[1]] = replace_once(
    post[paths[1]],
    "pub use position::{Action, Position, RULESET_ID, RulesError};",
    "pub use position::{Action, Position, RULESET_ID, RulesError, WallDistanceGeometry};\n\n// Reuse the existing independent integration-test queue oracle in private tests.\n#[cfg(test)]\nextern crate self as quoridor_core;",
)
path = paths[2]
text = re.sub(
    r"(\w+)\s*\.wall_distance_maps_after_addition\((\w+), &(\w+)\)",
    lambda m: f"{m[2]}.wall_distance_geometry().after_addition({m[1]}).map(|geometry| *geometry.distances())",
    post[path],
)
lc.require(
    "wall_distance_maps_after_addition" not in text,
    "all owning old API test callers migrated",
)
text = text.replace("fn wall391_", "fn wall393_adapted_")
strict = text.index("fn wall393_adapted_strict_addition")
text = text[:strict] + text[strict:].replace(
    "    let old = parent.wall_distance_maps();\n", "", 1
)
post[path] = text
path = paths[3]
text = replace_once(
    post[path],
    "use quoridor_core::Position;",
    "use quoridor_core::{Position, WallDistanceGeometry};",
)
text = replace_once(
    text,
    """    horizontal: u64,
    vertical: u64,
    distances: [[u8; 81]; 2],
""",
    "    geometry: WallDistanceGeometry,\n",
)
text = replace_once(
    text,
    """        (self.horizontal == p.horizontal && self.vertical == p.vertical).then_some(&self.distances)""",
    "        self.geometry.distances_for(p)",
)
start = text.index("    let distances = parent\n")
end = text.index("\n}\n\nfn distance(", start)
text = (
    text[:start]
    + """    let geometry = parent
        .filter(|(before, maps)| maps.distances_for(*before).is_some())
        .and_then(|(_, maps)| maps.geometry.after_addition(p))
        .unwrap_or_else(|| p.wall_distance_geometry());
    Arc::new(WallMaps { geometry })"""
    + text[end:]
)
text = replace_once(
    text,
    """    if maps.horizontal != p.horizontal || maps.vertical != p.vertical {
        return Err(Error::Input("integer distance wall-map mismatch".into()));
    }
""",
    """    let rows = maps.distances_for(p)
        .ok_or_else(|| Error::Input("integer distance wall-map mismatch".into()))?;
""",
)
text = text.replace("maps.distances[player]", "maps.geometry.distances()[player]")
text = text.replace("maps.distances[side]", "rows[side]").replace(
    "maps.distances[side ^ 1]", "rows[side ^ 1]"
)
text = text.replace(
    "fresh.distances, parent.distances",
    "fresh.geometry.distances(), parent.geometry.distances()",
)
text = text.replace(
    "miss.distances, after.wall_distance_maps()",
    "*miss.geometry.distances(), after.wall_distance_maps()",
)
text = text.replace(
    "maps.distances, other.wall_distance_maps()",
    "*maps.geometry.distances(), other.wall_distance_maps()",
)
text = text.replace("fn wall391_private_", "fn wall393_private_")
post[path] = text
post[paths[4]] += (
    '\n#[cfg(all(test, feature = "research"))]\nmod distance_delta393_tests;\n'
)
for path, name in new_paths.items():
    post[path] = (OWN / name).read_text()
OUT.mkdir()
temporary = OUT / "temporary-edited-subjects"
temporary.mkdir()
reconstruction = OWN / "before"
reconstruction.mkdir()
for path, text in before.items():
    target = reconstruction / (path.replace("/", "__") + ".gz")
    with target.open("xb") as output:
        output.write(gzip.compress(text.encode(), mtime=0))
for path, text in post.items():
    target = temporary / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(text)
spec = {
    "kind": "software",
    "cwd": str(MAIN),
    "env": dict(os.environ),
    "limits": {
        "family_B": 384 * 1024**2,
        "controller_B": 64 * 1024**2,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 5,
        "guardian_cpu": 6,
        "log_B": 128 * 1024,
    },
}
resources = lc.process.CycleResources(
    {"host_ram_reserve": 4 * 1024**3, "max_memory_bytes": 320 * 1024**2}, OUT, None
)
checks = []
rustfmt = shutil.which("rustfmt")
lc.require(rustfmt is not None, "current existing formatter")
formatter = ref(Path(rustfmt).resolve())
patch_tool = ref(Path("/usr/bin/patch"))


def command(name, argv):
    lc.command(
        spec,
        {"name": name, "role": "source", "argv": argv},
        OUT,
        resources,
        ledger=checks,
    )


try:
    command(
        "rustfmt",
        [
            rustfmt,
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            *[str(temporary / p) for p in post],
        ],
    )
    command(
        "rustfmt-check",
        [
            rustfmt,
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            "--check",
            *[str(temporary / p) for p in post],
        ],
    )
    formatted = {p: (temporary / p).read_text() for p in post}
    patch = "".join(
        "".join(
            difflib.unified_diff(
                before.get(p, "").splitlines(True),
                formatted[p].splitlines(True),
                fromfile="a/" + p if p in before else "/dev/null",
                tofile="b/" + p,
            )
        )
        for p in post
    )
    patch_path = OWN / "distance-map-delta393.patch"
    patch_path.write_text(patch)
    post_refs = [
        {
            "logical_Main_path": str(MAIN / p),
            **{k: v for k, v in ref(temporary / p).items() if k != "path"},
        }
        for p in post
    ]
    command(
        "exact-inverse",
        [
            "/usr/bin/patch",
            "--batch",
            "--reverse",
            "--no-backup-if-mismatch",
            "-p1",
            "-d",
            str(temporary),
            "-i",
            str(patch_path),
        ],
    )
    for path, text in before.items():
        lc.require(
            (temporary / path).read_bytes() == text.encode(),
            "full inverse original bytes",
        )
    lc.require(
        all(not (temporary / p).exists() for p in new_paths),
        "inverse restores new path absence",
    )
    command(
        "exact-forward",
        [
            "/usr/bin/patch",
            "--batch",
            "--forward",
            "--no-backup-if-mismatch",
            "-p1",
            "-d",
            str(temporary),
            "-i",
            str(patch_path),
        ],
    )
    for path, text in formatted.items():
        lc.require(
            (temporary / path).read_bytes() == text.encode(),
            "full forward formatted bytes",
        )
    for path in paths:
        lc.read_ref(bindings[path])
    lc.read_ref(root_refs)
    lc.read_ref(formatter, formatter["bytes"])
    lc.read_ref(patch_tool)
    facts = {
        "issue": "quoridor-4lc.393.1",
        "root_source_refs": root_refs,
        "Main_before_after": [bindings[p] for p in paths],
        "independent_reference_readonly": bindings[
            "crates/quoridor-core/tests/support/queue_reference.rs"
        ],
        "new_Main_paths_absent": list(new_paths),
        "temporary_formatted_postimages": post_refs,
        "reconstruction": [
            ref(reconstruction / (p.replace("/", "__") + ".gz")) for p in before
        ],
        "patch": ref(patch_path),
        "formatter": formatter,
        "patch_tool": patch_tool,
        "checks": checks,
        "exact_forward_inverse_bytes_and_new_absence": True,
        "selected_candidate": "saved two-player four-u128 descents plus32B WallEdges; private opaque genuine wall-key geometry",
        "native_type_tests_sizeof_alignment_callcount": "UNBUILT/UNTYPED/UNRUN",
        "model_Search_game_Perf_fit_build_calls": 0,
        "mixed342_17": "USERPAUSE unchanged",
        "storage_budget": None,
    }
finally:
    # Exact files created above only. Unknown leftovers refuse recursive removal.
    for path in post:
        target = temporary / path
        if target.exists():
            target.unlink()
    for directory in sorted(
        [p for p in temporary.rglob("*") if p.is_dir()],
        key=lambda p: len(p.parts),
        reverse=True,
    ):
        directory.rmdir()
    temporary.rmdir()
facts["actual_source_reader_writer_STOP"] = lc.stamp()
facts["temporary_source_remaining"] = []
lc.new_json(OUT / "result.json", facts)
print(json.dumps({"result": ref(OUT / "result.json"), "patch": facts["patch"]}))
