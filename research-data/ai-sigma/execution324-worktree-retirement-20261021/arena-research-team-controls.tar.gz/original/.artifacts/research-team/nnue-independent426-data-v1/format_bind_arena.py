"""Format only the new426 drafts and rebind their existing FileRefs."""

import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parent
OUT = OWN / "arena-settings-v1"
ROOT = Path("/workspaces/quoridor")


def ref(path):
    path = Path(path).resolve()
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def read(name):
    return json.loads((OUT / name).read_bytes())


def put(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def fmt(names):
    before = {name: json.loads((OUT / name).read_bytes()) for name in names}
    subprocess.run(
        [
            str(ROOT / "tools/research-quality/node_modules/.bin/prettier"),
            "--write",
            "--ignore-path",
            "/dev/null",
            *[str(OUT / name) for name in names],
        ],
        env=dict(os.environ, NODE_OPTIONS="--max-old-space-size=128"),
        check=True,
    )
    for name, value in before.items():
        assert read(name) == value


before_refs = [ref(p) for p in sorted(OUT.glob("*.json"))]
old_binding = read("draft-binding.json")
fmt(["arena-book.json", "carrier-provenance.json", "schedule.json"])
carrier = ref(OUT / "arena-book.json")
provenance = ref(OUT / "carrier-provenance.json")
schedule = ref(OUT / "schedule.json")
configs = []
for batch in range(12):
    name = f"config-{batch:03d}.json"
    value = read(name)
    for opening in value["arena"]["book"]["openings"]:
        assert opening["reference"]["source_sha256"] == old_binding["carrier"]["sha256"]
        opening["reference"]["source_sha256"] = carrier["sha256"]
    put(name, value)
    configs.append(name)
fmt(configs)
plan = read("plan.json")
replacements = {
    old_binding["carrier"]["path"]: carrier,
    str(OUT / "carrier-provenance.json"): provenance,
    old_binding["schedule"]["path"]: schedule,
}
plan["book"] = carrier
plan["schedule"] = schedule
plan["inputs"] = [replacements.get(item["path"], item) for item in plan["inputs"]]
for batch in plan["batches"]:
    batch["config"] = ref(OUT / f"config-{batch['batch']:03d}.json")
put("plan.json", plan)
fmt(["plan.json"])
plan_ref = ref(OUT / "plan.json")
settings = read("settings.json")
for run in settings["runs"]:
    run["approved_plan"] = plan_ref
put("settings.json", settings)
fmt(["settings.json"])
binding = old_binding
binding.update(
    settings=ref(OUT / "settings.json"),
    plan=plan_ref,
    schedule=schedule,
    carrier=carrier,
)
for operation in binding["operations"]:
    operation["config"] = ref(OUT / f"config-{operation['batch']:03d}.json")
put("draft-binding.json", binding)
fmt(["draft-binding.json"])
(OWN / "arena-format-rebind.json").write_text(
    json.dumps(
        dict(
            scope="only new426 draft JSON; native inputs and original files unchanged",
            before=before_refs,
            after=[ref(p) for p in sorted(OUT.glob("*.json"))],
            semantic_changes="only FileRefs and source_sha256 rebound to formatted same-value JSON",
            foreign_or_frozen_original_mutation=False,
        ),
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        dict(
            settings=ref(OUT / "settings.json"), binding=ref(OUT / "draft-binding.json")
        )
    )
)
