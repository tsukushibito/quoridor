# 426 rules-only入力の原失敗

既知383の選択36局面、411の8prefix、422の7局面は全件、既存355未封印bookのprefixの直接延長である。追加除外bookは不要。保存列だけの照合であり、新しい分類器・rules replayは実行していない。

固定Max設定199ed9bfから2048候補、prefix seed42620261017、長さ4/8/12/16、split seed42620261018、五book528members、unique_families=trueのactual input-config.jsonを作成し、既存35e47e65 CLIを一度だけ実行した。原CLIはexit1、No such file or directoryで終了した。新候補出力ディレクトリは存在せず、schedule/partition/book/censusは未保存。要求2048を成功件数としない。Search/ゲーム/モデル/forwardは0。

出力親nnue-independent426-v1/inputsが未作成だった。私の事前確認が最終出力のfresh absenceだけで、親ディレクトリの存在を確認していなかった。固定sourceはglobal_schedule/filter/partitionの後でfs::create_dir(output)を呼ぶため、原失敗前にrules-only計算が行われた可能性を保持する。新pool未入場とは主張しない。

元native費、returned NULLとdisk pending/attempted、cleanup/directwait/handles/freshabsenceの別事実をinput-failure-receipt.jsonに保存した。自動再実行・新seed・refillは行わない。具体修復は許可された親ディレクトリだけの作成と、同一固定configの回復であり、統合担当へこの失敗境界を渡す。候補192・arena384の実入力/設定/Experimentは未成立のまま。

元の全FAILED/RAW/費UNKNOWN、pause/default/model/sealは変更していない。
