"""Prepare finite426 arena metadata only after the actual native input collection."""

import copy
import hashlib
import json
import stat
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
OUT = OWN / "arena-settings-v1"
PERF = ROOT / ".worktree/assets/perf/nnue-independent426-v1/arena384-v1"
OLD = (
    ROOT
    / ".artifacts/research-team/integration324/nnue-teacher-refresh423-v1/science-v1/arena160-entry-v4"
)
SELECTED = []


def ref(path):
    path = Path(path).resolve()
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def read(path, expected=None):
    before = ref(path)
    if expected:
        for key, value in expected.items():
            assert before[key] == value, (path, key)
    result = json.loads(Path(path).read_bytes())
    assert ref(path) == before
    SELECTED.append(before)
    return result, before


def put(name, value):
    path = OUT / name
    with path.open("x") as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write("\n")
    return ref(path)


def main():
    # This is a real dependency, never a dummy future FileRef.
    collection, collection_ref = read(OWN / "input-collection.json")
    assert collection["status"] == "ACTUAL_RULES_ONLY_INPUT_COLLECTED"
    resolved, resolved_ref = read(
        OWN.parent / "nnue-independent426-analysis-v1/design-v1/resolved-settings.json",
        {
            "sha256": "199ed9bf5ef9562df0377418e4f5fa064868dd6919ca7c145313161aa306d99f",
            "bytes": 8198,
            "mode": "0644",
        },
    )
    recipe = resolved["A"]
    book, book_ref = read(
        collection["files"]["prefix_book"]["path"], collection["files"]["prefix_book"]
    )
    schedule, schedule_ref = read(
        collection["files"]["schedule"]["path"], collection["files"]["schedule"]
    )
    partition, partition_ref = read(
        collection["files"]["partition"]["path"], collection["files"]["partition"]
    )
    config, config_ref = read(collection["config"]["path"], collection["config"])
    assignments = {a["game"]: a for a in partition["assignments"]}
    openings = {entry["id"]: entry for entry in book["openings"]}
    slots = schedule["scheduled"]
    assert len(slots) == recipe["candidate_requests"] == 2048
    assert config["prefix_seed"] == schedule["prefix_seed"] == recipe["prefix_seed"]
    assert config["split_seed"] == partition["seed"] == recipe["split_seed"]
    assert book["schedule"] == {
        "path": schedule_ref["path"],
        "sha256": schedule_ref["sha256"],
    }
    eligible = []
    native_families = set()
    for ordinal, slot in enumerate(slots):
        assert slot["game"] == ordinal
        assert slot["request_id"] == f"fixed-d-family-{ordinal:06}"
        assert slot["requested_prefix_length"] == [4, 8, 12, 16][ordinal % 4]
        if slot["prefix"] is None:
            assert slot["scheduled_failure"] is not None
            assert slot["request_id"] not in assignments
            continue
        assignment = assignments[slot["request_id"]]
        opening = openings[slot["request_id"]]
        assert slot["prefix"] == assignment["prefix"] == opening["prefix"]
        assert slot["root"] is not None and slot["scheduled_failure"] is None
        # Equality of already-native family labels, not a new classifier.
        assert assignment["family"] not in native_families
        native_families.add(assignment["family"])
        eligible.append(slot)
    assert len(eligible) == collection["result"]["accepted_slots"]
    if len(eligible) < 192:
        raise ValueError(f"native input shortfall {len(eligible)}/192; no refill")
    chosen = eligible[:192]
    old_settings, old_settings_ref = read(
        OLD / "settings.json",
        {
            "sha256": "c720f718ec3e1cf1cef1f9e48258d8cbd3a459e8b0528f431dcd7bccc7a9cb3a",
            "bytes": 31941,
            "mode": "0644",
        },
    )
    old_plan, old_plan_ref = read(
        old_settings["runs"][0]["approved_plan"]["path"],
        old_settings["runs"][0]["approved_plan"],
    )
    base_config, base_config_ref = read(
        old_plan["batches"][0]["config"]["path"], old_plan["batches"][0]["config"]
    )
    route, route_ref = read(
        ROOT
        / ".artifacts/research-team/integration324/nnue-independent426-v1/intake-v1/entry-route.json"
    )
    assert [e["model"] for e in base_config["engines"]] == [
        m["descriptor"]["path"] for m in route["models"]
    ]
    assert base_config["arena"]["evaluator_sha256"] == [
        m["evaluator_sha256"] for m in route["models"]
    ]
    for engine in base_config["engines"]:
        assert engine["kind"] == "nnue" and engine["ordering_profile"] == "control"
        assert engine["lmr"] is True and engine["lmr_method"] == "depth_rank"
        assert engine["depth"] == 64 and engine["max_nodes"] == 1000000
        assert engine["time_ms"] == 100
        assert "zero_stock_safe_race" not in engine
        assert "zero_stock_approx_min_root_walls" not in engine
    OUT.mkdir(exist_ok=False)
    families, lineage = [], []
    for selection_index, slot in enumerate(chosen):
        accepted = [
            a
            for a in slot["attempts"]
            if a["rejection"] is None and a["prefix"] == slot["prefix"]
        ]
        assert len(accepted) == 1
        root = slot["root"]
        family = dict(
            family_id=slot["game"],
            id=slot["request_id"],
            seed=config["prefix_seed"],
            prefix=slot["prefix"],
            root_key=root["state_key"],
            history_counts=root["history"],
            attempt_id=accepted[0]["attempt"],
        )
        families.append(family)
        lineage.append(
            dict(
                selection_ordinal=selection_index,
                global_request_id=slot["game"],
                request_id=slot["request_id"],
                canonical_family=assignments[slot["request_id"]]["family"],
                source_schedule=schedule_ref,
                source_root_pointer=f"/scheduled/{slot['game']}/root",
                seed_scope="shared_generator_batch_prefix_seed",
                per_family_rng_state=None,
                full_prefix_history_unchanged=True,
            )
        )
    assert len({f["family_id"] for f in families}) == 192
    carrier_ref = put(
        "arena-book.json",
        dict(complete=True, rules=old_plan["rules"], families=families),
    )
    correspondence_ref = put(
        "carrier-provenance.json",
        dict(
            source_config=config_ref,
            source_collection=collection_ref,
            source_schedule=schedule_ref,
            source_partition=partition_ref,
            source_book=book_ref,
            selection=recipe["selection"],
            selected=lineage,
            native_global_IDs_preserved=True,
            display_selection_ordinals_are_not_global_IDs=True,
            per_family_rng_state="UNKNOWN",
            new_inputs_or_rules_replays=0,
        ),
    )
    game_schedule = []
    batches, runs, operations = [], [], []
    for batch in range(12):
        group = families[batch * 16 : (batch + 1) * 16]
        openings_for_native = []
        for family in group:
            openings_for_native.append(
                dict(
                    id=family["id"],
                    cohort="main",
                    lineage="426-independent:" + family["id"],
                    siblings=[],
                    original_seed=family["seed"],
                    reference=dict(
                        source_sha256=carrier_ref["sha256"],
                        model_sha256=None,
                        settings=family,
                        q_definition=None,
                        q_perspective=None,
                        q_aggregation=None,
                        q=None,
                    ),
                    selection_reason=recipe["selection"],
                    candidate_pool_size=recipe["candidate_requests"],
                    prefix=family["prefix"],
                )
            )
        native = copy.deepcopy(base_config)
        data_root = str(PERF / f"batch-{batch:03d}/data")
        native.update(
            run_id=f"426-W-vs-BEST43-control-depth-rank-batch-{batch:03d}",
            output=data_root,
            games=32,
            seed=recipe["arena_rng_seed"],
            max_output_bytes=None,
        )
        native["arena"].update(
            book=dict(
                id="426-independent-first192-native-families",
                usage="main",
                frozen_before_candidate_results=True,
                independence="One192-family primary contrast, adjacent two-colour pairs; chunks are not statistical replicates.",
                openings=openings_for_native,
            ),
            first_candidate_colors=[0] * 16,
            bootstrap_seed=resolved["statistics"]["bootstrap_seed"],
            bootstrap_resamples=resolved["statistics"]["bootstrap_resamples"],
            retained_outcome_bytes=630784,
            max_total_nodes=250000000,
        )
        native_ref = put(f"config-{batch:03d}.json", native)
        globalslots = list(range(batch * 32, (batch + 1) * 32))
        batches.append(
            dict(batch=batch, matchup=0, config=native_ref, slots=globalslots)
        )
        for local_family, family in enumerate(group):
            for color in [0, 1]:
                local_game = 2 * local_family + color
                game_schedule.append(
                    dict(
                        slot=32 * batch + local_game,
                        batch=batch,
                        matchup=0,
                        local_game=local_game,
                        family_id=family["family_id"],
                        candidate_color=color,
                    )
                )
        run = copy.deepcopy(old_settings["runs"][0])
        operation = PERF / f"template-{batch:03d}/operation"
        run.update(
            output=str(operation),
            support=None,
            approved_plan=None,
            artifact=route["arena_runner"],
            experiment=None,
            caller_sources=None,
            data_root=data_root,
            owned_outputs=None,
            TMP=str(operation.parent / "TMP"),
            env=None,
            argv=None,
            data=None,
        )
        run["limits"].update(owned_B=None, free_B=None)
        runs.append(run)
        operations.append(
            dict(
                batch=batch,
                selection_index=batch,
                source_family_selection_ordinals=list(
                    range(batch * 16, (batch + 1) * 16)
                ),
                global_family_ids=[f["family_id"] for f in group],
                games=32,
                pairs=16,
                node_quota=250000000,
                config=native_ref,
                actual_Experiment=None,
                actual_runtime=None,
                normal_output_forecast=None,
            )
        )
    schedule_ref_arena = put("schedule.json", game_schedule)
    plan = copy.deepcopy(old_plan)
    plan.update(
        book=carrier_ref,
        inputs=[
            carrier_ref,
            correspondence_ref,
            config_ref,
            collection_ref,
            book_ref,
            schedule_ref,
            partition_ref,
            resolved_ref,
            route_ref,
        ],
        models=route["models"],
        schedule=schedule_ref_arena,
        family_ids=[f["family_id"] for f in families],
        matchups=[
            dict(
                id=0,
                engines=base_config["engines"],
                evaluator_sha256=base_config["arena"]["evaluator_sha256"],
                inference=None,
            )
        ],
        batches=batches,
        planned_slots=384,
    )
    plan_ref = put("plan.json", plan)
    for run in runs:
        run["approved_plan"] = plan_ref
    settings_ref = put(
        "settings.json",
        dict(
            kind="sequence",
            cwd=str(ROOT),
            owner=str(ROOT),
            output=str(PERF / "execution-v1"),
            runs=runs,
            measurements=[],
            arena=None,
            interpreter=old_settings["interpreter"],
        ),
    )
    assert len(game_schedule) == 384
    assert len({(g["family_id"], g["candidate_color"]) for g in game_schedule}) == 384
    assert sum(op["node_quota"] for op in operations) == 3000000000
    assert [g["slot"] for g in game_schedule] == list(range(384))
    for before in SELECTED:
        assert ref(before["path"]) == before
    put(
        "draft-binding.json",
        dict(
            status="NOT_READY_ROOT_FORECAST_SUPPORT_EXPERIMENT_CALLER_RUNTIME",
            settings=settings_ref,
            plan=plan_ref,
            schedule=schedule_ref_arena,
            carrier=carrier_ref,
            selectedrefs=SELECTED,
            operations=operations,
            image=route["arena_runner"],
            Build=route["arena_Build"],
            source_delta=None,
            native_arena_or_Search_launched=False,
            new_model_or_image_payload_reads=0,
            bootstrap_executed=False,
            input_prefix_seed=recipe["prefix_seed"],
            arena_rng_seed=recipe["arena_rng_seed"],
            bootstrap_seed=resolved["statistics"]["bootstrap_seed"],
            operation_output_cap=None,
            whole_bulk_cap_B=384 * 1024**2,
            actual_physical_allocation=None,
            actual_caller_sources=None,
            approx_and_safe_OFF_authority="unchanged existing image/default; no unsupported Engine fields added",
            native_methods_namespace="authoritative native session; no Python ID builder",
            original_failed_input_preserved=True,
            source_examples=[old_settings_ref, old_plan_ref, base_config_ref],
        ),
    )
    print(
        json.dumps(
            dict(
                status="DRAFT_METADATA_READY_NOT_SUBMITTED",
                families=192,
                games=384,
                operations=12,
                quota_each=250000000,
                settings=settings_ref,
            )
        )
    )


if __name__ == "__main__":
    main()
