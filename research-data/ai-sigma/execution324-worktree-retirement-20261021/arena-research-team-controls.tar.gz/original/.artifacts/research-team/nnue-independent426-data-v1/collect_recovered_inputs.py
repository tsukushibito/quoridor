"""Collect the one explicit426 input recovery without recomputing any family."""

import hashlib
import json
import stat
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from quoridor_training.cycle_process import alive

OWN = Path(__file__).resolve().parent
SELECTED = []


def ref(path):
    path = Path(path).resolve()
    body = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def read(path, expected=None):
    path = Path(path).resolve()
    before = ref(path)
    if expected:
        for key, value in expected.items():
            assert before[key] == value, (path, key)
    value = json.loads(path.read_bytes())
    assert ref(path) == before
    SELECTED.append(before)
    return value, before


def put(name, value):
    path = OWN / name
    with path.open("x") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    return ref(path)


runtime, runtime_ref = read(OWN / "input-recovery-v1/result.json")
assert runtime["returned"] is not None and runtime["error"] is None
process = runtime["returned"]
assert process["exit_code"] == 0 and process["cleanup_complete"]
assert process["direct_child_reaped"] and process["handle_closes_complete"]
assert process["remaining"] == [] and not alive(process["child"])
assert not (OWN / "input-recovery-v1/TMP").exists()
summary, summary_ref = read(OWN / "input-recovery-v1/stdout.json")
result = summary["result"]
assert result["outcomes_selected"] is False and result["search_calls"] == 0
config, config_ref = read(summary["config"]["path"], summary["config"])
assert (
    config_ref["sha256"]
    == "47530ab0d5062ac31917ed2bee46b083294ac27088941de84c803ad1bf475511"
)
assert config["families"] == result["requested_slots"] == result["families"] == 2048
files, data = {}, {}
for name in ["schedule", "partition", "prefix_book"]:
    data[name], files[name] = read(result[name]["path"], result[name])
    assert Path(files[name]["path"]).parent == Path(config["output"])
schedule, partition, book = data["schedule"], data["partition"], data["prefix_book"]
assert schedule["prefix_seed"] == config["prefix_seed"] == 42620261017
assert schedule["prefix_lengths"] == config["prefix_lengths"] == [4, 8, 12, 16]
assert partition["seed"] == config["split_seed"] == 42620261018
assert book["schedule"] == result["schedule"]
slots = schedule["scheduled"]
assert len(slots) == 2048
assignments = {row["game"]: row for row in partition["assignments"]}
openings = {row["id"]: row for row in book["openings"]}
assert len(assignments) == len(partition["assignments"])
assert len(openings) == len(book["openings"])
accepted, missing = [], []
attempt_count, reject_reasons = 0, Counter()
lengths, splits = Counter(), Counter()
native_families = set()
for ordinal, slot in enumerate(slots):
    request_id = f"fixed-d-family-{ordinal:06}"
    assert slot["game"] == ordinal and slot["request_id"] == request_id
    assert slot["requested_prefix_length"] == [4, 8, 12, 16][ordinal % 4]
    lengths[slot["requested_prefix_length"]] += 1
    attempt_count += len(slot["attempts"])
    for attempt in slot["attempts"]:
        if attempt["rejection"] is not None:
            reject_reasons[attempt["rejection"]] += 1
    if slot["prefix"] is None:
        assert slot["scheduled_failure"] is not None
        assert request_id not in assignments and request_id not in openings
        missing.append(
            dict(game=ordinal, request_id=request_id, reason=slot["scheduled_failure"])
        )
        continue
    assert slot["scheduled_failure"] is None and slot["root"] is not None
    assignment = assignments[request_id]
    assert slot["prefix"] == assignment["prefix"] == openings[request_id]["prefix"]
    assert len(slot["prefix"]) == slot["requested_prefix_length"]
    assert slot["root"]["ply"] == len(slot["prefix"])
    assert len(slot["root"]["history"]) > 0
    accepted_attempts = [
        a
        for a in slot["attempts"]
        if a["rejection"] is None and a["prefix"] == slot["prefix"]
    ]
    assert len(accepted_attempts) == 1
    assert assignment["family"] not in native_families
    native_families.add(assignment["family"])
    splits[assignment["split"]] += 1
    accepted.append(
        dict(
            global_request_id=ordinal,
            request_id=request_id,
            native_canonical_family=assignment["family"],
            prefix_length=len(slot["prefix"]),
            accepted_attempt=accepted_attempts[0]["attempt"],
            native_root_pointer=f"/scheduled/{ordinal}/root",
        )
    )
assert len(accepted) == result["accepted_slots"]
assert len(missing) == result["missing_slots"]
assert len(accepted) + len(missing) == 2048
assert len(native_families) == result["unique_family_count"]
for before in SELECTED:
    assert ref(before["path"]) == before
census_ref = put(
    "input-census.json",
    dict(
        at=datetime.now(timezone.utc).isoformat(),
        requested_slots=len(slots),
        accepted_slots=len(accepted),
        missing_slots=len(missing),
        native_unique_families=len(native_families),
        requested_length_counts=lengths,
        native_split_counts=splits,
        original_candidate_attempts=attempt_count,
        original_attempt_rejections=reject_reasons,
        missing=missing,
        native_accepted_order=accepted,
        selection="first192 in preserved native accepted scheduled order",
        first192_global_request_ids=[
            row["global_request_id"] for row in accepted[:192]
        ],
        target192_available=len(accepted) >= 192,
        extra_seed_pool_refill_or_outcome_selection=False,
        geometry_rules_history_replay_or_classifier_executed=False,
    ),
)
collection_ref = put(
    "input-collection.json",
    dict(
        status="ACTUAL_RULES_ONLY_INPUT_COLLECTED",
        at=datetime.now(timezone.utc).isoformat(),
        config=config_ref,
        config_value=config,
        files=files,
        result=result,
        native_summary=summary_ref,
        runtime=runtime_ref,
        original_failed_runtime=ref(OWN / "input-native-v1/result.json"),
        original_failed_seconds=0.17982568900333717,
        explicit_same_config_recovery_seconds=process["wall_seconds"],
        original_unsaved_rules_work="may have run; preserved without census",
        native_resource_STOP=runtime["at"],
        census=census_ref,
        selected_refs_before_after_exact=SELECTED,
        exact_native_identity=process["child"],
        exact_native_fresh_absent=True,
        directwait_reaped=True,
        handles_closed=True,
        TMP_absent=True,
        owned=[],
        leases=[],
        input_math_authority="unchanged native input owner; saved metadata joins only, no Python classifier/rules replay",
        model_forward_Search_or_games=0,
    ),
)
print(
    json.dumps(
        dict(
            collection=collection_ref,
            census=census_ref,
            requested=len(slots),
            accepted=len(accepted),
            missing=len(missing),
            native_families=len(native_families),
            first192_global_ids=[row["global_request_id"] for row in accepted[:192]],
            native_STOP=runtime["at"],
        )
    )
)
