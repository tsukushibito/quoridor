"""Limited426 metadata checks, including the maintained full-schedule consumer."""

import hashlib
import importlib.util
import json
import stat
from collections import Counter
from pathlib import Path

OWN = Path(__file__).resolve().parent
OUT = OWN / "arena-settings-v1"
ROOT = Path("/workspaces/quoridor")
SELECTED = []


def ref(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def read(expected):
    before = ref(expected["path"])
    assert before == expected
    value = json.loads(Path(expected["path"]).read_bytes())
    assert ref(expected["path"]) == before
    SELECTED.append(before)
    return value


binding = read(ref(OUT / "draft-binding.json"))
plan = read(binding["plan"])
schedule = read(binding["schedule"])
settings = read(binding["settings"])
carrier = read(binding["carrier"])
provenance = read(ref(OUT / "carrier-provenance.json"))
collection = read(provenance["source_collection"])
native_schedule = read(provenance["source_schedule"])
native_partition = read(provenance["source_partition"])
native_slots = native_schedule["scheduled"]
native_families = {a["game"]: a for a in native_partition["assignments"]}
route = read(
    next(
        r
        for r in binding["selectedrefs"]
        if r["path"].endswith("/nnue-independent426-v1/intake-v1/entry-route.json")
    )
)
caller = next(
    r
    for r in route["current_caller_sources"]
    if r["path"].endswith("/research-lifecycle.py")
)
assert ref(caller["path"]) == caller
spec = importlib.util.spec_from_file_location(
    "check426_lifecycle_owner", caller["path"]
)
lc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lc)
# Only this ordinary consumer is called. No fabricated Experiment file is written.
planned = lc.planned_game_slice({"planned_slots": 384, "batch": 0}, schedule, plan)
assert len(planned) == 32
assert len(plan["family_ids"]) == len(carrier["families"]) == 192
assert plan["family_ids"] == list(range(192))
assert len(plan["batches"]) == len(settings["runs"]) == 12
assert (
    len(schedule)
    == len({(g["family_id"], g["candidate_color"]) for g in schedule})
    == 384
)
assert [g["slot"] for g in schedule] == list(range(384))
assert [m["id"] for m in plan["matchups"]] == [0]
families = {f["family_id"]: f for f in carrier["families"]}
history_checks = 0
for row in provenance["selected"]:
    global_id = row["global_request_id"]
    family, slot = families[global_id], native_slots[global_id]
    assert family["id"] == slot["request_id"] == row["request_id"]
    assert family["prefix"] == slot["prefix"]
    assert family["root_key"] == slot["root"]["state_key"]
    assert family["history_counts"] == slot["root"]["history"]
    assert row["canonical_family"] == native_families[family["id"]]["family"]
    assert family["seed"] == 42620261017
    assert row["per_family_rng_state"] is None
    history_checks += 1
caps = []
for batch, run in zip(plan["batches"], settings["runs"], strict=True):
    config = read(batch["config"])
    assert config["games"] == 32 and config["seed"] == 42620261019
    assert config["max_plies"] == 200
    assert config["cpu_cores"] == [2, 6] and config["management_cpu_core"] == 4
    assert config["max_output_bytes"] is None
    assert config["arena"]["max_total_nodes"] == 250000000
    caps.append(config["arena"]["max_total_nodes"])
    assert config["arena"]["retained_outcome_bytes"] == 630784
    assert config["arena"]["tt_entries"] == 1048576
    assert config["arena"]["clock_policy"] == "strict_unknown"
    assert config["arena"]["return_reserve_ms"] == 5
    assert config["arena"]["bootstrap_seed"] == 42620261016
    assert config["arena"]["bootstrap_resamples"] == 10000
    assert config["arena"]["evaluator_sha256"] == [
        m["evaluator_sha256"] for m in route["models"]
    ]
    assert (
        config["arena"]["search_artifact_sha256"]
        == [route["arena_runner"]["sha256"]] * 2
    )
    assert config["engines"] == plan["matchups"][0]["engines"]
    for engine, model in zip(config["engines"], route["models"], strict=True):
        assert engine["model"] == model["descriptor"]["path"]
        assert engine["ordering_profile"] == "control" and engine["lmr"] is True
        assert engine["lmr_method"] == "depth_rank"
        assert engine["depth"] == 64 and engine["max_nodes"] == 1000000
        assert engine["time_ms"] == 100 and engine["simd"] is False
        assert "zero_stock_safe_race" not in engine
        assert "zero_stock_approx_min_root_walls" not in engine
    assert run["approved_plan"] == binding["plan"]
    assert run["artifact"] == route["arena_runner"]
    assert run["experiment"] is run["support"] is run["caller_sources"] is None
    openings = config["arena"]["book"]["openings"]
    assert len(openings) == len(config["arena"]["first_candidate_colors"]) == 16
    for i, opening in enumerate(openings):
        left = schedule[batch["slots"][2 * i]]
        right = schedule[batch["slots"][2 * i + 1]]
        assert left["family_id"] == right["family_id"]
        assert left["candidate_color"] == 0 and right["candidate_color"] == 1
        family = families[left["family_id"]]
        assert opening["prefix"] == family["prefix"]
        assert opening["id"] == family["id"]
        assert opening["original_seed"] == family["seed"]
        assert opening["reference"]["settings"] == family
        assert opening["reference"]["source_sha256"] == binding["carrier"]["sha256"]
assert sum(caps) == 3000000000
assert ref(caller["path"]) == caller
for before in SELECTED:
    assert ref(before["path"]) == before
result = dict(
    scope="new426 draft input/plan/config correspondence only",
    maintained_consumer="research-lifecycle.planned_game_slice",
    maintained_consumer_source=caller,
    result="PASS_METADATA_ONLY_NOT_NATIVE_ADMISSION",
    unique_slots=384,
    complete_planned_colourpairs=192,
    source_fullprefix_root_history_joins=history_checks,
    native_family_IDs=list(families),
    prefix_length_counts=Counter(len(f["prefix"]) for f in carrier["families"]),
    operations=12,
    disjoint_node_caps=caps,
    total_node_cap=sum(caps),
    retained_outcome_bytes_per_game=630784,
    per_game_retention_product_not_forecast=384 * 630784,
    full_arena_plan_check="PENDING actual outputforecast and Experiment/model/caller Root admission; not called with invented caps",
    actual_Experiment=None,
    actual_runtime=None,
    actual_output_forecast=None,
    actual_physical_allocation=None,
    bootstrap_or_native_Search_games=0,
    source_Model_or_image_payload_reads=0,
    selected_refs_before_after=SELECTED,
)
(OUT / "metadata-checks.json").write_text(json.dumps(result, indent=2) + "\n")
print(
    json.dumps(
        {
            k: result[k]
            for k in [
                "result",
                "unique_slots",
                "complete_planned_colourpairs",
                "operations",
                "source_fullprefix_root_history_joins",
                "total_node_cap",
            ]
        }
    )
)
