"""Bounded saved prefix correspondence; no native family classifier or rule replay."""

import hashlib
import json
import stat
from datetime import datetime, timezone
from pathlib import Path

OWN = Path(__file__).resolve().parent
READS = []


def ref(path, data=None):
    path = Path(path)
    data = path.read_bytes() if data is None else data
    return {
        "path": str(path.resolve()),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


def load(expected):
    path = Path(expected["path"])
    data = path.read_bytes()
    before = ref(path, data)
    assert before == expected, (before, expected)
    value = json.loads(data)
    READS.append(before)
    return value


def fixed(path, sha256, size):
    return {"path": path, "sha256": sha256, "bytes": size, "mode": "0644"}


book_ref = fixed(
    "/workspaces/quoridor/.worktree/value-search-strength-arena355/.artifacts/"
    "value-search-strength355/maintained-build-v1/campaign-generation-v1/data/book.json",
    "a6abde1f3182ba0e876c9e7719d3389502a44b3406ca28b7af9a0456952a6878",
    85083,
)
case_ref = fixed(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/"
    "three-engine-comparison374-v1/nnue-loss-cases383-v1/analysis-v2/result.json",
    "bd2f5cb333ceae21a06c509af57c7bc7fedf3da0b74d0c9f75fd19e87ac8bdff",
    459603,
)
race_ref = fixed(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/"
    "zero-stock-safe-race411-v1/eight-prefixes.json",
    "eec77569104f589b2e6b38c9cd388ad5c51e2ec4a549e34fea3d85a6c9588daa",
    4318,
)
static_ref = fixed(
    "/workspaces/quoridor/research-data/ai-sigma/static-evaluators422/input.json",
    "35cbef99ab6fc11212f6eba61f88196e4ff0df94461d672d0204836508fa0602",
    31791,
)
book = load(book_ref)
assert book["complete"] and len(book["families"]) == 128


def matches(prefix):
    """Literal extension only; native owner supplies the collision relation."""
    result = []
    for family in book["families"]:
        base = family["prefix"]
        if prefix[: len(base)] == base:
            result.append(
                {
                    "book_family_id": family["family_id"],
                    "book_id": family["id"],
                    "book_prefix": base,
                    "relation": "literal_prefix_extension",
                }
            )
    assert result, ("no literal extension match", prefix)
    return result


cases = load(case_ref)
by_case = {row["index"]: row for row in cases["cases"]}
assert len(by_case) == 12 and len(cases["positions"]) == 36
case_rows = []
for position in cases["positions"]:
    case = by_case[position["case_index"]]
    trace = case["trace"]
    assert [entry["ply"] for entry in trace] == list(range(len(trace)))
    prefix = [entry["action"] for entry in trace[: position["ply"]]]
    digest = hashlib.sha256(
        json.dumps(prefix, separators=(",", ":")).encode()
    ).hexdigest()
    assert digest == position["prefix_actions_sha256"]
    opening = [entry["action"] for entry in trace if entry["is_opening"]]
    assert prefix[: len(opening)] == opening
    case_rows.append(
        {
            "case": position["case_index"],
            "position": position["position_index"],
            "slot": position["slot"],
            "ply": position["ply"],
            "saved_prefix_sha256": digest,
            "position_ref": position["position_record"],
            "matches": matches(prefix),
        }
    )

race = load(race_ref)
assert len(race) == 8
race_rows = [
    {
        "index": index,
        "game": row["game"],
        "source_family": row["family"],
        "prefix_length": len(row["prefix"]),
        "matches": matches(row["prefix"]),
    }
    for index, row in enumerate(race)
]
static = load(static_ref)
assert len(static["rows"]) == 7
static_rows = [
    {
        "id": row["id"],
        "source_file": row["source_file"],
        "source_pointer": row["source_pointer"],
        "prefix_length": len(row["prefix"]),
        "matches": matches(row["prefix"]),
    }
    for row in static["rows"]
]
for expected in READS:
    assert ref(expected["path"]) == expected

result = {
    "issue": "quoridor-4lc.426.2",
    "scope": "saved383/411/422_selected_prefix_exclusion_correspondence",
    "before_parse_after_read_exact": True,
    "selected_refs": READS,
    "383": {"cases": 12, "selected_positions": 36, "rows": case_rows},
    "411": {"selected_prefixes": 8, "rows": race_rows},
    "422": {"selected_prefixes": 7, "rows": static_rows},
    "additional_exclusion_books_required_for_this_scope": [],
    "basis": (
        "All named selected prefixes are literal extensions of prefixes in the "
        "already bound 355 unsealed128 book. The existing native partition_families "
        "owner joins prefix extensions, left-right equivalents and equal endpoints; "
        "this helper does not implement that classifier or replay rules/history."
    ),
    "limits": [
        "No claim about unknown public whole-game provenance or unenumerated books.",
        "Saved selected prefix correspondence is not new native input admission.",
        "Future candidate-family filtering remains with the canonical native owner.",
    ],
    "native_calls": 0,
    "reader_finished_at": datetime.now(timezone.utc).isoformat(),
}
(OWN / "lineage-correspondence.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
report = """# 426 既知選択prefixの除外対応

既存の五book除外のうち355未封印128family bookだけで、指定された383・411・422の保存選択prefixをすべて包含する。追加のbook参照は不要だった。

| 保存対象 | 件数 | 実際に対応した355 family ID |
| --- | ---: | --- |
| 383 | 12ケース・選択36局面 | 0, 1, 2, 3, 4 |
| 411 | 8 prefix | 23, 29, 34, 93, 14, 14, 16, 16（保存順） |
| 422 | 7局面 | 全件0 |

対応は数値IDの同名推定ではなく、実際のActionID列の先頭一致で確認した。383は保存case traceから各選択plyまでの列を取り、保存prefix SHA256との一致も確認した。生RAW、geometry、モデル、旧Searchは再読・再実行していない。各対応と位置参照は lineage-correspondence.json に保存した。

正本terminal::partition_familiesはprefix延長・左右反転・同endpointをunionする。今回確認した文字列ではないActionID列の直接延長は、その既存関係の十分条件になる。新しいfamily分類器や左右反転・endpoint計算をPythonへ実装していない。実候補の除外は既存native ownerが既知bookと結合して行う。五bookの件数合計を独立family数とは扱わない。

4参照をSHA256・size・modeでparse前と読取後に一致確認した。未知の公開全game provenanceや、今回指定外の未列挙bookの網羅性はUNKNOWN。今回の保存対応は426候補のnative admissionや新結果の資格ではない。元の失敗・費用・NULLとdiskの区別、全pause/default/model/sealは変更しない。
"""
(OWN / "lineage-report-ja.md").write_text(report)
print(
    json.dumps(
        {"383": 36, "411": 8, "422": 7, "additional_books": [], "refs": len(READS)}
    )
)
