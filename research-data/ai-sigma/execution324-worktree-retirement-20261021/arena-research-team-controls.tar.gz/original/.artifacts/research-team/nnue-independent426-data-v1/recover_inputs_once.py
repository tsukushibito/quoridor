"""One authorized rules-only native preparation, using existing process/storage owners."""

import hashlib
import importlib.util
import json
import os
import stat
import sys
from datetime import datetime, timezone
from pathlib import Path

from quoridor_training.cycle_process import CycleResources, alive, execute

OWN = Path(__file__).resolve().parent
OUT = OWN / "input-recovery-v1"
OUT.mkdir(exist_ok=False)
TMP = OUT / "TMP"
TMP.mkdir()
ROOT = Path("/workspaces/quoridor")
BASE = ROOT / ".artifacts/research-team/integration324/nnue-independent426-v1"
selected = []


def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {
        "path": str(path.resolve()),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


def read_bound(expected):
    path = Path(expected["path"])
    before = ref(path)
    assert before == expected, (before, expected)
    value = json.loads(path.read_bytes())
    assert ref(path) == before
    selected.append(before)
    return value


route = json.loads((BASE / "intake-v1/entry-route.json").read_bytes())
selected.append(ref(BASE / "intake-v1/entry-route.json"))
resolved_ref = {
    "path": str(
        OWN.parent / "nnue-independent426-analysis-v1/design-v1/resolved-settings.json"
    ),
    "sha256": "199ed9bf5ef9562df0377418e4f5fa064868dd6919ca7c145313161aa306d99f",
    "bytes": 8198,
    "mode": "0644",
}
resolved = read_bound(resolved_ref)
config_ref = ref(OWN / "input-config.json")
assert (
    config_ref["sha256"]
    == "47530ab0d5062ac31917ed2bee46b083294ac27088941de84c803ad1bf475511"
)
config = read_bound(config_ref)
assert config["families"] == resolved["A"]["candidate_requests"] == 2048
assert config["prefix_seed"] == resolved["A"]["prefix_seed"] == 42620261017
assert config["split_seed"] == resolved["A"]["split_seed"] == 42620261018
assert config["prefix_lengths"] == [4, 8, 12, 16] and config["unique_families"] is True
assert not Path(config["output"]).exists()
output_parent = Path(config["output"]).parent
assert (
    str(output_parent)
    == "/workspaces/quoridor/.worktree/assets/data/nnue-independent426-v1/inputs"
)
missing_parents = [
    str(p) for p in [output_parent.parent, output_parent] if not p.exists()
]
output_parent.mkdir(parents=True, exist_ok=True)
assert output_parent.is_dir() and not Path(config["output"]).exists()
(OUT / "authorized-parent-recovery.json").write_text(
    json.dumps(
        {
            "same_original_config": config_ref,
            "created_missing_parents": missing_parents,
            "original_failure_preserved": str(OWN / "input-native-v1/result.json"),
            "authority": "Root426 explicit same-config deterministic original input recovery",
            "new_seed_pool_refill_or_outcome_selection": False,
        },
        indent=2,
    )
    + "\n"
)

assert config["excluded_books"] == [
    {"path": r["path"], "sha256": r["sha256"]} for r in resolved["A"]["excluded_books"]
]
for bound in resolved["A"]["excluded_books"]:
    read_bound(bound)
for bound in [route["arena_runner"], route["arena_Build"]]:
    assert ref(bound["path"]) == bound
    selected.append(bound)
for item in route["original_dynamic_libraries"]:
    bound = item["file"]
    assert ref(bound["path"]) == bound
    selected.append(bound)
for bound in route["current_caller_sources"]:
    assert ref(bound["path"]) == bound
    selected.append(bound)

lc_path = ROOT / "scripts/dev/research-lifecycle.py"
lc_spec = importlib.util.spec_from_file_location("input426_lifecycle_owner", lc_path)
lc = importlib.util.module_from_spec(lc_spec)
sys.modules[lc_spec.name] = lc
lc_spec.loader.exec_module(lc)
support = json.loads((BASE / "resources.json").read_bytes())
assert support["storage_budget"] == 384 * 1024**2
whole_roots = [*support["whole_science_roots"], str(OWN)]
topology = {
    str(cpu): {
        key: Path(f"/sys/devices/system/cpu/cpu{cpu}/topology/{key}")
        .read_text()
        .strip()
        for key in ["physical_package_id", "core_id"]
    }
    for cpu in [8, 12]
}
assert topology["8"] != topology["12"]
assert os.sched_getaffinity(0) == {12}
controller = {
    "pid": os.getpid(),
    "start_ticks": Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()[19],
    "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    "affinity": sorted(os.sched_getaffinity(0)),
    "topology": topology,
    "cpuset": Path("/sys/fs/cgroup/cpuset.cpus.effective").read_text().strip(),
    "cpu_max": Path("/sys/fs/cgroup/cpu.max").read_text().strip(),
}
(OUT / "controller.json").write_text(json.dumps(controller, indent=2) + "\n")
resources = CycleResources(
    {
        "host_ram_reserve": 4 * 1024**3,
        "max_memory_bytes": 960 * 1024**2,
        "max_output_bytes": None,
    },
    OUT,
    None,
)
ordinary_check = resources.check
storage_observations = []


def whole_check(owned=()):
    ordinary_check(owned)
    seen = set()
    charged = sum(lc.allocated(p, seen=seen) for p in whole_roots)
    assert charged <= support["storage_budget"], "whole426 allocation limit"
    storage_observations.append(charged)


resources.check = whole_check
env = dict(
    os.environ,
    CUDA_VISIBLE_DEVICES="",
    TMPDIR=str(TMP),
    PYTHONDONTWRITEBYTECODE="1",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    RAYON_NUM_THREADS="1",
)
command = [
    route["arena_runner"]["path"],
    "teacher-pilot",
    "--prepare-inputs",
    config_ref["path"],
    "--input-sha256",
    config_ref["sha256"],
]
(OUT / "entry.json").write_text(
    json.dumps(
        {
            "at": datetime.now(timezone.utc).isoformat(),
            "issue": "quoridor-4lc.426.2",
            "thread_id": "01a11062-b120-73a1-8aa3-fe2cb922c7c0",
            "command": command,
            "config": config_ref,
            "selected_refs_before": selected,
            "whole_roots": whole_roots,
            "whole_cap_B": support["storage_budget"],
            "models_read": False,
            "Search_or_game": False,
            "deadline": None,
        },
        indent=2,
    )
    + "\n"
)
returned = None
error = None
captured = 0
try:
    with (OUT / "stdout.json").open("xb") as capture:

        def sink(data):
            global captured
            captured += len(data)
            assert captured <= 2 * 1024**2, "bounded rules-only summary capture"
            capture.write(data)

        returned = execute(
            command,
            OUT / "native.log",
            None,
            cpu_core=8,
            resources=resources,
            cwd=str(ROOT),
            env=env,
            output_sink=sink,
            no_new_privs=True,
        )
    whole_check()
except Exception as failure:
    error = {"type": type(failure).__name__, "message": str(failure)}
after = []
for bound in selected:
    actual = ref(bound["path"])
    after.append(actual)
    assert actual == bound, ("selected reference drift", bound, actual)
process = json.loads((OUT / "native.process.json").read_bytes())
child = process.get("child")
fresh_absent = child is not None and not alive(child)
tmp_remaining = [str(p) for p in TMP.iterdir()]
if not tmp_remaining:
    TMP.rmdir()
(OUT / "result.json").write_text(
    json.dumps(
        {
            "at": datetime.now(timezone.utc).isoformat(),
            "returned": returned,
            "error": error,
            "original_process": process,
            "selected_refs_after": after,
            "exact_child_fresh_absent": fresh_absent,
            "TMP_remaining": tmp_remaining,
            "observed_whole_allocated_max_B": max(storage_observations),
            "continuous_RSS_peak": "UNKNOWN",
            "controller_external_cost": "UNKNOWN",
            "owned": []
            if process.get("cleanup_complete") and fresh_absent
            else "UNKNOWN",
            "leases": [],
            "models_or_Search_or_games": 0,
        },
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "result": str(OUT / "result.json"),
            "returned": returned,
            "error": error,
            "fresh_absent": fresh_absent,
        }
    )
)
raise SystemExit(
    0
    if returned
    and returned["exit_code"] == 0
    and not error
    and fresh_absent
    and not tmp_remaining
    else 1
)
