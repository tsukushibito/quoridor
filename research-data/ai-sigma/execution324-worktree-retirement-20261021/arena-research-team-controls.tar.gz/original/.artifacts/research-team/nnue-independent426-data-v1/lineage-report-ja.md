# 426 既知選択prefixの除外対応

既存の五book除外のうち355未封印128family bookだけで、指定された383・411・422の保存選択prefixをすべて包含する。追加のbook参照は不要だった。

| 保存対象 |                 件数 | 実際に対応した355 family ID              |
| -------- | -------------------: | ---------------------------------------- |
| 383      | 12ケース・選択36局面 | 0, 1, 2, 3, 4                            |
| 411      |             8 prefix | 23, 29, 34, 93, 14, 14, 16, 16（保存順） |
| 422      |                7局面 | 全件0                                    |

対応は数値IDの同名推定ではなく、実際のActionID列の先頭一致で確認した。383は保存case traceから各選択plyまでの列を取り、保存prefix SHA256との一致も確認した。生RAW、geometry、モデル、旧Searchは再読・再実行していない。各対応と位置参照は lineage-correspondence.json に保存した。

正本terminal::partition_familiesはprefix延長・左右反転・同endpointをunionする。今回確認した文字列ではないActionID列の直接延長は、その既存関係の十分条件になる。新しいfamily分類器や左右反転・endpoint計算をPythonへ実装していない。実候補の除外は既存native ownerが既知bookと結合して行う。五bookの件数合計を独立family数とは扱わない。

4参照をSHA256・size・modeでparse前と読取後に一致確認した。未知の公開全game provenanceや、今回指定外の未列挙bookの網羅性はUNKNOWN。今回の保存対応は426候補のnative admissionや新結果の資格ではない。元の失敗・費用・NULLとdiskの区別、全pause/default/model/sealは変更しない。
