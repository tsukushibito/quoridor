# 426.2 同一入力回復と384 slotsの設定準備

同一config47530ab0の明示的な回復を一度実施し、2048要求・2048受入れ・native unique family2048・欠測0を保存した。元のFAILED/0.17982568900333717秒/未保存rules計算は変更していない。回復は0.22304607401019894秒、native directwait後の観測STOPは2026-10-16T21:52:54.921400Z。二回の元process費は別々で、source/LLM/adminの総費やcontinuous RSS peakはUNKNOWN。新seed/pool/refillや結果選択はない。

| 固定項目       | 実値                                                                                  |
| -------------- | ------------------------------------------------------------------------------------- |
| 候補           | 2048、prefix seed42620261017、長さ4/8/12/16を元ordinalでround-robin                   |
| 正本split seed | 42620261018。native割当T1638/V410だが、今回は学習splitとして使わない                  |
| 除外           | 五bookの実member528。既知383/411/422も既存355延長関係内、追加bookなし                 |
| 実候補census   | 各長さ512、attempt2048・rejection0、missing0                                          |
| 採用する開始   | 正本受入れ順の先頭192、実global request ID0..191、各長さ48                            |
| 条件           | W BEST118対BEST43のみ、同prefixを両roleへ。モデル再選択・fitなし                      |
| 操作           | 12×32slots、各16family二色。384unique slots/192色pair                                 |
| node quota     | 各250M、総3G、独立割当。移譲・リセット・refillなし                                    |
| 時計等         | 100ms authority receipt、5ms reserve、各探索1M、名目depth64、prefix込み200ply         |
| 探索           | Control/PVS/TT1048576/LMR ON depth_rank、同一既存image35e47e65/Build9bf66048          |
| RNG            | arena42620261019、bootstrap42620261016/10000 resamples                                |
| 保存           | retained_outcome_bytes630784/ゲーム。全ゲーム積242221056Bはforecastや追加予約ではない |

旧ancillary old_open8_prefixesを新しいmemberへ混ぜず、empty universal prefixも供給していない。分類は既存native partition_familiesが担う。Pythonは正本のcanonical familyラベルの同一性を照合しただけで、新classifier/LR/endpoint計算を作っていない。

native schedule/partition/bookをSHA-size-modeでparse前・読取後照合した。192開始のprefix/root key/全history/実attempt_idを元scheduleの同じglobal requestへ対応させた。carrierのseedは明示的な共有generator batch seedであり、per-family RNG stateはUNKNOWN。Rootの通常arena admissionがfullprefix/historyを再生する責務は残す。JSON整合だけで新しいchronology資格とはしない。

既存normal configを共通baseに使って12configを生成し、共通plan/schedule/settings.runsの正常なRUN形を準備した。Engineのmodel path、typed identity、時計、名目深さ、LMR methodは実既存metadataと一致。Pythonにはmethod/namespace合成を置かない。既存imageでOFFのapprox/safeについて未対応Engine JSON fieldを加えていない。製品/generator既定は変更しない。

既存research-lifecycle.planned_game_sliceへ新384scheduleを渡し、全12batchのslot/二色/family coverageを確認した。192全件の元history対応と12×250M、per-game630784、model/clock/cap metadataも限定確認PASS。native arena、Search、forward、bootstrap、compiler/Cargo/testは実行していない。production deltaは不要でpatch/inverseはnull。

全192familyを一つの主要対照として後段で扱う。12chunkのnative CIを平均して全体CIにはしない。主要基準は元契約どおり、全384完成時だけ全192色pairを単位にした固定book条件の下限>.5。旧423の成績/CIや別B観測を混ぜず、一般棋力/Elo/非劣性の根拠へしない。この段階の勝敗は未観測。

## Rootの実entryで残る項目

actual output forecastとnative config.max_output_bytes、whole support/limits、実Experiment、current caller sources、環境、runtime/physical guardは未生成・未設定のまま。settings.runsのselection_indexは既存normal prepareが対応するrunへ付与する。draft-bindingにこの12位置対応を保存した。実refsのない項目はnullであり、ダミーFileRef・提出・launchはしない。

full arena_plan_checkはretention<=実output capやmodel/Experimentを検査するため、この未設定draftへ架空capを入れて成功化していない。Rootが実forecastを解決してconfig→plan→settingsを通常rebindし、normal Experiment/admissionで確認する。これは通常の未成立依存であり、親closeや人間/Root ACKを新しいgateにはしない。

手書きPythonはRuff format/check、draft JSON/本reportはproject Prettierで担当範囲だけ整形し、整形後のFileRefs/source_shaを再bindingした。元native入力、古いpacket、原FAILEDとNULL-vs-disk/capture/費UNKNOWNは不変。CPU8/G12/family1GiB/GPU0/reserve4GiBの実guardで子をdirectwait/reapし、exact identity/freshabsence/handles/TMPと終了STOPを保存する。idle leaseや将来quietの資格は主張しない。全旧pause/default/model/weight/sealと323/342.17の停止は変更しない。
