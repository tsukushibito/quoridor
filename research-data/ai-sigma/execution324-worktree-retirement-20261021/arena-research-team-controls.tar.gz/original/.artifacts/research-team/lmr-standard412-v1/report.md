# 412：Control fixed_one対depth_rankの追加比較draft

既存metadataで同じ開始系統と確定できた24 familyを除き、昇順104 familyの候補draftを作成した。NNUE主要・固定D副次で同じ104を二色ずつ使うため416局/208色pair、評価器ごとに全104familyを1 operation、計2 operationへまとめた。実行・提出・モデルpayload読取・旧勝敗の選択/再集計・RAW decodeは0。planned参照のmanifest metadataだけを使った。

**ready=false。** canonical LR/extension/endpoint群と旧cost後続rootの同値がmetadataだけでは未確定のため、104を最終資格済みfamilyとは呼ばない。選択候補と既知除外は結果前に固定し、Rootの既存入力資格で必要な群対応を解決する。独自分類器・新資格framework・人間ACKは作っていない。

## 除外の対応

| 元subject             | 確認した同一book/開始の根拠                                                                                                                    | family                                              |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------- |
| 408 exploratory arena | book SHAa6abde1f、config内exact prefix/root_key/history_counts                                                                                 | 14,16,23,27,37,38,39,44,64,74,82,86,103,109,118,124 |
| 400/402 arena         | 両planが同じbook SHA、各openingのprefix/root_key/historyを原bookへ一致                                                                         | 23,29,34,46,64,93,105,108                           |
| 400/402 cold cost     | 実Experiment input0が同book、JSON pointer /families/102 と /families/34を実arrayへ解決                                                         | 102,34                                              |
| 400/402 warm cost     | 実input1のgame0を元planned.jsonだけで照合。開始prefix [186,77,13,68] と完全historyがbook family0へ一意一致。prefix_len4/6/8/10はこの開始の継続 | 0                                                   |

数値ラベルだけでは除外していない。旧completed.jsonlには触れておらず、後続手そのものや結果は読んでいない。重複排除後の24 IDと各source/root/refはexclusion-proof.jsonにある。

元355 bookの128件はexact action prefixと完全root_key+historyのmetadata上で一意だが、LR・prefix延長・同endpointの群IDを保存していない。参照した0abbb版の生成/検査機能もexact prefix/historyを検査するが、book内compiled_sourcesの元生成sourceとは異なる版なので、そのhistorical byte一致や対称群資格は主張しない。既存quoridor_data::terminal::partition_familiesは群を作る正本で、common_corpusもこれを再用する。今回の許可はmetadata準備のみなので、代替Python分類器やnative/geometry実行を追加しなかった。旧costのprefix_len6/8/10と他familyの群衝突も、元開始family0への所属とは別にUNKNOWNである。必要な最小inletはこの既存群対応と、利用可能な凍結root metadataの正常な照合である。

既知除外：`0, 14, 16, 23, 27, 29, 34, 37, 38, 39, 44, 46, 64, 74, 82, 86, 93, 102, 103, 105, 108, 109, 118, 124`。

残る104候補の昇順：`1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 17, 18, 19, 20, 21, 22, 24, 25, 26, 28, 30, 31, 32, 33, 35, 36, 40, 41, 42, 43, 45, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 65, 66, 67, 68, 69, 70, 71, 72, 73, 75, 76, 77, 78, 79, 80, 81, 83, 84, 85, 87, 88, 89, 90, 91, 92, 94, 95, 96, 97, 98, 99, 100, 101, 104, 106, 107, 110, 111, 112, 113, 114, 115, 116, 117, 119, 120, 121, 122, 123, 125, 126, 127`。

## 共通条件と順序

主要関心はB=depth_rank。nativeのA=fixed_one原WDL/score/区間を保存し、B score=1−A、B区間=[1−A上限, 1−A下限]として提示する。人間の区間下限>0.5基準はBへ適用する。各評価器で事前選択全familyを一つのnative区間対象にし、旧408や副次Dとpoolしない。未完了があればその分母/UNKNOWNを保持し、完全収集に昇格しない。

| 位置づけ | 評価器          | 左A                       | 右B                        | 候補family / 局 / 色pair |
| -------- | --------------- | ------------------------- | -------------------------- | ------------------------ |
| 主要     | NNUE BEST43     | Control・LMR ON fixed_one | Control・LMR ON depth_rank | 104 / 208 / 104          |
| 副次     | FixedD(0,8tanh) | 同左A                     | 同左B                      | 104 / 208 / 104          |

同じ真正408 image bb63fc177c1a15eebfa888bbd649591650f725789f045ee6d8d5ee725389c497 / Build e934c534（実manifestはparse前hash照合）を宣言参照した。image/モデルpayloadや動的libraryを再読していない。現在のcaller/model/input/library対応はRootの正常bindingまでnullであり、再利用の現在資格を偽装しない。HEAD合わせのbuildを要求していない。

TT1048576、PVS、Control、LMR ON、100ms authority receipt/5ms reserve、node1M/depth64/200plyを固定。旧近似OFFは旧imageの既存設定、新exact safe leaf OFFは未変更408 codeに存在しないことによる。未対応JSON flagやfake zero counterは追加していない。actual method/namespaceはnative正本から将来記録し、PythonにID builderを作っていない。元408 qualified pure helper apply_comparison_arenaを固定body SHAからAST選択して再用した。

候補順はNNUE全104familyの昇順、次にDの同じ104family昇順。各familyの二色を連続配置し、最初のA色はfamily_id%2、次は反対色。seed41220261015、既存bootstrap設定10000は結果前のproposal。予定config/plan/scheduleは既存formatで、各configは104family/208局を保持し、各評価器のnative区間を全事前選択familyで一度だけ作る予定とした。32局subbatchの区間を平均しない。分母・全slot一意・両評価器の同family順・色・method・clock/TTをdraft-validation.jsonで検証した。

AI2/6、main/guardian4、family4GiB/GPU0/ext4 ownerをprospective値として記載した。future output/runtime/Experiment/support/currentcallerは未作成/未確定で、FileRefを捏造していない。actual physical/quiet/空きと411比較STOPはRootの実entryで再確認する。sequence draftは一つの連続順で、pairごとLLM/ACK/submissionを設けない。

## 出力forecastの未確定部分

元native arena_manifest::preflightの正本式を参照した。raw=games*(630784+1)、archive_cap=raw+ceil(raw/8192)*5+64、必要量=6\*(typed config bytes+native slots bytes)+8MiB+raw+archive_cap。

| 局/operation | 個数 | raw＋archive＋8MiB の既知項/operation | draft cap proposal |
| -----------: | ---: | ------------------------------------: | -----------------: |
|          208 |    2 |                           270875317 B |        335544320 B |

2本の既知項合計は541750634B。これはmetadata項を含まないcomponentで、完全forecast・予約・実retained量ではない。320MiB proposalをそのまま実retainedやwhole予算へ変換していない。native checked slotsの実serialized量が必要で、正確なnormal forecastと全retained/live union・decimal50GBへの適合はRootの通常entry準備で未完了。32MiB拒否の旧scopeを成功へ変更していない。

## 後続と限界

実run後だけ原manifest/receiptと128以外の実分母を用い、主要NNUEのB=depth_rankを対象にし、副次Dと混ぜずにWDL/family score/既存family区間、accepted depth中央値・全hist/平均、terminal work/LMR/TT/gauge、receipt/drain/fallback/errors/UNKNOWNを集計する。旧408は探索的結果の別subjectとして保持し、poolしない。共有開始familyを二倍の独立標本へせず、selective nominal depthを全幅証明や勝因へ変えない。孤立費/physicalNN/continuousRSS未記録はUNKNOWN。新bootstrap・Search・ゲームは今回発行していない。

必要handoffはsettings.json・plan.json・schedule.json・configs/・exclusion-proof.json・forecast-components.json。現在のsource/metadata scopeはここで停止し、Rootが既存群対応と通常binding/forecastを解決する。新しいreview/科学gateを増やさず、未確定をreadyへ昇格しない。Main/Git/Cargo/Beads/backup/closeは324のみ、411packetと全pause/defaults/weights/seals/旧RAWFAILED費を変更していない。

選択参照前後一致、format/lint、actual reader/child/directwait/reap/handles/TMP/lease STOPとOWN一回usageはcompletion.json/STOP.jsonに記録する。初回arena_runtime.rsという非存在Git pathの探索status128は読取helperログに保持し、そのsourceは実行していない。
