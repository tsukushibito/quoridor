"""Finite metadata-only412 drafts; no runtime, payload or outcome reader."""

import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent
INTEGRATION = Path("/workspaces/quoridor/.artifacts/research-team/integration324")
OLD = INTEGRATION / "lmr-adaptive408-v1/arena128-unentered-v1"
FUTURE = Path("/workspaces/quoridor/.worktree/assets/perf/lmr-standard412-arena-v1")
REFS = []


def file_ref(path):
    body = path.read_bytes()
    st = path.stat()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{st.st_mode & 0o777:04o}",
    )


def read(path, expected=None):
    body = path.read_bytes()
    actual = file_ref(path)
    if expected:
        for key, value in expected.items():
            assert actual[key] == value, (path, key)
    REFS.append(actual)
    return json.loads(body)


def write(name, value):
    path = OWN / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return file_ref(path)


old_plan = read(
    OLD / "plan.json",
    {"sha256": "51f0569acfd91db8c7d4d75aa8e2fc01fd7e285c864a525a07d1f4ca42cf0404"},
)
book = read(Path(old_plan["book"]["path"]), old_plan["book"])
assert book["complete"] is True and len(book["families"]) == 128
families = {f["family_id"]: f for f in book["families"]}
assert list(families) == list(range(128))
assert len({tuple(f["prefix"]) for f in families.values()}) == 128
assert (
    len(
        {
            json.dumps([f["root_key"], f["history_counts"]], sort_keys=True)
            for f in families.values()
        }
    )
    == 128
)
exclusions = {i: [] for i in families}


def exclude(family_id, source):
    exclusions[family_id].append(source)


for label, plan_path in [
    ("408 exploratory arena", OLD / "plan.json"),
    ("400 arena", INTEGRATION / "lmr400-v1/arena128-v4/plan.json"),
    ("402 arena", INTEGRATION / "shared-signed-ordering402-v1/arena128-v1/plan.json"),
]:
    plan = read(plan_path)
    assert plan["book"] == old_plan["book"]
    config = read(
        Path(plan["batches"][0]["config"]["path"]), plan["batches"][0]["config"]
    )
    for opening, fid in zip(
        config["arena"]["book"]["openings"], plan["family_ids"], strict=True
    ):
        f = families[fid]
        assert opening["prefix"] == f["prefix"]
        assert opening["reference"]["source_sha256"] == old_plan["book"]["sha256"]
        assert opening["reference"]["settings"]["family_id"] == fid
        for key in ("root_key", "history_counts"):
            assert opening["reference"]["settings"][key] == f[key]
        exclude(
            fid,
            dict(
                subject=label,
                plan=file_ref(plan_path),
                book_sha256=plan["book"]["sha256"],
                match="same immutable book + exact prefix/root_key/history",
                prefix=f["prefix"],
            ),
        )

for label, directory in [
    ("400 cost", INTEGRATION / "lmr400-v1/cost96-v2"),
    ("402 cost", INTEGRATION / "shared-signed-ordering402-v1/cost96-v1"),
]:
    settings = read(directory / "settings.json")
    experiment_ref = settings["measurements"][0]["experiment"]
    experiment = read(Path(experiment_ref["path"]), experiment_ref)
    config = read(Path(experiment["config"]["path"]), experiment["config"])
    assert experiment["inputs"][0] == old_plan["book"]
    for root in config["roots"]:
        if root["input"] == 0:
            parts = root["pointer"].split("/")
            assert parts[:2] == ["", "families"] and root["field"] == "prefix"
            index = int(parts[2])
            f = book["families"][index]
            assert f["family_id"] == index
            exclude(
                index,
                dict(
                    subject=label,
                    experiment=experiment_ref,
                    root=root,
                    book_sha256=old_plan["book"]["sha256"],
                    match="actual input0 same book + JSON pointer",
                    prefix=f["prefix"],
                ),
            )
        else:
            # Only original planned metadata: never open the completed.jsonl outcome input.
            input_ref = experiment["inputs"][root["input"]]
            metadata_dir = Path(input_ref["path"]).parent
            native = read(metadata_dir / "manifest.json")
            artifact = native["artifacts"]["planned.json"]
            planned_path = metadata_dir / "planned.json"
            planned = read(planned_path, artifact)
            rows = [
                r
                for r in planned
                if all(r[k] == v for k, v in root["jsonl_match"].items())
            ]
            assert len(rows) == 1 and rows[0]["replay_error"] is None
            row = rows[0]
            # Native planned metadata owns the full saved prefix history, not a numeric family label.
            matches = [
                f
                for f in families.values()
                if f["prefix"] == row["opening"]
                and f["history_counts"] == row["replay"]["history"]
            ]
            assert len(matches) == 1 and root["prefix_len"] >= len(row["opening"])
            f = matches[0]
            exclude(
                f["family_id"],
                dict(
                    subject=label,
                    experiment=experiment_ref,
                    root=root,
                    original_completed_input_declared_only=input_ref,
                    planned_metadata=file_ref(planned_path),
                    match="same exact opening + complete saved prefix history; later cost root is its continuation",
                    prefix=f["prefix"],
                    continuation_actions="not read; no outcome/RAW access",
                ),
            )

excluded = [i for i in families if exclusions[i]]
available = [i for i in families if not exclusions[i]]
assert excluded == [
    0,
    14,
    16,
    23,
    27,
    29,
    34,
    37,
    38,
    39,
    44,
    46,
    64,
    74,
    82,
    86,
    93,
    102,
    103,
    105,
    108,
    109,
    118,
    124,
]
assert len(available) == 104

# Reuse the qualified408 pure resolver without a copied implementation or namespace builder.
resolver_path = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/research-team/lmr-adaptive408-analysis-v1/research-lifecycle.py.immutable.gz"
)
body = gzip.decompress(resolver_path.read_bytes())
assert (
    hashlib.sha256(body).hexdigest()
    == "386d37456360402502569a4fc20a81309a2c5c4255ce7aaf37a8736ccb2167ef"
)
resolver_ref = file_ref(resolver_path)
tree = ast.parse(body)
node = next(
    n
    for n in tree.body
    if isinstance(n, ast.FunctionDef) and n.name == "apply_comparison_arena"
)
namespace = {}
exec(
    compile(
        ast.Module(body=[node], type_ignores=[]),
        "immutable408/research-lifecycle.py",
        "exec",
    ),
    namespace,
)
apply_arena = namespace["apply_comparison_arena"]
common = dict(
    tt_entries=1048576,
    use_tt=True,
    use_pvs=True,
    ruleset="standard_2p_threefold",
    family_B=4 * 1024**3,
    controller_B=64 * 1024**2,
    host_reserve_B=4 * 1024**3,
    arena=dict(
        return_reserve_ms=5,
        management_guardian=4,
        AI_workers=[2, 6],
        max_plies=200,
        depth=64,
        max_nodes=1000000,
        time_ms=100,
    ),
)
seed = 41220261015
templates = [
    read(OLD / "config-000.json", old_plan["batches"][0]["config"]),
    read(OLD / "config-002.json", old_plan["batches"][2]["config"]),
]
template_experiment = read(OLD / "experiment-template.json")
build_ref = template_experiment["build_manifest"]
assert (
    build_ref["sha256"]
    == "e934c534bedce904189c30ede4489a53a25c6664d876b87d5ca861b9ca7f56c2"
)
build = read(Path(build_ref["path"]), build_ref)
assert (
    build["artifact"]["sha256"]
    == "bb63fc177c1a15eebfa888bbd649591650f725789f045ee6d8d5ee725389c497"
)
artifact = build["artifact"]
chunks = [available]
schedule, batches, operations = [], [], []
for matchup, evaluator in enumerate(["nnue", "distance"]):
    for chunk_id, ids in enumerate(chunks):
        batch = len(batches)
        config = copy.deepcopy(templates[matchup])
        pair = [
            dict(evaluator=evaluator, profile="control", lmr=True),
            dict(evaluator=evaluator, profile="control", lmr=True),
        ]
        apply_arena(config, common, pair)
        assert [e["lmr_method"] for e in config["engines"]] == [
            "fixed_one",
            "depth_rank",
        ]
        assert config["arena"]["search_artifact_sha256"] == [artifact["sha256"]] * 2
        config.update(
            run_id=f"412-{evaluator}-control-fixed_one-vs-depth_rank-block{chunk_id:02}",
            output=str(FUTURE / f"batch-{batch:03}/data"),
            games=2 * len(ids),
            seed=seed,
        )
        # Operational proposals only; exact normal native forecast remains Root-owned.
        config["max_output_bytes"] = 320 * 1024**2
        a = config["arena"]
        a["bootstrap_seed"] = seed
        a["first_candidate_colors"] = [fid % 2 for fid in ids]
        a["book"].update(
            id=f"412-preoutcome-control-block{chunk_id:02}",
            independence="Fixed book; common families across evaluators and shared canonical initial lineage. LR/extension/endpoint grouping pending normal owning input qualification.",
        )
        opening_template = templates[matchup]["arena"]["book"]["openings"][0]
        a["book"]["openings"] = []
        slots = []
        for local_family, fid in enumerate(ids):
            f = families[fid]
            opening = copy.deepcopy(opening_template)
            opening.update(
                id=f["id"],
                lineage=f"original355-family-{fid}",
                original_seed=f["seed"],
                prefix=f["prefix"],
                selection_reason="412 ascending existing family IDs after exact same-book exclusions; canonical collision qualification pending",
                candidate_pool_size=f["attempt_id"] + 1,
            )
            opening["reference"]["settings"] = f
            a["book"]["openings"].append(opening)
            for color in [fid % 2, 1 - fid % 2]:
                slot = len(schedule)
                schedule.append(
                    dict(
                        slot=slot,
                        batch=batch,
                        matchup=matchup,
                        local_game=local_family * 2 + (color != fid % 2),
                        family_id=fid,
                        candidate_color=color,
                    )
                )
                slots.append(slot)
        config_ref = write(f"configs/config-{batch:03}.json", config)
        batches.append(
            dict(batch=batch, matchup=matchup, config=config_ref, slots=slots)
        )
        raw = config["games"] * (a["retained_outcome_bytes"] + 1)
        operations.append(
            dict(
                batch=batch,
                evaluator=evaluator,
                role="primary" if matchup == 0 else "secondary",
                family_ids=ids,
                games=config["games"],
                config=config_ref,
                output=config["output"],
                artifact_declared=artifact,
                build_manifest_declared=build_ref,
                current_artifact_model_caller_qualification=None,
                Experiment=None,
                runtime=None,
                support=None,
                ready=False,
                normal_output_forecast=None,
                native_forecast_source="arena_manifest::preflight: 6*(serialized config bytes+serialized native slots bytes)+8MiB+raw+archive_cap(raw)",
                raw_journal_bound_B=raw,
                output_cap_proposal_B=config["max_output_bytes"],
                cap_status="whole208-game operation proposal; Root must replace/confirm with exact normal native forecast before games; not measured retained usage",
            )
        )
schedule_ref = write("schedule.json", schedule)
plan = {
    k: copy.deepcopy(old_plan[k])
    for k in [
        "schema",
        "phase",
        "comparison",
        "rules",
        "distance_units",
        "value_perspective",
        "book",
        "inputs",
        "models",
    ]
}
plan.update(
    schedule=schedule_ref,
    family_ids=available,
    matchups=[
        copy.deepcopy(old_plan["matchups"][0]),
        copy.deepcopy(old_plan["matchups"][2]),
    ],
    batches=batches,
    planned_slots=len(schedule),
)
for index, matchup in enumerate(plan["matchups"]):
    matchup["id"] = index
plan_ref = write("plan.json", plan)
proof = dict(
    book=old_plan["book"],
    known_same_book_excluded_ids=excluded,
    exclusions=[dict(family_id=i, evidence=exclusions[i]) for i in excluded],
    remaining_candidate_ids=available,
    remaining_count=104,
    book_exact_prefix_and_fullhistory_unique=True,
    canonical_LR_extension_endpoint_groups="UNKNOWN: absent in355 book/plan metadata;355 native generate/validate checks exact prefixes and fullkey+history, not this quotient",
    owning_group_route="quoridor_data::terminal::partition_families(planned:&[(String,Vec<u16>)],seed); uses existing reflection, prefix-extension and canonical endpoint. Requires owning normal input qualification; no author native or replacement classifier.",
    warm_cost_continuation_aliases="Other-family LR/extension/endpoint equivalence with the original later cost roots is UNKNOWN without owning grouping/available fixed root metadata. No completed RAW opened.",
    selection_outcomes_read=False,
    no_new_classifier=True,
)
write("exclusion-proof.json", proof)
conditions = [
    dict(
        evaluator=evaluator,
        role="primary" if i == 0 else "secondary",
        ordering="control",
        left="fixed_one",
        right="depth_rank",
        lmr=True,
        TT=1048576,
        old_zero_stock_approximation=False,
        new_exact_safe_leaf="OFF by unchanged408 code: no unsupported field or fabricated counter",
        games=208,
        pairs=104,
    )
    for i, evaluator in enumerate(["NNUE BEST43", "FixedD(0,8tanh)"])
]
settings = dict(
    issue="quoridor-4lc.412.2",
    status="reviewable_draft_not_ready",
    primary_estimand=dict(
        method="depth_rank B",
        native_preserved="raw A fixed_one WDL/score/interval",
        B_score="1-A",
        B_interval="[1-A_upper,1-A_lower]",
        primary_criterion="B NNUE Control lower bound >0.5, within fixed conditions only",
        interval_scope="one native family bootstrap per evaluator covering all preselected families once; never average subbatch intervals; preserve incomplete/UNKNOWN",
    ),
    plan=plan_ref,
    schedule=schedule_ref,
    conditions=conditions,
    common=common,
    book=old_plan["book"],
    known_excluded=excluded,
    remaining_candidate_ids=available,
    planned_candidate_families=104,
    games=416,
    pairs=208,
    operations=operations,
    seed=seed,
    resolver=dict(
        source_gzip=resolver_ref,
        uncompressed_sha256=hashlib.sha256(body).hexdigest(),
        function="apply_comparison_arena",
    ),
    original408_image=artifact,
    original408_Build=build_ref,
    current412_qualification=None,
    sequence=dict(
        kind="sequence",
        owner=str(FUTURE),
        output=str(FUTURE / "execution-v1"),
        arena_block=2,
        serial_order=["arena", "measure"],
        arena_range=[0, len(batches) - 1],
        measurements=[],
        artifact=artifact,
        approved_plan=plan_ref,
        Experiment=None,
        support=None,
        caller_sources=None,
        runtime=None,
        ready=False,
    ),
    pending=[
        "existing canonical LR/extension/endpoint grouping for book and earlier named cost continuations; no metadata-only qualification invented",
        "normal current caller/model/input/image/library binding by Root",
        "normal native per-operation output forecast incl actual slots; concrete whole retained/live union within50GB",
        "actual411comparisonSTOP and fresh physical/quiet/resources at412entry",
    ],
    no_native_Search_games_model_payload_reads=True,
)
write("settings.json", settings)
for ref in REFS:
    assert file_ref(Path(ref["path"])) == ref
write("selected-refs.json", REFS)
write(
    "validation.json",
    dict(
        same_book_exclusions=24,
        candidate_families=104,
        games=416,
        pairs=208,
        operations=2,
        per_operation_games=[x["games"] for x in operations],
        all_slots_unique=len({x["slot"] for x in schedule}) == 416,
        both_evaluators_same_order=True,
        all_methods_explicit=True,
        normal_resolver_reused=True,
        unresolved_group_qualification=True,
        source_or_runtime_launches=0,
    ),
)
print(
    json.dumps(
        dict(
            excluded=excluded,
            remaining=len(available),
            games=len(schedule),
            operations=len(batches),
            per_operation_games=[x["games"] for x in operations],
            ready=False,
            pending=settings["pending"],
        ),
        ensure_ascii=False,
    )
)
