"""Scoped formatting and sparse exact patch freeze; never typecheck or test."""

import difflib
import gzip
import hashlib
import json
import resource
import shutil
import stat
import subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
TMP = OWN / "source-TEMP"
subjects = json.loads((OWN / "subjects.json").read_text())
changed, new = subjects["changed"], subjects["new"]
commands = []


def ref(path):
    raw = path.read_bytes()
    info = path.stat()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def call(name, argv, cwd=None):
    child = subprocess.Popen(
        argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, cwd=cwd
    )
    try:
        identity = {
            "pid": child.pid,
            "start_ticks": (Path("/proc") / str(child.pid) / "stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19],
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        }
    except FileNotFoundError:
        identity = {"pid": child.pid, "start_ticks": "UNKNOWN", "boot_id": "UNKNOWN"}
    out, err = child.communicate()
    assert len(out) + len(err) < 128 * 1024
    (OWN / (name + ".stdout")).write_bytes(out)
    (OWN / (name + ".stderr")).write_bytes(err)
    commands.append(
        {
            "name": name,
            "argv": argv,
            "identity": identity,
            "directwait_exit": child.returncode,
            "reaped": True,
            "handles_closed": True,
            "stdout": ref(OWN / (name + ".stdout")),
            "stderr": ref(OWN / (name + ".stderr")),
        }
    )
    assert child.returncode == 0, (name, err.decode())


rustfmt = Path(
    "/usr/local/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt"
)
tool_before = [ref(p) for p in [rustfmt, Path("/usr/bin/patch")]]
argv = [
    str(rustfmt),
    "--edition",
    "2024",
    "--config",
    "skip_children=true",
    *[str(TMP / r) for r in [*changed, *new]],
]
call("rustfmt", argv)
call("rustfmt-check", [*argv[:5], "--check", *argv[5:]])
before = {
    r: gzip.decompress((OWN / "before" / (r.replace("/", "__") + ".gz")).read_bytes())
    for r in changed
}
after = {r: (TMP / r).read_bytes() for r in [*changed, *new]}
for r in subjects["readonly_unchanged"]:
    assert (TMP / r).read_bytes() == gzip.decompress(
        (OWN / "before" / (r.replace("/", "__") + ".gz")).read_bytes()
    ), r


def body(text, marker):
    start = text.index(marker)
    opened = text.index("{", start)
    depth, end = 1, opened + 1
    while depth:
        if text[end] == "{":
            depth += 1
        elif text[end] == "}":
            depth -= 1
        end += 1
    return text[start:end]


protect = []
ai = "crates/quoridor-ai/src/alphabeta.rs"
old_ai, new_ai = before[ai].decode(), after[ai].decode()
for name in [
    "    fn control(",
    "    fn enter(",
    "    fn ordering_scores(",
    "    fn child(",
    "    fn reduced_child(",
    "    fn root_depth(",
    "    fn shared_signed_ordering(",
]:
    raw = body(old_ai, name)
    assert raw in new_ai, name
    protect.append(
        {
            "relative": ai,
            "scope": name,
            "sha256": hashlib.sha256(raw.encode()).hexdigest(),
            "bytes": len(raw.encode()),
        }
    )
runtime = "crates/quoridor-runner/src/runtime.rs"
for name in ["fn alpha_receipt_decision(", "fn evaluation_turn(", "fn commit_action("]:
    raw = body(before[runtime].decode(), name)
    assert raw in after[runtime].decode(), name
    protect.append(
        {
            "relative": runtime,
            "scope": name,
            "sha256": hashlib.sha256(raw.encode()).hexdigest(),
            "bytes": len(raw.encode()),
        }
    )
for r in [
    "crates/quoridor-ai/src/static_ordering.rs",
    "crates/quoridor-ai/src/cheap_static_ordering.rs",
]:
    raw = body(before[r].decode(), "pub(super) fn prepare(")
    assert raw in after[r].decode(), r
    protect.append(
        {
            "relative": r,
            "scope": "prepare scorer",
            "sha256": hashlib.sha256(raw.encode()).hexdigest(),
            "bytes": len(raw.encode()),
        }
    )
assert "new_for_ordering_assessment" not in "\n".join(
    p.read_text() for p in TMP.glob("crates/*/src/*.rs")
)
assert (
    "== crate::teacher_pilot_execution::EVALUATOR_ID"
    not in after["crates/quoridor-runner/src/measurement.rs"].decode()
)
assert ":cheap-static376-integer-parent-v1:" not in after[runtime].decode()


def diff(original, updated, relative):
    return "".join(
        difflib.unified_diff(
            original.decode().splitlines(keepends=True),
            updated.decode().splitlines(keepends=True),
            fromfile="a/" + relative if original else "/dev/null",
            tofile="b/" + relative if updated else "/dev/null",
        )
    )


forward = "".join(diff(before.get(r, b""), after[r], r) for r in [*changed, *new])
inverse = "".join(diff(after[r], before.get(r, b""), r) for r in [*changed, *new])
(OWN / "cleanup403.patch").write_text(forward)
(OWN / "cleanup403.inverse.patch").write_text(inverse)
roundtrip = OWN / "roundtrip-TEMP"
assert not roundtrip.exists()
roundtrip.mkdir()
for r, raw in before.items():
    p = roundtrip / r
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(raw)
call(
    "forward",
    [
        "/usr/bin/patch",
        "--batch",
        "--fuzz=0",
        "-p1",
        "-i",
        str(OWN / "cleanup403.patch"),
    ],
    roundtrip,
)
assert all((roundtrip / r).read_bytes() == after[r] for r in after)
call(
    "inverse",
    [
        "/usr/bin/patch",
        "--batch",
        "--fuzz=0",
        "-p1",
        "-i",
        str(OWN / "cleanup403.inverse.patch"),
    ],
    roundtrip,
)
assert all((roundtrip / r).read_bytes() == before[r] for r in before)
assert all(not (roundtrip / r).exists() for r in new)
assert [ref(Path(r["path"])) for r in tool_before] == tool_before
posts = []
for r, raw in after.items():
    posts.append(
        {
            "relative": r,
            "before": {
                "sha256": hashlib.sha256(before[r]).hexdigest(),
                "bytes": len(before[r]),
            }
            if r in before
            else "ABSENT",
            "after": {
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": "0644",
            },
        }
    )
for r in new:
    target = OWN / Path(r).name
    target.write_bytes(after[r])
for r in subjects["readonly_unchanged"]:
    (OWN / "before" / (r.replace("/", "__") + ".gz")).unlink()
shutil.rmtree(roundtrip)
shutil.rmtree(TMP)
(OWN / "static-proof.json").write_text(
    json.dumps(
        {
            "status": "FORMATTED_SPARSE_EXACT_FORWARD_INVERSE_PASS_NOT_NATIVE",
            "Git_base": subjects["base"],
            "posts": posts,
            "protected": protect,
            "readonly_unchanged": subjects["readonly_unchanged"],
            "new_file_absence_recovered": new,
            "patch": ref(OWN / "cleanup403.patch"),
            "inverse": ref(OWN / "cleanup403.inverse.patch"),
            "tools": tool_before,
            "commands": commands,
            "source_TEMP_roundtrip_removed": True,
            "native_type_tests_Search_model": "UNBUILT/UNTYPED/UNRUN",
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "source_format_patch_PASS": True,
            "changed": len(changed),
            "new": len(new),
            "native": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
