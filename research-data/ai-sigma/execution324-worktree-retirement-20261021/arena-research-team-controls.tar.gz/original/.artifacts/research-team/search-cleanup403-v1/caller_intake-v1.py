"""Named constructor callers on immutable accepted402 Git; no repository audit."""

import gzip
import hashlib
import json
import resource
import subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
BASE = "98444d57d5891d874b4851af1bda6a3b48c5d774"
commands = []


def git(args):
    argv = ["git", "-C", str(MAIN), *args]
    child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        identity = {
            "pid": child.pid,
            "start_ticks": (Path("/proc") / str(child.pid) / "stat")
            .read_text()
            .rsplit(")", 1)[1]
            .split()[19],
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        }
    except FileNotFoundError:
        identity = {"pid": child.pid, "start_ticks": "UNKNOWN", "boot_id": "UNKNOWN"}
    out, err = child.communicate()
    assert child.returncode == 0 and len(out) < 512 * 1024, (argv, err)
    commands.append(
        {
            "argv": argv,
            "identity": identity,
            "directwait_exit": 0,
            "reaped": True,
            "handles_closed": True,
        }
    )
    return out


names = (
    git(
        [
            "grep",
            "-l",
            "-E",
            "new_for_ordering_assessment|new_with_control_ordering",
            BASE,
            "--",
            "crates/quoridor-ai/src",
            "crates/quoridor-runner/src",
        ]
    )
    .decode()
    .splitlines()
)
relative = [name.split(":", 1)[1] for name in names]
subjects = []
for rel in [
    *relative,
    "crates/quoridor-ai/src/continuation_history.rs",
    "crates/quoridor-ai/src/static_ordering_tests.rs",
    "crates/quoridor-runner/src/teacher_pilot_execution.rs",
]:
    path = OWN / "source-TEMP" / rel
    if path.exists():
        continue
    raw = git(["show", BASE + ":" + rel])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    gz = OWN / "before" / (rel.replace("/", "__") + ".gz")
    gz.write_bytes(gzip.compress(raw, mtime=0))
    subjects.append(
        {
            "relative": rel,
            "Git_base": BASE,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "recovery": str(gz),
        }
    )
(OWN / "caller-intake.json").write_text(
    json.dumps(
        {
            "literal_constructor_callers": relative,
            "added_subjects": subjects,
            "commands": commands,
            "Main_Git_index_mutations": 0,
            "native_tests_calls": 0,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {"named_callers": len(relative), "additional_named_subjects": len(subjects)}
    )
)
