"""Private responsibility refactor on the frozen402 base; no native execution."""

import json
import re
import resource
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
TMP = OWN / "source-TEMP"


def path(relative):
    return TMP / relative


def change(relative, before, after):
    p = path(relative)
    s = p.read_text()
    assert before in s, (relative, before[:100])
    p.write_text(s.replace(before, after, 1))


AI = "crates/quoridor-ai/src/alphabeta.rs"
RUNTIME = "crates/quoridor-runner/src/runtime.rs"
MEASURE = "crates/quoridor-runner/src/measurement.rs"
method_code = """
/// Profile names are configuration, never inferred from an evaluator/namespace.
impl OrderingProfile {
    pub fn from_name(name: &str) -> Result<Self> {
        match name {
            "control" => Ok(Self::CheapStaticControl),
            "cheap" => Ok(Self::CombinedSignedCheapStatic),
            _ => Err(SearchError::Limits("unsupported signed ordering profile".into())),
        }
    }
    pub fn name(self) -> &'static str {
        match self {
            Self::CheapStaticControl => "control",
            Self::CombinedSignedCheapStatic => "cheap",
        }
    }
    pub fn namespace(self, namespace: SearchNamespace, lmr: bool) -> SearchNamespace {
        SessionMethod::Profile(self).namespace(namespace, lmr)
    }
}
// SignedControl is still an actual teacher/fixed-D constructor, not a shim.
// Keep that explicitly selected method identity across resets as well.
#[derive(Clone, Copy)]
enum SessionMethod {
    Plain,
    SignedControl,
    Profile(OrderingProfile),
}
fn append_lmr_method(namespace: &mut SearchNamespace) {
    namespace.selectivity.push(':');
    namespace.selectivity.push_str(LMR_METHOD);
}
impl SessionMethod {
    fn namespace(self, mut namespace: SearchNamespace, lmr: bool) -> SearchNamespace {
        match self {
            Self::Plain => {},
            Self::SignedControl => namespace.selectivity.push_str(":signed-control-goal-first"),
            Self::Profile(profile) => {
                namespace.selectivity.push(':');
                namespace.selectivity.push_str(cheap_static_ordering::ALGORITHM);
                namespace.selectivity.push(':');
                namespace.selectivity.push_str(profile.name());
            }
        }
        if lmr { append_lmr_method(&mut namespace); }
        namespace
    }
}
"""
change(
    AI,
    "/// A player/game owns this bounded table",
    method_code + "\n/// A player/game owns this bounded table",
)
change(
    AI,
    "    ordering_diagnostics: bool,\n    lmr: bool,\n}",
    "    ordering_diagnostics: bool,\n    lmr: bool,\n    method: SessionMethod,\n}",
)
change(
    AI,
    "                self.namespace.selectivity.push(':');\n                self.namespace.selectivity.push_str(LMR_METHOD);",
    "                append_lmr_method(&mut self.namespace);",
)
change(
    AI,
    '        mut namespace: SearchNamespace,\n        capacity: usize,\n        score_domain: ScoreDomain,\n    ) -> Result<Self> {\n        namespace.selectivity.push_str(":signed-control-goal-first");\n        let mut session = Self::create(evaluator, namespace, capacity, score_domain, true, false)?;\n        session.static_enabled = StaticMode::CheapControl;\n        Ok(session)\n    }',
    "        namespace: SearchNamespace,\n        capacity: usize,\n        score_domain: ScoreDomain,\n    ) -> Result<Self> {\n        let mut session = Self::create(evaluator, namespace, capacity, score_domain, true, false)?;\n        session.static_enabled = StaticMode::CheapControl;\n        session.method = SessionMethod::SignedControl;\n        session.namespace = session.method.namespace(session.namespace, false);\n        Ok(session)\n    }",
)
p = path(AI)
s = p.read_text()
start = s.index("    /// Current research Control/Cheap selection;")
end = s.index("    fn create(", start)
s = (
    s[:start]
    + """    /// Shared explicit Control/Cheap construction; product defaults are separate.
    pub fn new_with_ordering(
        evaluator: Arc<dyn StaticEvaluator>,
        namespace: SearchNamespace,
        capacity: usize,
        score_domain: ScoreDomain,
        profile: OrderingProfile,
        observe_ordering: bool,
        lmr: bool,
    ) -> Result<Self> {
        let mut session = Self::create(evaluator, namespace, capacity, score_domain, true, false)?;
        session.ordering_diagnostics = observe_ordering;
        session.static_enabled = match profile {
            OrderingProfile::CheapStaticControl => StaticMode::CheapControl,
            OrderingProfile::CombinedSignedCheapStatic => StaticMode::Cheap,
        };
        session.method = SessionMethod::Profile(profile);
        session.namespace = session.method.namespace(session.namespace, false);
        session.set_lmr(lmr)?;
        Ok(session)
    }
"""
    + s[end:]
)
s = s.replace(
    "            ordering_diagnostics: false,\n            lmr: false,",
    "            ordering_diagnostics: false,\n            lmr: false,\n            method: SessionMethod::Plain,",
    1,
)
start = s.index(
    "        // Bind current real profile/method again after caller namespace reset."
)
end = s.index("        self.score_domain = score_domain;", start)
s = (
    s[:start]
    + "        self.namespace = self.method.namespace(namespace, self.lmr);\n"
    + s[end:]
)
p.write_text(s)

# Mechanically migrate named test/current callers of the removed six-arg API.
ported = []
for p in sorted(TMP.glob("crates/*/src/*.rs")):
    s = p.read_text()
    matches = list(re.finditer(r"SearchSession::new_for_ordering_assessment\(", s))
    for m in reversed(matches):
        opened = m.end() - 1
        depth, quoted, escaped = 1, False, False
        end = opened + 1
        while depth:
            c = s[end]
            if quoted:
                if escaped:
                    escaped = False
                elif c == "\\":
                    escaped = True
                elif c == '"':
                    quoted = False
            elif c == '"':
                quoted = True
            elif c == "(":
                depth += 1
            elif c == ")":
                depth -= 1
            end += 1
        close = end - 1
        args = s[opened + 1 : close].rstrip()
        args += " false,\n" if args.endswith(",") else ", false\n"
        s = s[: m.start()] + "SearchSession::new_with_ordering(" + args + s[close:]
    if matches:
        p.write_text(s)
        ported.append(
            {
                "relative": str(p.relative_to(TMP)),
                "calls": len(matches),
                "change": "new name and explicit defaultOFF, old assertions retained",
            }
        )

# Runtime delegates names and complete method composition to the existing AI type.
p = path(RUNTIME)
s = p.read_text()
start = s.index("fn arena_alpha_namespace(")
end = s.index("fn arena_alpha_session(", start)
s = (
    s[:start]
    + """fn arena_alpha_namespace(
    engine: &Engine,
    base: alphabeta::SearchNamespace,
) -> alphabeta::Result<alphabeta::SearchNamespace> {
    match engine.ordering_profile.as_deref() {
        Some(name) => Ok(alphabeta::OrderingProfile::from_name(name)?.namespace(base, engine.lmr)),
        None if engine.lmr => Err(alphabeta::SearchError::Limits("LMR needs an explicit ordering target".into())),
        None => Ok(base),
    }
}
"""
    + s[end:]
)
start = s.index(
    "        let profile = match profile {", s.index("fn arena_alpha_session")
)
end = s.index("    } else if arena.is_some_and", start)
s = (
    s[:start]
    + """        let profile = alphabeta::OrderingProfile::from_name(profile)?;
        alphabeta::SearchSession::new_with_ordering(
            evaluator, base, capacity, quoridor_ai::score::ScoreDomain::LEGACY,
            profile, false, engine.lmr,
        )?
"""
    + s[end:]
)
for variable in ["search_result", "result"]:
    marker = f"let {variable} = invoke_alpha_observed("
    start = s.index(marker)
    opened = s.index("(", start)
    depth, end = 1, opened + 1
    while depth:
        if s[end] == "(":
            depth += 1
        elif s[end] == ")":
            depth -= 1
        end += 1
    # The constructor callback now receives the namespace only after typed parse.
    s = s[:end] + ")" + s[end:]
    s = s[:start] + s[start:].replace(
        marker,
        f"let {variable} = namespace.and_then(|namespace| invoke_alpha_observed(",
        1,
    )
p.write_text(s)
# Mechanical expected-namespace test adaptation, not an old assertion replay.
change(
    "crates/quoridor-runner/src/runtime_lmr400_tests.rs",
    "&arena_alpha_namespace(&e, namespace())",
    "&arena_alpha_namespace(&e, namespace()).unwrap()",
)

# Measurement chooses from its explicit typed profile, never evaluator text.
p = path(MEASURE)
s = p.read_text()
start = s.index("        let mut session = match self.settings.profile {")
end = s.index("        let method = session.namespace()", start)
s = (
    s[:start]
    + """        let session = match self.settings.profile.native() {
            None => SearchSession::new(self.evaluator.clone(), namespace, self.settings.tt_entries)?,
            Some(profile) => SearchSession::new_with_ordering(
                self.evaluator.clone(), namespace, self.settings.tt_entries,
                quoridor_ai::score::ScoreDomain::LEGACY, profile,
                request.diagnostic, self.settings.lmr,
            )?,
        };
"""
    + s[end:]
)
p.write_text(s)
# Arena's operation-specific kind/globaldisable exclusions remain here.
change(
    "crates/quoridor-runner/src/arena.rs",
    '!matches!(profile, "control" | "cheap")',
    "quoridor_ai::alphabeta::OrderingProfile::from_name(profile).is_err()",
)

# Core's private u8 neighbours/WallEdges are not an accessible matching API.
# One minimal internal usize/legal-wall helper, no BFS/coverage/Cheap math merge.
geometry = """//! Wall-only grid arithmetic shared by the two different static scorers.
pub(super) fn neighbours(cell: usize) -> [Option<usize>; 4] {
    debug_assert!(cell < 81);
    [
        (cell >= 9).then(|| cell - 9),
        (cell < 72).then(|| cell + 9),
        (!cell.is_multiple_of(9)).then(|| cell - 1),
        (cell % 9 < 8).then(|| cell + 1),
    ]
}
pub(super) fn blocked_edges(action: u16) -> [(usize, usize); 2] {
    debug_assert!((81..209).contains(&action));
    let horizontal = action < 145;
    let anchor = usize::from(action - if horizontal { 81 } else { 145 });
    let cell = (anchor / 8) * 9 + anchor % 8;
    if horizontal {
        [(cell, cell + 9), (cell + 1, cell + 10)]
    } else {
        [(cell, cell + 1), (cell + 9, cell + 10)]
    }
}
"""
path("crates/quoridor-ai/src/static_geometry.rs").write_text(geometry)
change(
    AI,
    '#[path = "static_ordering.rs"]\nmod static_ordering;',
    '#[path = "static_ordering.rs"]\nmod static_ordering;\n#[path = "static_geometry.rs"]\nmod static_geometry;',
)
for relative in [
    "crates/quoridor-ai/src/static_ordering.rs",
    "crates/quoridor-ai/src/cheap_static_ordering.rs",
]:
    p = path(relative)
    s = p.read_text()
    for name in ["neighbours", "blocked_edges"]:
        start = s.index("fn " + name + "(")
        opened = s.index("{", start)
        depth, end = 1, opened + 1
        while depth:
            if s[end] == "{":
                depth += 1
            elif s[end] == "}":
                depth -= 1
            end += 1
        s = s[:start] + s[end:]
    s = "use super::static_geometry::{blocked_edges, neighbours};\n" + s
    p.write_text(s)
path(AI).write_text(
    path(AI).read_text()
    + '\n#[cfg(test)]\n#[path = "search_settings403_tests.rs"]\nmod search_settings403_tests;\n'
)
(OWN / "refactor-metadata.json").write_text(
    json.dumps(
        {
            "base": "accepted402 Git98444d57",
            "mechanical_callers": ported,
            "active_constructor_retained": "new_with_control_ordering used by actual teacher/fixedD and TT tests",
            "retired": [
                "new_for_ordering_assessment old naming/API with all named callers",
                "measurement evaluator-name-derived constructor selector",
                "two duplicate geometry function pairs",
            ],
            "new_method_state": "Explicit Plain/SignedControl/Profile, no namespace-to-settings inference; layout UNRUN",
            "math_default_search_test_execution": 0,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {
            "refactor_private_only": True,
            "old_api_calls_migrated": sum(p["calls"] for p in ported),
            "native_tests": "UNBUILT/UNTYPED/UNRUN",
        }
    )
)
