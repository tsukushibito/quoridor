"""Named immutable Git intake on the accepted402 base, no Main writer."""

import gzip
import hashlib
import json
import os
import resource
import subprocess
from pathlib import Path

resource.setrlimit(resource.RLIMIT_AS, (480 * 1024**2, 480 * 1024**2))
OWN = Path(__file__).resolve().parent
MAIN = Path("/workspaces/quoridor")
BASE = "98444d57d5891d874b4851af1bda6a3b48c5d774"
SUBJECTS = [
    "crates/quoridor-ai/src/alphabeta.rs",
    "crates/quoridor-ai/src/lib.rs",
    "crates/quoridor-ai/src/static_ordering.rs",
    "crates/quoridor-ai/src/cheap_static_ordering.rs",
    "crates/quoridor-ai/src/shared_signed402_tests.rs",
    "crates/quoridor-ai/src/lmr400_tests.rs",
    "crates/quoridor-ai/src/cheap376_tests.rs",
    "crates/quoridor-runner/src/runtime.rs",
    "crates/quoridor-runner/src/measurement.rs",
    "crates/quoridor-runner/src/arena.rs",
    "crates/quoridor-runner/src/runtime_lmr400_tests.rs",
    "crates/quoridor-core/src/position.rs",
]
tools = []
refs = []
tmp = OWN / "source-TEMP"
assert not tmp.exists()
tmp.mkdir()
(OWN / "before").mkdir()
for relative in SUBJECTS:
    argv = ["git", "-C", str(MAIN), "show", BASE + ":" + relative]
    child = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    try:
        proc = Path("/proc") / str(child.pid) / "stat"
        identity = {
            "pid": child.pid,
            "start_ticks": proc.read_text().rsplit(")", 1)[1].split()[19],
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        }
    except FileNotFoundError:
        identity = {"pid": child.pid, "start_ticks": "UNKNOWN", "boot_id": "UNKNOWN"}
    raw, error = child.communicate()
    assert child.returncode == 0 and len(raw) < 512 * 1024 and len(error) < 64 * 1024, (
        relative,
        error,
    )
    tools.append(
        {
            "argv": argv,
            "identity": identity,
            "directwait_exit": child.returncode,
            "reaped": True,
            "handles_closed": True,
        }
    )
    path = tmp / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw)
    compressed = OWN / "before" / (relative.replace("/", "__") + ".gz")
    compressed.write_bytes(gzip.compress(raw, mtime=0))
    refs.append(
        {
            "relative": relative,
            "Git_base": BASE,
            "sha256": hashlib.sha256(raw).hexdigest(),
            "bytes": len(raw),
            "recovery": str(compressed),
        }
    )
stop = Path(
    "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/shared-signed-ordering402-v1/source-STOP.json"
)
raw = stop.read_bytes()
assert (
    hashlib.sha256(raw).hexdigest()
    == "99faaaa2f7e2ea61c903b87952727cdac63d641c6a8ab677d7daae48303bacf7"
    and len(raw) == 50152
)
frozen = json.loads(raw)
for item in frozen["subjects"]:
    if item["relative"] in SUBJECTS:
        own = next(r for r in refs if r["relative"] == item["relative"])
        assert (own["sha256"], own["bytes"]) == (
            item["after"]["sha256"],
            item["after"]["bytes"],
        )
(OWN / "intake.json").write_text(
    json.dumps(
        {
            "Git_base": BASE,
            "frozen402": {
                "path": str(stop),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "bytes": len(raw),
                "mode": "0644",
            },
            "subjects": refs,
            "tools": tools,
            "source_CPU": sorted(os.sched_getaffinity(0)),
            "Main_Git_index_Cargo_source_writes": 0,
            "native_test_Search_model_geometry_game_calls": 0,
        },
        ensure_ascii=False,
        indent=2,
    )
    + "\n"
)
print(
    json.dumps(
        {"named_Git_subjects": len(refs), "base402_exact": True, "science_calls": 0}
    )
)
