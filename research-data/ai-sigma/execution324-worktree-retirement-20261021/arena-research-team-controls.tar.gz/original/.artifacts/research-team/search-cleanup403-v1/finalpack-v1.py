"""Bind the frozen sparse source and inspect original owned process identities."""

import datetime
import gzip
import hashlib
import json
import os
import re
import stat
from pathlib import Path

OWN = Path(__file__).resolve().parent


def ref(path):
    data = path.read_bytes()
    info = path.stat()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }


def emit(name, value):
    with (OWN / name).open("x") as output:
        output.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def verify(binding):
    actual = ref(Path(binding["path"]))
    assert actual == binding, (actual, binding)
    return actual


proof_ref = ref(OWN / "static-proof.json")
proof = json.loads((OWN / "static-proof.json").read_text())
verify(proof["patch"])
verify(proof["inverse"])
assert "shared_signed402_tests.rs" not in (OWN / "cleanup403.patch").read_text()
recovery = []
for subject in proof["posts"]:
    if subject["before"] == "ABSENT":
        actual = ref(OWN / Path(subject["relative"]).name)
        assert all(
            actual[k] == subject["after"][k] for k in ("sha256", "bytes", "mode")
        )
    else:
        path = OWN / "before" / (subject["relative"].replace("/", "__") + ".gz")
        data = gzip.decompress(path.read_bytes())
        assert hashlib.sha256(data).hexdigest() == subject["before"]["sha256"]
        assert len(data) == subject["before"]["bytes"]
        recovery.append(
            {
                "relative": subject["relative"],
                "compressed": ref(path),
                "before": subject["before"],
            }
        )
assert len(recovery) == 11
source = (OWN / "search_settings403_tests.rs").read_text()
names = re.findall(r"^fn ((?:settings403|geometry403)_\w+)\(", source, re.MULTILINE)
assert len(names) == 4
emit(
    "verification-plan.json",
    {
        "status": "UNBUILT/UNTYPED/UNRUN",
        "author_native_tests": 0,
        "new_tests": [
            {
                "package": "quoridor-ai",
                "exact_filter": "alphabeta::search_settings403_tests::" + name,
                "expected_tests": 1,
            }
            for name in names
        ],
        "total_new_definitions": 4,
        "required_Root_scope": [
            "AI/runner research and research-diagnostics compile",
            "four changed-boundary definitions once",
            "affected Clippy and genuine optimized comparison image",
        ],
        "mechanical_caller_test_changes": "compile only; no old successful assertion replay",
        "original402_scopes": "new6/affected4 original PASS retained; no automatic replay",
        "review_question": "positive settings-to-method, raw/qualified namespace/reset, active SignedControl, operation exclusions and independent legal-edge geometry; join existing related402 review",
        "study_settings": {
            "NNUE_TT": 1048576,
            "fixed_D_TT": 1048576,
            "owner": "Root settings-only derivation; frozen402.2 unchanged",
            "Rust_TT_correction_change": False,
            "calls": 96,
            "games": 128,
        },
        "new_image": None,
        "new_Build": None,
        "actual_Experiment": None,
    },
)
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
identities = {}
records = []


def collect(value):
    if isinstance(value, dict):
        if all(k in value for k in ("pid", "start_ticks", "boot_id")):
            identities[(value["pid"], str(value["start_ticks"]), value["boot_id"])] = (
                value
            )
        for child in value.values():
            collect(child)
    elif isinstance(value, list):
        for child in value:
            collect(child)


for path in sorted(OWN.glob("*/*.process.json")):
    binding = ref(path)
    collect(json.loads(path.read_text()))
    records.append(binding)
for name in ("intake.json", "caller-intake.json", "static-proof.json"):
    collect(json.loads((OWN / name).read_text()))
fresh = []
for old in identities.values():
    path = Path("/proc") / str(old["pid"]) / "stat"
    try:
        current = {
            "pid": old["pid"],
            "start_ticks": path.read_text().rsplit(")", 1)[1].split()[19],
            "boot_id": boot,
        }
    except FileNotFoundError:
        current = None
    assert current != old, (old, current)
    fresh.append(
        {
            "original": old,
            "fresh": current,
            "state": "ABSENT" if current is None else "DIFFERENT_IDENTITY",
        }
    )
tmp_paths = [OWN / "source-TEMP", OWN / "roundtrip-TEMP"]
tmp_paths += [p / "TMP" for p in OWN.iterdir() if p.is_dir() and p.name != "before"]
assert not any(p.exists() for p in tmp_paths)
assert ref(OWN / "static-proof.json") == proof_ref
emit(
    "frozen-metadata.json",
    {
        "checked_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "static_proof": proof_ref,
        "patch": proof["patch"],
        "inverse": proof["inverse"],
        "posts": proof["posts"],
        "minimum_before_recovery": recovery,
        "new_definitions": [
            ref(OWN / "search_settings403_tests.rs"),
            ref(OWN / "static_geometry.rs"),
        ],
        "verification_plan": ref(OWN / "verification-plan.json"),
        "report": ref(OWN / "report-ja.md"),
        "authoritative_persisted_process_records": records,
        "fresh_original_process_identities": fresh,
        "original_formatter_fast_identity": "UNKNOWN after original pre-collection exception; original checked directwait0/logs referenced in static proof, original FAILED unchanged",
        "known_TMP_paths_absent": [str(p) for p in tmp_paths],
        "old_returned_vs_persisted": "Original guardian_return NULL/capturefalse remain in original failed receipts; these fresh identity facts do not synthesize returned receipts",
        "Main_source_Git_native_test_Search_model_geometry_game_changes_calls": 0,
        "private_source_writer_STOP": "2026-10-14T22:33:01.056732+00:00",
    },
)
print(
    json.dumps(
        {
            "frozen_metadata": ref(OWN / "frozen-metadata.json"),
            "fresh_identities": len(fresh),
            "new_test_definitions": 4,
        }
    )
)
