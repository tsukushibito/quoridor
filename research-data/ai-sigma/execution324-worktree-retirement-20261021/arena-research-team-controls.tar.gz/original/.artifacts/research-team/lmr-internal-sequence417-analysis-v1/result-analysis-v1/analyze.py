"""Deterministic arithmetic on the frozen 417 compact collection only."""

import csv
import hashlib
import json
import os
import statistics
import struct
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

OWN = Path(__file__).resolve().parent
BASE = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/"
    "lmr-internal-sequence417-v1/diagnostic204-v1/collection-v1"
)


def load(path):
    return json.loads(path.read_text())


def save(name, value):
    (OWN / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def file_ref(path):
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
    }


def table(name, rows):
    with (OWN / name).open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def float_value(bits):
    return struct.unpack("!f", struct.pack("!I", bits))[0]


def nonclock(arm):
    return {
        k: v
        for k, v in arm.items()
        if k
        not in {
            "label",
            "repeat",
            "arm_index",
            "kernel_elapsed_ns",
            "whole_elapsed_ns",
            "Search_internal_elapsed_seconds",
        }
    }


def parent_id(branch):
    parent = dict(branch["parent"])
    parent["history_counts"] = sorted(parent["history_counts"])
    return json.dumps(parent, sort_keys=True)


assert sorted(os.sched_getaffinity(0)) == [5]
refs = load(OWN / "original-refs-before.json")
for item in refs:
    assert file_ref(Path(item["path"])) == item
result = load(BASE / "result.json")
roots = load(BASE / "roots.json")
assert len(roots) == 12 and len({r["root_id"] for r in roots}) == 12
assert load(BASE / "STOP.json")["branch_shards"] == result["branch_shards"]
branches = []
for item in result["branch_shards"]:
    actual = file_ref(Path(item["path"]))
    assert all(actual[k] == item[k] for k in actual)
    refs.append(actual)
    branches.extend(load(Path(item["path"])))
assert len(branches) == 48
spec = OWN.parent / "spec-ja.md"
assert (
    file_ref(spec)["sha256"]
    == "4bd725f25597e661e8665163be1c4c010d99d0fd57be1ab13a7d8894c87f6745"
)
refs.append(file_ref(spec))
settings = Path(result["settings"]["path"])
actual = file_ref(settings)
assert all(actual[k] == result["settings"][k] for k in actual)
refs.append(actual)
save("selected-refs-before.json", refs)

branch_rows, trial_rows, coverage_rows, root_rows = [], [], [], []
grouped = defaultdict(list)
seen = set()
parents = defaultdict(set)
for row in branches:
    b = row["branch"]
    root = roots[row["root_index"]]
    assert root["root_id"] == row["root_id"] and root["evaluator"] == row["evaluator"]
    assert (b["iteration_depth"], b["parent_depth"], b["parent_ply"]) == (5, 3, 2)
    hypothesis, rank = b["hypothesis"], b["distinct_rank"]
    assert b["eligible"] and b["original_q"] == (0 if hypothesis == "H0" else 1)
    if hypothesis == "H0":
        assert 4 <= rank <= 8
    identity = parent_id(b)
    key = (row["root_index"], identity, b["action"])
    assert key not in seen
    seen.add(key)
    parent_set = parents[row["root_index"], hypothesis]
    assert identity not in parent_set
    parent_set.add(identity)
    arms = b["arms"]
    assert [a["label"] for a in arms] == ["N1", "R1", "R2", "N2"]
    n1, r1, r2, n2 = arms
    assert nonclock(n1) == nonclock(n2) and nonclock(r1) == nonclock(r2)
    alpha_bits = b["post_TT_pre_child_alpha_beta_bits"][0]
    window = n1["window_bits"]
    assert window[0] == alpha_bits and float_value(window[1]) > float_value(window[0])
    alpha = float_value(alpha_bits)
    expected_next = 1 if alpha == 0 else alpha_bits + (1 if alpha > 0 else -1)
    assert window[1] == expected_next
    for arm in arms:
        assert arm["status"] == "COMPLETE" and arm["parent_restored"]
        assert arm["protocol_complete"] and arm["state_work_known"]
        assert arm["initial_TT_entries"] == 0 and arm["node_cap_total"] == 100000
        assert arm["window_bits"] == window and arm["child_scouts"] == 1
        stage = arm["stages"][0]
        assert arm["stages"][1] is None and stage["completed"]
        assert stage["window_bits"] == window
        assert (
            stage["value_bits"] == arm["value_bits"] and stage["bound"] == arm["bound"]
        )
        assert stage["nodes_after"] - stage["nodes_before"] == arm["work"]["nodes"]
        assert (
            stage["evaluations_after"] - stage["evaluations_before"]
            == arm["work"]["evaluations"]
        )
        assert arm["work"]["nodes"] <= 100000
        assert arm["whole_elapsed_ns"] >= arm["kernel_elapsed_ns"] >= 0
        value, alpha = float_value(arm["value_bits"]), float_value(alpha_bits)
        assert (value <= alpha) == (arm["bound"] == "Upper")
        assert arm["returned_child_depth"] == (2 if arm["arm"] == "N" else 1)
        assert not arm["confirmation_entered"] and arm["confirmation_completed"] is None
        if arm["arm"] == "R":
            assert arm["confirmation_condition"] is False and arm["bound"] == "Upper"
        trial_rows.append(
            {
                "root_index": row["root_index"],
                "root_id": row["root_id"],
                "evaluator": row["evaluator"],
                "slot": b["slot"],
                "arm": arm["label"],
                "value_bits": arm["value_bits"],
                "bound": arm["bound"],
                "returned_child_depth": arm["returned_child_depth"],
                "kernel_ns": arm["kernel_elapsed_ns"],
                "whole_ns": arm["whole_elapsed_ns"],
                **arm["work"],
            }
        )
    warm = b["original_stages"][0]
    assert warm["completed"] and warm["window_bits"] == window
    assert warm["child_depth"] == (2 if hypothesis == "H0" else 1)
    if hypothesis == "H+":
        assert warm["bound"] == "Upper"
    cold = n1 if hypothesis == "H0" else r1
    record = {
        "root_index": row["root_index"],
        "root_id": row["root_id"],
        "evaluator": row["evaluator"],
        "hypothesis": hypothesis,
        "slot": b["slot"],
        "rank": rank,
        "q": b["original_q"],
        "visit_serial": b["eligible_visit_serial"],
        "action": b["action"],
        "parent_identity_sha256": hashlib.sha256(identity.encode()).hexdigest(),
        "alpha_bits": alpha_bits,
        "scout_beta_bits": window[1],
        "parent_wide_beta_bits": b["post_TT_pre_child_alpha_beta_bits"][1],
        "warm_value_bits": warm["value_bits"],
        "warm_bound": warm["bound"],
        "warm_depth": warm["child_depth"],
        "warm_cold_comparator": cold["arm"],
        "warm_cold_bits_equal": warm["value_bits"] == cold["value_bits"],
        "warm_cold_bounds_equal": warm["bound"] == cold["bound"],
        "N_value_bits": n1["value_bits"],
        "R_value_bits": r1["value_bits"],
        "N_value": float_value(n1["value_bits"]),
        "R_value": float_value(r1["value_bits"]),
        "alpha": float_value(alpha_bits),
        "N_bound": n1["bound"],
        "R_bound": r1["bound"],
        "N_R_bits_equal": n1["value_bits"] == r1["value_bits"],
        "N_nodes_each": n1["work"]["nodes"],
        "R_nodes_each": r1["work"]["nodes"],
        "N_evals_each": n1["work"]["evaluations"],
        "R_evals_each": r1["work"]["evaluations"],
    }
    for cost in ["kernel", "whole"]:
        values = [a[f"{cost}_elapsed_ns"] for a in arms]
        for label, value in zip(["N1", "R1", "R2", "N2"], values, strict=True):
            record[f"{label}_{cost}_ns"] = value
        nmean, rmean = (values[0] + values[3]) / 2, (values[1] + values[2]) / 2
        spread = max(abs(values[0] - values[3]), abs(values[1] - values[2]))
        record[f"N_mean_{cost}_ns"] = nmean
        record[f"R_mean_{cost}_ns"] = rmean
        record[f"R_minus_N_{cost}_ns"] = rmean - nmean
        record[f"N_repeat_span_{cost}_ns"] = abs(values[0] - values[3])
        record[f"R_repeat_span_{cost}_ns"] = abs(values[1] - values[2])
        record[f"difference_exceeds_max_repeat_span_{cost}"] = (
            abs(rmean - nmean) > spread
        )
    branch_rows.append(record)
    grouped[row["evaluator"], hypothesis].append(record)

for root in roots:
    index, obs, measurement = (
        root["root_index"],
        root["observation"],
        root["measurement"],
    )
    selected = [b for b in branch_rows if b["root_index"] == index]
    assert len(selected) == 4 and all(len(parents[index, h]) == 2 for h in ["H0", "H+"])
    assert measurement["status"] == "COMPLETE" and measurement["completed_depth"] == 5
    assert obs["missing_branch_slots"] == 0 and obs["root_completed_D5_and_restored"]
    root_rows.append(
        {
            "root_index": index,
            "root_id": root["root_id"],
            "evaluator": root["evaluator"],
            "root_nodes": measurement["work"]["nodes"],
            "root_evals": measurement["work"]["evaluations"],
            "root_Search_call_seconds": measurement["Search_call_seconds"],
            "arm_nodes": obs["arm_recorded_nodes"],
            "arm_evals": obs["arm_recorded_evaluations"],
            "H0_NLower_RUpper_branches": sum(
                b["hypothesis"] == "H0" and b["N_bound"] == "Lower" for b in selected
            ),
            "ranks_H0_Hplus": "/".join(str(b["rank"]) for b in selected),
            "warm_cold_same_bits": sum(b["warm_cold_bits_equal"] for b in selected),
            "arm_confirmation_entered": obs["R_confirmation_entered"],
            "root_all_depth_LMR_confirmations": measurement["work"][
                "LMR_full_depth_confirmations"
            ],
        }
    )
    for rank_i, cells in enumerate(obs["coverage"]):
        for quantum, cell in enumerate(cells):
            coverage_rows.append(
                {
                    "root_index": index,
                    "evaluator": root["evaluator"],
                    "rank_band": obs["coverage_axes"]["distinct_rank"][rank_i],
                    "q": quantum,
                    **cell,
                }
            )

summary_groups = []
for (evaluator, hypothesis), rows in grouped.items():
    output = {
        "evaluator": evaluator,
        "hypothesis": hypothesis,
        "branches": len(rows),
        "R_N_bounds": dict(Counter(b["R_bound"] + "/" + b["N_bound"] for b in rows)),
        "rank_counts": dict(Counter(b["rank"] for b in rows)),
        "warm_cold_same_bits": sum(b["warm_cold_bits_equal"] for b in rows),
        "warm_cold_same_bounds": sum(b["warm_cold_bounds_equal"] for b in rows),
        "N_R_same_bits": sum(b["N_R_bits_equal"] for b in rows),
    }
    for arm in ["N", "R"]:
        for work in ["nodes", "evals"]:
            output[f"{arm}_{work}_both_repeats"] = 2 * sum(
                b[f"{arm}_{work}_each"] for b in rows
            )
    for cost in ["kernel", "whole"]:
        for arm in ["N", "R"]:
            output[f"{arm}_median_branch_mean_{cost}_ns"] = statistics.median(
                b[f"{arm}_mean_{cost}_ns"] for b in rows
            )
            output[f"{arm}_median_repeat_span_{cost}_ns"] = statistics.median(
                b[f"{arm}_repeat_span_{cost}_ns"] for b in rows
            )
        differences = [b[f"R_minus_N_{cost}_ns"] for b in rows]
        output[f"median_R_minus_N_{cost}_ns"] = statistics.median(differences)
        output[f"R_lower_{cost}_branches"] = sum(x < 0 for x in differences)
        output[f"difference_exceeds_repeat_span_{cost}_branches"] = sum(
            b[f"difference_exceeds_max_repeat_span_{cost}"] for b in rows
        )
        output[f"N1_gt_N2_{cost}_branches"] = sum(
            b[f"N1_{cost}_ns"] > b[f"N2_{cost}_ns"] for b in rows
        )
    summary_groups.append(output)

assert sum(t["nodes"] for t in trial_rows) == 16322
assert sum(t["evaluations"] for t in trial_rows) == 14276
assert sum(r["root_nodes"] for r in root_rows) == 4062877
assert result["recorded_total_nodes"] == 4079199
for ref in refs:
    assert file_ref(Path(ref["path"])) == ref
save("selected-refs-after.json", refs)
table("branches.csv", branch_rows)
table("trials.csv", trial_rows)
table("roots.csv", root_rows)
table("coverage.csv", coverage_rows)
summary = {
    "groups": summary_groups,
    "census": result["census"],
    "outer_seconds_once": result["outer_seconds"],
    "root_nodes": 4062877,
    "arm_nodes": 16322,
    "arm_evaluations": 14276,
    "total_nodes": 4079199,
    "total_entries": 204,
    "all_roots_complete": 12,
    "all_arms_complete": 192,
    "missing_UNKNOWN": 0,
    "repeated_nonclock_matches": {"N": 48, "R": 48},
    "cold_confirmation_entered": 0,
    "cold_confirmation_unused": 96,
    "reader_stopped_at": datetime.now(timezone.utc).isoformat(),
    "scientific_calls": 0,
    "additional_original_payload_reads": 0,
}
save("summary.json", summary)
save(
    "verification.json",
    {
        "status": "PASS",
        "verified_original_refs": len(refs),
        "checks": [
            "fixed hashes before/after",
            "48 unique fullhistory+action branches",
            "two distinct parents per hypothesis/root",
            "final iteration5,parentd3,ply2",
            "same scout windows and returned bounds/depths",
            "NRRN and nonclock repeat equality",
            "stage and cumulative work identity",
            "root/arm node and eval sums",
        ],
        "helper": file_ref(Path(__file__)),
        "scope": "saved arithmetic only",
    },
)
print(json.dumps(summary, ensure_ascii=False))
