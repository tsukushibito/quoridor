"""Use the existing process guardian for this finite saved-result analysis."""

import json
import os
import sys
from pathlib import Path

from quoridor_training.cycle_process import CycleResources, execute

own = Path(__file__).resolve().parent
out = own / sys.argv[1]
out.mkdir(exist_ok=False)
tmp = out / "TMP"
tmp.mkdir()
assert sorted(os.sched_getaffinity(0)) == [9]
env = dict(
    os.environ,
    CUDA_VISIBLE_DEVICES="",
    GOMAXPROCS="1",
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    NODE_DISABLE_COMPILE_CACHE="1",
    RUFF_CACHE_DIR=str(own / "ruff-cache"),
    TMPDIR=str(tmp),
    BEADS_ACTOR="codex:01a13f6c-6d72-7461-8653-e02ca53b6126",
)
resources = CycleResources(
    {
        "host_ram_reserve": 4 * 1024**3,
        "max_memory_bytes": 1024**3,
        "max_output_bytes": None,
    },
    out,
    None,
)
result = execute(
    sys.argv[2:],
    out / "command.log",
    None,
    cpu_core=5,
    resources=resources,
    cwd="/workspaces/quoridor",
    env=env,
)
(out / "return.json").write_text(json.dumps(result, indent=2) + "\n")
for path in tmp.iterdir():
    if path.is_file() and path.stat().st_size == 0 and "lock" in path.name:
        path.unlink()
remaining = list(tmp.iterdir())
if not remaining:
    tmp.rmdir()
print(json.dumps(result))
print((out / "command.log").read_text()[-16000:])
raise SystemExit(0 if result["exit_code"] == 0 and not remaining else 1)
