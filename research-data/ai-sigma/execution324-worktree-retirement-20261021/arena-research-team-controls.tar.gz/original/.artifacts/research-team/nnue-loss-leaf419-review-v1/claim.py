import datetime
import json
import os
import subprocess
from pathlib import Path

own = Path(__file__).resolve().parent
issue = "quoridor-4lc.419.3"
actor = "codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0"
env = dict(os.environ, BEADS_ACTOR=actor)
receipts = []
for args in [
    ["ready", "--json"],
    ["show", issue, "--json"],
    ["update", issue, "--claim", "--json"],
    ["show", issue, "--json"],
]:
    p = subprocess.run(
        ["bash", "scripts/dev/beads.sh", *args],
        env=env,
        capture_output=True,
        text=True,
        timeout=75,
    )
    assert p.returncode == 0, (args, p.returncode, p.stderr)
    value = json.loads(p.stdout)
    items = value if isinstance(value, list) else [value]
    selected = [
        {k: x.get(k) for k in ["id", "title", "assignee", "status"]}
        for x in items
        if x.get("id") == issue
    ]
    receipts.append(dict(argv=args, exit_code=p.returncode, selected=selected))
    if args[0] == "show":
        assert len(selected) == 1 and selected[0]["assignee"] in (None, actor)
assert (
    receipts[-1]["selected"][0]["assignee"] == actor
    and receipts[-1]["selected"][0]["status"] == "in_progress"
)
out = dict(
    issue=issue, at=datetime.datetime.now(datetime.UTC).isoformat(), receipts=receipts
)
(own / "beads-claim.json").write_text(
    json.dumps(out, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps(out, ensure_ascii=False))
