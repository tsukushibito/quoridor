import datetime
import hashlib
import json
import stat
from pathlib import Path

own = Path(__file__).resolve().parent
target = Path(
    "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/"
    "research-team/nnue-loss-leaf419-source-v1/source-v1"
)


def ref(path):
    path = Path(path)
    data = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


initial = json.loads((own / "fixed-source-selected-refs.json").read_text())
for expected in initial:
    assert ref(expected["path"]) == expected
binding = json.loads((target / "source-binding.json").read_text())
selected = list(initial)
for subject in binding["subjects"]:
    expected = subject["private_post"]
    assert ref(expected["path"]) == expected
    selected.append(expected)
for key in ["function-subject-map.json", "verification-plan.json"]:
    selected.append(ref(target / key))
for expected in selected:
    assert ref(expected["path"]) == expected
stop = datetime.datetime.now(datetime.UTC).isoformat()
(own / "fixed-source-selected-refs-v2.json").write_text(
    json.dumps(
        {"selected": selected, "before_after_exact": True, "reader_STOP": stop},
        indent=2,
    )
    + "\n"
)
print(json.dumps({"selected_count": len(selected), "reader_STOP": stop}))
