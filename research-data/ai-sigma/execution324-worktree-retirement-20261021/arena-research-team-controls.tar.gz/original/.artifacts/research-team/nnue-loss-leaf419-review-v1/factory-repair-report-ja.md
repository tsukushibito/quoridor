# factory419 関連修復の限定確認

**source_clear=true、blockers=[]、ordinary=[]**。修復Git `9c8f0c2f1f5273137499a6ff5063c59ab53a6736` の runner `measurement_loss_leaf.rs::call` だけを対象にした。

Root proof `76b503e8` /4178Bをparse前後に照合し、immutable Gitのbefore `012802d0` /37416B、after `2d80ee94` /37454Bと一致した。正本の7引数へ `ScoreDomain::LEGACY`、`OrderingProfile::CheapStaticControl`、observe=false、lmr=falseを渡し、直後の冗長なsetterを除去している。一置換のforward/inverseが完全一致し、同ファイルの残りのbytesは不変。approx=None、safe-race=false、実TT容量1048576検査もそのままである。

先の累積source判定のfactory419はこの修復で解消する。元のsource_clear=false報告・累積author packet・fixture修復bc8eef59・serialization括弧修復309894ef・失敗費用は上書きしない。初期spec、六境界、成功testを再実行・再レビューしていない。新たな不足は見つからなかった。native/test/model/Search/科学実行は0で、softwareや数値・速度・強さへ資格を与えない。

実turn_contextは2026-10-15T21:08:58.589Zの同thread、cwd Main、gpt-6.1-sol/high、danger-full-access/neverを確認した。source入場前のcontroller確認でbare `python` が見つからずexit127となったため、既存python3で実contextを確認した。原失敗を結果へ記録し、未知の環境変更やguard迂回はしていない。

CPU8/guardian12の別physical、family768MiB/GPU0/reserve4GiBの既存guardを使用。実selected reader STOPは **2026-10-15T21:10:07.533393Z**。各元helper/formatterのdirectwait/reap、fresh identity、handles/TMP/leaseと一回の修復対象usageは `factory-repair-STOP.json`、completionへ保存する。未記録controller費・continuous peakはUNKNOWN。全pause/default/model/seal/旧RAWFAILED費を保持する。
