import datetime
import hashlib
import json
from pathlib import Path

own = Path(__file__).resolve().parent
base = Path(
    "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-source-v1/source-v1"
)
refs = []


def read(path, sha=None, size=None):
    b = path.read_bytes()
    r = dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )
    assert sha is None or r["sha256"] == sha
    assert size is None or len(b) == size
    assert r["mode"] == "0644"
    refs.append(r)
    return b


for name, sha, size in [
    (
        "source-binding.json",
        "4682f577313ace2aa9319dccc0d79a2ca3dc8ecfd61c35fbd095b285542d341d",
        12223,
    ),
    (
        "source-STOP.json",
        "017bb84dc53e12df48067350482285096dc5dca086969f78f72b19635b10c79a",
        50482,
    ),
    (
        "forward.patch",
        "40d5cc08c9ac901ed722eaf75ca7f6aa279e4b0430b23457860837ac48eebf6c",
        82409,
    ),
]:
    b = read(base / name, sha, size)
    if name == "source-binding.json":
        print("BINDING", b.decode())
    if name == "forward.patch":
        print("PATCH", b.decode())
for r in refs:
    b = Path(r["path"]).read_bytes()
    assert hashlib.sha256(b).hexdigest() == r["sha256"] and len(b) == r["bytes"]
(own / "fixed-source-selected-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
print("READER_STOP", datetime.datetime.now(datetime.UTC).isoformat())
