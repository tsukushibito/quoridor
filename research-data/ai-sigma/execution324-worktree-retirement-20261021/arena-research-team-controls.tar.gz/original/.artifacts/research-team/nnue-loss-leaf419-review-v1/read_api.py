import datetime
import hashlib
import json
import re
import subprocess
from pathlib import Path

own = Path(__file__).resolve().parent
git = "61d783d1882bb02e8617cdbe42c1fce24cda8e9b"
files = {
    "crates/quoridor-runner/src/measurement.rs": [
        (r"^fn replay\(", 100),
        (r"^fn load_evaluator\(", 105),
    ],
    "crates/quoridor-nnue/src/residual.rs": [
        (r"pub fn evaluate_with_scratch_observed", 90),
        (r"fn linear_head_with_scratch_observed", 100),
    ],
    "crates/quoridor-ai/src/alphabeta.rs": [
        (r"^struct SearchInvocation", 95),
        (r"fn child\(", 105),
        (r"for depth in 1", 85),
    ],
}
refs = []
sections = []
for relative, patterns in files.items():
    body = subprocess.run(
        ["git", "show", git + ":" + relative], capture_output=True, check=True
    ).stdout
    ref = dict(
        Git=git,
        relative=relative,
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
    )
    if relative.endswith("residual.rs"):
        assert (
            ref["sha256"]
            == "99f5acd09eec12aa78142d62973e16fa8e0dcb377c26e6deca731897c519dabd"
        )
    refs.append(ref)
    lines = body.decode().splitlines()
    for pattern, count in patterns:
        hits = [i for i, line in enumerate(lines) if re.search(pattern, line)]
        print("MATCH", relative, pattern, [i + 1 for i in hits])
        for i in hits[:3]:
            chunk = "\n".join(
                f"{j + 1}: {lines[j]}"
                for j in range(max(0, i - 3), min(len(lines), i + count))
            )
            print("SECTION", relative)
            print(chunk)
            sections.append(
                dict(
                    relative=relative,
                    start_line=max(1, i - 2),
                    end_line=min(len(lines), i + count),
                    text=chunk,
                )
            )
    if relative.endswith("alphabeta.rs"):
        print(
            "API_NAMES",
            [
                (i + 1, line.strip())
                for i, line in enumerate(lines)
                if re.search(
                    r"fn .*?(captur|maintain|diagnos|iteration|search_|root|invocation)",
                    line,
                )
            ],
        )
for ref in refs:
    body = subprocess.run(
        ["git", "show", git + ":" + ref["relative"]], capture_output=True, check=True
    ).stdout
    assert (
        len(body) == ref["bytes"] and hashlib.sha256(body).hexdigest() == ref["sha256"]
    )
(own / "api-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
(own / "api-sections.json").write_text(json.dumps(sections, indent=2) + "\n")
print("READER_STOP", datetime.datetime.now(datetime.UTC).isoformat())
