import datetime
import hashlib
import json
import math
import struct
from pathlib import Path

own = Path(__file__).resolve().parent
base = Path(
    "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/"
    "research-team/nnue-loss-leaf419-analysis-v1"
)
selected = []


def read(ref):
    path = Path(ref["path"])
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == ref["sha256"]
    assert len(data) == ref["bytes"]
    assert f"{path.stat().st_mode & 0o777:04o}" == ref["mode"]
    selected.append(ref)
    return json.loads(data)


refs = json.loads((own / "selectedrefs.json").read_text())
analysis = read(
    next(r for r in refs if r["path"].endswith("saved-analysis-result.json"))
)
index = read(
    dict(
        path=str(base / "analysis-selectedrefs.json"),
        sha256="b60c2e37345e807208dd4bad7f4e986e18d1e80ed5acf058ae72d8fbda0ca7ec",
        bytes=17695,
        mode="0644",
    )
)
bound = {r["before"]["path"]: r["before"] for r in index["selected_refs"]}
original_ref = analysis["source_result_ref_before_after"]
assert bound[original_ref["path"]] == original_ref
collection_ref = next(r for p, r in bound.items() if p.endswith("/collection.json"))
collection = read(collection_ref)
assert collection["refs"]["raw_result"] == original_ref
original = read(original_ref)
inputs = read(bound[str(base / "fixed-inputs.json")])
parent = inputs["parents"][0]
assert parent["id"] == "distance-slot004-ply011"
assert parent["expected_maintained_rules_view"]["turn"] == 1
assert parent["original_actual_continuation_first_six"][:2] == [156, 123]


def f32(bits):
    value = struct.unpack("<f", struct.pack("<I", bits))[0]
    assert math.isfinite(value)
    return value


def bits(value):
    return struct.unpack("<I", struct.pack("<f", value))[0]


tree = original["trees"][0]
nodes = tree["tree"]["nodes"]
assert tree["candidates"] == [68, 156]
assert tree["tree_error"] is None and tree["parent_restored"]
target = nodes[12765]
assert target["ply"] == 2 and target["action"] == 91
assert target["terminal"] is None
first = nodes[target["parent"]]
assert first["action"] == 156 and first["parent"] == 0 and first["ply"] == 1
leaf = target["leaf"]
assert leaf["pre_tanh_bits"] == 1067678728
assert leaf["nnue_post_bits"] == 1062932988
assert leaf["distance_post_bits"] == 3197445870

# Only the H2 frontier of parent zero is assessed. No H3 backup or other
# intervention is recomputed. Python exactly represents these saved f32
# values; sign changes and comparisons introduce no additional rounding.
candidates = []
for child_id in nodes[0]["children"]:
    child = nodes[child_id]
    assert child["parent"] == 0 and child["ply"] == 1
    assert child["terminal"] is None
    assert (
        child["legal_children"] == child["planned_children"] == len(child["children"])
    )
    values = []
    replaced_values = []
    responses = []
    for endpoint in child["children"]:
        node = nodes[endpoint]
        assert node["parent"] == child_id and node["ply"] == 2
        assert node["terminal"] is None and node["leaf"] is not None
        value = f32(node["leaf"]["nnue_post_bits"])
        replacement = f32(leaf["distance_post_bits"]) if endpoint == 12765 else value
        values.append(-value)  # Child STM is P0.
        replaced_values.append(-replacement)
        responses.append(node["action"])
    old_parent = -max(values)  # Parent STM returns to P1.
    new_parent = -max(replaced_values)
    old_reply = min(a for a, v in zip(responses, values) if v == max(values))
    new_reply = min(
        a for a, v in zip(responses, replaced_values) if v == max(replaced_values)
    )
    candidates.append(
        dict(
            action=child["action"],
            responses=len(values),
            old_parent_value=old_parent,
            new_parent_value=new_parent,
            old_parent_bits=bits(old_parent),
            new_parent_bits=bits(new_parent),
            old_response=old_reply,
            new_response=new_reply,
        )
    )
assert sum(c["responses"] for c in candidates) == 217
old_best = max(c["old_parent_value"] for c in candidates)
new_best = max(c["new_parent_value"] for c in candidates)
old_ties = sorted(c["action"] for c in candidates if c["old_parent_value"] == old_best)
new_ties = sorted(c["action"] for c in candidates if c["new_parent_value"] == new_best)
assert old_ties == [156] and new_ties == [68]
case = next(c for c in analysis["conditions"] if c["parent"] == 0 and c["H"] == 2)
intervention = next(
    c
    for c in analysis["interventions"]
    if c["parent"] == 0 and c["H"] == 2 and c["node_ids"] == [12765]
)
native_intervention = tree["comparisons"][0]["interventions"][2]
assert native_intervention["replaced"][0]["node"] == 12765
assert native_intervention["ranking"] == intervention["new_rank"]
assert native_intervention["PV"] == intervention["new_PV"] == [68, 131]
for c in candidates:
    old = next(v for v in case["N"]["candidate_values"] if v["action"] == c["action"])
    new = next(
        v
        for v in intervention["new_rank"]["candidate_values"]
        if v["action"] == c["action"]
    )
    assert old["value_parent_bits"] == c["old_parent_bits"]
    assert new["value_parent_bits"] == c["new_parent_bits"]
assert nodes[0]["legal_children"] == 109
assert len(nodes[0]["children"]) == 2
assert original["census"] == analysis["census"] == collection["census"]
count = original["census"]
assert 12 + 4 * sum(map(len, original["candidates_shared_H2_H3"])) == 40
assert count["search_requests_admitted"] == count["search_calls_entered"] == 40
assert (
    count["search_nnue_evaluations_observed"]
    + count["tree_nnue_logical_evaluations"]
    + count["parity_nnue_logical_evaluations"]
    == 84673
)
for ref in selected:
    path = Path(ref["path"])
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == ref["sha256"]
    assert len(data) == ref["bytes"]
    assert f"{path.stat().st_mode & 0o777:04o}" == ref["mode"]
result = dict(
    interpretation_clear=True,
    blockers=[],
    ordinary=[],
    example=dict(
        parent=parent["id"],
        H=2,
        node=12765,
        path=[156, 91],
        root_STM=1,
        child_STM=0,
        leaf_STM=1,
        pre=f32(leaf["pre_tanh_bits"]),
        N_post=f32(leaf["nnue_post_bits"]),
        D_post=f32(leaf["distance_post_bits"]),
        candidates=candidates,
        old_ties=old_ties,
        new_ties=new_ties,
        root_alllegal_count=109,
        C_count=2,
        old_actual_reply=123,
        new_PV=[68, 131],
    ),
    recalculation_scope="One saved parent H2 and one singleton intervention, 217 frontier values; no six-backup or 23-intervention replay",
    original_operational_outcome=collection["operational_outcome"],
    original_cleanup=collection["original_disk_cleanup"],
    original_census=count,
    limits=[
        "finite fixed C only",
        "D is not an oracle",
        "old-game cause UNKNOWN",
        "true WDL UNKNOWN",
        "full-root post-intervention argmax UNKNOWN",
        "general NNUE weakness not established",
    ],
    reader_STOP=datetime.datetime.now(datetime.UTC).isoformat(),
    new_Search_forward_native_test_model_RAWstream_bootstrap=0,
)
(own / "example-check.json").write_text(json.dumps(result, indent=2) + "\n")
(own / "example-selectedrefs.json").write_text(json.dumps(selected, indent=2) + "\n")
print(json.dumps(result))
