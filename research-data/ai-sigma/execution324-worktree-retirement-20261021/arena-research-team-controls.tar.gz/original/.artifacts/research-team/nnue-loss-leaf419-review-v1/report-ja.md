# 419.3：固定spec／必要APIの限定確認

今回の範囲では、指定6境界のspecに具体的な矛盾や修正必須事項は見つからなかった。**最終419.2実装は未提供であり、source_clearはPENDING（null）**。software・native入力資格・数値・性能・棋力は未確認。blockers=[]／ordinary=[]はこのspec/API phaseだけの判定であり、実装の受入れではない。

対象はspec `51935438…/13935B`、design `af0cfa02…/8398B`、fixed-inputs `b26fb4d5…/24449B`。Root spec-bindingと作者inletは参照として読んだが、作者の自己評価から本判定を推論していない。APIはimmutable Git `61d783d1882bb02e8617cdbe42c1fce24cda8e9b` の名前付き範囲だけを独立に読んだ。現在Main全体の版・将来419 postimageを確認したという意味ではない。

## 6境界の見解と残る実装確認

| 境界                   | specで固定されている意味                                                                                                                        | 名前付きAPIの事実／最終sourceで確認する点                                                                                                                                                                                                                                                                                |
| ---------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| forced                 | Hに親action一手を含み、child H−1・非root ply1・親full window、符号反転一度。反復1..Hを同Invocation／同累積1M。通常requestとforced requestは別。 | `alphabeta.rs:1512` のchildはwindowを反転して既存negamaxへ入り、canonical make/undoと親fingerprint/path復元を所有する。`3093` の通常反復は同stateを共有する。一方、旧trial分岐`3051–3091`は一回のscout／別depth資格であり、そのまま419 forcedではない。419の薄い入口と反復・完成深さの対応はPENDING。                    |
| root TT                | 制限親の値を全合法rootのExactとして保存・再読しない。内部TTのfullhistory/depth/domain/boundは維持。                                             | 通常`root_depth:2196–2210`は同depth/contextのExactをreturnし、`2254–2269`は全合法rootのExactを保存する。単なる候補filterだけでこの経路を共有するのは不十分。419 forcedでは親Exactの両入口を避け、通常root／child TTを無変更に保つ実装を確認する。                                                                        |
| prefix／terminal／復元 | 完全11/39/12手prefixからrules/totalply/board/side/stock/全historyを照合、truegoal→threefold→static、error/cancelでも親を復元。                  | `measurement.rs:748–768`はfrom_prefix→validate_normal、synthetic/rules/ply/terminal拒否と期待root key/counts照合を所有する。今回のJSON配列・multiset整合確認は合法手や時系列再生の代替ではない。419 callerの全期待値へのbindingと中間terminal非通過は固定source／通常native admission待ち。                              |
| 共通木                 | Cだけをrootに、その後ALL合法をH3まで一度。ply2/3のstaticをH2/H3へ再用、noTT/no剪定/no pathmerge。欠損ancestorはUNKNOWN。                        | local STMのmax(-child)と親候補への一回の反転、goal±2／draw0／static有限±1を区別するspecは整合。±0はf32数値tie、最小ActionIDは表示用canonicalであり、Search実orderingの同点手と同一とは仮定しない。完成性、出力cap、中断時H2だけをCOMPLETEにできる条件は実装待ち。旧355全bodyの流用資格は確認していない。                 |
| 保存介入               | N/DのC内argmax集合差からaN/aDを固定し、各評価器の応手で最大4path、非terminal endpointを辞書順dedup。単独＋全同時で最大30。                      | 同葉local-STM N postだけをD postへ置換し、全応手をrebackupするので代替PVへの切替を許せる設計。canonical winnerが一致してtie集合だけ異なる場合も選択規則は定義されている。その有限endpointでflipしなくても他endpointを補充しない。D正解・旧敗戦原因・真のWDLの証明にはならない。sourceのendpoint選択／再backupはPENDING。 |
| 一計算view／会計       | canonical residual一計算からbaseline/residual/FP32 pre/f64 tanh→FP32 post。OFFにscan/heap/追加headを入れず、全論理評価を25Mへ実課金。           | `residual.rs:280–294`は同じheadのr、baseline u、FP32 u+rの有限検査、f64 tanh→f32を所有する。`297–347`のobserved callbackはrouting二boolだけで、現在のAPIだけからpreを取得できない。`320–322`の標準化距離入力はbaseline係数0でも残る。最小viewの単一計算／通常OFF非干渉とglobal counterは新source待ち。                   |

headのSIMD設定ラベルと、正本head内のfast-range／AVX2 availabilityというrouting事実は別に扱う。`simd=false`という設定だけから物理head routeや計算回数を推定しない。pre-tanhをatanhから復元せず、TT／normal Searchの起源不明値もstaticへ読み替えない。

## 小さい保存算術確認

新しい盤面再生・合法手生成・Search・forward・solverは行っていない。

- 3親のprefix長11/39/12、ordered history長12/40/13、末尾key、期待history multiset、手番と原着手がJSON内で対応した。3親は同family0の2ゲームであり、独立3標本ではない。
- normal12 request IDは一意で、親順×H2/H3×N/Dの固定順。H3の同じ呼出しをanchorへ再用し、H2救済や追加anchorを作らない。
- normal12＋forced最大36＝48、NNUE最大24、全48M。通常とforcedを値やactionの偶然の一致でdedupしない。
- tree上界は `3+9+9×136+9×136²=167700`、別の実capは300k。parity選択上界は `3+3×2×4×3=75`、実cap256を埋める追加状態選択はない。
- 保存介入上限は `3×2×(4+1)=30`。論理評価の保守算術は `24M+300000+256×4+3=24301027<25M`。

最後の値は、Search node由来の項・木・仮定した追加headを足した導出値であり、初期化を含む全ownerのhead回数を証明したものではない。prepare-only、FT full/delta、physical head、logical evaluateを分け、初期化／view／full-delta／復元が追加headを行えば同じglobal counterへ実課金し、超過は元error/UNKNOWNとして止める実装が必要。この点をsource未着のまま「上界内の実使用」へ昇格しない。

## 今回の結論と次の対象

現時点でspec修正を要求する一点はない。通常の実装差分として、forced共通kernel入口、canonical observed score view、global実counterが必要であることは固定版APIから確認できた。それぞれを作者が独自loop／別formula／毎node tracingで埋めてよいという意味ではない。

次は、419.2が一度渡す固定sourceのうち、上表の変更境界だけを同leafで確認する。原specで確認済みの部分や旧資格suiteを再演せず、通常修復ごとの新reviewも増やさない。source_clear／software／数値／重要な局所機序の結論はその実対象が来るまでPENDINGである。人間・Root ACKや親closeを実装の入口条件にしない。

必要境界の読取は終了した。実reader／formatterのdirectwait・fresh exact identity・handles・TMP・leases・owned[]はSTOP.jsonに記録する。最終source待ちの間はreader/helper/leaseを保持せず、pollingや周期wakeを行わない。本人claimant/in_progressは維持し、Rootが受入れ／close／backupを調整する。

## 資源・原記録

実turn contextはgpt-6.1-sol/high、cwdMain、danger-full-access／approval never。workerCPU10とguardian14は別physical core、family RSS768MiB（child704+controller64）、GPU0、hostreserve4GiB、AS capなし、no_new_privs=1、既存CycleResources/execute。topology/cpuset/readbackとpsの瞬間running-task観測を保存したが、静穏／公平timingの証明にはしていない。

Main/Git/index/Cargo/production source修復、native数学、model payload、forward、Search、arena、RAW全stream、旧383再生、solver、bootstrap、fit、旧成功suite、Astra、新session、再帰委譲は0。Git操作は指定immutable objectのreadだけ。未観測の高速子PID／controller／exact finish UTCや全作業費はUNKNOWNとし、返値completedとdisk pending/attemptedを混同しない。

ordinary reviewの事前storage枠は設けていない。本人affectedusage一回は最終固定source reviewの終了時へ残し、この初期phaseでは再walkしない。保守上界49,328,115,712B/globalactualUNKNOWN/decimal50GBを新しい実測へ読み替えず、既存targetを二重計上しない。全mixed/learner prep/pipeline・323 USERPAUSE、defaults/models/weights/seals/oldfits96/foreign、全旧RAWFAILED費UNKNOWNを保持する。
