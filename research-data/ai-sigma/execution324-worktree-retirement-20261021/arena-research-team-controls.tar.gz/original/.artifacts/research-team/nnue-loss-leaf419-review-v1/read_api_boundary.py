import datetime
import hashlib
import json
import subprocess
from pathlib import Path

own = Path(__file__).resolve().parent
git = "61d783d1882bb02e8617cdbe42c1fce24cda8e9b"
refs = []
sections = []
for relative, ranges in [
    ("crates/quoridor-runner/src/measurement.rs", [(1, 45)]),
    ("crates/quoridor-ai/src/alphabeta.rs", [(2186, 2350), (2960, 3094), (3166, 3228)]),
]:
    body = subprocess.run(
        ["git", "show", git + ":" + relative], capture_output=True, check=True
    ).stdout
    refs.append(
        dict(
            Git=git,
            relative=relative,
            sha256=hashlib.sha256(body).hexdigest(),
            bytes=len(body),
        )
    )
    lines = body.decode().splitlines()
    for start, end in ranges:
        text = "\n".join(
            f"{i + 1}: {lines[i]}" for i in range(start - 1, min(end, len(lines)))
        )
        sections.append(
            dict(relative=relative, start_line=start, end_line=end, text=text)
        )
        print(text)
(own / "api-boundary-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
(own / "api-boundary-sections.json").write_text(json.dumps(sections, indent=2) + "\n")
print("READER_STOP", datetime.datetime.now(datetime.UTC).isoformat())
