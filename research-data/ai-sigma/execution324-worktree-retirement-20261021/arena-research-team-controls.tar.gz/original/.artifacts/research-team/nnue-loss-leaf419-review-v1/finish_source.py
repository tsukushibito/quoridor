import datetime
import hashlib
import json
from pathlib import Path

own = Path(__file__).resolve().parent
boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def ref(path):
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def fresh(identity):
    path = Path(f"/proc/{identity['pid']}/stat")
    try:
        ticks = path.read_text().rsplit(")", 1)[1].split()[19]
    except FileNotFoundError:
        return "absent"
    assert ticks != str(identity["start_ticks"]) or boot != identity["boot_id"]
    return "different_identity"


def write(name, value):
    (own / name).write_text(json.dumps(value, indent=2) + "\n")


refs = json.loads((own / "fixed-source-selected-refs-v2.json").read_text())
for expected in refs["selected"]:
    assert ref(Path(expected["path"])) == expected
selected_stop = datetime.datetime.now(datetime.UTC).isoformat()
refs["final_before_after_exact"] = True
refs["final_selected_reader_STOP"] = selected_stop
write("fixed-source-selected-refs-v2.json", refs)

stages = [
    "fixed-intake-v1",
    *[f"source-read-{c}-v1" for c in "abcdefg"],
    "fixed-format-python-v1",
    "fixed-lint-python-v1",
    "fixed-format-report-v1",
    "fixed-refs-v1",
    "fixture-boundary-read-v1",
    "fixed-format-report-v2",
    "fixed-format-finish-v1",
    "fixed-lint-finish-v1",
    "fixed-beads-show-v1",
    "fixed-beads-note-v1",
    "fixed-beads-backup-v1",
]
receipts = []
for name in stages:
    directory = own / name
    returned = json.loads((directory / "return.json").read_text())
    controller = json.loads((directory / "controller.json").read_text())
    disk = json.loads((directory / "command.process.json").read_text())
    assert returned["exit_code"] == 0
    assert returned["cleanup_complete"] and returned["direct_child_reaped"]
    assert returned["handle_closes_complete"] and returned["remaining"] == []
    assert not (directory / "TMP").exists()
    receipts.append(
        dict(
            stage=name,
            child=dict(identity=returned["child"], fresh=fresh(returned["child"])),
            controller=dict(identity=controller, fresh=fresh(controller)),
            returned=ref(directory / "return.json"),
            persisted=ref(directory / "command.process.json"),
            directwait_reaped=True,
            handles_closed=True,
            TMP_absent=True,
            no_new_privs=returned["launch_policy"],
            returned_masks=returned.get("signal_mask_restoration"),
            disk_masks=disk.get("signal_mask_restoration"),
            returned_persist=returned.get("final_record_persist"),
            disk_persist=disk.get("final_record_persist"),
            wall_seconds=returned["wall_seconds"],
        )
    )
stop = dict(
    issue="quoridor-4lc.419.3",
    phase="FIXED_SOURCE_REVIEW",
    selected_reader_STOP=selected_stop,
    completed_stage_fresh_observation=datetime.datetime.now(datetime.UTC).isoformat(),
    receipts=receipts,
    owned=[],
    readers=[],
    children=[],
    jobs=[],
    handles=[],
    TMP=[],
    leases=[],
    reservation="NONE",
    writer_scope="Completed reviewed source/formatter/admin stages; this small metadata publisher is directly reaped separately.",
    source_clear=False,
    blockers=["factory419"],
    original_initial_STOP_unchanged=ref(own / "STOP.json"),
    continuous_peak_and_unrecorded_controller_cost="UNKNOWN",
)
write("fixed-source-STOP.json", stop)
completion = dict(
    issue="quoridor-4lc.419.3",
    phase="FIXED_CUMULATIVE_SOURCE_REVIEW",
    source_clear=False,
    blockers=["factory419"],
    ordinary=[],
    report=ref(own / "source-report-ja.md"),
    control=ref(own / "source-control.json"),
    selectedrefs=ref(own / "fixed-source-selected-refs-v2.json"),
    STOP=ref(own / "fixed-source-STOP.json"),
    software_native_numeric_strength="NOT_GRANTED",
    status="in_progress; same related ordinary repair can be checked without a new review parent",
)
write("source-completion.json", completion)
print(json.dumps(completion))
