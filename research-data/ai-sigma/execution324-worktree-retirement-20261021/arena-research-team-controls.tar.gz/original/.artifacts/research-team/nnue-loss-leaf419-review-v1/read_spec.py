import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

own = Path(__file__).resolve().parent
base = Path(
    "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-analysis-v1"
)
refs = []


def read(path, sha=None, size=None):
    b = path.read_bytes()
    s = path.stat()
    r = dict(
        path=str(path),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{s.st_mode & 0o777:04o}",
    )
    assert sha is None or r["sha256"] == sha
    assert size is None or len(b) == size
    assert r["mode"] == "0644"
    refs.append(r)
    return b


for name, sha, size in [
    (
        "spec-ja.md",
        "51935438948fd853e22d3e29421c0a0099cf0e412d33ba688bfd5ee8ae5be03f",
        13935,
    ),
    (
        "design.json",
        "af0cfa0295b26aee4240f06ee69ff368eda1e5d02866ea9b17741defa5ac1897",
        8398,
    ),
    (
        "fixed-inputs.json",
        "b26fb4d5f21bac5b9614610504aac7022850223a6af67b4680530c08e8429304",
        24449,
    ),
]:
    b = read(base / name, sha, size)
    print("FILE", name)
    print(
        b.decode()
        if name != "fixed-inputs.json"
        else json.dumps(json.loads(b), ensure_ascii=False)[:28000]
    )
for p in [
    Path(
        "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-loss-leaf419-v1/spec-binding.json"
    ),
    base.parent / "nnue-loss-leaf419-source-v1/inlet-cost-ja.md",
    base.parent / "nnue-loss-leaf419-source-v1/observed-head-ref.json",
]:
    if p.exists():
        print("FILE", str(p))
        print(read(p).decode())
    else:
        print("NAMED_PATH_ABSENT", str(p))
for r in refs:
    b = Path(r["path"]).read_bytes()
    assert (
        len(b) == r["bytes"]
        and hashlib.sha256(b).hexdigest() == r["sha256"]
        and f"{Path(r['path']).stat().st_mode & 0o777:04o}" == r["mode"]
    )
occupancy = subprocess.run(
    ["ps", "-eLo", "pid,lwp,psr,stat,comm"], capture_output=True, text=True, check=True
).stdout.splitlines()
rows = [
    line
    for line in occupancy[1:]
    if len(line.split()) >= 5
    and line.split()[2] in ("10", "14")
    and line.split()[3].startswith("R")
]
physical = dict(
    at=datetime.datetime.now(datetime.UTC).isoformat(),
    worker_affinity=sorted(os.sched_getaffinity(0)),
    source_RSS_readback=Path("/proc/self/status")
    .read_text()
    .split("VmRSS:")[1]
    .splitlines()[0]
    .strip(),
    running_tasks_psr_10_14=rows,
    caution="instant scheduling snapshot only; no quiet/fairness proof",
)
(own / "spec-selected-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
(own / "physical.json").write_text(json.dumps(physical, indent=2) + "\n")
print("READER_STOP", datetime.datetime.now(datetime.UTC).isoformat())
