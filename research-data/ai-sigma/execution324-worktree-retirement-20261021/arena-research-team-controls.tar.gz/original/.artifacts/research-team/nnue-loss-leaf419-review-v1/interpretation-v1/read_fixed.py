import datetime
import hashlib
import json
from pathlib import Path

own = Path(__file__).resolve().parent
target = Path(
    "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/"
    "research-team/nnue-loss-leaf419-analysis-v1"
)
subjects = [
    (
        "analysis-completion.json",
        "5ab0fb6f35c189a2d833b193f4b6e6efc32eac1e5f48c5bab3789af56f6a2802",
        13924,
    ),
    (
        "report-ja.md",
        "c4f05a657eff972ed63a6680621e554ae3065a48806e00d86c5981861eb939d2",
        14023,
    ),
    (
        "saved-analysis-result.json",
        "3c051972259fea236e64e1ff11a2197c841a6911fea07bafe140faa9859b00bf",
        113914,
    ),
    (
        "finite-leaf-example.svg",
        "5fdf345345f459ac3eaef88f8f998058d8ecc6d2e0b03853afc3b25d138833d2",
        4097,
    ),
]
refs = []
parsed = {}
for name, sha, size in subjects:
    path = target / name
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == sha
    assert len(data) == size
    assert path.stat().st_mode & 0o777 == 0o644
    refs.append(dict(path=str(path), sha256=sha, bytes=size, mode="0644"))
    if name.endswith(".json"):
        parsed[name] = json.loads(data)
for ref in refs:
    path = Path(ref["path"])
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == ref["sha256"]
    assert len(data) == ref["bytes"]
    assert path.stat().st_mode & 0o777 == 0o644
(own / "selectedrefs.json").write_text(json.dumps(refs, indent=2) + "\n")
print("COMPLETION", json.dumps(parsed["analysis-completion.json"], indent=2))
print("RESULT_KEYS", list(parsed["saved-analysis-result.json"]))
print("READER_STOP", datetime.datetime.now(datetime.UTC).isoformat())
