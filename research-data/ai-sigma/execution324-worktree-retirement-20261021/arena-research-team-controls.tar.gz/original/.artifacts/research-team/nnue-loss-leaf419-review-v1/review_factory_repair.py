import datetime
import hashlib
import json
import subprocess
from pathlib import Path

own = Path(__file__).resolve().parent
commit = "9c8f0c2f1f5273137499a6ff5063c59ab53a6736"
subject = "crates/quoridor-runner/src/measurement_loss_leaf.rs"
proof_path = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/"
    "nnue-loss-leaf419-v1/factory-repair-v1.json"
)


def git(*args):
    return subprocess.run(
        ["git", *args], cwd="/workspaces/quoridor", check=True, capture_output=True
    ).stdout


proof_bytes = proof_path.read_bytes()
assert hashlib.sha256(proof_bytes).hexdigest() == (
    "76b503e8d1c274a35bb28db95a8c41b858bfe1057d5c9bd0f061e766447d5cad"
)
assert len(proof_bytes) == 4178
proof = json.loads(proof_bytes)
assert proof["commit"] == commit
before = git("show", f"{commit}^:{subject}")
after = git("show", f"{commit}:{subject}")
for data, expected in [(before, proof["before"]), (after, proof["after"])]:
    assert hashlib.sha256(data).hexdigest() == expected["sha256"]
    assert len(data) == expected["bytes"]
old = b"""        OrderingProfile::Control,
        false,
    )?;
    session.set_lmr(false);
"""
new = b"""        alphabeta::ScoreDomain::LEGACY,
        OrderingProfile::CheapStaticControl,
        false,
        false,
    )?;
"""
assert before.count(old) == 1
assert before.replace(old, new, 1) == after
assert after.replace(new, old, 1) == before
api_path = Path(
    "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/"
    "research-team/nnue-loss-leaf419-source-v1/source-v1/post/"
    "crates/quoridor-ai/src/alphabeta.rs"
)
api = api_path.read_bytes()
assert hashlib.sha256(api).hexdigest() == (
    "2f056fb00d33fb18ed24416f1a0954d83ccc2b4187b78c8ded4ff028e6f8a887"
)
signature = b"""    pub fn new_with_ordering(
        evaluator: Arc<dyn StaticEvaluator>,
        namespace: SearchNamespace,
        capacity: usize,
        score_domain: ScoreDomain,
        profile: OrderingProfile,
        observe_ordering: bool,
        lmr: bool,
    ) -> Result<Self>"""
assert signature in api
for line in [
    b"session.set_zero_stock_approx_min_root_walls(None)?;",
    b"session.set_zero_stock_safe_race(false);",
    b"if capacity.0 != 1_048_576",
]:
    assert line in before and line in after
assert proof_path.read_bytes() == proof_bytes
assert api_path.read_bytes() == api
result = dict(
    issue="quoridor-4lc.419.3",
    phase="factory419 related repair only",
    source_clear=True,
    blockers=[],
    ordinary=[],
    commit=commit,
    subject=subject,
    before=proof["before"],
    after=proof["after"],
    proof=json.loads((own / "factory-repair-proof-ref.json").read_text()),
    authoritative_signature_sha256=hashlib.sha256(signature).hexdigest(),
    strict_single_replacement_forward_inverse=True,
    all_other_subject_bytes_unchanged=True,
    reader_STOP=datetime.datetime.now(datetime.UTC).isoformat(),
    software_native_numeric_speed_strength="NOT_GRANTED; no execution by reviewer",
    original_false_verdict_and_failed_software="RETAINED_UNCHANGED",
    preflight_controller_error="bare python command unavailable (exit127); context verification used python3 before review source entry",
)
(own / "factory-repair-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
