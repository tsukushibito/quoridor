import collections
import datetime
import hashlib
import json
from pathlib import Path

own = Path(__file__).resolve().parent
base = Path(
    "/workspaces/quoridor/.worktree/arena-generalization377/.artifacts/research-team/nnue-loss-leaf419-analysis-v1"
)
refs = json.loads((own / "spec-selected-refs.json").read_bytes())


def document(name):
    p = base / name
    r = next(r for r in refs if r["path"] == str(p))
    b = p.read_bytes()
    assert len(b) == r["bytes"] and hashlib.sha256(b).hexdigest() == r["sha256"]
    return json.loads(b)


design = document("design.json")
fixed = document("fixed-inputs.json")
parents = fixed["parents"]
assert len(parents) == 3
assert [len(p["from_prefix_actions"]) for p in parents] == [11, 39, 12]
assert [p["historical_candidate_action"] for p in parents] == [156, 192, 104]
for p in parents:
    assert p["parent_horizons"] == [2, 3] and p["candidate_anchor_horizon"] == 3
    assert len(p["expected_ordered_history_keys"]) == len(p["from_prefix_actions"]) + 1
    assert (
        p["expected_ordered_history_keys"][-1]
        == p["expected_native_history_key_from_maintained_rules_view"]
    )
    expected = dict(p["expected_history_multiset_for_comparison_only"])
    assert collections.Counter(p["expected_ordered_history_keys"]) == expected
    assert (
        p["original_nnue_observation"]["side"]
        == p["nnue_colour"]
        == p["expected_maintained_rules_view"]["turn"]
    )
    assert p["original_nnue_observation"]["action"] == p["historical_candidate_action"]
    assert p["expected_maintained_rules_view"]["ply"] == len(p["from_prefix_actions"])
    assert p["native_full_prefix_admission"] == "PENDING_NORMAL_CANONICAL_REPLAY"
assert len({p["family_id_383"] for p in parents}) == 1
assert (
    len(
        {
            (p["source_raw"]["journal"]["sha256"], p["source_raw"]["line_1_based"])
            for p in parents
        }
    )
    == 2
)
schedule = design["normal_call_schedule"]
assert len(schedule) == len({r["id"] for r in schedule}) == 12
assert [(r["parent_id"], r["parent_horizon"], r["evaluator"]) for r in schedule] == [
    (p["id"], h, e) for p in parents for h in [2, 3] for e in ["N", "D"]
]
visits = 3 + 9 + 9 * 136 + 9 * 136**2
parity = 3 + 3 * 2 * 4 * 3
logical = 24 * 1000000 + 300000 + 256 * 4 + 3
assert visits == 167700 and parity == 75 and logical == 24301027 and logical < 25000000
assert design["census_caps"]["Search_calls_total"] == 12 + 3 * 3 * 2 * 2 == 48
assert design["census_caps"]["N_Search_calls"] == 6 + 3 * 3 * 2 == 24
assert design["intervention"]["maximum_saved_contrasts"] == 3 * 2 * (4 + 1) == 30
for r in refs:
    b = Path(r["path"]).read_bytes()
    assert len(b) == r["bytes"] and hashlib.sha256(b).hexdigest() == r["sha256"]
result = dict(
    issue="quoridor-4lc.419.3",
    phase="SPEC_AND_NAMED_API_ONLY",
    status="NO_SPEC_CONTRADICTION_FOUND_WITHIN_SIX_QUESTIONS",
    source_clear=None,
    software_numeric_performance_strength="NOT_REVIEWED",
    blockers=[],
    ordinary=[],
    implementation_target="PENDING; not provided; no polling",
    checks=dict(
        parent_prefix_lengths=[11, 39, 12],
        normal_unique_calls=12,
        forced_max=36,
        total_calls_max=48,
        N_calls_max=24,
        shared_families=1,
        source_games=2,
        tree_derived_upper=visits,
        tree_hard_cap=300000,
        parity_source_upper=parity,
        parity_hard_cap=256,
        intervention_max=30,
        logical_conservative_upper=logical,
        logical_hard_cap=25000000,
        arithmetic_is_actual_usage=False,
        chronology_legality_not_certified_from_JSON=True,
    ),
    important_source_checks_pending=[
        "forced one invocation iterative1..H, childH-1/ply1/fullwindow/cumulativecap and parent TT isolation",
        "fullprefix replay/terminal priority/undo errorcancel/parent restore",
        "alllegal complete H2/H3 tree backup numeric signedzero ties/no missing staticfill",
        "saved intervention rebacks allresponses; single sameleaf localSTM replacement",
        "single canonical ResidualModel view/pre/post and OFF no extrahead orscan",
        "one global actual logical-head budget including setup/view/parity/restore, counters separate from FT/prepare",
    ],
    reader_STOP=datetime.datetime.now(datetime.UTC).isoformat(),
    source_Scientific_Cargo_model_RAW_replay_tests=0,
)
(own / "protocol-checks.json").write_text(
    json.dumps(result, ensure_ascii=False, indent=2) + "\n"
)
print(json.dumps(result, ensure_ascii=False))
