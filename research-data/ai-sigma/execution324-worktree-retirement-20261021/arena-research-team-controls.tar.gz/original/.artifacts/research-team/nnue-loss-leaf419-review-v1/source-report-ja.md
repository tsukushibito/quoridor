# 419 固定累積ソースの六境界確認

判定は **source_clear=false、blockers=[factory419]、ordinary=[]**。対象は source-binding SHA256 `4682f577313ace2aa9319dccc0d79a2ca3dc8ecfd61c35fbd095b285542d341d`、12223B と、そこに束縛された累積 forward `40d5cc08`、82409B のみ。初期spec/API確認の再実行や独立head checkpointの重複確認は行っていない。Rootから通知された合成Gitは `7b79f85e3a9e435778db6988de017c5afef5a1fd`。可変Mainは読んでいない。

これは指定したsource境界の静的判定である。新12Rust定義とNN0一つ、compile、Clippy、native、モデル実行、数値、性能、棋力、旧敗戦の原因について成功を与えない。softwareはこのreviewではすべて未実行。関連する通常修復は同じ問いに限定して扱える。

## 必須の最小修正 factory419

固定 `measurement_loss_leaf.rs:236–245` の本番 `call()` は `SearchSession::new_with_ordering(eval, namespace, 1_048_576, OrderingProfile::Control, false)` を使う。しかし、同じ固定 `alphabeta.rs:2718–2726` の正本APIは7引数で、capacityの後に `ScoreDomain`、実 `OrderingProfile`、observe_ordering、lmrを取る。enumは `CheapStaticControl` / `CombinedSignedCheapStatic` であり、`Control` variantはない。これは実際のN/D検索へ到達する入口の不一致で、未実行のコンパイラを推測する必要なく固定source同士から確認できる。

最小修正はこのcallを `alphabeta::ScoreDomain::LEGACY, OrderingProfile::CheapStaticControl, false, false` の実引数へ合わせること。続く冗長な `session.set_lmr(false)` は除くか、Resultを `?` で処理する。係数・window・TT・木・headの変更は不要。Rootの `fixture-repair-v1.json` はAI test内の一constructorだけを直した別scopeであり、このrunner本番callの修正を含まない。新しいreview親や全suite再演を要求しない。同じconstructor境界の修正確認とRootの必要softwareへ戻す。

以下の六項はこの入口の具体的blockerを除いた実装構造の判定で、固定版の実行可能性を認定するものではない。

## 1. forced親の意味とTT

`alphabeta.rs:2186` の `forced_root_depth` は親を一度enterし、親の合法actionを検査して、既存childへ depth−1、ply1、両端無限のwindowを渡す。childは既存通りmake、context/board遷移、非terminal FT、negamax、undo、符号反転を行う。childを新しいrootとして呼び直していない。

`search_in_table:3168` の反復1..Hは同じstate/stats/node上限を共有し、通常rootとforcedのdispatchだけを分ける。forced側はalllegal `root_depth` のprobe/Exact保存を通らず、finish_valid_rootも除外する。内部negamaxの完全history、実depth一致、domain/bound、合法TT手の条件は既存bodyのまま。PVは親actionから既存child TT経路を辿る。fresh sessionとforced IDにより通常rootのrequestと役割も分離される。低い完成反復は保存されても、要求HのExactへ昇格しない。

## 2. 完全historyと中断・復元

`measurement_loss_leaf.rs:91` の入力照合は、完全prefixを既存checked ownerで再生し、順序付きHistoryKey列、集約count、rules、total ply、駒、stock、壁、手番、現在反復回数を比較する。countから順序を復元せず、selectorもprefix短縮やjsonl射影を拒否する。既存search入口のvalidate_normal、terminal先行、childのcontrol/error/undo、検索後の全親history復元検査を保つ。

共通木はchild再帰の成否にかかわらずundoを試み、undo失敗時には元エラーも添えて失敗にする。parityもdelta/full/headの途中失敗後にundoし、成功時は親identity・FT bits・復元後headを比較する。通常rootそのものは共有せずcloneを使い、外側でもidentity一致を検査する。terminal値は既存terminal ownerから得る。新しいhistory証明器やfrom_counts代替を作っていない。

## 3. 共通木・完備性・符号とtie

`Tree::visit:365` はrootでCだけ、その後は全合法手をH3まで展開する。TT、枝刈り、path mergeはない。ply2/3でcanonical N/D値を保存し、同じ保存木からH2/H3をbackupする。goal/threefoldはstatic計算より先で、既存LEGACY terminal ±2/0と非terminal有限±1を区別する。

`backup:487` は horizonの保存leaf又はterminalを使い、それより浅いnodeは予定全child数が揃い、各child値が存在する場合だけ max(−child) を返す。欠損した応手をstaticで埋めない。H3の深部が途中でも、既に全ply2葉が揃ったH2を利用できる意味は保つ。`ties:531` はf32の数値等値で±0を同tieとし、最小ActionIDを表示上のcanonicalとする。bit順序を数値順位にしていない。C内の完備backupを全合法rootの正解と呼ばない。

## 4. canonical一回headと通常OFF

`residual.rs:320` は元のlinear headを一度呼び、同じFP32 baseline u、residual r、pre=u+r、f64 tanhからFP32 postを一つのviewに返す。通常evaluateはそのpostを使い、research viewも同じ関数を呼ぶ。atanh推定、runner側formula、view用の二度目headはない。

標準化distance入力はbaseline係数0でも元packingに残る。線形head bodyとResidualScratchの保存領域は不変で、input_viewは不変borrow。通常OFFに追加scan、heap確保、head、node時計を入れていない。戻り値を小struct経由にしたことの機械語や実時間は未測定であり、無費用と認定しない。searched値のstatic/TT由来が追えない箇所は出力でもUNKNOWNを維持する。

## 5. 保存介入とPV切替

`saved_comparisons:581` はN/DのC内argmax集合が異なる場合だけ、各canonical winnerをN/D双方のbackupで辿った最大4 endpointを選ぶ。非terminal endpointだけをpath順に重複排除し、単独置換と全同時置換を保存する。global上限30を検査する。

置換は当該leafのlocal N postだけを同leafのD postへ変え、`backup` を全childで再実行する。応手とrootのtie/PVを再選択するので、元PVを固定しない。ここでSearchやheadを再実行せず、別endpointで補充もしない。Dはoracleではなく、固定した有限木での値介入である。元対局の敗因、真のWDL、一般原因・棋力へは外挿できない。

## 6. 全段NNUE会計と有限上限

`Census:170` は各N検索前に1Mの責務を予約し、N最大24、全検索最大48を制御する。正常返却時だけ実stats.evaluationsとの差を精算し、Err時は予約を残す。既存enterがnode上限を検査し、深さ0のevaluate開始前にevaluationsを増やす。今回のResidualEvaluatorはprepare/advanceでFT/contextだけを作り、各evaluateがcanonical head一回へ入る。setupに別headを追加していない。

共通木のview、parityの親・delta・full・復元後headはすべて実呼出し前に `charge_head` を通り、予約込みglobal25Mを超える前に拒否する。FT full/delta開始、head開始、Search evaluations、parity、tree訪問は別counterであり加算して物理forward数にしない。tree訪問300k、parity256、保存介入30にも実制御がある。24,301,027等の机上値を実使用へ置き換えない。Search内部の物理FT/head詳細はUNKNOWNのまま。

## 確認方法・限界と停止

固定patchと必要postimagesの指定関数だけを読んだ。新定義は、forced親TT/累積cap/errorcancel/terminal、canonical view、完全history拒否、欠損frontier/±0、応手切替、parity復元を対象としているが、ここでは実行していない。Rootの既存protected-body/逆patch証拠は元のscopeとして参照し、別の全source監査へ広げていない。

前後のSHA-size-mode照合と実reader/helper/formatter停止は `fixed-source-selected-refs-v2.json`、`fixed-source-STOP.json` に保存する。初期phaseのreport/STOP/FAILEDと今回のSTOPを混同しない。実行資源はCPU8/guardian12の別physical、family上限768MiB、GPU0、reserve4GiB。LLM/controller未記録費・continuous family peakはUNKNOWN。最終の対象usageは一度だけ別receiptに記録する。native、モデルpayload、Search、旧RAW、テスト、bootstrap、solver、Main/Git/Cargo変更は0。全pause/default/model/seal/旧費UNKNOWNを保持する。
