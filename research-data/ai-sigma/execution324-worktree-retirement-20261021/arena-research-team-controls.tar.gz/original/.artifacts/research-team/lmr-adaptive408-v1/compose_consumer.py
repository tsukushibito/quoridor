import gzip
from pathlib import Path

own = Path(__file__).resolve().parent
lc = gzip.decompress(
    (own / "subjects-v1/research-lifecycle.py.before.gz").read_bytes()
).decode()


def alter_function(text, name, old, new):
    start = text.index("def " + name + "(")
    end = text.index("\ndef ", start + 4)
    body = text[start:end]
    assert body.count(old) == 1
    return text[:start] + body.replace(old, new) + text[end:]


lc = alter_function(
    lc,
    "arena_plan_check",
    '            and type(engine.get("lmr", False)) is bool',
    """            and type(engine.get("lmr", False)) is bool
            and engine.get("lmr_method") in (None, "fixed_one", "depth_rank")""",
)
old = """                and method["selectivity"].endswith(
                    ":cheap-static376-integer-parent-v1:"
                    + engine["ordering_profile"]
                    + (
                        ":lmr400-late4-depth3-minus1-pvs-verify-v1"
                        if engine.get("lmr", False)
                        else ""
                    )
                )"""
new = """                # The native typed factory and report validator own exact namespace/ID
                # correspondence. Do not duplicate AI method suffixes in this reader.
                and counters.get("requested_lmr_method")
                == (engine.get("lmr_method") if engine.get("lmr_method") is not None else "fixed_one")
                and (
                    all(isinstance(counters.get(k), str) and counters[k] for k in ("actual_lmr_method_id", "lmr_reduction_rule"))
                    if engine.get("lmr", False)
                    else all(k in counters and counters[k] is None for k in ("actual_lmr_method_id", "lmr_reduction_rule"))
                )"""
lc = alter_function(lc, "arena_observation", old, new)
(own / "edited/research-lifecycle.py").write_text(lc)
print("changed only arena_plan_check / arena_observation")
