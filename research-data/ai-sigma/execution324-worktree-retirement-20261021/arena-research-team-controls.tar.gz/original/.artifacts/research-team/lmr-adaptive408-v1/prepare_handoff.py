import hashlib
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path

own = Path(__file__).resolve().parent


def ref(path):
    path = Path(path)
    body = path.read_bytes()
    return dict(
        path=str(path.resolve()),
        sha256=hashlib.sha256(body).hexdigest(),
        bytes=len(body),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def absent(child):
    try:
        tick = (
            Path(f"/proc/{child['pid']}/stat").read_text().rsplit(")", 1)[1].split()[19]
        )
    except FileNotFoundError:
        return "absent"
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    assert tick != str(child.get("start_ticks")) or boot != child.get("boot_id"), child
    return "different-identity"


# Keep the original failed controller/disk receipts and check their original
# children too. This collection never reissues those commands.
processes = []
for path in sorted(own.glob("*/command.process.json")):
    if path.parent == Path(os.environ["TMPDIR"]).parent:
        continue
    value = json.loads(path.read_text())
    child = value.get("child")
    processes.append(
        dict(
            receipt=ref(path),
            child=child,
            fresh_identity=absent(child) if child else "UNKNOWN",
            persisted_status=value.get("status"),
            persisted_exit_code=value.get("exit_code"),
            persisted_remaining=value.get("remaining"),
            persisted_cleanup_complete=value.get("cleanup_complete"),
            persisted_direct_child_reaped=value.get("direct_child_reaped"),
            persisted_signal_mask_restoration=value.get("signal_mask_restoration"),
        )
    )
for filename in ["formatter-children.json", "final-format-children.json"]:
    for item in json.loads((own / filename).read_text()):
        child = item.get("identity", item)
        item["fresh_identity"] = absent(child)

removed_caches = []
for directory in sorted(own.glob("*/TMP")):
    cache = directory / "node-compile-cache"
    if cache.exists():
        cache_bytes = 0
        for path in cache.rglob("*"):
            assert not path.is_symlink()
            if path.is_file():
                cache_bytes += path.stat().st_size
        assert cache_bytes <= 2 * 1024**2
        shutil.rmtree(cache)
        removed_caches.append(dict(path=str(cache), bytes=cache_bytes))
    if directory == Path(os.environ["TMPDIR"]):
        continue
    assert not list(directory.iterdir()), directory
    directory.rmdir()

proof = json.loads((own / "static-proof.json").read_text())
for subject in proof["subjects"]:
    name = Path(subject["path"]).name
    body = (own / "edited" / name).read_bytes()
    assert (
        hashlib.sha256(body).hexdigest() == subject["after_sha256"]
        and len(body) == subject["after_bytes"]
    )
test_dir = own / "test-definitions"
test_dir.mkdir()
for name in [
    "runtime_lmr_method_tests.rs",
    "arena_lmr_method_tests.rs",
    "test_arena_lmr_method.py",
]:
    (own / "edited" / name).rename(test_dir / name)
# Full edited subjects existed only for source formatting/static validation.
# Recovery is the immutable before gzip + strict forward/inverse patch.
for name in ["runtime.rs", "arena.rs", "research-lifecycle.py"]:
    (own / "edited" / name).unlink()
(own / "edited").rmdir()

selected = [
    own / name
    for name in [
        "forward.patch",
        "inverse.patch",
        "report-ja.md",
        "verification-plan.json",
        "config-field-needed.txt",
        "static-proof.json",
        "protected-proof.json",
        "formatter-cleanup.json",
        "selected-input-refs.json",
    ]
]
selected.extend(sorted(test_dir.iterdir()))
selected.extend(sorted((own / "drafts").glob("*.json")))
binding = dict(
    issue="quoridor-4lc.408.2",
    thread="01a11062-b120-73a1-8aa3-fe2cb922c7c0",
    source_base="aa233e38bab1dd164b6ae163905d386059af229a",
    scope="runtime/arena + arena_plan_check/arena_observation only",
    source_subjects=proof["subjects"],
    selected=[ref(path) for path in selected],
    before_refs=ref(own / "subjects-v1/before-refs.json"),
    temporary_edited_subjects_removed=True,
    native="UNBUILT/UNTYPED/UNRUN",
    rust_new_definitions=3,
    python_new_definitions=1,
    tests_executed=0,
    science_calls=0,
    Main_Git_Cargo_Beads_writes=0,
    existing_Root_only_config_field="72a6d42; separate scope; not overwritten",
    future_image_Build_current_callers_support_experiments_runtime=None,
    actual_source_resources=dict(
        worker=8,
        guardian=11,
        family_B=768 * 1024**2,
        guard_B=704 * 1024**2,
        host_reserve_B=4 * 1024**3,
        GPU=0,
        continuous_peak_RSS="UNKNOWN",
    ),
    process_receipts=processes,
    removed_owned_Node_caches=removed_caches,
    reader_finished_utc=datetime.now(timezone.utc).isoformat(),
    source_lease_acquired=False,
    fast_git_and_patch_child_identity="UNKNOWN; subprocess directwait/reap0; outer guardian receipts retained",
    original_errors=[
        "detail-v1 empty stdin code did not execute inspection",
        "detail-v2 text/bytes capture sink TypeError",
        "inspect.py name shadowed stdlib during named metadata reads; renamed inspect_subjects.py",
        "compose-v1 owning Python validation statement mismatch",
        "formatting-v1 and report-format-v1 tool exit0 but owned Node cache left; wrapper nonzero/TMP retained until exact cleanup",
        "final-static-v1/v2 overly narrow serde/brace insertion ranges; source unchanged; original failures retained",
    ],
    pauses="mixed/learner allprep/pipeline +323USERPAUSE unchanged",
)
(own / "source-binding.json").write_text(
    json.dumps(binding, ensure_ascii=False, indent=2) + "\n"
)
print(
    json.dumps(
        dict(
            binding=ref(own / "source-binding.json"),
            reader_finished_utc=binding["reader_finished_utc"],
            temporary_subjects_removed=True,
            selected_count=len(selected),
            active_science_jobs=[],
        )
    )
)
