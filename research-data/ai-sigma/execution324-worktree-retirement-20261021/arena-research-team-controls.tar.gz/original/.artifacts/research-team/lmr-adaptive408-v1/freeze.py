import ast
import difflib
import gzip
import hashlib
import json
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

own = Path(__file__).resolve().parent
edited = own / "edited"
scratch = Path(os.environ["TMPDIR"]) / "patch-check"
scratch.mkdir()
base = "aa233e38bab1dd164b6ae163905d386059af229a"
mapping = {
    "runtime.rs": "crates/quoridor-runner/src/runtime.rs",
    "arena.rs": "crates/quoridor-runner/src/arena.rs",
    "research-lifecycle.py": "scripts/dev/research-lifecycle.py",
    "runtime_lmr_method_tests.rs": "crates/quoridor-runner/src/runtime_lmr_method_tests.rs",
    "arena_lmr_method_tests.rs": "crates/quoridor-runner/src/arena_lmr_method_tests.rs",
}


def stamp():
    return datetime.now(timezone.utc).isoformat()


def ref(path):
    path = Path(path)
    b = path.read_bytes()
    return dict(
        path=str(path.resolve()),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def fresh_absent(identity):
    if not identity or not identity.get("pid"):
        return "UNKNOWN-unrecorded-identity"
    path = Path(f"/proc/{identity['pid']}/stat")
    try:
        tick = path.read_text().rsplit(")", 1)[1].split()[19]
    except FileNotFoundError:
        return "absent"
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    assert boot != identity.get("boot_id") or tick != str(
        identity.get("start_ticks")
    ), identity
    return "different-identity"


# Drain was already completed by the original formatter command. Remove only
# its bounded owned Node cache after checking those exact original children.
children = json.loads((own / "formatter-children.json").read_text())
for child in children:
    child["fresh_identity"] = fresh_absent(child)
cache = own / "formatting-v1/TMP/node-compile-cache"
cache_bytes = 0
if cache.exists():
    for path in cache.rglob("*"):
        assert not path.is_symlink()
        if path.is_file():
            cache_bytes += path.stat().st_size
    assert cache_bytes <= 2 * 1024**2
    shutil.rmtree(cache)
    cache.parent.rmdir()
(own / "formatter-cleanup.json").write_text(
    json.dumps(
        dict(
            children=children,
            own_Node_cache_removed_B=cache_bytes,
            TMP_absent=not cache.parent.exists(),
        ),
        indent=2,
    )
    + "\n"
)

before_lc = gzip.decompress(
    (own / "subjects-v1/research-lifecycle.py.before.gz").read_bytes()
).decode()
after_lc = (edited / "research-lifecycle.py").read_text()
before_ast = ast.parse(before_lc)
after_ast = ast.parse(after_lc)
allowed = {"arena_plan_check", "arena_observation"}


def protected(tree):
    return [
        ast.dump(node, include_attributes=False)
        for node in tree.body
        if not isinstance(node, ast.FunctionDef) or node.name not in allowed
    ]


assert protected(before_ast) == protected(after_ast)
changed = []
for name in allowed:
    b = next(
        n for n in before_ast.body if isinstance(n, ast.FunctionDef) and n.name == name
    )
    a = next(
        n for n in after_ast.body if isinstance(n, ast.FunctionDef) and n.name == name
    )
    assert ast.dump(b) != ast.dump(a)
    changed.append(name)
assert "lmr400-late4-depth3-minus1-pvs-verify-v1" not in ast.get_source_segment(
    after_lc,
    next(
        n
        for n in after_ast.body
        if isinstance(n, ast.FunctionDef) and n.name == "arena_observation"
    ),
)

before_map = {}
post_map = {}
patch = []
subjects = []
for name, destination in mapping.items():
    before_path = own / ("subjects-v1/" + name + ".before.gz")
    b = gzip.decompress(before_path.read_bytes()) if before_path.exists() else b""
    a = (edited / name).read_bytes()
    before_map[destination] = b
    post_map[destination] = a
    target = scratch / destination
    target.parent.mkdir(parents=True, exist_ok=True)
    if b:
        target.write_bytes(b)
    else:
        assert not target.exists()
    patch.extend(
        difflib.unified_diff(
            b.decode().splitlines(keepends=True),
            a.decode().splitlines(keepends=True),
            fromfile="a/" + destination if b else "/dev/null",
            tofile="b/" + destination,
            n=3,
        )
    )
    subjects.append(
        dict(
            path=destination,
            git_base=base,
            before_sha256=hashlib.sha256(b).hexdigest() if b else None,
            before_bytes=len(b) if b else None,
            before_absent=not bool(b),
            after_sha256=hashlib.sha256(a).hexdigest(),
            after_bytes=len(a),
        )
    )
forward = own / "forward.patch"
inverse = own / "inverse.patch"
forward.write_text("".join(patch))
inverse_text = []
for destination in mapping.values():
    b, a = before_map[destination], post_map[destination]
    inverse_text.extend(
        difflib.unified_diff(
            a.decode().splitlines(keepends=True),
            b.decode().splitlines(keepends=True),
            fromfile="a/" + destination,
            tofile="b/" + destination if b else "/dev/null",
            n=3,
        )
    )
inverse.write_text("".join(inverse_text))
patch_receipts = []
for file, expect in [(forward, post_map), (inverse, before_map)]:
    child = subprocess.Popen(
        ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(file)],
        cwd=scratch,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    output = child.communicate()[0].decode()
    assert child.returncode == 0, output
    for destination, expected in expect.items():
        target = scratch / destination
        if expected:
            assert target.read_bytes() == expected
        else:
            assert not target.exists()
    patch_receipts.append(
        dict(
            patch=ref(file),
            directwait_exit=child.returncode,
            reaped=True,
            output=output,
            fast_child_identity="UNKNOWN",
        )
    )
shutil.rmtree(scratch)

# Verify only the actual new draft structure, not native/legal game execution.
draft = own / "drafts"
resolved = json.loads((draft / "resolved-draft.json").read_text())
plan = json.loads((draft / "arena-plan.json").read_text())
slots = json.loads((draft / "arena-schedule.json").read_text())
assert len(slots) == 128 and sorted(s["slot"] for s in slots) == list(range(128))
assert len({(s["batch"], s["family_id"]) for s in slots}) == 64
assert len(plan["family_ids"]) == len(set(plan["family_ids"])) == 16
for batch in plan["batches"]:
    subset = [s for s in slots if s["batch"] == batch["batch"]]
    assert len(subset) == 32
    for family in plan["family_ids"]:
        assert sorted(
            s["candidate_color"] for s in subset if s["family_id"] == family
        ) == [0, 1]
    cfg = json.loads(Path(batch["config"]["path"]).read_text())
    assert ref(batch["config"]["path"]) == batch["config"]
    assert cfg["games"] == 32 and len(cfg["arena"]["book"]["openings"]) == 16
    assert cfg["arena"]["search_artifact_sha256"] == [None, None]
    assert [e["lmr_method"] for e in cfg["engines"]] == ["fixed_one", "depth_rank"]
    assert all(
        e["lmr"]
        and e["depth"] == 64
        and e["max_nodes"] == 1000000
        and e["time_ms"] == 100
        for e in cfg["engines"]
    )
    assert (
        cfg["arena"]["return_reserve_ms"] == 5 and cfg["arena"]["tt_entries"] == 1048576
    )
cost = resolved["cost"]["rows"]
assert (
    len(cost) == 16
    and sum(r["calls"] for r in cost) == 96
    and sum(r["sessions"] for r in cost) == 48
)
for i in range(0, 16, 4):
    assert [r["lmr_method"] for r in cost[i : i + 4]] == [
        "fixed_one",
        "depth_rank",
        "depth_rank",
        "fixed_one",
    ]
for path in draft.glob("*.json"):
    json.loads(path.read_text())
for ref_list in [own / "selected-input-refs.json", draft / "read-refs.json"]:
    for item in json.loads(ref_list.read_text()):
        assert ref(item["path"]) == item

# Static native protection: complete unchanged functions/regions remain
# byte-identical modulo rustfmt whitespace. These are source checks, not types.
before_runtime = gzip.decompress(
    (own / "subjects-v1/runtime.rs.before.gz").read_bytes()
).decode()
after_runtime = (edited / "runtime.rs").read_text()
for name in ["sigma_receipt_decision", "inference_work"]:

    def function(text):
        start = text.index("fn " + name + "(")
        # These two leading functions have their own unchanged bodies. Keep a
        # prefix/body view ending at the next top-level declaration.
        end = text.index("\n}", start) + 2
        return "".join(text[start:end].split())

    assert function(before_runtime) == function(after_runtime)

static = dict(
    utc=stamp(),
    python_outside_two_functions_AST_exact=True,
    changed_functions=sorted(changed),
    patch_forward_inverse_exact=True,
    new_file_absence_restored=True,
    patch_receipts=patch_receipts,
    runtime_sigma_receipt_and_inference_work_unchanged=True,
    draft_128_unique_64_pairs_four_operations_32_games=True,
    cost_96_48_288M_ABBA=True,
    named_input_refs_after_MATCH=True,
    native_status="UNBUILT/UNTYPED/UNRUN",
    tests_executed=0,
    source_base=base,
    subjects=subjects,
)
(own / "static-proof.json").write_text(json.dumps(static, indent=2) + "\n")
print(
    json.dumps(
        {k: v for k, v in static.items() if k not in ["subjects", "patch_receipts"]}
    )
)
