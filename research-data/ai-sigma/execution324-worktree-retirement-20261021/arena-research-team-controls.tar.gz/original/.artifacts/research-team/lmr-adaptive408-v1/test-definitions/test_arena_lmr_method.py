"""New saved-reader boundary definition; author never executes this test."""

import ast
import copy
import math
import os
import unittest
from pathlib import Path


class ArenaLmrMethodTests(unittest.TestCase):
    def test_requested_effective_method_and_off_nulls_keep_receipt_guard(self):
        source = Path(os.environ["QUORIDOR_LIFECYCLE_TEST_SOURCE"]).read_text()
        tree = ast.parse(source)
        function = next(
            n
            for n in tree.body
            if isinstance(n, ast.FunctionDef) and n.name == "arena_observation"
        )

        def require(condition, message):
            if not condition:
                raise ValueError(message)

        ns = {"math": math, "require": require}
        exec(
            compile(
                ast.Module(body=[function], type_ignores=[]),
                "owning arena_observation",
                "exec",
            ),
            ns,
        )
        audit = ns["arena_observation"]
        config = {
            "engines": [
                {
                    "kind": "distance",
                    "simd": False,
                    "ordering_profile": "control",
                    "lmr": True,
                    "lmr_method": "depth_rank",
                }
            ],
            "arena": {
                "comparison": "whole_wall_time",
                "evaluator_sha256": ["test-evaluator"],
                "book": {"openings": [{"prefix": []}]},
            },
        }
        # Synthetic native-authority metadata: no engine, geometry or WDL call.
        row = {
            "game": 0,
            "moves": [4],
            "observations": [
                {
                    "engine_index": 0,
                    "accepted": True,
                    "failure": None,
                    "engine_error": None,
                    "action": 4,
                    "accepted_ns": 14,
                    "admission_checked_ns": 13,
                    "returned_ns": 12,
                    "deadline_ns": 20,
                    "completed_depth": 3,
                    "value_stm": 0.0,
                    "pv": [4],
                    "counters": {
                        "actual_search_namespace": {
                            "evaluator": "distance-tanh-f32:sha256:test-evaluator:simd=false",
                            "rules": "research-standard-2p-threefold-goal-first-v1",
                            "selectivity": "synthetic-native-owned-selectivity",
                        },
                        "actual_lmr_enabled": True,
                        "requested_lmr_method": "depth_rank",
                        "actual_lmr_method_id": "synthetic-native-owned-id",
                        "lmr_reduction_rule": "synthetic-native-owned-rule",
                        "completed_snapshot_validation_failed": False,
                        "authority_receipt_ns": 10,
                        "drain_finished_ns": 12,
                        "inflight_after_drain": 0,
                    },
                }
            ],
        }
        audit(config, row)
        wrong = copy.deepcopy(row)
        wrong["observations"][0]["counters"]["requested_lmr_method"] = "fixed_one"
        with self.assertRaises(ValueError):
            audit(config, wrong)
        late = copy.deepcopy(row)
        late["observations"][0]["counters"]["authority_receipt_ns"] = 20
        with self.assertRaises(ValueError):
            audit(config, late)
        config["engines"][0]["lmr"] = False
        off = copy.deepcopy(row)
        counters = off["observations"][0]["counters"]
        counters.update(
            actual_lmr_enabled=False, actual_lmr_method_id=None, lmr_reduction_rule=None
        )
        audit(config, off)
        del counters["actual_lmr_method_id"]
        with self.assertRaises(ValueError):
            audit(config, off)


if __name__ == "__main__":
    unittest.main()
