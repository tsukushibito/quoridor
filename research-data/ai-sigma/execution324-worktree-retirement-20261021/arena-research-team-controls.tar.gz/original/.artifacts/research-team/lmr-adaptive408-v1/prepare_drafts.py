import ast
import copy
import gzip
import hashlib
import json
from pathlib import Path

own = Path(__file__).resolve().parent
out = own / "drafts"
out.mkdir(exist_ok=False)
old = Path(
    "/workspaces/quoridor/.artifacts/research-team/integration324/shared-signed-ordering402-v1"
)
base = "aa233e38bab1dd164b6ae163905d386059af229a"
reads = []


def ref(path):
    path = Path(path)
    b = path.read_bytes()
    return dict(
        path=str(path.resolve()),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )


def load(path, expected=None):
    actual = ref(path)
    if expected is not None:
        assert actual == expected
    reads.append(actual)
    return json.loads(Path(path).read_bytes())


def save(name, value):
    path = out / name
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


# Execute only the three existing pure preparation helpers from immutable Git
# bytes. Their implementation is not copied into this run helper.
lc = gzip.decompress(
    (own / "subjects-v1/research-lifecycle.py.before.gz").read_bytes()
).decode()
names = {"comparison_conditions", "apply_comparison_cost", "apply_comparison_arena"}
tree = ast.parse(lc)
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
assert len(nodes) == 3
ns = {}
exec(
    compile(ast.Module(body=nodes, type_ignores=[]), "immutableGit:" + base, "exec"), ns
)

plan = load(old / "arena128-v1/plan.json")
book = load(plan["book"]["path"], plan["book"])
seed = 40820261015
selected = []
selection = []
for length in [4, 8, 12, 16]:
    pool = [f for f in book["families"] if len(f["prefix"]) == length]
    ranked = sorted(
        pool,
        key=lambda f: hashlib.sha256(
            f"{seed}:{length}:{f['family_id']}".encode()
        ).digest(),
    )
    assert len(pool) >= 4
    chosen = sorted(ranked[:4], key=lambda f: f["family_id"])
    selected.extend(chosen)
    selection.append(
        dict(
            prefix_length=length,
            pool_count=len(pool),
            family_ids=[f["family_id"] for f in chosen],
        )
    )
assert len({f["family_id"] for f in selected}) == 16
selected_ref = save(
    "selection.json",
    dict(
        seed=seed,
        algorithm="per stratum SHA256(UTF8 decimal seed:prefix_length:family_id), first4 digest order, then original family order",
        source_book=plan["book"],
        strata=selection,
        family_ids=[f["family_id"] for f in selected],
        status="pre-outcome fixed metadata selection; no replay/geometry/qualification",
        lineage="historical unsealed355 book reused by402; no new sealed/holdout claim",
    ),
)

arena_template = load(
    plan["batches"][0]["config"]["path"], plan["batches"][0]["config"]
)
distance_template = load(
    plan["batches"][4]["config"]["path"], plan["batches"][4]["config"]
)
common = dict(
    evaluators=["nnue", "distance"],
    profiles=["control", "cheap"],
    lmr_values=[True],
    tt_entries=1048576,
    use_tt=True,
    use_pvs=True,
    rules=plan["rules"],
    ruleset=arena_template["ruleset"],
    host_reserve_B=4 * 1024**3,
    family_B=4 * 1024**3,
    controller_B=64 * 1024**2,
    arena=dict(
        AI_workers=[2, 6],
        management_guardian=4,
        return_reserve_ms=5,
        max_plies=200,
        depth=64,
        max_nodes=1000000,
        time_ms=100,
    ),
)
variants = ns["comparison_conditions"](common)
arena_owner = "/workspaces/quoridor/.worktree/assets/perf/lmr-adaptive408-arena128-v1"
cost_owner = "/workspaces/quoridor/.worktree/assets/perf/lmr-adaptive408-cost96-v1"
openings = []
for family in selected:
    openings.append(
        dict(
            id=family["id"],
            cohort="main",
            lineage=f"original355-family-{family['family_id']}",
            siblings=[],
            original_seed=family["seed"],
            reference=dict(
                source_sha256=plan["book"]["sha256"],
                model_sha256=None,
                settings=family,
                q_definition=None,
                q_perspective=None,
                q_aggregation=None,
                q=None,
            ),
            selection_reason="408 pre-outcome fixed16 SHA256 length-stratified selection; no refill",
            candidate_pool_size=32,
            prefix=family["prefix"],
        )
    )
book_view = dict(
    id="408-preoutcome-unsealed355-16",
    usage="main",
    frozen_before_candidate_results=True,
    independence="Same16 families reused across4 contrasts; two colours paired; conditional fixed-book family interval, not128 independent samples",
    openings=openings,
)
schedule = []
configs = []
matchups = []
methods = ["fixed_one", "depth_rank"]
for batch, variant in enumerate(variants):
    template = arena_template if variant["evaluator"] == "nnue" else distance_template
    cfg = copy.deepcopy(template)
    ns["apply_comparison_arena"](cfg, common, [variant, variant])
    cfg["run_id"] = (
        f"408-{variant['evaluator']}-{variant['profile']}-fixed_one-vs-depth_rank"
    )
    cfg["output"] = f"{arena_owner}/batch-{batch:03}/data"
    cfg["games"] = 32
    cfg["seed"] = seed
    cfg["arena"]["book"] = copy.deepcopy(book_view)
    cfg["arena"]["bootstrap_seed"] = seed
    cfg["arena"]["first_candidate_colors"] = [i % 2 for i in range(16)]
    cfg["arena"]["search_artifact_sha256"] = [None, None]
    for engine, method in zip(cfg["engines"], methods, strict=True):
        engine["lmr_method"] = method
    cfg_ref = save(f"arena-config-{batch:03}.json", cfg)
    slots = []
    for i, family in enumerate(selected):
        for color in range(2):
            slot = len(schedule)
            slots.append(slot)
            schedule.append(
                dict(
                    slot=slot,
                    batch=batch,
                    matchup=batch,
                    local_game=2 * i + color,
                    family_id=family["family_id"],
                    candidate_color=(i % 2) ^ color,
                )
            )
    configs.append(dict(batch=batch, matchup=batch, config=cfg_ref, slots=slots))
    matchups.append(
        dict(
            id=batch,
            engines=cfg["engines"],
            evaluator_sha256=cfg["arena"]["evaluator_sha256"],
            inference=None,
        )
    )
schedule_ref = save("arena-schedule.json", schedule)
new_plan = copy.deepcopy(plan)
new_plan.update(
    schedule=schedule_ref,
    family_ids=[f["family_id"] for f in selected],
    matchups=matchups,
    batches=configs,
    planned_slots=128,
)
plan_ref = save("arena-plan.json", new_plan)

old_arena_settings = load(old / "arena128-v1/settings.json")
arena_settings = copy.deepcopy(old_arena_settings)
arena_settings.update(
    owner=arena_owner, output=arena_owner + "/execution-v1", measurements=[]
)
arena_settings["arena"]["range"] = [0, 3]
arena_settings["arena"]["template"] = dict(
    schema="quoridor.research.lifecycle-intent.v1",
    kind="run",
    owner=arena_owner,
    writer="codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13",
    cwd="/workspaces/quoridor",
    output=arena_owner + "/template/operation",
    artifact=None,
    experiment=None,
    support=None,
    caller_sources=None,
    approved_plan=plan_ref,
    argv=None,
    env=None,
    limits=copy.deepcopy(old_arena_settings["arena"]["template"]["limits"]),
)
save("arena-settings.json", arena_settings)

cost_settings = load(old / "cost96-v1/settings.json")
cost_measurements = []
cost_rows = []
requests_ref = None
for variant in variants:
    old_index = 0 if variant["evaluator"] == "nnue" else 8
    intent = cost_settings["measurements"][old_index]
    exp = load(intent["experiment"]["path"], intent["experiment"])
    config_template = load(exp["config"]["path"], exp["config"])
    if requests_ref is None:
        requests = load(exp["schedule"]["path"], exp["schedule"])
        assert len(requests) == 6 and sum(r["node_cap"] for r in requests) == 18000000
        assert all(
            r["time_limit_ms"] is None
            and not r["diagnostic"]
            and not r["observe_completed_depths"]
            for r in requests
        )
        requests_ref = save("cost-requests.json", requests)
    for pass_index, method in enumerate(
        ["fixed_one", "depth_rank", "depth_rank", "fixed_one"]
    ):
        index = len(cost_measurements)
        cfg = copy.deepcopy(config_template)
        ns["apply_comparison_cost"](cfg, common, variant)
        cfg["lmr_method"] = method
        # Zero-stock approximation is absent in402 and therefore false. The
        # new406/407 selector must stay OFF, not be enabled by method strings.
        cfg_ref = save(f"cost-config-{index:03}.json", cfg)
        exp_draft = copy.deepcopy(exp)
        exp_draft.update(
            build_manifest=None,
            config=cfg_ref,
            schedule=requests_ref,
            batch=index,
            argv=None,
        )
        exp_ref = save(f"cost-experiment-{index:03}.json", exp_draft)
        item = dict(
            schema="quoridor.research.lifecycle-intent.v1",
            kind="run",
            owner=cost_owner,
            writer="codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            cwd="/workspaces/quoridor",
            output=f"{cost_owner}/template-{index:03}/operation",
            data_root=f"{cost_owner}/template-{index:03}/data",
            owned_outputs=[f"{cost_owner}/template-{index:03}"],
            artifact=None,
            experiment=exp_ref,
            caller_sources=None,
            support=None,
            argv=None,
            env=None,
            limits=copy.deepcopy(intent["limits"]),
            measurement=copy.deepcopy(intent.get("measurement")),
        )
        cost_measurements.append(item)
        cost_rows.append(
            dict(
                index=index,
                evaluator=variant["evaluator"],
                profile=variant["profile"],
                lmr=True,
                lmr_method=method,
                pass_index=pass_index,
                config=cfg_ref,
                experiment=exp_ref,
                calls=6,
                sessions=3,
                node_cap=18000000,
            )
        )
save(
    "cost-settings.json",
    dict(
        schema="quoridor.research.sequence.v1",
        kind="sequence",
        cwd="/workspaces/quoridor",
        owner=cost_owner,
        output=cost_owner + "/execution-v1",
        arena=None,
        arena_block=1,
        serial_order=["arena", "measure"],
        measurements=cost_measurements,
    ),
)
save(
    "resolved-draft.json",
    dict(
        ready=False,
        common=common,
        methods=dict(A="fixed_one", B="depth_rank"),
        cost=dict(rows=cost_rows, calls=96, sessions=48, node_cap=288000000),
        arena=dict(
            contrasts=4,
            families=16,
            pairs=64,
            games=128,
            selection=selected_ref,
            plan=plan_ref,
        ),
        zero_stock_approximation=False,
        provenance=dict(
            git=base,
            helper_names=sorted(names),
            inherited_model_and_library_refs="declared frozen402 only; no payload read/current qualification",
        ),
        unresolved=dict(
            image=None,
            build=None,
            current_callers=None,
            current_environment=None,
            physical_quiet_admission=None,
            resource_support=None,
            actual_experiments=None,
            runtime=None,
        ),
        native_entry=False,
    ),
)
save(
    "result-table.json",
    dict(
        status="unentered",
        cost=[
            dict(
                evaluator=v["evaluator"],
                profile=v["profile"],
                lmr_method=m,
                calls=None,
                complete=None,
                unknown=None,
                whole_median=None,
                nodes=None,
                evals=None,
                selective_nominal_depth=None,
                setup=None,
                drop=None,
            )
            for v in variants
            for m in methods
        ],
        arena=[
            dict(
                evaluator=v["evaluator"],
                profile=v["profile"],
                left="fixed_one",
                right="depth_rank",
                entered=None,
                W=None,
                D=None,
                L=None,
                UNKNOWN=None,
                family_scores=None,
                native_family_CI95=None,
            )
            for v in variants
        ],
        method_observations=[
            dict(
                evaluator=v["evaluator"],
                profile=v["profile"],
                lmr_method=m,
                accepted=None,
                selected_depth_n=None,
                selected_depth_median=None,
                selected_depth_histogram=None,
                selected_depth_mean=None,
                selected_work=None,
                terminal_work=None,
                TT_gauge=None,
            )
            for v in variants
            for m in methods
        ],
        cautions=[
            "16 shared families; conditional native interval, no new bootstrap",
            "selected nominal depth is selective, not full width; trajectories/endgame mix differ",
            "selected snapshot and terminal work are nested and not added; TT gauge is separate",
            "unrecorded RSS/isolated cost/physical forward work UNKNOWN",
            "no400/402 outcome pooling or causal speed inference",
        ],
    ),
)

for item in reads:
    assert ref(item["path"]) == item
save("read-refs.json", reads)
print(
    json.dumps(
        dict(
            family_ids=[f["family_id"] for f in selected],
            strata=selection,
            arena_games=len(schedule),
            arena_pairs=len(schedule) // 2,
            contrasts=len(configs),
            cost_calls=sum(r["calls"] for r in cost_rows),
            cost_sessions=sum(r["sessions"] for r in cost_rows),
            all_future_refs_null=True,
        )
    )
)
