import gzip
import hashlib
import json
import subprocess
from pathlib import Path

p = Path(__file__).resolve().parent / "subjects-v1"
base = "aa233e38bab1dd164b6ae163905d386059af229a"
for path in [
    "crates/quoridor-runner/src/config.rs",
    "crates/quoridor-runner/src/runtime_lmr400_tests.rs",
    "crates/quoridor-runner/src/arena_lmr400_tests.rs",
]:
    b = subprocess.run(
        ["git", "show", base + ":" + path], capture_output=True, check=True
    ).stdout
    p.joinpath(Path(path).name + ".before.gz").write_bytes(gzip.compress(b, mtime=0))
    print(path, len(b), hashlib.sha256(b).hexdigest())
    s = b.decode().splitlines()
    if path.endswith("config.rs"):
        i = next(i for i, line in enumerate(s) if "pub struct Engine" in line)
        print("\n".join(s[i : i + 80]))
    else:
        print(b.decode()[:11000])
for name in [
    "comparison_conditions",
    "apply_comparison_cost",
    "apply_comparison_arena",
]:
    print(name, p.joinpath(name + ".before.txt").read_text())
r = Path(".artifacts/research-team/integration324/shared-signed-ordering402-v1")
for name in [
    "arena128-v1/plan.json",
    "arena128-v1/settings.json",
    "cost96-v1/settings.json",
]:
    x = json.loads((r / name).read_text())
    print(name, "KEYS", list(x))
    if "plan" in name:
        print(
            json.dumps(
                {
                    k: v
                    for k, v in x.items()
                    if k not in ["schedule", "batches", "matchups"]
                },
                indent=1,
            )[:12000]
        )
        print("FIRST_BATCH", json.dumps(x.get("batches", [None])[0])[:3000])
        print("FIRST_MATCHUP", json.dumps(x.get("matchups", [None])[0])[:2000])
    elif "arena" in name:
        print("ARENA", json.dumps(x.get("arena"))[:3000])
    else:
        m = x["measurements"][0]
        print("first_experiment", m["experiment"])
        e = json.loads(Path(m["experiment"]["path"]).read_text())
        print("expkeys", list(e))
        print(json.dumps(e, indent=1)[:9000])
