import ast
import difflib
import gzip
import json
import subprocess
from pathlib import Path

own = Path(__file__).resolve().parent
edited = own / "edited"
before_dir = own / "subjects-v1"


def function_range(lines, name):
    start = next(
        i
        for i, line in enumerate(lines)
        if ("fn " + name + "(") in line and not line.startswith(" ")
    )
    end = next(i for i in range(start + 1, len(lines)) if lines[i] == "}") + 1
    return start, end


protected = {}
for name in ["runtime.rs", "arena.rs"]:
    before = (
        gzip.decompress((before_dir / (name + ".before.gz")).read_bytes())
        .decode()
        .splitlines()
    )
    after = (edited / name).read_text().splitlines()
    if name == "runtime.rs":
        allowed = [
            function_range(before, n)
            for n in ["arena_alpha_namespace", "arena_alpha_session"]
        ]
        tokens = [
            "pub actual_lmr_enabled: Option<bool>",
            "profile.actual_lmr_enabled = Some(session.lmr_enabled());",
            '"actual_lmr_enabled":game.tt_profiles[engine].actual_lmr_enabled,',
        ]
    else:
        allowed = []
        tokens = [
            "for engine in &c.engines {",
            "|| a.lmr != b.lmr",
            "let fallback = a.comparison == Comparison::WholeWallTime",
        ]
    for token in tokens:
        for i, line in enumerate(before):
            if token in line:
                # diff may align the new if's closing brace with the preceding
                # MCTS branch brace; include that one unchanged brace boundary.
                low = i - 1 if token.startswith("let fallback") else i
                allowed.append(
                    (
                        low,
                        i
                        + (2 if token == "pub actual_lmr_enabled: Option<bool>" else 1),
                    )
                )
    # The new helper precedes the existing namespace function, and two test mod
    # declarations are appended. No timing/rules/search body is allowed to drift.
    allowed.append((len(before), len(before)))
    changes = []
    for tag, a, b, c, d in difflib.SequenceMatcher(
        a=before, b=after, autojunk=False
    ).get_opcodes():
        if tag == "equal":
            continue
        assert any(a >= low and b <= high for low, high in allowed), (
            name,
            tag,
            a,
            b,
            before[a:b],
        )
        changes.append(
            dict(before_lines=[a + 1, b], after_lines=[c + 1, d], operation=tag)
        )
    protected[name] = dict(outside_selected_hunks_exact=True, changed_hunks=changes)
python_files = sorted(own.glob("*.py")) + sorted(edited.glob("*.py"))
for path in python_files:
    ast.parse(path.read_text(), filename=str(path))
ruff = "/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff"
config = "/workspaces/quoridor/pyproject.toml"
commands = [
    [ruff, "format", "--config", config, *map(str, python_files)],
    [ruff, "check", "--config", config, *map(str, python_files)],
    [
        "rustfmt",
        "--check",
        "--edition",
        "2024",
        "--config",
        "skip_children=true",
        *map(str, sorted(edited.glob("*.rs"))),
    ],
]
receipts = []
for command in commands:
    child = subprocess.Popen(command)
    identity = dict(
        pid=child.pid,
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    )
    try:
        identity["start_ticks"] = (
            Path(f"/proc/{child.pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
        )
    except FileNotFoundError:
        identity["start_ticks"] = "UNKNOWN-fast-child"
    code = child.wait()
    receipts.append(
        dict(
            command=command,
            identity=identity,
            exit_code=code,
            directwait=True,
            reaped=True,
        )
    )
    (own / "final-format-children.json").write_text(
        json.dumps(receipts, indent=2) + "\n"
    )
    assert code == 0
(own / "protected-proof.json").write_text(
    json.dumps(
        dict(
            protected=protected,
            python_syntax_only=True,
            native_types="UNBUILT/UNTYPED/UNRUN",
            tests_run=0,
        ),
        indent=2,
    )
    + "\n"
)
print(
    "protected outside hunks exact, syntax + scoped format/lint PASS; native/test UNRUN"
)
