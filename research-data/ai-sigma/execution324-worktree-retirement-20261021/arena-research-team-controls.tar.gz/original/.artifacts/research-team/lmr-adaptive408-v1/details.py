import gzip
import hashlib
import json
from pathlib import Path

own = Path(__file__).resolve().parent
refs = []


def read(path, expected=None):
    path = Path(path)
    b = path.read_bytes()
    ref = dict(
        path=str(path.resolve()),
        sha256=hashlib.sha256(b).hexdigest(),
        bytes=len(b),
        mode=f"{path.stat().st_mode & 0o777:04o}",
    )
    if expected:
        assert all(ref[k] == expected[k] for k in ["path", "sha256", "bytes", "mode"])
    refs.append(ref)
    return json.loads(b)


root = Path(".artifacts/research-team/integration324/shared-signed-ordering402-v1")
plan = read(root / "arena128-v1/plan.json")
book = read(plan["book"]["path"], plan["book"])
print("BOOK", type(book), list(book) if isinstance(book, dict) else "array")
families = book["families"]
print("FAMILIES", len(families), json.dumps(families[:2])[:6000])
config = read(plan["batches"][0]["config"]["path"], plan["batches"][0]["config"])
print("ARENA_CONFIG", json.dumps(config, indent=1)[:13000])
settings = read(root / "cost96-v1/settings.json")
for index in [0, 8]:
    intent = settings["measurements"][index]
    exp = read(intent["experiment"]["path"], intent["experiment"])
    cfg = read(exp["config"]["path"], exp["config"])
    print("COST_CONFIG", index, json.dumps(cfg, indent=1))
    requests = read(exp["schedule"]["path"], exp["schedule"])
    print("REQUESTS", json.dumps(requests)[:3500])
for ref in refs:
    read_bytes = Path(ref["path"]).read_bytes()
    assert (
        len(read_bytes) == ref["bytes"]
        and hashlib.sha256(read_bytes).hexdigest() == ref["sha256"]
    )
(own / "selected-input-refs.json").write_text(json.dumps(refs, indent=2) + "\n")
s = (
    gzip.decompress((own / "subjects-v1/arena.rs.before.gz").read_bytes())
    .decode()
    .splitlines()
)
for a, b in [(115, 160), (345, 400), (700, 775), (815, 870)]:
    print("ARENA", a, b, "\n".join(s[a - 1 : b]))
