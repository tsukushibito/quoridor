import copy
import json
from pathlib import Path

own = Path(__file__).resolve().parent
draft = own / "drafts"
old = Path(".artifacts/research-team/integration324/shared-signed-ordering402-v1")


def mapped(value, before, after):
    if isinstance(value, str):
        return after + value[len(before) :] if value.startswith(before) else value
    if isinstance(value, list):
        return [mapped(v, before, after) for v in value]
    if isinstance(value, dict):
        return {k: mapped(v, before, after) for k, v in value.items()}
    return value


def save(name, value):
    (draft / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


for phase in ["cost96", "arena128"]:
    original = json.loads((old / f"{phase}-v1/settings.json").read_text())
    current = json.loads(
        (
            draft
            / ("cost-settings.json" if phase == "cost96" else "arena-settings.json")
        ).read_text()
    )
    owner = current["owner"]
    if phase == "cost96":
        for i, current_intent in enumerate(current["measurements"]):
            template = original["measurements"][i]
            intent = mapped(copy.deepcopy(template), original["owner"], owner)
            for key in [
                "artifact",
                "support",
                "caller_sources",
                "argv",
                "env",
                "finalizers",
            ]:
                intent[key] = None
            intent["experiment"] = current_intent["experiment"]
            current["measurements"][i] = intent
    else:
        template = mapped(
            copy.deepcopy(original["arena"]["template"]), original["owner"], owner
        )
        for key in [
            "artifact",
            "experiment",
            "support",
            "caller_sources",
            "argv",
            "env",
            "finalizers",
        ]:
            if key in template:
                template[key] = None
        template["approved_plan"] = current["arena"]["template"]["approved_plan"]
        current["arena"]["template"] = template
    save("cost-settings.json" if phase == "cost96" else "arena-settings.json", current)
print(
    "draft intents preserve original existing format/TMP/data/limits keys; future bindings null"
)
