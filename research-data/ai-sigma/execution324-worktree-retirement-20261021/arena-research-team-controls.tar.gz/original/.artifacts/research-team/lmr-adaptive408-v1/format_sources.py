import json
import os
import subprocess
from pathlib import Path

own = Path(__file__).resolve().parent
env = dict(os.environ, NODE_OPTIONS="--max-old-space-size=128", NODE_COMPILE_CACHE="")
ruff = "/home/vscode/.cache/inference/envs/quoridor-training/bin/ruff"
config = "/workspaces/quoridor/pyproject.toml"
prettier = "/workspaces/quoridor/tools/research-quality/node_modules/.bin/prettier"
python_files = sorted(own.glob("*.py")) + sorted((own / "edited").glob("*.py"))
rust_files = sorted((own / "edited").glob("*.rs"))
commands = [
    [
        "rustfmt",
        "--edition",
        "2024",
        "--config",
        "skip_children=true",
        *map(str, rust_files),
    ],
    [ruff, "format", "--config", config, *map(str, python_files)],
    [ruff, "check", "--config", config, *map(str, python_files)],
    [
        prettier,
        "--config",
        "/workspaces/quoridor/tools/research-quality/.prettierrc.json",
        "--write",
        str(own / "report-ja.md"),
        str(own / "verification-plan.json"),
    ],
]
receipts = []
for command in commands:
    child = subprocess.Popen(command, env=env)
    receipt = dict(
        command=command,
        pid=child.pid,
        boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    )
    try:
        receipt["start_ticks"] = (
            Path(f"/proc/{child.pid}/stat").read_text().rsplit(")", 1)[1].split()[19]
        )
    except FileNotFoundError:
        receipt["start_ticks"] = "UNKNOWN-fast-child"
    code = child.wait()
    receipt.update(exit_code=code, directwait=True, reaped=True)
    receipts.append(receipt)
    (own / "formatter-children.json").write_text(json.dumps(receipts, indent=2) + "\n")
    if code:
        raise SystemExit(code)
print("scoped formatting/lint complete; no test/native entry")
