# 408.2 arena呼出境界と未入場draft

今回の私有差分はruntime/arenaと既存Pythonの `arena_plan_check` / `arena_observation` のみ。immutable Git `aa233e38bab1dd164b6ae163905d386059af229a` を基準とし、408.1のAI変更とは疎合成する。Main/Git/Cargo/Beadsの変更、テスト、モデル読取、Search、対局、bootstrapの実行は0。

`engine.lmr_method` は省略時fixed_one、指定時はOFFでもAI `LmrMethod::from_name` で検査する。factoryはLMR falseで作り、typed method選択、既存enable setterの順に設定する。期待namespaceも同じAI `OrderingProfile::namespace` に渡し、namespaceから設定を復元しない。runtimeは要求名と、実session getter由来のeffective ID/null・reduction rule/nullを保存する。native保存検査もAIのID/ruleを直接照合する。Pythonは要求名・ON/OFF・null/型を確認し、AIのmethod suffixを再実装しない。時計、receipt、drain、fallback、取消、合法性、未完了拒否の経路は保持する。

唯一の追加config入口は、Rootが合成する `config.rs::Engine` のoptional String一項目。`config-field-needed.txt` に最小指定を保存した。本人はこの非担当ファイルを書かない。Rootから合成予定の通知を受領済みであり、返信を工程条件にしていない。406/407の近似設定やAI数学は担当外で、408 draftは近似OFFを明示する。

既存355の未封印book（a6abde1f…/85083B）からseed40820261015で、4/8/12/16手の各32 familyをSHA256で固定選択した。各層4件、計16件は **14,16,23,27 / 37,38,39,44 / 64,74,82,86 / 103,109,118,124**。prefix・元seed・root key・全history countsは保存bookの値をそのまま参照する。新しいgeometry replayやbook資格は与えていない。従来の未封印355由来という限界を維持し、sealed/holdoutやmixed評価bookは読まない。

NNUE/D × Control/Cheap の4対照それぞれで、同16 familyの2色32局を一operationにする。arenaの現行games/openings対応とnative family集計は件数に依存し、8family固定ではない。合計128局/64色pair、familyは共用するため128独立標本ではない。A=fixed_one、B=depth_rank、双方LMR ON。100ms authority receipt、5ms reserve、depth64/node1M/200ply、TT1M、AI2/6・main4をdraftへ固定した。将来のphysical/quiet判定はRoot実entryで行う。

費用比較は既存pure helperをimmutable sourceから読み、各evaluator/profileにA-B-B-Aを適用した16条件。各6root/3session、計96calls/48sessions/288M cap。既存cold/warm入力選択とTT/PVS、diagnostics OFF、depth callback OFF、無時間制限を保持する。旧400/402の結果・RAWは読取/再集計していない。新image、Build、current caller/environment/support、実Experiment/runtimeは未生成なのでnull/not-ready。draftは投入不可であり、実発行は324が行う。

結果表はnative WDL/family score/保存CIとaccepted selected completed snapshotのn/中央値/小histogram/平均/workを別欄とする。LMRの深さは選択的nominalで全幅資格ではなく、軌跡・手数・終盤比率の違いが平均に混ざる。selected snapshotとterminal workはnestedで非加算、TT容量はgaugeとして分離する。未知RSS、独立した採点費、physical forward数はUNKNOWN。旧400/402との別時刻比から因果speedupを述べない。

新しいRust3定義とPython1定義を準備しただけで、UNBUILT/UNTYPED/UNRUN。Rootの必要softwareで型/API/config合成と新境界を検証する。既存成功suiteは再演していない。formatter、syntax/static patch検査はsource receiptsに分離する。

原エラーは保存した。detail-v1はPython stdinをchildへ渡せず空実行となり、検証成功として数えない。detail-v2はcapture sinkのtext/bytes不一致でcontroller失敗した。私有 `inspect.py` の名前がstdlibと衝突してmetadata helperを再読したため `inspect_subjects.py` へ改名した。compose-v1は既存Pythonの検査statementが想定した文字列と異なり拒否し、途中の私有Rust以外を出力しなかった。所有する既存statementを読んで最小修正し、これらの失敗・元disk receiptsを保持した。native/テスト/科学の再試行ではない。

sourceSTOP・前後hash/strict patch/protected outside・exact child/TMP cleanupと一回のOWN usageは最終bindingに記録する。元405その他の原物、mixed/learner全prep/pipeline、323 USERPAUSE、defaults/models/weights/sealsは不変。

後着のRoot通知でconfig fieldと非arena除外がGit72a6d42へ合成済みと確認した。これは本人patchの一部ではなく、Rootが所有する別scopeである。最終hunk検査の初回二件はdiffが既存serde属性/閉じbraceへ挿入を整列したため、検査側の行区間が狭過ぎて拒否した。元失敗を保存し、実diffを読んでその境界だけを訂正した。production sourceは変更せず、最終の担当外hunk不変検査は通過した。formatterの元returnは成功だがNode cacheがTMPに残ったためwrapperは非完了を返した。元formatter子のfresh identity不在を確認して当該私有cacheだけ除去し、再format成功へ置換していない。
