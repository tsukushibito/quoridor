import gzip
from pathlib import Path

own = Path(__file__).resolve().parent
s = gzip.decompress(
    (own / "subjects-v1/research-lifecycle.py.before.gz").read_bytes()
).decode()
for name in ["arena_plan_check", "arena_observation"]:
    start = s.index("def " + name + "(")
    end = s.index("\ndef ", start + 4)
    body = s[start:end]
    if name == "arena_observation":
        print(body)
    else:
        pos = body.index('engine.get("lmr"')
        print(body[pos - 900 : pos + 1000])
