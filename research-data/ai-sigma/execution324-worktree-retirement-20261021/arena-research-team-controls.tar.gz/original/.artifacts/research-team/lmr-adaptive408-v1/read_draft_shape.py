import json
from pathlib import Path

r = Path(".artifacts/research-team/integration324/shared-signed-ordering402-v1")
p = json.loads((r / "arena128-v1/plan.json").read_text())
print("schedule_ref", p["schedule"])
s = json.loads(Path(p["schedule"]["path"]).read_text())
print("schedule_type", type(s).__name__)
print(
    "schedule_sample",
    s[:2]
    if isinstance(s, list)
    else {k: v[:2] if isinstance(v, list) else v for k, v in s.items()},
)
print(
    "matchups",
    [
        (
            m["id"],
            m["engines"][0]["kind"],
            m["engines"][0]["ordering_profile"],
            m["evaluator_sha256"],
        )
        for m in p["matchups"]
    ],
)
cfg = json.loads(Path(p["batches"][4]["config"]["path"]).read_text())
print("D_engine", cfg["engines"][0])
print("D_hashes", cfg["arena"]["evaluator_sha256"])
