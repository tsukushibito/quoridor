import gzip
from pathlib import Path

own = Path(__file__).resolve().parent
out = own / "edited"
out.mkdir(exist_ok=False)


def replace(text, before, after):
    assert text.count(before) == 1, before[:100]
    return text.replace(before, after)


runtime = gzip.decompress(
    (own / "subjects-v1/runtime.rs.before.gz").read_bytes()
).decode()
runtime = replace(
    runtime,
    "    pub actual_lmr_enabled: Option<bool>,",
    """    pub actual_lmr_enabled: Option<bool>,
    #[serde(default)]
    pub actual_lmr_method_id: Option<String>,
    #[serde(default)]
    pub lmr_reduction_rule: Option<String>,""",
)
runtime = replace(
    runtime,
    "fn arena_alpha_namespace(",
    """pub(crate) fn arena_lmr_method(engine: &Engine) -> alphabeta::Result<alphabeta::LmrMethod> {
    alphabeta::LmrMethod::from_name(
        engine.lmr_method.as_deref().unwrap_or(alphabeta::LmrMethod::FixedOne.name()),
    )
}
fn arena_alpha_namespace(""",
)
runtime = replace(
    runtime,
    """    match engine.ordering_profile.as_deref() {
        Some(name) => Ok(alphabeta::OrderingProfile::from_name(name)?.namespace(base, engine.lmr)),""",
    """    let method = arena_lmr_method(engine)?;
    match engine.ordering_profile.as_deref() {
        Some(name) => Ok(alphabeta::OrderingProfile::from_name(name)?.namespace(base, engine.lmr.then_some(method))),""",
)
runtime = replace(
    runtime,
    "    let session = if let Some(profile) = engine.ordering_profile.as_deref() {",
    "    let method = arena_lmr_method(engine)?;\n    let mut session = if let Some(profile) = engine.ordering_profile.as_deref() {",
)
runtime = replace(
    runtime,
    """            false,
            engine.lmr,
        )?""",
    """            false,
            false,
        )?""",
)
runtime = replace(
    runtime,
    """    // The setter acts on configuration, not the namespace string; log the getter.
    if session.lmr_enabled() != engine.lmr {""",
    """    // Configuration selects the typed method; the namespace never enables LMR.
    session.set_lmr_method(method);
    session.set_lmr(engine.lmr)?;
    if session.lmr_enabled() != engine.lmr
        || session.lmr_method() != engine.lmr.then_some(method)
    {""",
)
runtime = replace(
    runtime,
    "        profile.actual_lmr_enabled = Some(session.lmr_enabled());",
    """        profile.actual_lmr_enabled = Some(session.lmr_enabled());
        profile.actual_lmr_method_id = session.lmr_method().map(|m| m.id().to_owned());
        profile.lmr_reduction_rule = session.lmr_method().map(|m| m.reduction_rule().to_owned());""",
)
runtime = replace(
    runtime,
    '        "actual_lmr_enabled":game.tt_profiles[engine].actual_lmr_enabled,',
    """        "actual_lmr_enabled":game.tt_profiles[engine].actual_lmr_enabled,
        "requested_lmr_method":config.engines[engine].lmr_method.as_deref().unwrap_or(alphabeta::LmrMethod::FixedOne.name()),
        "actual_lmr_method_id":game.tt_profiles[engine].actual_lmr_method_id,
        "lmr_reduction_rule":game.tt_profiles[engine].lmr_reduction_rule,""",
)
runtime += '\n#[cfg(test)]\n#[path = "runtime_lmr_method_tests.rs"]\nmod runtime_lmr_method_tests;\n'
(out / "runtime.rs").write_text(runtime)

arena = gzip.decompress((own / "subjects-v1/arena.rs.before.gz").read_bytes()).decode()
arena = replace(
    arena,
    "        for engine in &c.engines {\n            if let Some(profile)",
    """        for engine in &c.engines {
            crate::runtime::arena_lmr_method(engine).map_err(|e| e.to_string())?;
            if let Some(profile)""",
)
arena = arena.replace(
    "                    || a.lmr != b.lmr\n",
    """                    || a.lmr != b.lmr
                    || (a.lmr && crate::runtime::arena_lmr_method(a).ok() != crate::runtime::arena_lmr_method(b).ok())
""",
)
assert arena.count("a.lmr && crate::runtime::arena_lmr_method") == 2
arena = replace(
    arena,
    "            let fallback = a.comparison == Comparison::WholeWallTime",
    """            if engine.ordering_profile.is_some() {
                let method = crate::runtime::arena_lmr_method(engine)?;
                let effective = engine.lmr.then_some(method);
                if obs.counters["requested_lmr_method"] != method.name()
                    || obs.counters["actual_lmr_enabled"] != engine.lmr
                    || obs.counters["actual_lmr_method_id"] != serde_json::json!(effective.map(|m| m.id()))
                    || obs.counters["lmr_reduction_rule"] != serde_json::json!(effective.map(|m| m.reduction_rule()))
                {
                    return Err("arena requested/effective LMR method mismatch".into());
                }
            }
            let fallback = a.comparison == Comparison::WholeWallTime""",
)
arena += '\n#[cfg(test)]\n#[path = "arena_lmr_method_tests.rs"]\nmod arena_lmr_method_tests;\n'
(out / "arena.rs").write_text(arena)

lc = gzip.decompress(
    (own / "subjects-v1/research-lifecycle.py.before.gz").read_bytes()
).decode()
start = lc.index("def arena_plan_check(")
end = lc.index("\ndef ", start + 4)
body = lc[start:end]
needle = '        need(isinstance(engine.get("lmr", False), bool), "arena LMR mode")'
if needle not in body:
    # Keep the exact current function visible on a genuine intake mismatch.
    print(
        body[
            body.index('engine.get("lmr"') - 100 : body.index('engine.get("lmr"') + 300
        ]
    )
    raise ValueError("owning LMR validation statement differs")
body = replace(
    body,
    needle,
    needle
    + """
        need(engine.get("lmr_method") in (None, "fixed_one", "depth_rank"), "arena LMR method name")""",
)
lc = lc[:start] + body + lc[end:]
start = lc.index("def arena_observation(")
end = lc.index("\ndef ", start + 4)
body = lc[start:end]
(out / "observation-intake.txt").write_text(body)
(out / "research-lifecycle.py").write_text(lc)
