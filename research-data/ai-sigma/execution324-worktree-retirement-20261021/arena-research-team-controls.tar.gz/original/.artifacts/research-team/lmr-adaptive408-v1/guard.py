import json
import os
import sys
from pathlib import Path

from quoridor_training.cycle_process import CycleResources, execute

root = Path(__file__).resolve().parent
name = sys.argv[1]
out = root / name
out.mkdir(exist_ok=False)
tmp = out / "TMP"
tmp.mkdir()
env = dict(
    os.environ, TMPDIR=str(tmp), CUDA_VISIBLE_DEVICES="", PYTHONDONTWRITEBYTECODE="1"
)
resources = CycleResources(
    {
        "host_ram_reserve": 4 * 1024**3,
        "max_memory_bytes": 704 * 1024**2,
        "max_output_bytes": None,
    },
    out,
    None,
)
with (out / "full.log").open("xb") as sink:
    result = execute(
        sys.argv[2:],
        out / "command.log",
        None,
        cpu_core=8,
        resources=resources,
        cwd="/workspaces/quoridor",
        env=env,
        output_sink=sink.write,
    )
(out / "return.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
left = list(tmp.iterdir())
# Existing uv controller may leave only its own zero-byte lock after directwait.
for item in left:
    if item.is_file() and item.stat().st_size == 0 and "lock" in item.name:
        item.unlink()
left = list(tmp.iterdir())
if not left:
    tmp.rmdir()
print(
    json.dumps({"return": result, "TMP_remaining": [str(x) for x in left]}, default=str)
)
print((out / "full.log").read_text()[-22000:])
sys.exit(0 if result.get("exit_code") == 0 and not left else 1)
