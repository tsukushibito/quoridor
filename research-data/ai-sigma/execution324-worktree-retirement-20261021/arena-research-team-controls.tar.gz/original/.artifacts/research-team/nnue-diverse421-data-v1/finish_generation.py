import datetime
import hashlib
import json
from pathlib import Path
import stat

OWN = Path(__file__).resolve().parent
PACKET = OWN / "generation-source-v1"


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path.resolve()),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


def current(identity):
    try:
        raw = Path(f"/proc/{identity['pid']}/stat").read_text()
        return {
            "pid": identity["pid"],
            "start_ticks": raw.rsplit(")", 1)[1].split()[19],
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        }
    except FileNotFoundError:
        return None


receipts = []
for stage in sorted(OWN.iterdir()):
    if not stage.is_dir() or not (stage / "controller.json").exists():
        continue
    controller = json.loads((stage / "controller.json").read_text())
    original_controller = {
        key: controller[key] for key in ("pid", "start_ticks", "boot_id")
    }
    assert current(original_controller) != original_controller
    records = list(stage.glob("*.process.json"))
    children = []
    for records_path in records:
        record = json.loads(records_path.read_text())
        child = record.get("child")
        if child and child not in children:
            assert current(child) != child
            children.append(child)
        assert record["direct_child_reaped"] and record["handle_closes_complete"]
        assert record["cleanup_complete"] and record["remaining"] == []
    # CycleResources records the original child and final direct-reap/handles
    # facts even when the execute return value was NULL after a failure.
    returned_path = stage / "return.json"
    returned = json.loads(returned_path.read_text()) if returned_path.exists() else None
    if returned:
        assert current(returned["child"]) != returned["child"]
        assert returned["direct_child_reaped"] and returned["handle_closes_complete"]
        assert returned["cleanup_complete"] and returned["remaining"] == []
        if returned["child"] not in children:
            children.append(returned["child"])
    assert not (stage / "TMP").exists()
    receipts.append(
        {
            "stage": stage.name,
            "controller": original_controller,
            "controller_current": current(original_controller),
            "children": children,
            "returned": ref(returned_path) if returned_path.exists() else None,
            "returned_null": returned is None,
            "persisted_process_refs": [ref(p) for p in records],
            "controller_error": ref(stage / "controller-error.json")
            if (stage / "controller-error.json").exists()
            else None,
            "TMP_absent": True,
        }
    )

for subject in json.loads((PACKET / "source-binding.json").read_text())["subjects"]:
    assert ref(Path(subject["post"]["path"])) == subject["post"]
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
stop = {
    "issue": "quoridor-4lc.421.3",
    "scope": "EARLY_GENERATION_AND_INPUT_SOURCE_ONLY",
    "fresh_observation_utc": now,
    "source_readers_writers_children_jobs_TMP_leases_waits_remaining": [],
    "current_next_reservation": "NONE",
    "receipts": receipts,
    "source": ref(PACKET / "source-binding.json"),
    "known_errors_retained": "Original locator failure, stdout-owner wrong type locator, and excluded-book openings KeyError; returned NULL differs from persisted failure. No native/science ran.",
    "metadata_writer": "This finite administrative writer returns through tools exec; its final exit receipt is separate from the completed source children. No idle hardware/canonical lease.",
    "native_compile_tests": "UNBUILT/UNTYPED/UNRUN",
    "later_scope": "arena aggregate-node inlet remains open; this frozen packet is immutable",
    "affected_usage": "one end-of-leaf directed check pending; no repeated whole-target charge",
}
(PACKET / "source-STOP.json").write_text(json.dumps(stop, indent=2) + "\n")
completion = {
    "issue": "quoridor-4lc.421.3",
    "source_binding": ref(PACKET / "source-binding.json"),
    "STOP": ref(PACKET / "source-STOP.json"),
    "report": ref(PACKET / "report-ja.md"),
    "forward": ref(PACKET / "forward.patch"),
    "inverse": ref(PACKET / "inverse.patch"),
    "static_proof": ref(PACKET / "static-proof.json"),
    "verification": ref(PACKET / "verification-plan.json"),
    "selected_inputs": ref(PACKET / "selected-input-refs.json"),
    "drafts": [ref(p) for p in sorted(PACKET.glob("*.draft.json"))],
    "source_ready_not_software_or_scientific_success": True,
}
(PACKET / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
body = f"""421.3 early generation/input source slice frozen; no native/science/tests by author.
completion={json.dumps(ref(PACKET / "completion.json"))}
Six thin existing subjects over8be646be, forward e95be544/34085; exact before/post, strict forward/inverse and scoped Rustfmt/Ruff PASS. New6 definitions UNBUILT/UNTYPED/UNRUN. Existing fullhistory/outcome/raw±2/NodeBudget/dynamicqueue retained.
Actual typed Control/LMR-depth_rank/TT1M setters+getter namespace/capacity check; pure Table-derived byte bound, no extra allocation. 4M/move/global1G, unchanged defaultOFF. run_bound returns small saved-summary+refs rather than whole report stdout.
Input CLI unchanged: teacher-pilot --prepare-inputs CONFIG --input-sha256 SHA. Native canonical filter preserves original colliding slots/attempts as missing, no retry/refill; unique_families=true keeps first eval family. Same partition_families owner before/at admission. Split42120261023/addendum bound.
Actual old unsealed128family book a6abde1f/85083 has families, not openings. A single data common_corpus prefix reader now serves preparation+admission, narrow extra private path recorded; no compact schema change. Exact book locator/refs in selected-input-refs. Only this existing book independently established; append any other separately named actual existing evalbook refs BEFORE inputs. No sealed read.
Generation draft64 ready for genuine software/Rootbinding, eval16 remains null until actual generation prefix_book is returned and appended to excluded_books. No dummy refs/no prefix recreation. Freeze actual64+16 schedule/partition/eval before outcomes. Use ONE1G-budget generation config, not perbatch1G resets. Actualworker/resource resolution stays Rootentry.
All original errors/NULL-vs-disk kept. Fresh source identities absent/different, original returned directreap/handles/TMPnone; owned source/reader/child/jobs/leases=[] at {now}. Administrative metadata writer exit is tools receipt, not fabricated old child UTC. No ACK gate. Continuing only separate later arena aggregate1G inlet; old paused scopes/defaults/seals unchanged.
"""
(OWN / "generation-source-delivery.txt").write_text(body)
print(json.dumps(ref(PACKET / "completion.json")))
