import json
import os
import sys
from pathlib import Path

from quoridor_training.cycle_process import CycleResources, execute

own = Path(__file__).resolve().parent
out = own / sys.argv[1]
out.mkdir(exist_ok=False)
tmp = out / "TMP"
tmp.mkdir()
cpu = {
    str(i): {
        k: Path(f"/sys/devices/system/cpu/cpu{i}/topology/{k}").read_text().strip()
        for k in ["physical_package_id", "core_id"]
    }
    for i in [16, 18]
}
assert cpu["16"] != cpu["18"]
controller = dict(
    pid=os.getpid(),
    start_ticks=Path("/proc/self/stat").read_text().rsplit(")", 1)[1].split()[19],
    boot_id=Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    affinity=sorted(os.sched_getaffinity(0)),
    topology=cpu,
    cpuset=Path("/sys/fs/cgroup/cpuset.cpus.effective").read_text().strip(),
    quota=Path("/sys/fs/cgroup/cpu.max").read_text().strip(),
)
assert controller["affinity"] == [18]
(out / "controller.json").write_text(json.dumps(controller, indent=2) + "\n")
env = dict(
    os.environ,
    PYTHONDONTWRITEBYTECODE="1",
    CUDA_VISIBLE_DEVICES="",
    TMPDIR=str(tmp),
    OMP_NUM_THREADS="1",
    OPENBLAS_NUM_THREADS="1",
    MKL_NUM_THREADS="1",
    NODE_DISABLE_COMPILE_CACHE="1",
    RUFF_CACHE_DIR=str(own / "ruff-cache"),
)
resources = CycleResources(
    {
        "host_ram_reserve": 4 * 1024**3,
        "max_memory_bytes": 960 * 1024**2,
        "max_output_bytes": None,
    },
    out,
    None,
)
returned = None
failure = None
try:
    with (out / "full.log").open("xb") as capture:
        returned = execute(
            sys.argv[2:],
            out / "command.log",
            None,
            cpu_core=16,
            resources=resources,
            cwd="/workspaces/quoridor",
            env=env,
            output_sink=capture.write,
            no_new_privs=True,
        )
except Exception as error:
    failure = {"type": type(error).__name__, "message": str(error)}
    (out / "controller-error.json").write_text(json.dumps(failure, indent=2) + "\n")
(out / "return.json").write_text(json.dumps(returned, indent=2) + "\n")
for path in tmp.iterdir():
    if path.is_file() and path.stat().st_size == 0 and "lock" in path.name:
        path.unlink()
remaining = list(tmp.iterdir())
if not remaining:
    tmp.rmdir()
print(
    json.dumps(
        dict(
            returned=returned, error=failure, TMP_remaining=[str(p) for p in remaining]
        )
    )
)
print((out / "full.log").read_text()[-28000:])
raise SystemExit(0 if returned and returned["exit_code"] == 0 and not remaining else 1)
