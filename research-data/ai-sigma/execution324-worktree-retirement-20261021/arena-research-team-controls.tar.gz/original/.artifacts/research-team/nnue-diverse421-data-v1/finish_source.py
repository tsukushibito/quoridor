import datetime
import json
import os
from pathlib import Path

from freeze_generation import ref

OWN = Path(__file__).resolve().parent
PACKET = OWN / "arena-source-v1"
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def fresh(identity):
    try:
        raw = Path(f"/proc/{identity['pid']}/stat").read_text()
        actual = {
            "pid": identity["pid"],
            "start_ticks": raw.rsplit(")", 1)[1].split()[19],
            "boot_id": BOOT,
        }
    except FileNotFoundError:
        actual = None
    assert actual != identity, identity
    return actual


records = []
for stage in sorted(OWN.iterdir()):
    if not stage.is_dir() or not (stage / "controller.json").exists():
        continue
    controller = json.loads((stage / "controller.json").read_text())
    original = {key: controller[key] for key in ("pid", "start_ticks", "boot_id")}
    record = {
        "stage": stage.name,
        "controller": original,
        "controller_current": fresh(original),
        "processes": [],
    }
    for path in stage.glob("*.process.json"):
        process = json.loads(path.read_text())
        assert process["direct_child_reaped"] and process["handle_closes_complete"]
        assert process["cleanup_complete"] and process["remaining"] == []
        record["processes"].append(
            {
                "ref": ref(path),
                "original": process["child"],
                "current": fresh(process["child"]),
                "disk_exit": process.get("exit_code"),
                "disk_primary_error": process.get("primary_error"),
                "disk_status": process["status"],
            }
        )
    assert not (stage / "TMP").exists()
    record["TMP_absent"] = True
    returned = stage / "return.json"
    record["returned_ref"] = ref(returned) if returned.exists() else None
    record["returned_null_or_absent"] = (
        not returned.exists() or json.loads(returned.read_text()) is None
    )
    records.append(record)

for packet in (OWN / "generation-source-v1", PACKET):
    binding = json.loads((packet / "source-binding.json").read_text())
    for subject in binding["subjects"]:
        assert ref(Path(subject["post"]["path"])) == subject["post"]
        assert ref(Path(subject["recovery"]["path"])) == subject["recovery"]
    assert ref(Path(binding["forward"]["path"])) == binding["forward"]
    assert ref(Path(binding["inverse"]["path"])) == binding["inverse"]
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
stop = {
    "issue": "quoridor-4lc.421.3",
    "fresh_original_identity_observation_utc": now,
    "source_readers_writers_children_jobs_TMP_leases_waits_remaining": [],
    "current_next_reservation": "NONE",
    "receipts": records,
    "source": ref(PACKET / "source-binding.json"),
    "early_source_original_STOP": ref(OWN / "generation-source-v1/source-STOP.json"),
    "unrecorded_controller_peak_CPU_cost": "UNKNOWN; source process receipts are not all-work accounting",
    "metadata_writer": "This finite metadata controller returns via tools exec, separate from already-stopped guarded source processes. Its exact UTC exit is not invented.",
    "metadata_writer_identity": {
        "pid": os.getpid(),
        "start_ticks": Path("/proc/self/stat")
        .read_text()
        .rsplit(")", 1)[1]
        .split()[19],
        "boot_id": BOOT,
        "affinity": sorted(os.sched_getaffinity(0)),
        "role": "ordinary final metadata controller; live at this write, tool directwait exit follows",
    },
    "software_new_science": "UNBUILT/UNTYPED/UNRUN; author native/Search/game/model/forward=0",
    "errors": "Original failed helper receipts, NULL returns and disk masks preserved; no successful software or scientific replay.",
}
(PACKET / "source-STOP.json").write_text(json.dumps(stop, indent=2) + "\n")
completion = {
    "issue": "quoridor-4lc.421.3",
    "status": "SOURCE_AND_DRAFTS_FROZEN_SOFTWARE_PENDING",
    "generation_completion": ref(OWN / "generation-source-v1/completion.json"),
    "arena_source_binding": ref(PACKET / "source-binding.json"),
    "arena_report": ref(PACKET / "report-ja.md"),
    "arena_forward": ref(PACKET / "forward.patch"),
    "arena_inverse": ref(PACKET / "inverse.patch"),
    "arena_static_proof": ref(PACKET / "static-proof.json"),
    "arena_verification": ref(PACKET / "verification-plan.json"),
    "arena_draft": ref(PACKET / "arena-settings.draft.json"),
    "source_STOP": ref(PACKET / "source-STOP.json"),
    "usage": None,
    "default_pause_models_seals_old_failed": "UNCHANGED",
    "Root_integration_and_native": "324 sole writer; no ACK/parent-close gate; source_ready is not adoption/software/numeric success",
}
(OWN / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
usage_path = OWN / "usage.json"
assert not usage_path.exists()
usage_path.write_text("{}\n")
# One directed ordinary affected-namespace sample, never assets/target/global.
paths = [OWN, *OWN.rglob("*")]
file_count = 0
logical = 0
allocated = 0
for path in paths:
    info = path.lstat()
    allocated += info.st_blocks * 512
    if path.is_file() and not path.is_symlink():
        file_count += 1
        logical += info.st_size
usage = {
    "scope": str(OWN),
    "as_of_utc": now,
    "regular_files": file_count,
    "logical_B_as_of_scan": logical,
    "allocated_B_as_of_scan_including_directories": allocated,
    "scan_count": 1,
    "global_actual": "UNKNOWN",
    "total_controller_or_scientific_peak": "UNKNOWN",
    "cap_decimal_B": 50000000000,
    "already_retained_target_charge": 0,
    "subsequent_small_admin_delivery_and_backup_bytes": "not yet included; no scientific data or shared target charged here",
}
usage_path.write_text(json.dumps(usage, indent=2) + "\n")
completion["usage"] = ref(usage_path)
(OWN / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
message = f"""421.3 final private source/draft handoff, source STOP {now}, all known original source children/controllers freshabsent/different/directreap/handles/TMPgone/owned[].
completion={json.dumps(ref(OWN / "completion.json"))}
Early generation/input packet7ad25c6e/3371 unchanged and already accepted delivery01a141f2-77b0. Later arena patch d0175657/14347 applies AFTER generation: arena/runtime/resources from8be646be, teacher execution from frozen generation post. Exact preimages/recovery/forward-inverse/protected factory/clock/commit/search bodies bound. Newarena1 UNBUILT/UNTYPED/UNRUN + original NodeBudget fixture relocated exact, not duplicate new PASS. Generation6 remain UNRUN here.
Only native optional arena.max_total_nodes and original shared NodeBudget move: main reservation BEFORE clock/dispatch, worker actualmaxnodes clamp, actualmatching terminal-only settlement afterdrain, opaque reservations retained, cap raises existing UNKNOWN + unentered preservation, no fallback-forfeit/goal changes. OFF skips budget allocation/extra observation keys; physical layout/cost UNKNOWN. Pump records cap/remaining/charged includingopaque, nested not added toterminalnodes.
Draft resolves conservative4x250M preallocated contrast quotas<=whole1G, no transfer/refill, may yieldUNKNOWN before128. Root may fix a different disjoint allocation BEFORE any outcomes within1G, not give1Gpercontrast. This avoids a new crossprocess scheduler/budget registry. Frozen firstspec/science limits/model/default unchanged; future C/M/book/image/Build/Experiment/actualresources staynull.
One affected OWN usage={json.dumps(usage)}
Original source errors/NULL-vs-disk preserved; metadata writer exits via direct toolsreceipt, original sourceSTOPs not relabeled. No Main/Git/Cargo/native/tests/Search/game/model/forward by author; leaf remainsin_progress for genuine Rootacceptance. Pauses342.17/323, oldweights/defaults/seals/oldRAW/feesUNKNOWN unchanged. Root source/software/generation can continue without reply/whole-arena/parentACK gate.
"""
(OWN / "final-source-delivery.txt").write_text(message)
print(
    json.dumps(
        {
            "completion": ref(OWN / "completion.json"),
            "STOP": completion["source_STOP"],
            "usage": usage,
        }
    )
)
