"""Prepare one private421 arena input projection and metadata derivative."""

import copy
import difflib
import gzip
import hashlib
import json
import os
import stat
import subprocess
from pathlib import Path

OWN = Path(__file__).resolve().parent
OLD = OWN.parent / "arena-settings-v2"
SRC = OWN / "source-v1"
META = OWN / "metadata-v1"
ROOT = Path("/workspaces/quoridor")
SELECTED = {}


def ref(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(raw).hexdigest(),
        bytes=len(raw),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def read(path):
    path = Path(path).resolve()
    before = ref(path)
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == before["sha256"]
    obj = json.loads(raw)
    assert ref(path) == before
    SELECTED[str(path)] = before
    return obj, before


def put(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


def main():
    note = "421.3 actual424STOP release: source private arena.rs projection complete/rules/families + one NN0 receiver fixture, source-v1/post/crates/quoridor-runner/src/arena.rs only; metadata-v1 same16 carrier/config/plan. Root sole Main/Git/Cargo/native/tests. CPU8/guardian12/family1GiB/G0/reserve4G, existing guard. Preserve355 validator, runtime/math/TT/history/clock/model/caps and old frozen packets/FAILED. Same claimant/in_progress."
    result = subprocess.run(
        [
            "bash",
            "scripts/dev/beads.sh",
            "update",
            "quoridor-4lc.421.3",
            "--append-notes",
            note,
        ],
        capture_output=True,
        text=True,
        env=dict(os.environ, BEADS_ACTOR="codex:01a11062-b120-73a1-8aa3-fe2cb922c7c0"),
        check=False,
    )
    (OWN / "source-path-note.stdout").write_text(result.stdout)
    (OWN / "source-path-note.stderr").write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    original = gzip.decompress((SRC / "arena.rs.before.gz").read_bytes()).decode()
    assert (
        hashlib.sha256(original.encode()).hexdigest()
        == "53491f34996647904d2c7d71fc6b1b46607ba0c9847aa91a383052302e90b61d"
    )
    anchor = "/// Scientific declarations are approved JSON, not experiment/count-specific Rust branches.\n"
    assert original.count(anchor) == 1
    projection = """/// Arena admission consumes this common immutable book view, not a producer's RNG recipe.
/// Extra producer provenance remains bound by the input FileRef. Each Family
/// retains its strict field types and full-prefix/history correspondence.
#[derive(Debug, Deserialize)]
pub struct ArenaInputBook {
    pub complete: bool,
    pub rules: String,
    pub families: Vec<crate::value_search_strength::Family>,
}

"""
    updated = original.replace(anchor, projection + anchor)
    assert updated.count("crate::value_search_strength::GeneratedBook") == 3
    updated = updated.replace(
        "crate::value_search_strength::GeneratedBook", "ArenaInputBook"
    )
    test = """    #[test]
    fn arena421_input_book_projection_batch_seed_and_strict_history() {
        // Admission metadata only: no model, geometry, RNG regeneration or Search.
        let (plan, experiment, mut config, slots, _) = fixture(1, 4);
        let batch_seed = 42120261016_u64;
        let family = json!({
            "family_id":100, "id":"fake-0", "attempt_id":0, "seed":batch_seed,
            "prefix":[13], "root_key":"FAKE_HISTORY",
            "history_counts":[["FAKE_HISTORY",1]]
        });
        let minimal = json!({
            "complete":true, "rules":plan.rules, "families":[family]
        });
        let book: ArenaInputBook = serde_json::from_value(minimal.clone()).unwrap();
        assert_eq!(book.families[0].seed, batch_seed);
        assert_eq!(book.families[0].attempt_id, 0);
        assert_eq!(book.families[0].prefix, vec![13]);
        assert_eq!(book.families[0].history_counts, vec![("FAKE_HISTORY".into(), 1)]);
        config.arena.as_mut().unwrap().book.openings[0].original_seed = Some(batch_seed);
        plan.validate_config(&experiment, &config, &slots, &book).unwrap();

        // Historical producer-specific envelope fields are not355 qualifications.
        let mut producer = minimal.clone();
        producer["source_native_schedule"] = json!({"seed_scope":"shared_batch"});
        let projected: ArenaInputBook = serde_json::from_value(producer).unwrap();
        assert_eq!(projected.families[0].history_counts, book.families[0].history_counts);

        let mut null_seed = minimal.clone();
        null_seed["families"][0]["seed"] = serde_json::Value::Null;
        assert!(serde_json::from_value::<ArenaInputBook>(null_seed).is_err());
        let mut missing_attempt = minimal.clone();
        missing_attempt["families"][0].as_object_mut().unwrap().remove("attempt_id");
        assert!(serde_json::from_value::<ArenaInputBook>(missing_attempt).is_err());
        let mut extra_family_field = minimal;
        extra_family_field["families"][0]["invented_rng_state"] = json!(0);
        assert!(serde_json::from_value::<ArenaInputBook>(extra_family_field).is_err());

        let mut wrong_seed = config.clone();
        wrong_seed.arena.as_mut().unwrap().book.openings[0].original_seed = Some(batch_seed + 1);
        assert!(plan.validate_config(&experiment, &wrong_seed, &slots, &book).is_err());
        config.arena.as_mut().unwrap().book.openings[0].reference.as_mut().unwrap()
            .settings["history_counts"] = json!([["FAKE_HISTORY",2]]);
        assert!(plan.validate_config(&experiment, &config, &slots, &book).is_err());
    }

"""
    test_anchor = "    #[test]\n    fn generic_arena377_decision_modes_counts_ordering_and_unsupported_sigma()"
    assert updated.count(test_anchor) == 1
    updated = updated.replace(test_anchor, test + test_anchor)
    post = SRC / "post/crates/quoridor-runner/src/arena.rs"
    post.parent.mkdir(parents=True, exist_ok=False)
    post.write_text(updated)

    completion, completion_ref = read(OLD / "completion.json")
    assert (
        completion_ref["sha256"]
        == "438ed3f67469083d9ba72a011b7c0725bcca537d0a352c51f6affc824648b6dc"
    )
    for original_ref in completion["outputs"]:
        assert ref(original_ref["path"]) == original_ref, original_ref["path"]
    book, old_book_ref = read(OLD / "arena-book.json")
    schedule, native_schedule_ref = read(book["source_native_schedule"]["path"])
    assert native_schedule_ref == book["source_native_schedule"]
    evaluation, evaluation_ref = read(book["source_preparation"]["path"])
    config, config_ref = read(evaluation["config"]["path"])
    batch_seed = config["prefix_seed"]
    assert batch_seed == book["prefix_batch_seed"] == 42120261016
    families = copy.deepcopy(book["families"])
    attempt_records = []
    for i, (family, row) in enumerate(
        zip(families, schedule["scheduled"], strict=True)
    ):
        assert row["game"] == family["family_id"] == i
        assert row["request_id"] == family["id"] and row["prefix"] == family["prefix"]
        assert row["root"]["state_key"] == family["root_key"]
        assert row["root"]["history"] == family["history_counts"]
        accepted = [a for a in row["attempts"] if a["rejection"] is None]
        assert len(accepted) == 1 and accepted[0]["prefix"] == family["prefix"]
        assert accepted[0]["attempt"] == 0
        family.update(seed=batch_seed, attempt_id=accepted[0]["attempt"])
        attempt_records.append(
            dict(
                family_id=i,
                attempt_id=accepted[0]["attempt"],
                request_id=row["request_id"],
            )
        )
    META.mkdir(exist_ok=False)
    provenance_ref = put(
        META / "provenance.json",
        dict(
            scope="Same16 original421 evaluation inputs; no new generation or classification",
            seed=batch_seed,
            seed_scope="shared native generator batch prefix_seed",
            per_family_rng_state="UNKNOWN",
            per_family_independent_seed=False,
            seed_regeneration_claim=False,
            source_prefix_book=book["source_prefix_book"],
            source_native_schedule=native_schedule_ref,
            source_native_input_preparation=evaluation_ref,
            source_generator_config=config_ref,
            actual_attempts=attempt_records,
            original_carrier=old_book_ref,
            unchanged="fullprefix/root/history/family order and IDs; source-native replay still required",
            producer355_identity_claim=False,
        ),
    )
    # The existing Family's exact strict keys, plus the consumer's three required fields.
    carrier_ref = put(
        META / "arena-book.json",
        dict(complete=book["complete"], rules=book["rules"], families=families),
    )
    configs = []
    before_after = [(OLD / "arena-book.json", META / "arena-book.json")]
    for i in range(4):
        c, before_ref = read(OLD / f"config-{i:03d}.json")
        a = c["arena"]
        assert a["max_total_nodes"] == 250000000
        for opening, family in zip(a["book"]["openings"], families, strict=True):
            assert (
                opening["id"] == family["id"] and opening["prefix"] == family["prefix"]
            )
            opening["original_seed"] = batch_seed
            reference = opening["reference"]
            assert reference["source_sha256"] == old_book_ref["sha256"]
            reference["source_sha256"] = carrier_ref["sha256"]
            reference["settings"] = dict(
                family,
                seed_scope="shared_generator_batch_prefix_seed",
                per_family_rng_state=None,
            )
        after_ref = put(META / f"config-{i:03d}.json", c)
        configs.append(dict(before=before_ref, after=after_ref))
        before_after.append(
            (OLD / f"config-{i:03d}.json", META / f"config-{i:03d}.json")
        )
    plan, old_plan_ref = read(OLD / "plan.json")
    assert plan["book"] == old_book_ref
    plan["book"] = carrier_ref
    plan["inputs"] = [
        carrier_ref if r == old_book_ref else r for r in plan["inputs"]
    ] + [provenance_ref]
    for i, batch in enumerate(plan["batches"]):
        assert batch["config"] == configs[i]["before"]
        batch["config"] = configs[i]["after"]
    plan_ref = put(META / "plan.json", plan)
    before_after.append((OLD / "plan.json", META / "plan.json"))
    forward, inverse = "", ""
    for before, after in before_after:
        old_text, new_text = before.read_text(), after.read_text()
        forward += "".join(
            difflib.unified_diff(
                old_text.splitlines(True),
                new_text.splitlines(True),
                fromfile="a/" + before.name,
                tofile="b/" + after.name,
            )
        )
        inverse += "".join(
            difflib.unified_diff(
                new_text.splitlines(True),
                old_text.splitlines(True),
                fromfile="a/" + after.name,
                tofile="b/" + before.name,
            )
        )
    (META / "forward.patch").write_text(forward)
    (META / "inverse.patch").write_text(inverse)
    put(
        META / "binding.json",
        dict(
            original_completion=completion_ref,
            carrier=carrier_ref,
            provenance=provenance_ref,
            plan=plan_ref,
            configs=configs,
            unchanged_schedule=plan["schedule"],
            future_native_image=None,
            future_Build=None,
            launch_ready=False,
            root_rebind="New native receiver image/Build, four search_artifact_sha256 fields, current caller/numerical/Experiment/range/output paths. Existing image fields are historical genuine424 image, not the new parser.",
            actual_original_games=0,
            new_Search_games=0,
            caps=[250000000] * 4,
        ),
    )
    for path, original_ref in SELECTED.items():
        assert ref(path) == original_ref, path
    put(
        OWN / "selectedrefs-fixed.json",
        dict(
            before_parse=list(SELECTED.values()),
            after=list(SELECTED.values()),
            exact=True,
        ),
    )
    print(
        json.dumps(
            dict(
                source_post=str(post),
                carrier=carrier_ref,
                plan=plan_ref,
                configs=4,
                families=16,
                new_receiver_fixture=1,
                author_test_execution=False,
            )
        )
    )


if __name__ == "__main__":
    main()
