import datetime
import json
import os
from pathlib import Path

from freeze import ref

OWN = Path(__file__).resolve().parent
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def absent_or_different(identity):
    try:
        raw = Path(f"/proc/{identity['pid']}/stat").read_text()
        actual = {
            "pid": identity["pid"],
            "start_ticks": raw.rsplit(")", 1)[1].split()[19],
            "boot_id": BOOT,
        }
    except FileNotFoundError:
        actual = None
    assert actual != identity, identity
    return actual


receipts = []
for stage in sorted(OWN.iterdir()):
    if not stage.is_dir() or not (stage / "controller.json").exists():
        continue
    controller = json.loads((stage / "controller.json").read_text())
    identity = {key: controller[key] for key in ("pid", "start_ticks", "boot_id")}
    item = {
        "stage": stage.name,
        "controller": identity,
        "controller_current": absent_or_different(identity),
        "resource_readback": controller,
        "processes": [],
    }
    for path in stage.glob("*.process.json"):
        record = json.loads(path.read_text())
        assert record["direct_child_reaped"] and record["handle_closes_complete"]
        assert record["cleanup_complete"] and record["remaining"] == []
        item["processes"].append(
            {
                "ref": ref(path),
                "original": record["child"],
                "current": absent_or_different(record["child"]),
                "disk_status": record["status"],
                "disk_exit": record.get("exit_code"),
            }
        )
    returned = stage / "return.json"
    item["returned"] = ref(returned) if returned.exists() else None
    item["returned_null_or_absent"] = (
        not returned.exists() or json.loads(returned.read_text()) is None
    )
    assert not (stage / "TMP").exists()
    item["TMP_absent"] = True
    receipts.append(item)
binding = json.loads((OWN / "source-binding.json").read_text())
for subject in binding["subjects"]:
    assert ref(Path(subject["post"]["path"])) == subject["post"]
    assert ref(Path(subject["before_recovery"]["path"])) == subject["before_recovery"]
for key in ("forward", "inverse", "selected_original_view"):
    assert ref(Path(binding[key]["path"])) == binding[key]
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
stop = {
    "issue": "quoridor-4lc.421.3",
    "scope": "CURRENT_RECEIVER_REPAIR_SOURCE_ONLY",
    "fresh_source_observation_utc": now,
    "readers_writers_children_jobs_TMP_leases_waits_remaining": [],
    "current_next_reservation": "NONE",
    "receipts": receipts,
    "source_binding": ref(OWN / "source-binding.json"),
    "current_metadata_writer": {
        "pid": os.getpid(),
        "start_ticks": Path("/proc/self/stat")
        .read_text()
        .rsplit(")", 1)[1]
        .split()[19],
        "boot_id": BOOT,
        "affinity": sorted(os.sched_getaffinity(0)),
        "scope": "finite ordinary metadata write; live at this write, tools directwait follows; not an original source child",
    },
    "controller_peak_or_total_fee": "UNKNOWN; source receipts are not all-work accounting",
    "errors": [
        "tool JS syntax error before execution",
        "taskset python absent127 before source",
        "bounded RAW helper assumed first record header; original KeyError preserved, repaired only bounded first3 record view",
        "static factory proof initially counted rustfmt optional trailing comma as a change; source unchanged, whitespace/trailing-comma-only normalization proved",
    ],
    "author_native_Cargo_tests_model_Search_geometry_science": 0,
    "original_generation_conversion_partial_RAW_fees": "UNCHANGED; no replay or partial-cache repair",
    "new_fixtures": "3 UNBUILT/UNTYPED/UNRUN",
    "status": "same claimant in_progress pending Root acceptance",
}
(OWN / "source-STOP.json").write_text(json.dumps(stop, indent=2) + "\n")
completion = {
    "issue": "quoridor-4lc.421.3",
    "base_git": binding["base_git"],
    "source_binding": ref(OWN / "source-binding.json"),
    "forward": ref(OWN / "forward.patch"),
    "inverse": ref(OWN / "inverse.patch"),
    "report": ref(OWN / "report-ja.md"),
    "static_proof": ref(OWN / "static-proof.json"),
    "verification": ref(OWN / "verification-plan.json"),
    "bounded_original_metadata": ref(OWN / "bounded-original-record-view.json"),
    "canonical_capacity_source_view": ref(OWN / "canonical-capacity-source-view.json"),
    "source_STOP": ref(OWN / "source-STOP.json"),
    "usage": None,
    "scope": "one fixed receiver repair; software and original unfinished conversion Root-owned; no author review dispatch",
}
(OWN / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
usage_path = OWN / "usage.json"
assert not usage_path.exists()
usage_path.write_text("{}\n")
files = 0
logical = 0
allocated = 0
for path in [OWN, *OWN.rglob("*")]:
    info = path.lstat()
    allocated += info.st_blocks * 512
    if path.is_file() and not path.is_symlink():
        files += 1
        logical += info.st_size
usage = {
    "scope": str(OWN),
    "as_of_utc": now,
    "regular_files": files,
    "logical_B_as_of_scan": logical,
    "allocated_B_as_of_scan_including_directories": allocated,
    "directed_scan_count": 1,
    "global_actual": "UNKNOWN",
    "global_decimal_cap_B": 50000000000,
    "retained_target_or_old_science_recharge": 0,
    "future_small_delivery_metadata": "not yet included; no bulk/science/model data written",
}
usage_path.write_text(json.dumps(usage, indent=2) + "\n")
completion["usage"] = ref(usage_path)
(OWN / "completion.json").write_text(json.dumps(completion, indent=2) + "\n")
message = f"""SAME421.3 receiver repair fixed source STOP {now}; current67668ddd thinbase, no Main/Cargo/native/test/Search/model/forward/science by author.
completion={json.dumps(ref(OWN / "completion.json"))}
forward={json.dumps(ref(OWN / "forward.patch"))}
Four exact subjects: terminal_stream.rs + common_corpus.rs pure shared metadata inlet + dataCargo.toml single existingAIresearch dependency + teacher_pilot_execution.rs mechanical route/removal of superseded local builders. Root normalCargo.lock adds existingquoridor-ai dependency to data; no download/newversion requested. AI/core/NNUE dependencies checked only necessary manifests, no newcycle identified.
Receiver now boundsTT1..1048576 fromactualconfig, derivesbyte-limit via existing SearchSession::requested_tt_byte_limit (noTTallocation/secondformula), and compares complete search.counters.session against canonical profile/namespace/LMR owner output, plus actualLMR/approxOFF/safeOFF counters andretained limit. Strict nominalD6/nodes/PVS/fullhistory/STM/outcome/split/census/raw±2 unchanged. No selfdeclared unlimitedcapacity/legacyshim/schema/newcolumn.
Producer observedformatter moved byteexact; namespace source parameter substitution only; typedfactory/setter token-equivalent apart from sharedhelperroute. Protected validate_game/census/targets/rawdecoder/play/finish bodies byteexact. New3 focused receiver definitions UNBUILT/UNTYPED/UNRUN; existing2 owningfixtures field-adapted assertions unchanged. No oldsuccessfulsuite replay. Rustfmt/scopedRuff/strictforward-inversePASS; TOMLmanualprojectstyle+tomllib because noformatter installed, limitation explicit.
OriginalRAW57dac034/2467174 +config440e7c96 checked via bounded requests/header/firstgame-firstrow counters only: actualTT1M/83886128/depth_rank alreadyrecorded. No fullstream/census/WDL/modelanalysis, originalfailedcompact/incomplete/partial untouched. Preserve originalconversion failures/NULL-vs-disk/fees; Root freshoutput after genuine currentsoftware and same421.4 changedreceiver question, no authorreviewdispatch.
source owned readers/writers/children/jobs/TMP/leases=[] atfreshobservation; exactoriginal identities absent/different/directreap/handlesclosed, original failures retained including boundedreaderKeyError and optionalcomma proof repair. Finalmetadatawriter directtools exit separate, no invented oldexitUTC. One scopedusage={json.dumps(usage)}
Sameleafin_progress; Rootacceptance/close, no ACK/parentgate. Whole256MiB/6Mforward and all old342/323 pauses/defaults/models/seals/RAWfeesUNKNOWN held.
"""
(OWN / "delivery.txt").write_text(message)
print(
    json.dumps(
        {
            "completion": ref(OWN / "completion.json"),
            "STOP": completion["source_STOP"],
            "usage": usage,
        }
    )
)
