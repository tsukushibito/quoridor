"""Prepare four 421 arena operations from existing fixed metadata only."""

import copy
import hashlib
import json
import stat
from pathlib import Path

OWN = Path(__file__).resolve().parent
ROOT = Path("/workspaces/quoridor")
BASE = ROOT / ".artifacts/research-team/integration324"
B421 = BASE / "nnue-diverse421-v1"
OLD = BASE / "lmr-adaptive408-v1/arena128-unentered-v1"
PERF = ROOT / ".worktree/assets/perf/nnue-diverse421-arena128-v1"
SELECTED = {}


def ref(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(
        path=str(path),
        sha256=hashlib.sha256(data).hexdigest(),
        bytes=len(data),
        mode=f"{stat.S_IMODE(path.stat().st_mode):04o}",
    )


def read(path, expected=None):
    path = Path(path).resolve()
    before = ref(path)
    if expected:
        for key, value in expected.items():
            assert before[key] == value, (path, key)
    data = path.read_bytes()
    assert hashlib.sha256(data).hexdigest() == before["sha256"]
    obj = json.loads(data)
    assert ref(path) == before
    SELECTED[str(path)] = before
    return obj, before


def put(name, obj):
    path = OWN / name
    assert not path.exists(), path
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n")
    return ref(path)


def main():
    book, book_ref = read(
        ROOT
        / ".worktree/assets/data/nnue-diverse421-v1/inputs/evaluation-v1/prefix-book.json",
        dict(
            sha256="0889cb36bc4c07fb6599fce834d2a300bb674c7f2b175a4849aebdfe576ce5e1",
            bytes=1490,
            mode="0644",
        ),
    )
    sch, sch_ref = read(
        book["schedule"]["path"], dict(sha256=book["schedule"]["sha256"])
    )
    ec, ec_ref = read(B421 / "input-preparation-v1/evaluation-collection.json")
    assert ec["files"]["prefix_book"] == book_ref and ec["files"]["schedule"] == sch_ref
    assert ec["result"]["accepted_slots"] == ec["result"]["unique_family_count"] == 16
    assert ec["result"]["missing_slots"] == 0
    cfg, cfg_ref = read(ec["config"]["path"], ec["config"])
    assert cfg["prefix_seed"] == 42120261016
    spec, spec_ref = read(
        ROOT
        / ".worktree/arena-generalization377/.artifacts/research-team/nnue-diverse421-analysis-v1/spec.json",
        dict(
            sha256="afa79145aa59e1f93c1006ca825d5d8ee2e9ddc79ede02d9214ecb0544384734",
            bytes=7583,
            mode="0644",
        ),
    )
    build, build_ref = read(
        BASE
        / "zero-stock-wall-detour424-v1/compatible-build-v1/operation-v1/manifest.json",
        dict(
            sha256="e551167298f0fdb759f64a34cfe7691dff5c568c9742856d3b9191f0d5329672",
            bytes=53955,
            mode="0644",
        ),
    )
    assert build["status"] == "PASS"
    artifact = build["artifact"]
    assert (
        artifact["sha256"]
        == "f4bbae67eb305d5ff467a8fcf82bb52bd9651d01c0257f394c9dc7117b6f75fe"
    )
    assert artifact["bytes"] == 9384592
    identity, identity_ref = read(
        B421 / "science-v1/identity-view-v1/collection.json",
        dict(
            sha256="df73facd1deb60b82b86b53ee2dd64448fab95b70cce6f3ef42fce5f1407133b",
            bytes=4748,
            mode="0644",
        ),
    )
    assert (
        identity["typed_evaluator_sha256"]
        == "0de86cbd8db0e0c3d326ca1d83bda6522f6497ace1eeeb7ec6d843088e5c8d50"
    )
    c, c_ref = read(
        B421 / "science-v1/fit-C-v1/saved-completion.json",
        dict(
            sha256="cae9293da09e586c28debf9611fc25d41388b5d7dfa3d5232f58fdaa241e5497",
            bytes=6292,
            mode="0644",
        ),
    )
    best_exp, best_ref = read(B421 / "science-v1/depth4-v1/BEST43/experiment.json")
    d_exp, d_ref = read(B421 / "science-v1/depth4-v1/D/experiment.json")
    assert best_exp["build_manifest"] == d_exp["build_manifest"] == build_ref
    best = best_exp["models"][0]
    assert c["best_step"] == 0 and c["selected_BEST"] == best["descriptor"]
    assert (
        best["evaluator_sha256"]
        == "96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875"
    )
    m = dict(
        descriptor=identity["descriptor"],
        weights=identity["weights"],
        evaluator_sha256=identity["typed_evaluator_sha256"],
    )
    payload_stat_only = []
    for r in [
        artifact,
        best["descriptor"],
        best["weights"],
        m["descriptor"],
        m["weights"],
    ]:
        actual = Path(r["path"]).stat()
        assert (
            actual.st_size == r["bytes"]
            and f"{stat.S_IMODE(actual.st_mode):04o}" == r["mode"]
        )
        payload_stat_only.append(
            dict(
                file=r,
                size_mode_exact=True,
                payload_read=False,
                sha_authority="declared immutable metadata above; no author payload rehash",
            )
        )
    old_config, old_config_ref = read(OLD / "config-000.json")
    old_plan, old_plan_ref = read(OLD / "plan.json")
    old_settings, old_settings_ref = read(OLD / "settings.json")
    verification, verification_ref = read(
        OWN.parent / "arena-source-v1/verification-plan.json"
    )
    exact_filter = verification["new_definitions"][0]["name"]
    assert (
        exact_filter
        == "runtime::research_threefold_runtime_tests::arena421_exhausted_operation_budget_enters_no_worker_and_preserves_unknown_parent"
    )

    # This is an existing-format carrier of native-owned metadata, not a new classifier.
    # No per-family seed was recorded; preserve null rather than inventing one.
    families = []
    assert len(book["openings"]) == len(sch["scheduled"]) == 16
    for i, (opening, row) in enumerate(
        zip(book["openings"], sch["scheduled"], strict=True)
    ):
        assert row["game"] == i and row["request_id"] == opening["id"]
        assert row["scheduled_failure"] is None and row["prefix"] == opening["prefix"]
        assert len(opening["prefix"]) == [4, 8, 12, 16][i % 4]
        families.append(
            dict(
                family_id=i,
                id=opening["id"],
                seed=None,
                prefix=opening["prefix"],
                root_key=row["root"]["state_key"],
                history_counts=row["root"]["history"],
            )
        )
    assert (
        len({f["id"] for f in families})
        == len({tuple(f["prefix"]) for f in families})
        == 16
    )
    carrier = put(
        "arena-book.json",
        dict(
            complete=True,
            rules="research-standard-2p-threefold-goal-first-v1",
            families=families,
            source_prefix_book=book_ref,
            source_native_schedule=sch_ref,
            source_preparation=ec_ref,
            prefix_batch_seed=cfg["prefix_seed"],
            scope="Shape adaptation of the already accepted16 inputs only. No geometry/collision/history reconstruction or new qualification; normal native full-prefix replay remains required.",
        ),
    )
    openings = [
        dict(
            id=f["id"],
            cohort="main",
            lineage="421-evaluation:" + f["id"],
            siblings=[],
            original_seed=None,
            reference=dict(
                source_sha256=carrier["sha256"],
                model_sha256=None,
                settings=f,
                q_definition=None,
                q_perspective=None,
                q_aggregation=None,
                q=None,
            ),
            selection_reason="All original16 fixed native evaluation slots; preserved order, no outcome-based choice/refill",
            candidate_pool_size=32,
            prefix=f["prefix"],
        )
        for f in families
    ]
    native_book = dict(
        id="nnue-diverse421-fixed-evaluation16",
        usage="main",
        frozen_before_candidate_results=True,
        independence="Same16 families shared across4 contrasts; two colours paired; conditional fixed-book family interval, not128 independent starts.",
        openings=openings,
    )
    models = dict(BEST43=best, C=best, M=m, D=None)
    d_id = old_plan["matchups"][2]["evaluator_sha256"][0]
    assert d_id == "c83db10ba1403b7fc3417e73e14cc5f1a1040c65ac4ac23a5f5703abbb5aa887"
    common = dict(
        distance_a=0.0,
        distance_b=8.0,
        depth=64,
        max_nodes=1000000,
        time_ms=100,
        simd=False,
        ordering_profile="control",
        lmr=True,
        lmr_method="depth_rank",
    )

    def engine(label):
        model = models[label]
        return dict(
            kind="distance" if model is None else "nnue",
            model=None if model is None else model["descriptor"]["path"],
            **common,
        )

    contrasts = [("M", "BEST43"), ("C", "BEST43"), ("M", "D"), ("C", "D")]
    schedule, batches, matchups, conditions = [], [], [], []
    colors = [i % 2 for i in range(16)]
    for batch, (left, right) in enumerate(contrasts):
        config = copy.deepcopy(old_config)
        config.update(
            run_id=f"421-{left}-vs-{right}-control-depth-rank",
            output=str(PERF / f"batch-{batch:03d}/data"),
            seed=spec["seeds"]["arena_and_native_family_bootstrap"],
            engines=[engine(left), engine(right)],
        )
        a = config["arena"]
        a.update(
            book=native_book,
            max_total_nodes=250000000,
            bootstrap_seed=spec["seeds"]["arena_and_native_family_bootstrap"],
            first_candidate_colors=colors,
            evaluator_sha256=[
                d_id if models[x] is None else models[x]["evaluator_sha256"]
                for x in (left, right)
            ],
            search_artifact_sha256=[artifact["sha256"]] * 2,
        )
        assert config["games"] == 32 and config["max_plies"] == 200
        assert config["cpu_cores"] == [2, 6] and config["management_cpu_core"] == 4
        config_ref = put(f"config-{batch:03d}.json", config)
        slots = []
        for i, f in enumerate(families):
            for offset, color in enumerate([colors[i], 1 - colors[i]]):
                slot = batch * 32 + 2 * i + offset
                schedule.append(
                    dict(
                        slot=slot,
                        batch=batch,
                        matchup=batch,
                        local_game=2 * i + offset,
                        family_id=f["family_id"],
                        candidate_color=color,
                    )
                )
                slots.append(slot)
        batches.append(dict(batch=batch, matchup=batch, config=config_ref, slots=slots))
        matchups.append(
            dict(
                id=batch,
                engines=config["engines"],
                evaluator_sha256=a["evaluator_sha256"],
                inference=None,
            )
        )
        conditions.append(
            dict(
                batch=batch,
                left=left,
                right=right,
                config=config_ref,
                operation_node_quota=250000000,
                games_max=32,
                pairs_max=16,
                identical_model_control=(left == "C" and right == "BEST43"),
            )
        )
    schedule_ref = put("schedule.json", schedule)
    inputs = [carrier, book_ref, sch_ref, ec_ref, cfg_ref, identity_ref, c_ref]
    plan = dict(
        schema="quoridor.research.arena-plan.v1",
        phase="arena",
        comparison="whole_wall_time",
        rules="research-standard-2p-threefold-goal-first-v1",
        distance_units="wall-distance/80",
        value_perspective="side-to-move",
        book=carrier,
        inputs=inputs,
        models=[best, m],
        schedule=schedule_ref,
        family_ids=list(range(16)),
        matchups=matchups,
        batches=batches,
        planned_slots=128,
    )
    plan_ref = put("plan.json", plan)
    experiment = dict(
        schema="quoridor.research.experiment.v1",
        phase="arena",
        build_manifest=build_ref,
        config=batches[0]["config"],
        inputs=inputs,
        models=plan["models"],
        dynamic_libraries=best_exp["dynamic_libraries"],
        schedule=schedule_ref,
        numerical_qualification=None,
        canonical_plan_sha256=plan_ref["sha256"],
        rules=plan["rules"],
        distance_units=plan["distance_units"],
        value_perspective=plan["value_perspective"],
        planned_slots=128,
        batch=0,
        argv=[
            artifact["path"],
            "arena",
            "--experiment",
            "@EXPERIMENT@",
            "--experiment-sha256",
            "@EXPERIMENT_SHA256@",
        ],
    )
    experiment_ref = put("experiment-template.json", experiment)
    run = copy.deepcopy(old_settings["arena"]["template"])
    run.update(
        owner=str(PERF),
        output=str(PERF / "template/operation"),
        env=None,
        support=None,
        approved_plan=plan_ref,
        artifact=artifact,
        experiment=experiment_ref,
        caller_sources=None,
        data_root=str(PERF / "batch-000/data"),
        owned_outputs=[],
        TMP=str(PERF / "template/TMP"),
        finalizers=[],
        argv=None,
    )
    for item in run["data"]:
        item["path"] = str(PERF / "batch-000/data" / Path(item["path"]).name)
    run_ref = put("run-template.json", run)
    seq = dict(
        schema="quoridor.research.lifecycle-intent.v1",
        kind="sequence",
        owner=str(PERF),
        cwd=str(ROOT),
        output=str(PERF / "execution-v1"),
        arena_block=8,
        serial_order=["arena", "measure"],
        arena=dict(range=[0, 3], template=run),
        measurements=[],
    )
    seq_ref = put("sequence-template.json", seq)
    settings = dict(
        issue="quoridor-4lc.421.3",
        scope="ARENA_SETTINGS_V2_ONLY",
        configs_ready=True,
        plan_ready=True,
        launch_ready=False,
        build_manifest=build_ref,
        artifact=artifact,
        spec=spec_ref,
        evaluation_prefix_book=book_ref,
        original_schedule=sch_ref,
        plan=plan_ref,
        schedule=schedule_ref,
        conditions=conditions,
        run_template=run_ref,
        sequence_template=seq_ref,
        experiment_template=experiment_ref,
        aliases=dict(C=dict(alias_of="BEST43", best_step=0, proof=c_ref, model=best)),
        M_identity=dict(
            typed_sha256=m["evaluator_sha256"],
            raw_fingerprint_NOT_typed=identity["model_raw_fingerprint_hex"],
            proof=identity_ref,
        ),
        quota=dict(
            per_contrast=250000000,
            contrasts=4,
            whole=1000000000,
            transfer=False,
            refill=False,
            scope="Persistent operation budget, across all family/colour games; no per-pair reset",
        ),
        clock=dict(
            authority_receipt_ms=100,
            return_reserve_ms=5,
            node_safety_per_move=1000000,
            max_total_plies_including_prefix=200,
        ),
        method=dict(
            ordering_profile="control",
            lmr=True,
            lmr_method="depth_rank",
            use_tt=True,
            tt_entries=1048576,
            use_pvs=True,
            zero_stock_approx="OFF by unchanged arena session factory; Engine has no such JSON field",
            safe_leaf="OFF by unchanged arena session factory; no invented JSON field",
            namespace="actual native session owner; no local method/namespace composition",
        ),
        counts=dict(
            families=16,
            contrasts=4,
            games_max=128,
            colour_pairs_max=64,
            family_order=list(range(16)),
            first_candidate_colors=colors,
        ),
        software=dict(
            new_exact_filter=exact_filter,
            status="ROOT_PENDING_ONE_TARGETED_RUN",
            old_NodeBudget_success_replay=False,
            author_test_execution=False,
        ),
        root_pending=dict(
            current_caller_sources=None,
            resource_support=None,
            env=None,
            numerical_qualification=None,
            runtime_resources=None,
            runtime_Experiment=None,
            jobs=None,
            physics_quiet=None,
            bulk_remaining_and_output_forecast=None,
            whole256MiB_decimal50GB_entry=None,
        ),
        output=dict(
            per_operation_config_ceiling_B=67108864,
            meaning="Existing arena output ceiling only, not a claim all four ceilings plus retained421 fit. Root existing forecast/whole256MiB guard required; partial UNKNOWN retained.",
        ),
        no_new_science=True,
        source_mutations=False,
        old_failures_preserved=True,
    )
    settings_ref = put("settings.json", settings)
    assert len(schedule) == len({r["slot"] for r in schedule}) == 128
    assert len({(r["batch"], r["family_id"]) for r in schedule}) == 64
    for batch in range(4):
        for family in range(16):
            assert sorted(
                r["candidate_color"]
                for r in schedule
                if r["batch"] == batch and r["family_id"] == family
            ) == [0, 1]
    assert sum(c["operation_node_quota"] for c in conditions) == 1000000000
    for path, original in SELECTED.items():
        assert ref(path) == original, path
    put(
        "selectedrefs.json",
        dict(
            before_parse=list(SELECTED.values()),
            after_parse=list(SELECTED.values()),
            exact=True,
            payload_metadata_only=payload_stat_only,
            historical_format_only=[old_config_ref, old_plan_ref, old_settings_ref],
            original_fixture_owner=verification_ref,
            no_payload_reads=True,
            native_prefix_admission="Root pending; no author chronology qualification",
        ),
    )
    put(
        "static-checks.json",
        dict(
            status="PASS_METADATA_ARITHMETIC_ONLY",
            settings=settings_ref,
            slots=128,
            planned_colour_pairs=64,
            original16_only=True,
            cap_sum=1000000000,
            C_alias_exact=True,
            correct_M_typed_ID=True,
            source_fixtures_RUN=0,
            native_Search_games_model_forwards=0,
            old_RAW_reads=0,
            source_write_stdin_attempt="author-v1 guard child python '-' received no stdin and performed no write; empty log retained; this is ordinary first materialization, not a science replay",
        ),
    )
    print(
        json.dumps(
            dict(
                settings=settings_ref,
                plan=plan_ref,
                schedule=schedule_ref,
                slots=128,
                pairs=64,
                caps=[250000000] * 4,
                launch_ready=False,
            )
        )
    )


if __name__ == "__main__":
    main()
