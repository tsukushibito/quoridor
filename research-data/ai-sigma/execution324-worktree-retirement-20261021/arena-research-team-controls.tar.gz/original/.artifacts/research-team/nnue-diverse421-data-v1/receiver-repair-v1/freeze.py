import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile
import tomllib

OWN = Path(__file__).resolve().parent
BASE = "67668dddf09589cd30a860e6bb5fd6d842842a65"


def ref(path):
    raw = path.read_bytes()
    return {
        "path": str(path.resolve()),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


def save(name, value):
    (OWN / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def body(text, signature):
    start = text.index(signature)
    end = text.index("{", start)
    depth = 1
    end += 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[start:end]


def tokens(text):
    # Rustfmt may add an optional trailing argument comma after routing a call
    # to the shared helper. Ignore that spelling and whitespace only.
    return re.sub(r",\)", ")", re.sub(r"\s+", "", text))


def main():
    rust = sorted((OWN / "post").rglob("*.rs"))
    subprocess.run(
        [
            "rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            *map(str, rust),
        ],
        check=True,
    )
    subprocess.run(
        [
            "rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            "--check",
            *map(str, rust),
        ],
        check=True,
    )
    old = {}
    new = {}
    subjects = []
    forward = []
    inverse = []
    for post in sorted((OWN / "post").rglob("*")):
        if not post.is_file():
            continue
        rel = str(post.relative_to(OWN / "post"))
        recovery = OWN / "before" / (rel + ".gz")
        before = gzip.decompress(recovery.read_bytes())
        assert before == subprocess.check_output(["git", "show", f"{BASE}:{rel}"])
        after = post.read_bytes()
        old[rel] = before.decode()
        new[rel] = after.decode()
        subjects.append(
            {
                "subject": rel,
                "before": {
                    "sha256": hashlib.sha256(before).hexdigest(),
                    "bytes": len(before),
                    "mode": "0644",
                },
                "before_recovery": ref(recovery),
                "post": ref(post),
            }
        )
        forward += list(
            difflib.unified_diff(
                before.decode().splitlines(True),
                after.decode().splitlines(True),
                fromfile="a/" + rel,
                tofile="b/" + rel,
            )
        )
        inverse += list(
            difflib.unified_diff(
                after.decode().splitlines(True),
                before.decode().splitlines(True),
                fromfile="a/" + rel,
                tofile="b/" + rel,
            )
        )
    assert len(subjects) == 4
    (OWN / "forward.patch").write_text("".join(forward))
    (OWN / "inverse.patch").write_text("".join(inverse))
    scratch = Path(tempfile.mkdtemp(prefix="receiver-proof-", dir=os.environ["TMPDIR"]))
    try:
        for rel, value in old.items():
            path = scratch / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(value)
        subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OWN / "forward.patch")],
            cwd=scratch,
            check=True,
        )
        assert all((scratch / rel).read_text() == value for rel, value in new.items())
        subprocess.run(
            ["patch", "--batch", "--fuzz=0", "-p1", "-i", str(OWN / "inverse.patch")],
            cwd=scratch,
            check=True,
        )
        assert all((scratch / rel).read_text() == value for rel, value in old.items())
    finally:
        shutil.rmtree(scratch)
    protected = []
    for rel, signatures in {
        "crates/quoridor-data/src/terminal_stream.rs": [
            "fn validate_game(",
            "fn common_depth_census(",
            "fn validate_completion_index(",
            "fn validate_game_slot(",
            "fn common_config(",
        ],
        "crates/quoridor-data/src/common_corpus.rs": [
            "pub fn targets(",
            "pub fn raw_completed_d6(",
            "pub fn validate_inputs(",
            "pub fn excluded_book_prefixes(",
        ],
        "crates/quoridor-runner/src/teacher_pilot_execution.rs": [
            "fn play_with_budget(",
            "fn finish_game(",
            "fn play_using_policy(",
        ],
    }.items():
        for signature in signatures:
            before = body(old[rel], signature)
            assert before == body(new[rel], signature), signature
            protected.append(
                {
                    "subject": rel,
                    "body": signature,
                    "sha256": hashlib.sha256(before.encode()).hexdigest(),
                    "exact": True,
                }
            )
    producer = "crates/quoridor-runner/src/teacher_pilot_execution.rs"
    corpus = "crates/quoridor-data/src/common_corpus.rs"
    observed = body(old[producer], "fn session_settings(").replace(
        "fn session_settings(", "pub fn fixed_d_session_settings(", 1
    )
    assert observed == body(new[corpus], "pub fn fixed_d_session_settings(")
    expected_namespace = body(old[producer], "fn search_namespace(")
    expected_namespace = (
        expected_namespace.replace(
            "fn search_namespace(policy: SearchPolicy)",
            "pub fn fixed_d_search_namespace(max_nodes: u64, tt_slots: usize)",
        )
        .replace("EVALUATOR_ID.into()", "EVALUATOR.into()")
        .replace("quoridor_data::common_corpus::VERSION", "VERSION")
        .replace("policy.nodes", "max_nodes")
        .replace("policy.tt_slots", "tt_slots")
    )
    assert tokens(expected_namespace) == tokens(
        body(new[corpus], "pub fn fixed_d_search_namespace(")
    )
    assert (
        "fn search_namespace(" not in new[producer]
        and "fn expected_session_settings(" not in new[producer]
        and "fn session_settings(" not in new[producer]
    )
    # The producer factory/constructor/setter sequence changes only which pure
    # helper formats and checks the same observed metadata.
    factory = (
        body(old[producer], "fn configured_sessions(")
        .replace(
            "search_namespace(policy)",
            "fixed_d_search_namespace(policy.nodes, policy.tt_slots)",
        )
        .replace("session_settings(", "fixed_d_session_settings(")
    )
    factory = factory.replace(
        "expected_fixed_d_session_settings(policy)",
        "expected_fixed_d_session_settings(policy.nodes, policy.tt_slots, policy.lmr, policy.lmr_method)",
    )
    assert tokens(factory) == tokens(body(new[producer], "fn configured_sessions("))
    manifest = "crates/quoridor-data/Cargo.toml"
    dependency = 'quoridor-ai = { path = "../quoridor-ai", features = ["research"] }\n'
    assert new[manifest].replace(dependency, "", 1) == old[manifest]
    before_toml = tomllib.loads(old[manifest])
    after_toml = tomllib.loads(new[manifest])
    assert after_toml["dependencies"].pop("quoridor-ai") == {
        "path": "../quoridor-ai",
        "features": ["research"],
    }
    assert after_toml == before_toml
    tests = re.findall(
        r"#\[test\]\s+fn (receiver421_\w+)",
        new["crates/quoridor-data/src/terminal_stream.rs"],
    )
    assert len(tests) == 3
    save(
        "static-proof.json",
        {
            "forward_inverse_exact": True,
            "before_base_exact": BASE,
            "new_maintained_files": [],
            "new_file_absence": "All four affected subjects exist in the named immutable Git",
            "protected_bodies": protected,
            "observed_metadata_formatter_moved_exact": True,
            "namespace_formatter_moved_with_parameter_substitution_only": True,
            "producer_factory_token_equivalent_after_pure_helper_routing": True,
            "no_duplicate_TT_ABI_formula_or_LMR_enum": True,
            "TOML": "No installed formatter; project workflow fallback: manual existing one-line dependency style + stdlib tomllib parse; only one dependency differs",
            "native_tests": "UNBUILT/UNTYPED/UNRUN",
        },
    )
    save(
        "verification-plan.json",
        {
            "new_count": 3,
            "new_definitions": [
                {
                    "filter": "terminal_stream::receiver421_tests::" + name,
                    "status": "UNBUILT/UNTYPED/UNRUN",
                }
                for name in tests
            ],
            "existing_fixture_mechanical_changes": [
                "stream_repair_depth_policy_bound_not_rebranded: explicit current config and session counters; assertions unchanged",
                "configured_intake_requires_completed_d6_without_closed_phase_or_quantity: explicit current TT/PVS fields; assertions unchanged",
            ],
            "necessary_Root_software": "Apply minimal Cargo dependency/normal Cargo.lock package dependency update; affected data+runner research/diagnostics compile, new3 assertions, relevant Clippy/current converter optimized build. No old success-suite replay, no new generation/model/fit by author.",
            "runtime": "Root uses immutable original RAW and fresh output after receiver acceptance. Existing failedcompact-v1 partial/incomplete markers untouched. Exact metadata match is a receiver check, not native success or arbitrary self-declared capacity authority.",
            "default_OFF_scope": "Current metadata-bearing producer protocol supports omitted/false LMR and canonical fixed default. Missing session metadata is refused; no old-protocol compatibility shim. Header control correspondence remains exact.",
        },
    )
    save(
        "source-binding.json",
        {
            "issue": "quoridor-4lc.421.3",
            "base_git": BASE,
            "subjects": subjects,
            "forward": ref(OWN / "forward.patch"),
            "inverse": ref(OWN / "inverse.patch"),
            "selected_original_view": ref(OWN / "bounded-original-record-view.json"),
            "raw_mutations": 0,
            "author_native_Cargo_tests_Search_model_geometry_science": 0,
            "Cargo_lock": "Root normal lock update adds existing quoridor-ai workspace dependency to quoridor-data package; no new version/registry/dependency download requested",
            "software": "UNBUILT/UNTYPED/UNRUN",
        },
    )
    print(
        json.dumps(
            {
                "forward": ref(OWN / "forward.patch"),
                "source_binding": ref(OWN / "source-binding.json"),
                "new_tests": tests,
            }
        )
    )


if __name__ == "__main__":
    main()
