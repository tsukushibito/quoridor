import gzip
import hashlib
import json
from pathlib import Path
import subprocess

OWN = Path(__file__).resolve().parent
BASE = "8be646be3657d2fd322f6769dce2d2228576b8ad"
SLICE = OWN / "arena-source-v1"
PATHS = [
    "crates/quoridor-runner/src/arena.rs",
    "crates/quoridor-runner/src/runtime.rs",
    "crates/quoridor-runner/src/resources.rs",
    "crates/quoridor-runner/src/teacher_pilot_execution.rs",
]


def replace(text, old, new, count=1):
    assert text.count(old) == count, (old[:100], text.count(old))
    return text.replace(old, new)


def main():
    SLICE.mkdir(exist_ok=False)
    (SLICE / "write-paths.json").write_text(
        json.dumps(
            {
                "paths": PATHS,
                "purpose": "Reuse existing node reservation arithmetic for optional alpha arena operation cap; no additional scheduler or scientific call",
                "before": "named immutable Git, except teacher execution is the exact frozen generation-source-v1 post",
                "scope": "private only; Main integration Root324",
            },
            indent=2,
        )
        + "\n"
    )
    texts = {}
    for rel in PATHS:
        if rel.endswith("teacher_pilot_execution.rs"):
            raw = (OWN / "post" / rel).read_bytes()
        else:
            raw = subprocess.check_output(["git", "show", f"{BASE}:{rel}"])
        p = SLICE / "before" / (rel + ".gz")
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(gzip.compress(raw, mtime=0))
        texts[rel] = raw.decode()
    arena, runtime, resources, teacher = (texts[p] for p in PATHS)
    arena = replace(
        arena,
        "    pub tt_entries: usize,",
        '    pub tt_entries: usize,\n    /// Whole-operation alpha node ceiling; absent keeps the existing caller.\n    #[serde(default, skip_serializing_if = "Option::is_none")]\n    pub max_total_nodes: Option<u64>,',
    )
    arena = replace(
        arena,
        "        let width = if self.decision_only { 1 } else { 2 };",
        """        if self.max_total_nodes.is_some_and(|n| n == 0)
            || (self.max_total_nodes.is_some()
                && (!c.evaluation_workers()
                    || c.engines.iter().any(|e| !matches!(e.kind.as_str(), "nnue" | "distance"))))
        {
            return Err("arena total-node cap requires positive alpha evaluation-worker budget".into());
        }
        let width = if self.decision_only { 1 } else { 2 };""",
    )
    # Move the one existing implementation, keeping its reservation/opaque-error
    # semantics and original meaningful fixture rather than copying them.
    a = teacher.index("/// Shared finite work ceiling.")
    b = teacher.index("\nfn scheduled_failure", a)
    budget_source = teacher[a:b]
    teacher = teacher[:a] + teacher[b:]
    teacher = replace(teacher, "    resources,", "    resources::{self, NodeBudget},")
    teacher = replace(
        teacher,
        "atomic::{AtomicBool, AtomicU64, Ordering}",
        "atomic::{AtomicBool, Ordering}",
    )
    # Existing synthetic tests need this counter; it is not an invocation cost.
    teacher = replace(
        teacher,
        "mod configured_generation_tests {\n    use super::*;",
        "mod configured_generation_tests {\n    use super::*;\n    use std::sync::atomic::AtomicU64;",
    )
    budget_source = replace(
        budget_source, "struct NodeBudget {", "pub(crate) struct NodeBudget {"
    )
    for name in ("new", "reserve", "settle"):
        budget_source = replace(
            budget_source, f"    fn {name}(", f"    pub(crate) fn {name}("
        )
    budget_source = replace(
        budget_source,
        "impl NodeBudget {",
        """impl NodeBudget {
    pub(crate) fn remaining(&self) -> u64 {
        self.remaining.load(Ordering::Acquire)
    }""",
    )
    resources += (
        "\nuse std::sync::atomic::{AtomicU64, Ordering};\n\n" + budget_source + "\n"
    )
    runtime = replace(
        runtime,
        "    pub arena_summary: Option<crate::arena_statistics::Summary>,",
        "    pub arena_summary: Option<crate::arena_statistics::Summary>,",
    )
    runtime = replace(
        runtime,
        "pub struct PumpProfile {",
        """pub struct PumpProfile {
    /// Reservation charge includes opaque/unreturned work; not a second node sum.
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub arena_node_budget: Option<serde_json::Value>,""",
    )
    runtime = replace(
        runtime,
        "struct EvaluationTurn {\n    id: RequestId,",
        "struct EvaluationTurn {\n    id: RequestId,\n    node_limit: Option<u64>,",
    )
    runtime = replace(
        runtime,
        "struct EvaluationWorkers {\n    workers:",
        "struct EvaluationWorkers {\n    node_budget: Option<crate::resources::NodeBudget>,\n    workers:",
    )
    runtime = replace(
        runtime,
        "        let mut owned = Self {\n            workers: Vec::new(),",
        "        let mut owned = Self {\n            node_budget: config.arena.as_ref().and_then(|a| a.max_total_nodes).map(crate::resources::NodeBudget::new),\n            workers: Vec::new(),",
    )
    # The one actual evaluation-worker alpha invocation receives main's cap.
    runtime = replace(
        runtime,
        """                            let limits = SearchLimits {
                                max_depth: e.depth,
                                max_nodes: e.max_nodes,""",
        """                            let limits = SearchLimits {
                                max_depth: e.depth,
                                max_nodes: turn.node_limit.unwrap_or(e.max_nodes),""",
    )
    runtime = replace(
        runtime,
        """    // Cache the legal no-work fallback outside the receipt critical path. The
    // immutable choice is frozen by main before a later terminal is processed.
    let fallback""",
        """    // Reserve before the thinking clock/dispatch. No next turn starts before
    // this turn's matching terminal is drained; errors keep their reservation.
    let node_limit = owners.node_budget.as_ref()
        .map(|budget| budget.reserve(config.engines[engine].max_nodes))
        .transpose().map_err(|error| error.to_string())?;
    // Cache the legal no-work fallback outside the receipt critical path. The
    // immutable choice is frozen by main before a later terminal is processed.
    let fallback""",
    )
    runtime = replace(
        runtime,
        """        .send(EvaluationCommand::Turn(Box::new(EvaluationTurn {
            id,""",
        """        .send(EvaluationCommand::Turn(Box::new(EvaluationTurn {
            id,
            node_limit,""",
    )
    runtime = replace(
        runtime,
        """    // No next turn or write occurs before this exact terminal is collected.
    received.freeze(game, sigma);""",
        """    // No next turn or write occurs before this exact terminal is collected.
    // Completed snapshots are nested: settle from the actual terminal only.
    if let (Some(budget), Some(reserved), EvaluationResult::Alpha { result: Ok(result), .. }) =
        (&owners.node_budget, node_limit, &terminal.0)
    {
        budget.settle(reserved, result.stats.nodes).map_err(|error| error.to_string())?;
    }
    received.freeze(game, sigma);""",
    )
    runtime = replace(
        runtime,
        """        observation.counters["matching_terminal_collected"] = terminal.5.is_some().into();""",
        """        if let Some(reserved) = node_limit {
            observation.counters["operation_node_reservation"] = reserved.into();
            observation.counters["operation_node_remaining_after_drain"] =
                owners.node_budget.as_ref().unwrap().remaining().into();
        }
        observation.counters["matching_terminal_collected"] = terminal.5.is_some().into();""",
    )
    runtime = replace(
        runtime,
        """    let joined = owners.close();
    if !joined {""",
        """    let joined = owners.close();
    pump.arena_node_budget = owners.node_budget.as_ref().map(|budget| {
        let cap = config.arena.as_ref().unwrap().max_total_nodes.unwrap();
        serde_json::json!({"cap":cap,"remaining":budget.remaining(),
            "charged_nodes_including_opaque_reservations":cap-budget.remaining(),
            "scope":"one operation; terminal node work is nested, not added again"})
    });
    if !joined {""",
    )
    # Existing source fixtures construct the private worker holder directly.
    runtime = runtime.replace(
        "EvaluationWorkers {\n            workers:",
        "EvaluationWorkers {\n            node_budget: None,\n            workers:",
    )
    runtime = runtime.replace(
        "EvaluationTurn {\n            id:",
        "EvaluationTurn {\n            node_limit: None,\n            id:",
    )
    for rel, value in zip(PATHS, (arena, runtime, resources, teacher)):
        p = SLICE / "post" / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(value)
    print(
        json.dumps(
            {
                "paths": PATHS,
                "unchanged_generation_packet": True,
                "native_tests": "UNBUILT/UNTYPED/UNRUN",
                "input": hashlib.sha256(
                    (OWN / "generation-source-v1/source-binding.json").read_bytes()
                ).hexdigest(),
            }
        )
    )


if __name__ == "__main__":
    main()
