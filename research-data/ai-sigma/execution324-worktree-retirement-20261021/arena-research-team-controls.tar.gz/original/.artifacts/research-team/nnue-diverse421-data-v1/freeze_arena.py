import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

from freeze_generation import body, ref

OWN = Path(__file__).resolve().parent
PACKET = OWN / "arena-source-v1"


def save(name, value):
    (PACKET / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def main():
    posts = sorted((PACKET / "post").rglob("*.rs"))
    subprocess.run(
        [
            "rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            *map(str, posts),
        ],
        check=True,
    )
    subprocess.run(
        [
            "rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            "--check",
            *map(str, posts),
        ],
        check=True,
    )
    before = {}
    after = {}
    subjects = []
    forward = []
    inverse = []
    for post in posts:
        rel = str(post.relative_to(PACKET / "post"))
        recovery = PACKET / "before" / (rel + ".gz")
        old = gzip.decompress(recovery.read_bytes())
        new = post.read_bytes()
        before[rel] = old.decode()
        after[rel] = new.decode()
        subjects.append(
            {
                "subject": rel,
                "before": {
                    "sha256": hashlib.sha256(old).hexdigest(),
                    "bytes": len(old),
                    "mode": "0644",
                },
                "recovery": ref(recovery),
                "post": ref(post),
            }
        )
        forward += list(
            difflib.unified_diff(
                old.decode().splitlines(True),
                new.decode().splitlines(True),
                fromfile="a/" + rel,
                tofile="b/" + rel,
            )
        )
        inverse += list(
            difflib.unified_diff(
                new.decode().splitlines(True),
                old.decode().splitlines(True),
                fromfile="a/" + rel,
                tofile="b/" + rel,
            )
        )
    (PACKET / "forward.patch").write_text("".join(forward))
    (PACKET / "inverse.patch").write_text("".join(inverse))
    scratch = Path(
        tempfile.mkdtemp(prefix="arena-thin-proof-", dir=os.environ["TMPDIR"])
    )
    try:
        for rel, old in before.items():
            path = scratch / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(old)
        subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "-p1",
                "-i",
                str(PACKET / "forward.patch"),
            ],
            cwd=scratch,
            check=True,
        )
        assert all((scratch / rel).read_text() == new for rel, new in after.items())
        subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "-p1",
                "-i",
                str(PACKET / "inverse.patch"),
            ],
            cwd=scratch,
            check=True,
        )
        assert all((scratch / rel).read_text() == old for rel, old in before.items())
    finally:
        shutil.rmtree(scratch)
    protected = []
    for rel, signatures in {
        "crates/quoridor-runner/src/runtime.rs": [
            "fn arena_alpha_session(",
            "fn arena_alpha_namespace(",
            "fn invoke_alpha_observed(",
            "fn record_evaluation_alpha(",
            "fn finish(",
        ],
        "crates/quoridor-runner/src/teacher_pilot_execution.rs": [
            "fn finish_game(",
            "fn play_with_budget(",
            "fn configured_sessions(",
        ],
    }.items():
        for signature in signatures:
            old = body(before[rel], signature)
            assert old == body(after[rel], signature), signature
            protected.append(
                {
                    "subject": rel,
                    "body": signature,
                    "sha256": hashlib.sha256(old.encode()).hexdigest(),
                }
            )
    # Exact relocated reservation arithmetic is the same producer of truth.
    teacher = "crates/quoridor-runner/src/teacher_pilot_execution.rs"
    resources = "crates/quoridor-runner/src/resources.rs"
    for method in ("new", "reserve", "settle"):
        old = body(before[teacher], f"    fn {method}(")
        new = body(after[resources], f"    pub(crate) fn {method}(").replace(
            "pub(crate) fn", "fn", 1
        )
        assert old == new, method
    old_test = body(
        before[teacher],
        "    fn parallel_reservations_returned_work_and_opaque_error_cannot_exceed_total(",
    )
    assert old_test == body(
        after[resources],
        "    fn parallel_reservations_returned_work_and_opaque_error_cannot_exceed_total(",
    )
    save(
        "static-proof.json",
        {
            "strict_forward_inverse_exact": True,
            "new_files": [],
            "new_absence": "All four subjects already exist; no new maintained module",
            "protected_bodies": protected,
            "node_budget_arithmetic_and_original_test_relocated_exact": True,
            "science_tests_build": "UNBUILT/UNTYPED/UNRUN",
            "generation_packet_unchanged": True,
        },
    )
    save(
        "verification-plan.json",
        {
            "new_definitions": [
                {
                    "name": "runtime::research_threefold_runtime_tests::arena421_exhausted_operation_budget_enters_no_worker_and_preserves_unknown_parent",
                    "status": "UNBUILT/UNTYPED/UNRUN",
                }
            ],
            "new_count": 1,
            "necessary_existing": [
                "resources::common_node_budget_tests::parallel_reservations_returned_work_and_opaque_error_cannot_exceed_total (same relocated original definition)",
                "affected native receipt/error/parent-restoration fixture at evaluation_turn boundary only, Root selects one relevant existing scope",
            ],
            "source_boundary": "reservation before clock, exact terminal rather than selected snapshot settlement, opaque retained, next turn only after drain, normal UNKNOWN funnel, requested capacity/method unchanged",
            "software": "Root affected runner compile/Clippy/release. No author execution, no blanket old success replay.",
        },
    )
    save(
        "arena-settings.draft.json",
        {
            "ready": False,
            "image": None,
            "Build": None,
            "Experiment": None,
            "evaluation_prefix_book": None,
            "models": {
                "BEST43": "existing immutable046fe/46ec/96a5 (no payload read here)",
                "C": None,
                "M": None,
                "D": "original-distance-a0-b8-tanh",
            },
            "conditions": [
                {"id": 0, "left": "M", "right": "BEST43"},
                {"id": 1, "left": "C", "right": "BEST43"},
                {"id": 2, "left": "M", "right": "D"},
                {"id": 3, "left": "C", "right": "D"},
            ],
            "families": "all actual accepted evaluation slots by fixed ID, <=16",
            "colours": 2,
            "games_max": 128,
            "pairs_max": 64,
            "clock": {"authority_receipt_ms": 100, "return_reserve_ms": 5},
            "engine": {
                "depth": 64,
                "max_nodes": 1000000,
                "ordering_profile": "control",
                "lmr": True,
                "lmr_method": "depth_rank",
            },
            "arena": {
                "tt_entries": 1048576,
                "max_total_nodes_per_contrast": 250000000,
                "bootstrap_seed": 42120261021,
            },
            "whole_arena_max_total_nodes": 1000000000,
            "budget_resolution": "Four disjoint preallocated operation quotas250M each, fixed before outcomes. No unused-quota transfer/refill. Sum<=1G; may leave UNKNOWN slots at a quota. This is an explicit conservative resource allocation, not a claim that all128 finish.",
            "max_plies": 200,
            "pvs": True,
            "zero_stock_approx": "explicit OFF",
            "safe_race": "explicit OFF",
            "worker_candidate": [2, 6],
            "management_candidate": 4,
            "family_B": 4294967296,
            "actual_resources": None,
            "finite_search": {
                "parents": "first min(6,E) actual accepted eval IDs",
                "evaluators": ["BEST43", "C", "M", "D"],
                "depth": 4,
                "max_nodes": 2000000,
                "calls_max": 24,
                "nodes_total_max": 48000000,
                "lmr": False,
                "lmr_method": "fixed_one",
                "ordering_profile": "control",
                "tt_entries": 1048576,
                "time_limit": None,
            },
            "whole_science_bulk_B": 268435456,
        },
    )
    save(
        "source-binding.json",
        {
            "issue": "quoridor-4lc.421.3",
            "scope": "ARENA_OPTIONAL_OPERATION_NODE_CAP",
            "before": "arena/runtime/resources from immutable8be646be; teacher execution from frozen generation-source-v1 post",
            "generation_binding": ref(OWN / "generation-source-v1/source-binding.json"),
            "subjects": subjects,
            "forward": ref(PACKET / "forward.patch"),
            "inverse": ref(PACKET / "inverse.patch"),
            "new_science": 0,
            "qualification": "UNBUILT/UNTYPED/UNRUN",
        },
    )
    print(
        json.dumps(
            {
                "subjects": len(subjects),
                "forward": ref(PACKET / "forward.patch"),
                "source": ref(PACKET / "source-binding.json"),
            }
        )
    )


if __name__ == "__main__":
    main()
