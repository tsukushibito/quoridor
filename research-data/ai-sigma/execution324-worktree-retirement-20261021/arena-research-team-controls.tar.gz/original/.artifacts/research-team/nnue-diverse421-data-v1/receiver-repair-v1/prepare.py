from pathlib import Path


OWN = Path(__file__).resolve().parent
POST = OWN / "post"


def replace(s, old, new):
    assert s.count(old) == 1, (old[:100], s.count(old))
    return s.replace(old, new)


def main():
    runner = POST / "crates/quoridor-runner/src/teacher_pilot_execution.rs"
    corpus = POST / "crates/quoridor-data/src/common_corpus.rs"
    manifest = POST / "crates/quoridor-data/Cargo.toml"
    receiver = POST / "crates/quoridor-data/src/terminal_stream.rs"
    s = runner.read_text()
    start = s.index("fn search_namespace(")
    end = s.index("fn configured_sessions(", start)
    metadata = s[start:end]
    s = s[:start] + s[end:]
    metadata = replace(
        metadata,
        "fn search_namespace(policy: SearchPolicy)",
        "pub fn fixed_d_search_namespace(max_nodes: u64, tt_slots: usize)",
    )
    metadata = metadata.replace("EVALUATOR_ID.into()", "EVALUATOR.into()")
    metadata = metadata.replace("quoridor_data::common_corpus::VERSION", "VERSION")
    metadata = metadata.replace("policy.nodes,", "max_nodes,").replace(
        "policy.tt_slots,", "tt_slots,"
    )
    metadata = replace(
        metadata, "fn session_settings(", "pub fn fixed_d_session_settings("
    )
    metadata = replace(
        metadata,
        "fn expected_session_settings(policy: SearchPolicy) -> Result<Value> {\n    let method = policy.lmr.then_some(policy.lmr_method);",
        """pub fn expected_fixed_d_session_settings(
    max_nodes: u64,
    tt_slots: usize,
    lmr: bool,
    lmr_method: LmrMethod,
) -> Result<Value> {
    if max_nodes == 0 || !(1..=1_048_576).contains(&tt_slots) {
        return Err("configured fixed-D TT/node bounds".into());
    }
    let method = lmr.then_some(lmr_method);""",
    )
    metadata = metadata.replace("Ok(session_settings(", "Ok(fixed_d_session_settings(")
    metadata = metadata.replace(
        "SearchSession::requested_tt_byte_limit(policy.tt_slots)?",
        "SearchSession::requested_tt_byte_limit(tt_slots)?",
    )
    metadata = metadata.replace(
        "search_namespace(policy)", "fixed_d_search_namespace(max_nodes, tt_slots)"
    )
    metadata = metadata.replace("policy.lmr,", "lmr,")
    assert "policy." not in metadata
    c = corpus.read_text()
    anchor = 'pub const EVALUATOR: &str = "original-distance-a0-b8-tanh";\n'
    c = replace(
        c,
        anchor,
        anchor
        + "\n// One pure metadata owner for both generation and authoritative stream intake.\n// Capacity arithmetic and method/namespace identity remain AI-owned; no session,\n// TT allocation, evaluator construction or model/head work is performed here.\n"
        + metadata,
    )
    c = replace(
        c,
        "use serde::{Deserialize, Serialize};",
        "use quoridor_ai::alphabeta::{LmrMethod, OrderingProfile, SearchNamespace, SearchSession};\nuse quoridor_core::research::Ruleset;\nuse serde::{Deserialize, Serialize};",
    )
    s = replace(
        s,
        "    Result, Teacher, TeacherRow,",
        "    Result, Teacher, TeacherRow,\n    common_corpus::{expected_fixed_d_session_settings, fixed_d_search_namespace, fixed_d_session_settings},",
    )
    s = replace(
        s,
        "OrderingProfile, SearchLimits, SearchNamespace, SearchResult,",
        "OrderingProfile, SearchLimits, SearchResult,",
    )
    s = s.replace(
        "let namespace = search_namespace(policy);",
        "let namespace = fixed_d_search_namespace(policy.nodes, policy.tt_slots);",
    )
    s = s.replace("*actual = session_settings(", "*actual = fixed_d_session_settings(")
    for name in ("policy", "p"):
        s = s.replace(
            f"expected_session_settings({name})",
            f"expected_fixed_d_session_settings({name}.nodes, {name}.tt_slots, {name}.lmr, {name}.lmr_method)",
        )
    assert "fn search_namespace" not in s and "expected_session_settings(" not in s
    m = manifest.read_text()
    m = replace(
        m,
        "[dependencies]\n",
        '[dependencies]\nquoridor-ai = { path = "../quoridor-ai", features = ["research"] }\n',
    )
    r = receiver.read_text()
    r = replace(r, '        || number(&h.config, "tt_slots")? != 4096\n', "")
    r = replace(
        r,
        "    strict_completed_depth: bool,\n}",
        "    strict_completed_depth: bool,\n    session: Value,\n    tt_byte_limit: u64,\n    lmr: bool,\n    lmr_method: quoridor_ai::alphabeta::LmrMethod,\n}",
    )
    r = replace(
        r,
        "        Ok(Self {\n            depth,\n            max_nodes,\n            strict_completed_depth,\n        })",
        """        let tt_slots = usize::try_from(number(config, "tt_slots")?)?;
        let lmr = config.get("lmr").map(|value| value.as_bool().ok_or("boolean LMR setting"))
            .transpose()?.unwrap_or(false);
        let lmr_method = match config.get("lmr_method") {
            None | Some(Value::Null) => quoridor_ai::alphabeta::LmrMethod::default(),
            Some(Value::String(name)) => quoridor_ai::alphabeta::LmrMethod::from_name(name)?,
            _ => return Err("typed LMR method name".into()),
        };
        if config["use_pvs"] != true {
            return Err("fixed-D PVS setting".into());
        }
        let session = crate::common_corpus::expected_fixed_d_session_settings(
            max_nodes.ok_or("positive node limit")?, tt_slots, lmr, lmr_method)?;
        let tt_byte_limit = number(&session, "tt_byte_limit")?;
        Ok(Self {
            depth, max_nodes, strict_completed_depth, session, tt_byte_limit, lmr, lmr_method,
        })""",
    )
    r = replace(
        r,
        '        || number(&s.counters, "tt_retained_bytes")? > 1024 * 1024',
        """        || number(&s.counters, "tt_retained_bytes")? > policy.tt_byte_limit
        || s.counters["session"] != policy.session
        || s.counters["lmr_enabled"].as_bool() != Some(policy.lmr)
        || s.counters["lmr_method_id"] != json!(policy.lmr.then_some(policy.lmr_method.id()))
        || s.counters["zero_stock_approx_permitted"].as_bool() != Some(false)
        || s.counters["zero_stock_safe_race_enabled"].as_bool() != Some(false)""",
    )
    # Mechanically supply current explicit metadata to the two existing owning
    # fixture constructors. Original assertions/depth/NodeLimit meaning remain.
    r = replace(
        r,
        '&json!({"depth":6,"max_nodes":600000,"strict_completed_depth":true}),',
        '&json!({"depth":6,"max_nodes":600000,"strict_completed_depth":true,"tt_slots":4096,"use_pvs":true}),',
    )
    r = replace(
        r,
        'counters: json!({"nodes":500000,"policy_calls":0,"tt_retained_bytes":0}),',
        'counters: json!({"nodes":500000,"policy_calls":0,"tt_retained_bytes":0,\n                "session":strict.session,"lmr_enabled":false,"lmr_method_id":null,\n                "zero_stock_approx_permitted":false,"zero_stock_safe_race_enabled":false}),',
    )
    r = replace(
        r,
        'let c = json!({"depth":6,"max_nodes":123});',
        'let c = json!({"depth":6,"max_nodes":123,"tt_slots":4096,"use_pvs":true});',
    )
    for p, text in [(runner, s), (corpus, c), (manifest, m), (receiver, r)]:
        p.write_text(text)
    print("four private subjects prepared; no Cargo/test/native execution")


if __name__ == "__main__":
    main()
