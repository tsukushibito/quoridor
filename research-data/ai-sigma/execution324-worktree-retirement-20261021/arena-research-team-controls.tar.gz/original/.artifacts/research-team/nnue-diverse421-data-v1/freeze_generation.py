import difflib
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile


OWN = Path(__file__).resolve().parent
BASE = "8be646be3657d2fd322f6769dce2d2228576b8ad"
PACKET = OWN / "generation-source-v1"


def ref(path):
    path = Path(path).resolve()
    raw = path.read_bytes()
    return {
        "path": str(path),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "bytes": len(raw),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
    }


def save(name, value):
    (PACKET / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def body(source, signature):
    start = source.index(signature)
    brace = source.index("{", start)
    depth = 1
    end = brace + 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end]


def main():
    PACKET.mkdir(exist_ok=False)
    posts = sorted((OWN / "post").rglob("*.rs"))
    subprocess.run(
        [
            "rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            *map(str, posts),
        ],
        check=True,
    )
    subprocess.run(
        [
            "rustfmt",
            "--edition",
            "2024",
            "--config",
            "skip_children=true",
            "--check",
            *map(str, posts),
        ],
        check=True,
    )
    references = []
    forward = []
    inverse = []
    before_text = {}
    after_text = {}
    for post in posts:
        rel = str(post.relative_to(OWN / "post"))
        compressed = OWN / "before" / (rel + ".gz")
        old = gzip.decompress(compressed.read_bytes())
        assert old == subprocess.check_output(["git", "show", f"{BASE}:{rel}"])
        new = post.read_bytes()
        before_text[rel] = old.decode()
        after_text[rel] = new.decode()
        forward.extend(
            difflib.unified_diff(
                old.decode().splitlines(True),
                new.decode().splitlines(True),
                fromfile="a/" + rel,
                tofile="b/" + rel,
            )
        )
        inverse.extend(
            difflib.unified_diff(
                new.decode().splitlines(True),
                old.decode().splitlines(True),
                fromfile="a/" + rel,
                tofile="b/" + rel,
            )
        )
        references.append(
            {
                "subject": rel,
                "before": {
                    "sha256": hashlib.sha256(old).hexdigest(),
                    "bytes": len(old),
                    "mode": "0644",
                },
                "recovery": ref(compressed),
                "post": ref(post),
            }
        )
    (PACKET / "forward.patch").write_text("".join(forward))
    (PACKET / "inverse.patch").write_text("".join(inverse))
    scratch = Path(tempfile.mkdtemp(prefix="thin-proof-", dir=os.environ["TMPDIR"]))
    try:
        for rel, old in before_text.items():
            p = scratch / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(old)
        subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "-p1",
                "-i",
                str(PACKET / "forward.patch"),
            ],
            cwd=scratch,
            check=True,
        )
        assert all(
            (scratch / rel).read_text() == new for rel, new in after_text.items()
        )
        subprocess.run(
            [
                "patch",
                "--batch",
                "--fuzz=0",
                "-p1",
                "-i",
                str(PACKET / "inverse.patch"),
            ],
            cwd=scratch,
            check=True,
        )
        assert all(
            (scratch / rel).read_text() == old for rel, old in before_text.items()
        )
    finally:
        shutil.rmtree(scratch)
    protected = []
    for rel, signatures in {
        "crates/quoridor-runner/src/teacher_pilot_execution.rs": [
            "fn finish_game(",
            "impl NodeBudget {",
        ],
        "crates/quoridor-runner/src/teacher_pilot.rs": [
            "pub fn termination(",
            "pub fn from_context(",
            "pub fn audit(",
        ],
        "crates/quoridor-data/src/common_corpus.rs": [
            "pub fn targets(",
            "pub fn raw_completed_d6(",
        ],
    }.items():
        for signature in signatures:
            old = body(before_text[rel], signature)
            new = body(after_text[rel], signature)
            assert old == new, (rel, signature)
            protected.append(
                {
                    "subject": rel,
                    "body": signature,
                    "sha256": hashlib.sha256(old.encode()).hexdigest(),
                    "unchanged": True,
                }
            )
    # The AI delta is precisely the table-owned arithmetic extraction and its
    # public caller. No search/TT entry/scoring/model body is edited.
    ai = "crates/quoridor-ai/src/alphabeta.rs"
    ai_diff = list(
        difflib.unified_diff(
            before_text[ai].splitlines(), after_text[ai].splitlines(), n=2
        )
    )
    save(
        "static-proof.json",
        {
            "strict_forward": True,
            "strict_inverse": True,
            "new_files": [],
            "new_file_absence": "No new maintained files; all six subjects pre-exist in named Git",
            "protected": protected,
            "ai_delta": ai_diff,
            "native_compile_tests": "UNBUILT/UNTYPED/UNRUN",
            "no_source_main_write": True,
        },
    )
    book_locator = Path(
        "/workspaces/quoridor/.artifacts/research-team/integration324/lmr-adaptive408-v1/arena128-unentered-v1/plan.json"
    )
    locator_before = ref(book_locator)
    book_ref = json.loads(book_locator.read_text())["book"]
    assert ref(book_ref["path"]) == book_ref
    book = json.loads(Path(book_ref["path"]).read_text())
    assert (
        book["schema"] == "quoridor.value-search-strength.book.v1"
        and book["complete"] is True
    )
    assert len(book["families"]) == 128
    assert ref(book_ref["path"]) == book_ref and ref(book_locator) == locator_before
    addendum = Path(
        "/workspaces/quoridor/.artifacts/research-team/integration324/nnue-diverse421-v1/input-resolution-addendum.json"
    )
    addendum_before = ref(addendum)
    resolution = json.loads(addendum.read_text())
    assert (
        resolution["split_seed"] == 42120261023
        and resolution["generation_max_nodes_per_move"] == 4000000
    )
    assert ref(addendum) == addendum_before
    exclusions = [{"path": book_ref["path"], "sha256": book_ref["sha256"]}]
    generation_input = {
        "families": 64,
        "prefix_seed": 42120261015,
        "prefix_lengths": [4, 8, 12, 16],
        "split_seed": 42120261023,
        "excluded_books": exclusions,
        "output": "/workspaces/quoridor/.worktree/assets/data/nnue-diverse421-v1/inputs/generation-v1",
    }
    save("generation-input.draft.json", generation_input)
    save(
        "evaluation-input.draft.json",
        {
            "ready": False,
            "config": {
                "families": 16,
                "prefix_seed": 42120261016,
                "prefix_lengths": [4, 8, 12, 16],
                "split_seed": 42120261023,
                "excluded_books": None,
                "unique_families": True,
                "output": "/workspaces/quoridor/.worktree/assets/data/nnue-diverse421-v1/inputs/evaluation-v1",
            },
            "resolve_excluded_books": {
                "existing": exclusions,
                "generation_prefix_book": None,
            },
            "resolution": "Use actual returned generation prefix_book BoundJson, append to existing exclusions, then freeze complete evaluation config before outcomes. No prefix regeneration or family projection in Python.",
        },
    )
    save(
        "generation-settings.draft.json",
        {
            "ready": False,
            "image": None,
            "Build": None,
            "Experiment": None,
            "schedule": None,
            "partition": None,
            "evaluator": "original-distance-a0-b8-tanh",
            "ordering_profile": "control",
            "lmr": True,
            "lmr_method": "depth_rank",
            "tt_slots": 1048576,
            "use_pvs": True,
            "depth": 6,
            "max_nodes": 4000000,
            "max_total_nodes": 1000000000,
            "max_total_plies": 200,
            "game_workers": None,
            "worker_cores": None,
            "distance_a": 0,
            "distance_b": 8,
            "per_move_timeout_ms": None,
            "approximation": "OFF by explicit setter",
            "safe_race": "OFF by explicit setter",
            "root_value_policy": "outcome_only",
            "whole_bulk_B": 268435456,
            "source_only": True,
        },
    )
    tests = []
    for rel, text in after_text.items():
        tests += [
            {"subject": rel, "name": name, "status": "UNBUILT/UNTYPED/UNRUN"}
            for name in re.findall(
                r"#\[test\]\s+fn ((?:input421|generation421)[a-zA-Z0-9_]*)", text
            )
        ]
    assert len(tests) == 6
    save(
        "verification-plan.json",
        {
            "new_definitions": tests,
            "new_count": 6,
            "necessary_existing_scope": [
                "common_node_budget_tests (shared reservation retained)",
                "configured_fixed_d_cancel_and_first_error_create_no_fabricated_label_or_reply",
                "configured_families_group_lr_extensions_and_endpoint_collisions_before_split",
                "configured_global_partition_refuses_eval_extension_and_bound_input_drift",
            ],
            "compile": "Root: affected AI/runner/data research + research-diagnostics, owning definitions, scoped Clippy, genuine release image. Author executes no tests/compile/Search/geometry.",
            "review": "One existing related Sol review of changed method/capacity/input/outcome boundary, routed by Root.",
            "runtime": "Root actual rules-only64+16 preparation once after software; bind all schedule/partition/eval refs before numerical results. Fixed1G generation one config/budget; no per-batch reset multiplying cap.",
        },
    )
    save(
        "selected-input-refs.json",
        {
            "excluded_books": [book_ref],
            "locator": locator_before,
            "input_addendum": addendum_before,
            "other_existing_books": "Only the named active unsealed128-family book was established here. Root may append separately named existing eval-book refs before preparation; no sealed-book read or false exhaustive-book claim.",
            "book_payload_unchanged_before_after": True,
        },
    )
    save(
        "source-binding.json",
        {
            "issue": "quoridor-4lc.421.3",
            "scope": "EARLY_GENERATION_AND_INPUT_SLICE",
            "base_git": BASE,
            "subjects": references,
            "forward": ref(PACKET / "forward.patch"),
            "inverse": ref(PACKET / "inverse.patch"),
            "spec_refs": json.loads((OWN / "fixed-spec-refs.json").read_text()),
            "addendum": addendum_before,
            "software": "UNBUILT/UNTYPED/UNRUN",
            "new_science": 0,
            "later_scope": "Arena aggregate1G budget inlet remains separate, not a generation admission dependency.",
        },
    )
    print(
        json.dumps(
            {
                "packet": str(PACKET),
                "subjects": len(references),
                "new_tests": len(tests),
                "forward": ref(PACKET / "forward.patch"),
            }
        )
    )


if __name__ == "__main__":
    main()
