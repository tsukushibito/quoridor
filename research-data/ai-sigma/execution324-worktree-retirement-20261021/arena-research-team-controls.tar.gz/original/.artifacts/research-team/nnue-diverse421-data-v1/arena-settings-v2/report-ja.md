421 arena設定v2は、4対照と元16families/二色を固定した。対照はM/BEST43、C/BEST43、M/D、C/Dの順で各32枠、最大128局/64色pair。各operationは250,000,000 nodesを一度だけ持ち、4枠の合計は1G。pair/gameごとの予算reset、未使用quotaの移譲、refillは行わない。上限でUNKNOWNが残り得るため128完了は保証しない。

| batch | 左  | 右          | 最大局数 | operation node上限 |
| ----- | --- | ----------- | -------: | -----------------: |
| 0     | M   | BEST43      |       32 |          250000000 |
| 1     | C   | BEST43      |       32 |          250000000 |
| 2     | M   | D(0,8,tanh) |       32 |          250000000 |
| 3     | C   | D(0,8,tanh) |       32 |          250000000 |

Mはcanonical no-head identity receipt df73facdのtyped ID 0de86cbd8db0e0c3d326ca1d83bda6522f6497ace1eeeb7ec6d843088e5c8d50、descriptor d1a28eb3、weights6ff74c07。raw fingerprint a65ea9c8をtyped IDとして使わない。Cはsaved-completion cae9293dがbest_step0/BEST43そのものを選んでおり、BEST43と同一descriptor46ec2c47/weights046fe926/typed96a5f41fを実参照でaliasした。C LASTや新しい模型を作っていない。C/BEST43は同一模型の対照である。

imageは424のPASS build e5511672から得た真正f4bbae67/9384592B。作者は模型・image payloadを開かず、保存FileRefと実size/modeだけを照合した。新fit/forward/qualifier/旧成功suiteの実行は0。D4の旧設定UNKNOWNやC元operation FAILEDをこのmetadataで成功へ書き換えない。

固定prefix-book0889cb36の16requestを全部、元のID順で使う。既存arena_plan_checkにはcomplete/families形のbookが必要なため、arena-book.jsonは正本native schedule d8278477のgame/request_id/prefix/root.state_key/root.historyをそのまま対応づけた既存形式のcarrierである。新しいprefix生成・geometry・collision classifier・history再構成は行わない。元input collectionは16accepted/0missingである。per-family seedの記録は無いためoriginal_seed/seedをnullに保ち、実batch seed42120261016を別記した。chronology/合法性の資格はRoot通常native replay/admissionが担う。16系列は4/8/12/16 plyが各4、全4対照で同じ。第一色はfamily順0,1交互、二色を必ず隣接させ、scheduleの128slotはunique、64pairの計画を確認した。

実設定はControl/PVS/TT1048576/LMRON depth_rank、各手100ms authority receipt/5ms return reserve/1M safety、名目depth64/序盤込み200ply。Engineには近似/safe用fieldがないため架空のOFF flagを追加せず、変更のないarena session factoryのOFFを使う。method/namespaceの文字列builderは追加しない。future actual namespaceはnativeが正本である。

既存research-lifecycle.pyのarena_plan_checkを、今回の4config/plan/scheduleに対して静的に実行し全4件PASS。native/source fixtures/model読み込みや実ゲームは伴わない。current caller読取SHA f74e5672/233906は対応確認の参照であり、未来launch時のcaller凍結の代わりではない。Python helper/guardはRuff format/check、reportは既存Prettierで整える。生成JSONは正本helperの出力をそのまま保存し、後からformatterで参照hashを変えない。

Rootが一度実行する新しいarena集約assertionのexact filterは
runtime::research_threefold_runtime_tests::arena421_exhausted_operation_budget_enters_no_worker_and_preserves_unknown_parent
である。元arena-source-v1/verification-plan.jsonをauthor bindingとして保存した。作者はUNRUNであり、旧resources::common_node_budget_tests::parallel_reservations_returned_work_and_opaque_error_cannot_exceed_totalの成功を再演しない。必要なRoot compile/fixture対応はRootの通常software入口で選ぶ。

config/planは用意済み。run-template.jsonとsequence-template.jsonは既存RUN/有限連続sequenceの形式を使う。Rootのenv/current caller_sources/support/numerical qualification/actual runtime/physical quiet/output forecast/whole budgetは未確定nullのまま。futureQ・PID・Experiment・dummy SHAを作らない。Rootが通常prepareで実bindingを埋めてからのみlaunch可能である。4G family/GPU0、AI2/6+main4は候補であり未来のallocationや静穏を証明しない。

各configの64MiB output ceilingは既存arena形の上限であり、4倍をwhole256MiBの追加予約へする意味ではない。Rootは既存normal forecastと421 whole256MiB残量/globaldecimal50GBを実entryで確認する。旧FAILED/partial/returnedNULL-vs-disk masks/費UNKNOWNを保持し、上限・cancel・error・incompleteをdrawや完了へ変換しない。whole timing/selected snapshot/TT gaugeも加算の別物である。

実source候補CPU8/guardian12、child960MiB+controller枠64MiB/family1GiB/G0/hostreserve4GiB、既存CycleResources/execute/no_new_privs/directwaitを使用した。actual topology/readback・exact childID・handle/TMP cleanupは各guard stageと最終STOPに保存する。affinityだけで公平静穏/未来の所有を主張せず、controller全工程のcontinuous family peakとLLM費はUNKNOWN。

最初のauthor-v1では既存guardがstdinをchildへ渡さずpython '-'が空入力で終了した。実write/metadata生成は無く空log/exit0を保持した。author-v2でguarded引数の通常writerへ修正した。新scienceの再演ではない。旧423 packet、421原RAW/fit/input、旧342/323 pauses/defaults/models/sealsは変更0。Root受入れまでissueは元claimant/in_progressを維持する。source clear、数値・速度・棋力資格はこのsettings packetの主張に含まない。
