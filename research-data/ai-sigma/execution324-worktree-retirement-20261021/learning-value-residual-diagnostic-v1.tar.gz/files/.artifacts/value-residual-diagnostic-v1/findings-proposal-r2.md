### BEST51固定距離・残差・tanhの診断340（固定8局面）

Historical RuleA/source ed168d3、trained patience1 BEST51/step209559/PT b16ba38e/params9ca438e4/T-only scale0a322186を保持した8親・28合法子のCPU FP32診断が完了した。新規geometry0（旧1680catalogueをexactfreeze2891で再用）、forward attempted/returned/validated44。observer有無の8親値と36行のFP32 add/tanhはexact一致、距離logit/STM/QF1/尺度/loaded metadata/parameter bindingも対象内で整合した。 固定u=8\*(d_opponent-d_STM)のdはwall-only盤面距離D/80をf32化したSTM-first値で、T標準化前である。残差は別に(d-mu)/sigmaを使用し、uを整数step差の8倍とは解釈しない。普遍的native/model資格やlivefault証明ではない。

残差は8親中6で非ゼロDの符号を変えた。限定38組の候補marginでD→u+rの非ゼロ逆転7（1組はD差5.96e-8）、D exact tieの分離11。R6 main game5/ply57ではu=-0.4、r=5.248730、v=0.999877、局所感度1-v²=0.000245675254828に対し、保存済みcompleted探索値は-2/depth6。R3でも静的v=0.378999と保存探索-2/depth5が共存する。一方、勝利対照C2もr=19.108433/v=1に飽和する。tanhによるsum順位逆転は今回0で、順位変化は残差、最終marginの圧縮は飽和として区別できる。感度は過去gradientや敗因の証拠ではない。

これは固定leafと有限horizon/壁戦術・teacher±1 MSE目的との適合を点検する根拠で、Dの普遍的優越、tanh不具合、対局regret、単一敗因は未確定。静的一手値と保存root minimax値は別scopeで、異なるtrajectory/全手未測定の比較を因果証明にしない。MSEはtanh(u+r)への誤差であり、残差単体や候補rankingの資格ではない。

Job340d500d actualSTART11:10:14.683046Z→controllerSTOP11:10:17.218335Z、whole2.535645142s、directwait/cleanup[]/exactscienceabsent。旧失敗3.337821918s、旧TMP・persistedmaskpending・UNKNOWNを保全し、既知controller全費5.873467060s。samplefamilyRSS800415744B、continuouspeakUNKNOWN。追加科学は起動しない。最小の次案はR3/R6の同局面・同履歴・同depth/候補でD対NNUEを比較してterminal到達とleaf成分を記録するものだが、全探索costは未測定で提案のみ。

証拠：learning-million `.artifacts/value-residual-diagnostic-v1/report.md`、`entry-v3/data/components.json`（SHA6788361a5eab2bddf748c41a273a99256c57108ae45d8bc700a5aa40d04678c4）、`saved-component-analysis.json`、`saved-components.csv`、`caller-v3/recovery-STOP-receipt.json`。数値観測と仮説の採用範囲を区別し、重要な因果結論は必要な限定独立確認と実行324の受入れを経る。
