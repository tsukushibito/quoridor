# quoridor-4lc.340.1 固定caller sourceレビュー

結論：通常修正C1を1件、導入前の未解消事項として返す。`acceptance.json`は作成していない。重要な研究方法・モデル・数学変更は求めない。親340の数値実行／完了を認定しない。

証拠root：`/workspaces/quoridor/.worktree/learning-million/.artifacts/value-residual-diagnostic-v1/review-v1`（review.md / control.json / probe.py / probe-result.json）。

対象：`caller-v1/source-STOP-binding.json` SHA256 `15e9786bf0e9ad6145d97dcf92ccc794ce2ab82b6fcb01a1bd7b994676addb8e`。guardの7対象mapとpacketの18小source/control/evidence refsを前後照合し、一致。7path/SHA、必要なproduction Python/config/scaleの照合結果は同ディレクトリ`control.json`。model/PT/library/weights payloadは読まず、提供された一次source連鎖と過去の限定資格証拠を再利用した。

## C1 [P2・通常修正、導入前に解消必要] 呼出前拒否の計数漏れ

固定`diagnostic.py` SHA `1192d4bcdb0dfcbe0b2ad636f8092608b5ba81cf3aab7fb4e882fd350ba99fee` の `run.invoke` 397–400行で、48回上限判定と`input_tensors`が409行の計数tryより前にある。

実際のnested function ASTを抽出し、入力ポートが`ValueError("owned model input bytes changed")`を返す場合を実行した。期待はattempted/returned/validatedを増やさず`rejected_before_invocation += 1`、実値はすべて0。元の例外objectは伝播した。同様にattempted=48で上限拒否した場合も拒否の増分は0。モデル呼出は0。`probe-result.json`に各counterの期待／実値を保存した。

これはfailed jobをPASSへ変える欠陥ではないが、明示されたinvocation-versus-rejection/failure receiptの意味を満たさない。入口の準備・上限判定も含めてattemptedの差分から拒否を分類し、旧値に由来する`last_call_returned`を残さない範囲へ通常修正する必要がある。提供12NN0は`invoke_model_once`とobserverを確認しており、このouter invokeの準備失敗を検査していない。修正はproducerのみ、同reviewerへ固定rebindで返す。

## 確認できた境界

- full-prefix ctypesのu16/usize/float/u8 ABI、空prefixの非null backing、offsetsと624/2/1出力、同期呼出中の独立所有は読んだRust inletと整合する。戻り値不正／部分出力は資格へ昇格せず、両view/距離はSTM順・side=1。historical RuleAの実履歴再生を現在のthreefoldやsynthetic contextへ読み替えない。
- 入力catalog freezeはモデルimportより前。owned FP32入力のhashとproduction source hash、trained BEST51位置／dataset／T-only尺度／parameter順SHAを実呼出前に要求する。実binaryとABIの一致は提供provenanceの範囲に留まり、こちらではlive検証していない。
- observerはexact `forward.__code__` のreturnだけを捕捉し、callbackでlocal tensor参照を保存する。production forwardの式やmodel stateを編集しない。独立Python object fixtureでdecoy codeを除外し、返り値を含む4参照identityとprofiler復帰を確認。observer差替え＋KeyboardInterruptでも元objectがgroupの先頭に残った。
- 正常呼出のattemptは実`model(*tensors)`直前、returnは直後。captured値のdtype/shape/finite/bit再構成と8 unprofiled親との比較を別途要求する。既知goalはmodel順位と分離、child STMから親への符号変更をreport内で明示。選択部分集合／leaf値／局所感度はroot minimax・歴史的gradient・因果・regretの証明ではない。
- `finish`はreceipt保存を1回試行し、primary＋cleanup＋保存IOのoriginal objectを非再帰groupへ保持することをfake IOで確認。guardianの個別保存category、family限度、null deadline、実child wait/cleanup、出力責任を静的に確認。runtime/resource/failure回復のlive成功は未検証。
- proofのhistorical global manifest SHAを現global manifestとの一致ゲートにしていない。331.2のscope-only追加だけを理由にrefreezeは不要。実entryでは固定source/private/framework/input/proofとfresh quiet／RAM／出力categoryの一致が依然必要で、異なれば停止・再bindする。

## 実行・限界・停止

独立stdlib AST probeは3確認と2 counterexample再現。Torch/ORT/NumPy/model/CDLL/native/forward/job/Cargo/networkは0。実Python fixture whole wall `0.0272800069s`、内部probe `0.0043795600s`、VmHWM `18132KiB`、CPU3、RLIMIT_AS512MiB。プローブはPython AST＋fake portsの証拠であり、Rust/Torch／family peak／実IO故障資格ではない。提供12NN0と費用・以前の失敗は別証拠として保持し、成功suite再実行なし。

初回evidence配置を自分の新規directoryのrenameで正しいphase直下review-v1へ訂正した。旧bytesを保持し、失敗startup分12KiBも保守的に予約、refundなし。RuffがPATHと3つの既知pathに無く、format開始前に拒否。自分のprobeだけstdlib `ast.unparse`で整形しAST同一性を確認、product/source未編集。初期read/controlの一部exact wallは未記録（UNKNOWN）；計測済みBeads/fixture/hash費と行政失敗はcontrolに保存し、総実費0とはしない。

reader/substantial analysis STOP：`2026-10-08T07:30:10.893521+00:00`。全own fixture childは同期directwait、owned jobs0、cleanup remaining `[]`、producer/source/main/Git/index writer0。未解消C1のためnumerical入口は解除しない。report後はこのleafのみclose＋backupし、324へ一度返す。parent340／paused323／sealed inputs／defaultsは変更しない。
