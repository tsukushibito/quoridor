"""Independent stdlib-only probes of the frozen caller's actual AST bodies."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import resource
import sys
import time
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
started = time.monotonic()
source = Path(__file__).parent.parent / 'caller-v1' / 'diagnostic.py'
blob = source.read_bytes()
assert hashlib.sha256(blob).hexdigest() == '1192d4bcdb0dfcbe0b2ad636f8092608b5ba81cf3aab7fb4e882fd350ba99fee'
tree = ast.parse(blob)
functions = {node.name: node for node in tree.body if isinstance(node, ast.FunctionDef)}
run = functions['run']
invoke = next((node for node in run.body if isinstance(node, ast.FunctionDef) and node.name == 'invoke'))
namespace = {'sys': sys, 'json': json}
for node in [functions['error_fact'], functions['finish'], functions['observe_return'], invoke]:
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(source), 'exec'), namespace)
facts = []
references = [object() for _ in range(4)]

def decoy():
    logit, residual, raw_distance = references[:3]
    return references[3]

def forward():
    logit, residual, raw_distance = references[:3]
    decoy()
    return references[3]
returned, captured = namespace['observe_return'](forward, forward)
assert returned is references[3]
assert all((a is b for a, b in zip(captured, references, strict=True)))
assert sys.getprofile() is None
facts.append({'case': 'exact-codeobject excludes decoy; four object identities preserved; profiler restored', 'PASS': True})
primary = KeyboardInterrupt('original object')

def failing_forward():
    logit, residual, raw_distance = references[:3]
    sys.setprofile(None)
    raise primary
try:
    namespace['observe_return'](failing_forward, failing_forward)
except BaseExceptionGroup as caught:
    assert caught.exceptions[0] is primary
    assert len(caught.exceptions) == 2
else:
    raise AssertionError('replacement must refuse')
assert sys.getprofile() is None
facts.append({'case': 'original primary plus observer replacement; restore attempted', 'PASS': True})
io_error = OSError('receipt write refused')
cleanup_error = ValueError('cleanup failed')
save_attempts = []

def fake_save(path, receipt):
    save_attempts.append((path, receipt))
    raise io_error
namespace['save_new'] = fake_save
receipt = {'phase': 'mock-only'}
try:
    namespace['finish'](receipt, None, primary, [('cleanup', cleanup_error)])
except BaseExceptionGroup as caught:
    assert caught.exceptions == (primary, cleanup_error, io_error)
    assert len(save_attempts) == 1
    assert receipt['primary_error']['type'] == 'KeyboardInterrupt'
else:
    raise AssertionError('all original failures must propagate')
facts.append({'case': 'single receipt attempt; primary/cleanup/IO original objects retained', 'PASS': True})
namespace.update(np=None, torch=None, model=None)
input_failure = ValueError('owned model input bytes changed')

def reject_input(*args):
    raise input_failure
namespace['input_tensors'] = reject_input
for label, attempted, expected_error in [('input_tensors refusal', 0, input_failure), ('ceiling refusal', 48, None)]:
    count = {'attempted': attempted, 'returned': 0, 'validated': 0, 'failed_or_partial_UNKNOWN': 0, 'rejected_before_invocation': 0}
    namespace['count'] = count
    try:
        namespace['invoke']({}, True)
    except ValueError as caught:
        if expected_error is not None:
            assert caught is expected_error
        else:
            assert str(caught) == '48 forward ceiling'
    else:
        raise AssertionError('refusal required')
    assert count['attempted'] == attempted
    assert count['rejected_before_invocation'] == 0
    facts.append({'case': label, 'counterexample_reproduced': True, 'expected_rejected_delta': 1, 'actual_rejected_delta': 0, 'counter': count})
result = {'source_SHA256': hashlib.sha256(blob).hexdigest(), 'actual_AST_bodies': ['error_fact', 'finish', 'observe_return', 'run.invoke'], 'facts': facts, 'wall_s': time.monotonic() - started, 'VmHWM_KiB': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss, 'CPU': [3], 'STOP': datetime.now(timezone.utc).isoformat(), 'framework_model_native_imports_calls': 0, 'owned_children': 0, 'limitations': 'Actual Python AST with fake ports and Python object references only; no Torch, ctypes library, numerical ABI or live failure qualification.'}
output = Path(__file__).parent / 'probe-result.json'
with output.open('x') as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write('\n')
print(json.dumps(result, allow_nan=False))
