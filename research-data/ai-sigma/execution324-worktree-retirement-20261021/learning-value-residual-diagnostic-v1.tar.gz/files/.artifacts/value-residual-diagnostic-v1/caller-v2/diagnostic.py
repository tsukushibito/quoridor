"""Temporary, admitted RuleA/BEST51 component caller; never changes model.forward."""

import ctypes
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import sys
import time


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def save_new(path, value, limit=262144):
    blob = json.dumps(value, indent=2, allow_nan=False).encode() + b"\n"
    if len(blob) > limit:
        raise ValueError(f"bounded JSON refused: {path.name}")
    with path.open("xb") as stream:
        stream.write(blob)
    return digest(blob)


def error_fact(error):
    try:
        message = str(error)
    except BaseException:
        message = "<exception stringification failed>"
    return {"type": type(error).__name__, "message": message}


def finish(receipt, path, primary, stages=()):
    """One nonrecursive receipt attempt; preserve every original exception object."""
    errors = list(stages)
    receipt["primary_error"] = error_fact(primary) if primary else None
    receipt["secondary_errors"] = [{"stage": stage, **error_fact(error)} for stage, error in errors]
    if primary or errors:
        receipt.update(status="FAILED", failed_phase=receipt["phase"])
    try:
        save_new(path, receipt)
    except BaseException as error:
        errors.append(("receipt_persist", error))
    if errors:
        facts = [{"stage": stage, **error_fact(error)} for stage, error in errors]
        group = BaseExceptionGroup(
            "component caller primary/finalization failures",
            ([primary] if primary else []) + [error for _, error in errors],
        )
        group.add_note("nonrecursive fallback facts: " + json.dumps(facts, allow_nan=False))
        raise group
    if primary:
        raise primary


def observe_return(forward, invoke):
    """Only keep references from the exact Python forward's return event."""
    previous = sys.getprofile()
    if previous is not None:
        raise RuntimeError("existing profiler refused")
    code = forward.__func__.__code__ if hasattr(forward, "__func__") else forward.__code__
    captured, callback_errors = [], []

    def observer(frame, event, returned):
        if frame.f_code is code and event == "return":
            try:
                local = frame.f_locals
                captured.append(
                    (local["logit"], local["residual"], local["raw_distance"], returned)
                )
            except BaseException as error:
                callback_errors.append(error)

    primary, result, restoration_errors = None, None, []
    try:
        sys.setprofile(observer)
        result = invoke()
    except BaseException as error:
        primary = error
    finally:
        try:
            if sys.getprofile() is not observer:
                restoration_errors.append(RuntimeError("observer replaced during invocation"))
        except BaseException as error:
            restoration_errors.append(error)
        try:
            sys.setprofile(previous)
            if sys.getprofile() is not previous:
                raise RuntimeError("profile restoration mismatch")
        except BaseException as error:
            restoration_errors.append(error)
    errors = callback_errors + restoration_errors
    if errors:
        raise BaseExceptionGroup(
            "forward/capture/restoration failures", ([primary] if primary else []) + errors
        )
    if primary:
        raise primary
    if len(captured) != 1 or captured[0][3] is not result:
        raise ValueError("one exact successful production return required")
    return result, captured[0]


class BulkOracle:
    """One live, independently owned ctypes allocation per full-prefix ABI call."""

    def __init__(self, function, counter):
        if sys.byteorder != "little" or tuple(
            ctypes.sizeof(t)
            for t in (ctypes.c_uint16, ctypes.c_size_t, ctypes.c_float, ctypes.c_int)
        ) != (2, 8, 4, 4):
            raise ValueError("retained Linux64 little-endian ABI widths")
        self.function, self.counter = function, counter

    def call(self, prefix, *, allow_invalid=False):
        if len(prefix) > 200 or any(type(a) is not int or not 0 <= a <= 208 for a in prefix):
            raise ValueError("bounded whole genuine-prefix action input")
        if self.counter["attempted"] >= 1680:
            raise ValueError("1680 geometry attempt ceiling")
        # Empty root still needs a nonnull allocation; actions_len is exactly zero.
        actions = (ctypes.c_uint16 * max(1, len(prefix)))(*prefix)
        offsets = (ctypes.c_size_t * 2)(0, len(prefix))
        features = (ctypes.c_float * 624)(*([float("nan")] * 624))
        distances = (ctypes.c_float * 2)(float("nan"), float("nan"))
        side = (ctypes.c_uint8 * 1)(255)
        self.counter["attempted"] += 1
        code = int(self.function(actions, len(prefix), offsets, 1, features, distances, side))
        self.counter["returned"] += 1
        codes = self.counter["return_codes"]
        codes[str(code)] = codes.get(str(code), 0) + 1
        if code == 3 and allow_invalid:
            self.counter["invalid_replay"] += 1
            return None
        if code != 0:
            raise ValueError(f"full-prefix ABI refused return code {code}")
        x, d, s = list(features), list(distances), int(side[0])
        if (
            s != 1
            or any(value not in (0.0, 1.0) for value in x)
            or any(not math.isfinite(value) or not 0 <= value <= 1 for value in d)
        ):
            raise ValueError("native both-view FP32/STM/distance output")
        ids = []
        for view in (x[:312], x[312:]):
            found = [i for i, value in enumerate(view) if value == 1]
            if len(found) > 24 or any(
                sum(lo <= i < hi for i in found) != 1
                for lo, hi in ((0, 81), (81, 162), (290, 301), (301, 312))
            ):
                raise ValueError("QF1 bounded pawn/stock one-hots")
            ids.append(found)
        blob = struct.pack("<624f2fq", *x, *d, 1)
        self.counter["validated"] += 1
        return {"ids": ids, "distance": d, "torch_side": s, "input_SHA256": digest(blob)}


def choose_ids(qualified, actual):
    if qualified != sorted(set(qualified)) or any(not 0 <= x <= 208 for x in qualified):
        raise ValueError("ordered unique candidate catalogue")
    if actual not in qualified:
        raise ValueError("saved accepted action must qualify under historical RuleA")
    chosen = [actual]
    for lo, hi in ((0, 81), (81, 145), (145, 209)):
        match = next((x for x in qualified if lo <= x < hi and x not in chosen), None)
        if match is not None:
            chosen.append(match)
    return chosen


def known_goal(parent, action):
    # Only a qualified pawn action can reach its mover's fixed goal row.
    return action < 81 and action // 9 == (8 if parent["geometry"]["turn"] == 0 else 0)


def components_finite(u, residual, total, value):
    if any(not math.isfinite(v) for v in (u, residual, total, value)) or not -1 <= value <= 1:
        raise ValueError("finite FP32 logit/residual/sum/bounded value")


def invoke_model_once(model, tensors, counter):
    if counter["attempted"] >= 48:
        raise ValueError("48 invocation ceiling")
    counter["attempted"] += 1
    value = model(*tensors)
    counter["returned"] += 1
    return value


def action_comparisons(results, selected):
    """Compare only selected model-evaluated children, in their parent's perspective."""
    report = []
    for group in selected:
        children = [
            row for row in results if row["root"] == group["root"] and row["action"] is not None
        ]
        margins = []
        for i, left in enumerate(children):
            for right in children[i + 1 :]:
                margins.append(
                    {
                        "actions": [left["action"], right["action"]],
                        "parent_u_margin": right["u"] - left["u"],
                        "parent_residual_margin": right["residual"] - left["residual"],
                        "parent_sum_margin": right["sum_f32"] - left["sum_f32"],
                        "parent_value_margin": right["value_stm"] - left["value_stm"],
                        "parent_D_only_margin": right["D_only_tanh"] - left["D_only_tanh"],
                        "scope": "FP64 differences of saved components; left-minus-right after child-to-parent negation",
                    }
                )
        report.append(
            {
                "root": group["root"],
                "pairwise_margins": margins,
                "parent_static_value_descending_actions": [
                    row["action"]
                    for row in sorted(children, key=lambda row: (row["value_stm"], row["action"]))
                ],
                "known_goal_actions_not_model_ranked": [
                    row["action"] for row in group["picked"] if row["known_goal"]
                ],
                "known_goal_parent_search_terminal_value": 2.0,
                "scope": "partial static ranking; no all-legal/terminal-aware minimax/best-move/regret claim",
            }
        )
    return report


def input_tensors(row, np, torch):
    x = np.zeros((1, 2, 312), dtype="<f4")
    for view, ids in enumerate(row["ids"]):
        x[0, view, ids] = 1
    d = np.array([row["distance"]], dtype="<f4", order="C", copy=True)
    side = np.array([1], dtype="<i8")
    if digest(x.tobytes() + d.tobytes() + side.tobytes()) != row["input_SHA256"]:
        raise ValueError("owned model input bytes changed")
    return tuple(torch.from_numpy(a) for a in (x, d, side))


def run(cfg, receipt, output):
    # Pure binding checks precede both library loading and model imports.
    receipt["phase"] = "immutable_bindings"
    receipt["CPU"] = sorted(os.sched_getaffinity(0))
    if receipt["CPU"] != [2, 3]:
        raise ValueError("actual caller CPU2,3 affinity")
    for path, expected in cfg["expected_files_SHA256"].items():
        if digest(Path(path).read_bytes()) != expected:
            raise ValueError("immutable source/input/model binding: " + path)
    fixed = json.loads(Path(cfg["fixed_set"]).read_text())
    if fixed["rules"] != "Sigma-RuleA-full-history-terminal-ply-v1" or len(fixed["rows"]) != 8:
        raise ValueError("frozen eight historical RuleA roots")
    roots = fixed["rows"]
    if [row["id"] for row in roots] != ["R1", "R2", "R3", "R4", "R5", "R6", "C1", "C2"]:
        raise ValueError("frozen root order")
    for row in roots:
        if digest(canonical(row["prefix_actions"])) != row["prefix_binding_SHA256"]:
            raise ValueError("full historical prefix binding")
    receipt["phase"] = "historical_geometry_loading"
    # CDLL stays local for this finite caller; no native model/evaluator symbol is loaded/called.
    library = ctypes.CDLL(cfg["geometry_library"])
    function = library.quoridor_qf1_bulk
    function.argtypes = [
        ctypes.POINTER(ctypes.c_uint16),
        ctypes.c_size_t,
        ctypes.POINTER(ctypes.c_size_t),
        ctypes.c_size_t,
        ctypes.POINTER(ctypes.c_float),
        ctypes.POINTER(ctypes.c_float),
        ctypes.POINTER(ctypes.c_uint8),
    ]
    function.restype = ctypes.c_int
    oracle = BulkOracle(function, receipt["geometry"])
    receipt["phase"] = "root_geometry"
    started = time.perf_counter()
    parent_inputs = [oracle.call(row["prefix_actions"]) for row in roots]
    receipt["phase"] = "candidate_geometry"
    catalogue, selected, candidates = [], [], []
    for root, parent_input in zip(roots, parent_inputs, strict=True):
        qualified, inputs, codes = [], {}, []
        for action in range(209):
            row = oracle.call(root["prefix_actions"] + [action], allow_invalid=True)
            codes.append(0 if row is not None else 3)
            if row is not None:
                qualified.append(action)
                inputs[action] = row
        picked = choose_ids(qualified, root["saved_accepted_action"])
        catalogue.append({"root": root["id"], "qualified_ids": qualified, "return_codes": codes})
        selected_rows = []
        for action in picked:
            row = inputs[action]
            terminal = known_goal(root, action)
            row.update(
                root=root["id"],
                action=action,
                prefix_actions=root["prefix_actions"] + [action],
                absolute_STM=root["geometry"]["turn"] ^ 1,
                scope="hypothetical legal one-ply continuation, not recorded chronology",
                known_goal=terminal,
                no_move_terminal="UNKNOWN; not exported by ABI; no additional oracle scan",
            )
            selected_rows.append(row)
            if not terminal:
                candidates.append(row)
        parent_input.update(root=root["id"], absolute_STM=root["geometry"]["turn"])
        selected.append({"root": root["id"], "picked": selected_rows})
    receipt["geometry_seconds"] = time.perf_counter() - started
    if receipt["geometry"]["attempted"] != 1680 or receipt["geometry"]["returned"] != 1680:
        raise ValueError("exact finite geometry count")
    receipt["phase"] = "pre_forward_input_freeze"
    frozen_inputs = {
        "rules": fixed["rules"],
        "fixed_set_SHA256": digest(Path(cfg["fixed_set"]).read_bytes()),
        "parents": parent_inputs,
        "catalogue": catalogue,
        "selected": selected,
        "model_forward_expected": 16 + len(candidates),
        "terminal_scope": "known goal skipped; no-move terminal UNKNOWN; no search ranking claim",
    }
    receipt["input_freeze_SHA256"] = save_new(
        output / "inputs" / "input-freeze.json", frozen_inputs
    )
    # The complete result-blind catalogue is durable before any model invocation.
    receipt["phase"] = "Torch_import_and_input_correspondence"
    import numpy as np
    import torch
    from quoridor_training.public_features import GEOMETRY
    from quoridor_training.test_public_features import scalar_reference
    from quoridor_training.residual_model import DistanceResidualModel

    model_source = Path(DistanceResidualModel.forward.__code__.co_filename).resolve()
    if (
        str(model_source) not in cfg["expected_files_SHA256"]
        or digest(model_source.read_bytes()) != cfg["expected_files_SHA256"][str(model_source)]
    ):
        raise ValueError("actual imported production forward source")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    if torch.__version__ != cfg["Torch_version"] or torch.get_num_threads() != 1:
        raise ValueError("qualified Torch backend/version/thread scope")
    receipt["framework"] = {
        "Torch": torch.__version__,
        "NumPy": np.__version__,
        "threads": torch.get_num_threads(),
        "interop_threads": torch.get_num_interop_threads(),
        "dtype": "CPU FP32",
        "actual_model_source": str(model_source),
    }
    for root, row in zip(roots, parent_inputs, strict=True):
        position = np.zeros(1, dtype=GEOMETRY)
        for key in ("pawns", "stocks", "horizontal", "vertical"):
            position[key][0] = root["geometry"][key]
        expected = scalar_reference(position[0])
        if root["geometry"]["turn"] == 1:
            expected = expected[::-1].copy()
        x, _, _ = input_tensors(row, np, torch)
        if not np.array_equal(x.numpy().view(np.uint32)[0], expected.view(np.uint32)):
            raise ValueError("genuine absolute geometry to STM-first QF1 views")
    receipt["phase"] = "trained_BEST51_loading"
    fit = json.loads(Path(cfg["fit_config"]).read_text())
    scale = json.loads(Path(cfg["scale"]).read_text())
    checkpoint = torch.load(cfg["checkpoint"], map_location="cpu", weights_only=True)
    if (
        checkpoint["model_config"] != fit["model"]
        or checkpoint["dataset_sha"] != cfg["cache_manifest_SHA256"]
        or checkpoint["target"] != "z"
        or checkpoint["position"] != cfg["position"]
        or any(checkpoint["scale"][k] != scale[k] for k in ("mu_f32", "sigma_f32"))
        or fit["model"] != cfg["model_config"]
    ):
        raise ValueError("trained BEST51/config/T-only scale/position provenance")
    torch.manual_seed(fit["training"]["seed"])
    model = DistanceResidualModel(fit["model"], scale, a=0.0, b=8.0).eval()
    model.load_state_dict(checkpoint["model"], strict=True)
    parameters = b"".join(
        value.detach().numpy().astype("<f4").tobytes()
        for value in (
            model.ft.weight,
            model.ft.bias,
            model.h.weight,
            model.h.bias,
            model.out.weight,
            model.out.bias,
        )
    )
    if digest(parameters) != cfg["weights_SHA256"]:
        raise ValueError("ordered trained parameter bytes before forward")
    count, results = receipt["model"], []

    def invoke(row, captured):
        count["last_call_returned"] = False
        before = count["attempted"]
        returned = False

        def actual():
            nonlocal returned
            value = invoke_model_once(model, tensors, count)
            returned = True
            count["last_call_returned"] = True
            return value

        try:
            if count["attempted"] >= 48:
                raise ValueError("48 forward ceiling")
            tensors = input_tensors(row, np, torch)
            if captured:
                value, (logit, residual, raw_distance, observed_value) = observe_return(
                    model.forward, actual
                )
            else:
                value = actual()
            if value.dtype != torch.float32 or tuple(value.shape) != (1,):
                raise ValueError("batch1 FP32 model return")
            v = float(value.item())
            if not math.isfinite(v) or not -1 <= v <= 1:
                raise ValueError("finite bounded model return")
            item = {
                "root": row["root"],
                "action": row.get("action"),
                "value_stm": v,
                "value_f32_hex": value.numpy().astype("<f4").tobytes().hex(),
                "input_SHA256": row["input_SHA256"],
                "absolute_STM": row["absolute_STM"],
            }
            if captured:
                if observed_value is not value or any(
                    t.dtype != torch.float32 or tuple(t.shape) != (1,) for t in (logit, residual)
                ):
                    raise ValueError("captured component dtype/shape/identity")
                if not np.array_equal(
                    raw_distance.numpy().view(np.uint32), tensors[1].numpy().view(np.uint32)
                ):
                    raise ValueError("captured raw distance must equal original STM input")
                total = logit + residual
                reconstructed = torch.tanh(total)
                if not np.array_equal(
                    reconstructed.numpy().view(np.uint32), value.numpy().view(np.uint32)
                ):
                    raise ValueError("FP32 captured add+tanh does not match actual production bits")
                u, r, combined = float(logit.item()), float(residual.item()), float(total.item())
                components_finite(u, r, combined, v)
                item.update(
                    u=u,
                    residual=r,
                    sum_f32=combined,
                    D_only_tanh=math.tanh(u),
                    D_only_scope="FP64 report tanh of actual captured FP32 u; not a new model call",
                    sensitivity_1_minus_v_squared=1.0 - v * v,
                    sensitivity_scope="FP64 of saved FP32 v; local output sensitivity, not training gradient",
                    component_f32_hex={
                        k: t.numpy().astype("<f4").tobytes().hex()
                        for k, t in (("u", logit), ("r", residual), ("sum", total))
                    },
                )
                if row.get("action") is not None:
                    item["parent_perspective"] = {
                        "u": -u,
                        "residual": -r,
                        "sum_f32": -combined,
                        "value": -v,
                        "D_only_tanh": -item["D_only_tanh"],
                        "scope": "negation of child STM components; no fabricated opposite-history forward",
                    }
            count["validated"] += 1
            return item
        except BaseException:
            if count["attempted"] > before:
                count["failed_or_partial_UNKNOWN"] += 1
            else:
                count["rejected_before_invocation"] += 1
            count["last_call_returned"] = returned
            raise

    receipt["phase"] = "finite_readonly_forward"
    started = time.perf_counter()
    with torch.inference_mode():
        references = [invoke(row, False) for row in parent_inputs]
        for row, reference in zip(parent_inputs, references, strict=True):
            item = invoke(row, True)
            if item["value_f32_hex"] != reference["value_f32_hex"]:
                raise ValueError("profile observer changed parent output bits")
            item["unprofiled_reference_f32_hex"] = reference["value_f32_hex"]
            results.append(item)
        results.extend(invoke(row, True) for row in candidates)
    receipt["forward_seconds"] = time.perf_counter() - started
    expected_count = 16 + len(candidates)
    if any(count[key] != expected_count for key in ("attempted", "returned", "validated")):
        raise ValueError("exact finite forward accounting")
    if sys.getprofile() is not None:
        raise ValueError("observer retained after model stage")
    receipt["phase"] = "component_persistence"
    receipt["components_SHA256"] = save_new(
        output / "components.json",
        {
            "input_freeze_SHA256": receipt["input_freeze_SHA256"],
            "fixed_set_SHA256": frozen_inputs["fixed_set_SHA256"],
            "rows": results,
            "action_comparisons": action_comparisons(results, selected),
            "weights_SHA256": cfg["weights_SHA256"],
            "static_scope": "actual production leaf components; not saved root minimax",
            "derivative_scope": "local output sensitivity only; no historical gradient observation",
            "ordering": "partial selected legal child comparisons in parent perspective require negation; known goals separate",
        },
    )
    receipt.update(
        status="PASS_COMPONENTS",
        phase="COMPLETED",
        expected_model_calls=expected_count,
        observer_restored=True,
        extra_add_tanh_recomputations=len(results),
    )


def main():
    from quoridor_training.cycle_process import cancellation_signals

    receipt = {
        "status": "STARTED",
        "phase": "configuration",
        "geometry": {
            "attempted": 0,
            "returned": 0,
            "validated": 0,
            "invalid_replay": 0,
            "return_codes": {},
        },
        "model": {
            "attempted": 0,
            "returned": 0,
            "validated": 0,
            "failed_or_partial_UNKNOWN": 0,
            "rejected_before_invocation": 0,
        },
        "native_head_calls": 0,
        "fit_gradient_search_export_ORT_calls": 0,
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
    primary, output = None, None
    started = time.perf_counter()
    try:
        with cancellation_signals():
            cfg = json.loads(Path(sys.argv[1]).read_text())
            candidate = Path(cfg["output"])
            candidate.mkdir(exist_ok=False)
            output = candidate
            (output / "inputs").mkdir()
            run(cfg, receipt, output)
    except BaseException as error:
        primary = error
    finally:
        receipt["geometry"]["failed_or_partial_UNKNOWN"] = (
            receipt["geometry"]["attempted"] - receipt["geometry"]["returned"]
        )
        receipt["geometry"]["returned_unvalidated"] = (
            receipt["geometry"]["returned"]
            - receipt["geometry"]["validated"]
            - receipt["geometry"]["invalid_replay"]
        )
        receipt["whole_worker_seconds"] = time.perf_counter() - started
        receipt["stopped_at"] = datetime.now(timezone.utc).isoformat()
        if output is not None:
            finish(receipt, output / "component-result.json", primary)
        elif primary:
            raise primary
    print(
        json.dumps(
            {
                "status": receipt["status"],
                "model": receipt["model"],
                "geometry": receipt["geometry"],
            }
        )
    )


if __name__ == "__main__":
    main()
