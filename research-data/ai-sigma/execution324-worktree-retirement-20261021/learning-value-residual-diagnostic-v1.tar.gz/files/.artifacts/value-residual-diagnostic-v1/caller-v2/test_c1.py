"""Only C1 outer invoke accounting, using its actual AST and fake ports."""

import ast
import ctypes
import importlib.abc
from pathlib import Path
import sys
import unittest
from unittest import mock


class NoBackends(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {"numpy", "torch", "onnxruntime"}:
            raise AssertionError("backend import refused: " + fullname)
        return None


sys.meta_path.insert(0, NoBackends())
import diagnostic  # noqa: E402

ROOT = Path(__file__).resolve().parent


def invoke_ast(path):
    tree = ast.parse(path.read_text())
    run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run")
    return tree, next(n for n in run.body if isinstance(n, ast.FunctionDef) and n.name == "invoke")


class C1(unittest.TestCase):
    def setUp(self):
        self.no_native = mock.patch.object(
            ctypes, "CDLL", side_effect=AssertionError("native refused")
        )
        self.no_native.start()
        self.addCleanup(self.no_native.stop)

    def tearDown(self):
        self.assertFalse(any(name in sys.modules for name in ("torch", "numpy", "onnxruntime")))
        self.assertIsNone(sys.getprofile())

    def make_invoke(self, count, inputs, model):
        _, node = invoke_ast(ROOT / "diagnostic.py")
        env = {
            "count": count,
            "input_tensors": inputs,
            "model": model,
            "np": object(),
            "torch": object(),
            "invoke_model_once": diagnostic.invoke_model_once,
            "observe_return": mock.Mock(
                side_effect=AssertionError("observer must not run before prep")
            ),
        }
        exec(
            compile(ast.Module(body=[node], type_ignores=[]), str(ROOT / "diagnostic.py"), "exec"),
            env,
        )
        return env["invoke"]

    def counter(self, attempted=7):
        return {
            "attempted": attempted,
            "returned": attempted,
            "validated": attempted,
            "failed_or_partial_UNKNOWN": 0,
            "rejected_before_invocation": 3,
            "last_call_returned": True,
        }

    def test_actual_outer_input_refusal_and_cancel_preserve_primary(self):
        for primary in (
            ValueError("owned model input bytes changed"),
            KeyboardInterrupt("prep cancel"),
        ):
            with self.subTest(type=type(primary).__name__):
                count = self.counter()
                model = mock.Mock(side_effect=AssertionError("model must not be invoked"))
                inputs = mock.Mock(side_effect=primary)
                call = self.make_invoke(count, inputs, model)
                with self.assertRaises(type(primary)) as caught:
                    call({}, True)
                self.assertIs(caught.exception, primary)
                self.assertEqual(
                    count,
                    {
                        "attempted": 7,
                        "returned": 7,
                        "validated": 7,
                        "failed_or_partial_UNKNOWN": 0,
                        "rejected_before_invocation": 4,
                        "last_call_returned": False,
                    },
                )
                inputs.assert_called_once()
                model.assert_not_called()

    def test_actual_outer_cap_refusal_precedes_inputs_and_model(self):
        count, inputs, model = self.counter(48), mock.Mock(), mock.Mock()
        call = self.make_invoke(count, inputs, model)
        with self.assertRaisesRegex(ValueError, "48 forward ceiling"):
            call({}, False)
        self.assertEqual(
            count,
            {
                "attempted": 48,
                "returned": 48,
                "validated": 48,
                "failed_or_partial_UNKNOWN": 0,
                "rejected_before_invocation": 4,
                "last_call_returned": False,
            },
        )
        inputs.assert_not_called()
        model.assert_not_called()

    def test_actual_outer_invocation_failure_is_not_prep_refusal(self):
        primary = OSError("fake model failure")
        count, model = self.counter(), mock.Mock(side_effect=primary)
        call = self.make_invoke(count, mock.Mock(return_value=()), model)
        with self.assertRaises(OSError) as caught:
            call({}, False)
        self.assertIs(caught.exception, primary)
        self.assertEqual(
            count,
            {
                "attempted": 8,
                "returned": 7,
                "validated": 7,
                "failed_or_partial_UNKNOWN": 1,
                "rejected_before_invocation": 3,
                "last_call_returned": False,
            },
        )
        model.assert_called_once_with()

    def test_actual_outer_return_then_validation_failure_records_return(self):
        primary = OSError("fake dtype validation port failure")

        class Returned:
            @property
            def dtype(self):
                raise primary

        count, model = self.counter(), mock.Mock(return_value=Returned())
        call = self.make_invoke(count, mock.Mock(return_value=()), model)
        with self.assertRaises(OSError) as caught:
            call({}, False)
        self.assertIs(caught.exception, primary)
        self.assertEqual(
            count,
            {
                "attempted": 8,
                "returned": 8,
                "validated": 7,
                "failed_or_partial_UNKNOWN": 1,
                "rejected_before_invocation": 3,
                "last_call_returned": True,
            },
        )

    def test_only_outer_invoke_AST_changed_no_math_or_observer_diff(self):
        old, old_invoke = invoke_ast(ROOT.parent / "caller-v1/diagnostic.py")
        new, new_invoke = invoke_ast(ROOT / "diagnostic.py")
        placeholder = ast.parse("def invoke(): pass").body[0]
        for tree, target in ((old, old_invoke), (new, new_invoke)):
            run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run")
            run.body[run.body.index(target)] = placeholder
        self.assertEqual(
            ast.dump(old, include_attributes=False), ast.dump(new, include_attributes=False)
        )
        old_try = next(n for n in old_invoke.body if isinstance(n, ast.Try))
        new_try = next(n for n in new_invoke.body if isinstance(n, ast.Try))
        self.assertEqual(
            ast.dump(ast.Module(body=old_try.body, type_ignores=[])),
            ast.dump(ast.Module(body=new_try.body[2:], type_ignores=[])),
        )
        self.assertEqual(
            ast.dump(ast.Module(body=old_try.handlers, type_ignores=[])),
            ast.dump(ast.Module(body=new_try.handlers, type_ignores=[])),
        )


if __name__ == "__main__":
    unittest.main()
