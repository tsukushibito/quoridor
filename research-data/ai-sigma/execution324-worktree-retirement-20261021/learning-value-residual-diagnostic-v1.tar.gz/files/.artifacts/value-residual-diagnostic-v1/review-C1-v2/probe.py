"""C1-only actual nested AST with stdlib input/output ports; no backend execution."""

import ast
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import resource
import struct
import time
from types import SimpleNamespace

resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
start = time.monotonic()
source = Path(__file__).parent.parent / "caller-v2/diagnostic.py"
raw = source.read_bytes()
assert (
    hashlib.sha256(raw).hexdigest()
    == "2ab298a2abb14d4fb38775476822d53af5ddad2538e6c077f6b9ee7f0aee5d6c"
)
tree = ast.parse(raw)
run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run")
invoke = next(
    n for n in run.body if isinstance(n, ast.FunctionDef) and n.name == "invoke"
)
primitive = next(
    n
    for n in tree.body
    if isinstance(n, ast.FunctionDef) and n.name == "invoke_model_once"
)
float32 = object()
facts = []


class ScalarPort:
    dtype = float32
    shape = (1,)

    def item(self):
        return 0.25

    def numpy(self):
        return self

    def astype(self, dtype):
        assert dtype == "<f4"
        return self

    def tobytes(self):
        return struct.pack("<f", self.item())


post_error = ValueError("returned dtype port refuses validation")


class RefusedOutput:
    @property
    def dtype(self):
        raise post_error


for case in [
    "prep ValueError",
    "prep KeyboardInterrupt",
    "ceiling",
    "invoked failure",
    "returned unvalidated",
    "validated port return",
]:
    cap = case == "ceiling"
    count = {
        "attempted": 48 if cap else 7,
        "returned": 48 if cap else 7,
        "validated": 48 if cap else 7,
        "failed_or_partial_UNKNOWN": 0,
        "rejected_before_invocation": 3,
        "last_call_returned": True,
    }
    before = dict(count)
    events = []
    primary = (
        KeyboardInterrupt("preparation cancelled")
        if case == "prep KeyboardInterrupt"
        else ValueError("input preparation refused")
    )
    model_error = OSError("invoked port failed")

    def inputs(*args):
        events.append("inputs")
        if case.startswith("prep "):
            raise primary
        return ()

    def model(*args):
        events.append("model_port")
        if case == "invoked failure":
            raise model_error
        return RefusedOutput() if case == "returned unvalidated" else ScalarPort()

    def observer(*args):
        raise AssertionError("observer not part of this C1 probe")

    ns = {
        "count": count,
        "input_tensors": inputs,
        "np": None,
        "torch": SimpleNamespace(float32=float32),
        "model": model,
        "observe_return": observer,
        "math": math,
    }
    exec(
        compile(
            ast.Module(body=[primitive, invoke], type_ignores=[]), str(source), "exec"
        ),
        ns,
    )
    caught = None
    try:
        ns["invoke"]({"root": "fake", "input_SHA256": "fake", "absolute_STM": 0}, False)
    except BaseException as error:
        caught = error
    if case.startswith("prep ") or cap:
        assert count["attempted"] == before["attempted"]
        assert count["returned"] == before["returned"]
        assert count["validated"] == before["validated"]
        assert count["rejected_before_invocation"] == 4
        assert count["failed_or_partial_UNKNOWN"] == 0
        assert count["last_call_returned"] is False
        assert "model_port" not in events
        if cap:
            assert str(caught) == "48 forward ceiling" and not events
        else:
            assert caught is primary
    else:
        assert count["attempted"] == 8 and count["rejected_before_invocation"] == 3
        assert events == ["inputs", "model_port"]
        if case == "invoked failure":
            assert caught is model_error
            assert count["returned"] == 7 and count["validated"] == 7
            assert (
                count["failed_or_partial_UNKNOWN"] == 1
                and count["last_call_returned"] is False
            )
        elif case == "returned unvalidated":
            assert caught is post_error
            assert count["returned"] == 8 and count["validated"] == 7
            assert (
                count["failed_or_partial_UNKNOWN"] == 1
                and count["last_call_returned"] is True
            )
        else:
            assert caught is None
            assert count["returned"] == 8 and count["validated"] == 8
            assert (
                count["failed_or_partial_UNKNOWN"] == 0
                and count["last_call_returned"] is True
            )
    facts.append(
        {
            "case": case,
            "PASS": True,
            "counter": count,
            "events": events,
            "original_exception_identity_preserved": True
            if caught is not None and not cap
            else "not applicable",
        }
    )

result = {
    "source_SHA256": hashlib.sha256(raw).hexdigest(),
    "actual_AST_bodies": ["run.invoke", "invoke_model_once"],
    "cases": facts,
    "wall_s": time.monotonic() - start,
    "VmHWM_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    "CPU": [3],
    "STOP": datetime.now(timezone.utc).isoformat(),
    "owned_children": 0,
    "backend_runtime_imports_calls": 0,
    "limits": "Python AST and stdlib ports only; ScalarPort is validation plumbing, not a model or numerical qualification.",
}
with (Path(__file__).parent / "probe-result.json").open("x") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")
print(json.dumps(result))
