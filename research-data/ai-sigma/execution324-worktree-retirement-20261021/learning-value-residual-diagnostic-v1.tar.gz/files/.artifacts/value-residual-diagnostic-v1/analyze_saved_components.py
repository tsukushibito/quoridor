"""Aggregate fixed saved components using stdlib only; never invoke a model."""

import csv
import hashlib
import json
import math
from pathlib import Path
import struct
import time


ROOT = Path(__file__).parent


def f32(value):
    return struct.unpack("<f", struct.pack("<f", value))[0]


def bits(value):
    return struct.pack("<f", value).hex()


def sign(value):
    return (value > 0) - (value < 0)


def main():
    started = time.monotonic()
    paths = [
        ROOT / "entry-v3/data/components.json",
        ROOT / "fixed-set-v1.json",
        ROOT / "entry-v2/data/inputs/input-freeze.json",
    ]
    payloads = [path.read_bytes() for path in paths]
    components, fixed, freeze = [json.loads(data) for data in payloads]
    assert components["weights_SHA256"] == (
        "9ca438e43b0c105ac5f802a302946f2ba71623ea2bc443b9c54cc9a8468b75b0"
    )
    assert components["input_freeze_SHA256"] == hashlib.sha256(payloads[2]).hexdigest()
    assert components["fixed_set_SHA256"] == hashlib.sha256(payloads[1]).hexdigest()
    assert len(components["rows"]) == 36
    assert len(components["action_comparisons"]) == len(fixed["rows"]) == 8
    inputs = {(row["root"], None): row for row in freeze["parents"]}
    for selection in freeze["selected"]:
        for row in selection["picked"]:
            inputs[row["root"], row["action"]] = row
    records = {(row["root"], row["action"]): row for row in components["rows"]}
    assert len(records) == 36
    rows = []
    for key, row in records.items():
        source = inputs[key]
        assert row["input_SHA256"] == source["input_SHA256"]
        assert row["absolute_STM"] == source["absolute_STM"]
        for field in ["u", "residual", "sum_f32", "value_stm"]:
            assert math.isfinite(row[field])
        assert -1 <= row["value_stm"] <= 1
        u = f32(8 * f32(source["distance"][1] - source["distance"][0]))
        assert bits(u) == row["component_f32_hex"]["u"]
        assert bits(row["residual"]) == row["component_f32_hex"]["r"]
        assert bits(f32(row["u"] + row["residual"])) == row["component_f32_hex"]["sum"]
        assert bits(row["value_stm"]) == row["value_f32_hex"]
        assert row["D_only_tanh"] == math.tanh(row["u"])
        assert row["sensitivity_1_minus_v_squared"] == 1 - row["value_stm"] ** 2
        if key[1] is None:
            assert row["unprofiled_reference_f32_hex"] == row["value_f32_hex"]
        rows.append(
            {
                "root": key[0],
                "action": key[1],
                "absolute_STM": row["absolute_STM"],
                "distance_STM": source["distance"][0],
                "distance_opponent": source["distance"][1],
                **{
                    k: row[k]
                    for k in [
                        "u",
                        "residual",
                        "sum_f32",
                        "value_stm",
                        "D_only_tanh",
                        "sensitivity_1_minus_v_squared",
                    ]
                },
                "input_SHA256": row["input_SHA256"],
                "input_scope": source.get("scope", "genuine recorded parent chronology"),
            }
        )
    roots = []
    margin_checks = 0
    for fixed_row, comparison in zip(fixed["rows"], components["action_comparisons"], strict=True):
        root = fixed_row["id"]
        assert root == comparison["root"]
        parent = records[root, None]
        children = [row for key, row in records.items() if key[0] == root and key[1] is not None]
        strict_reversals = []
        d_ties_separated = []
        sum_distinct_value_ties = []
        for margin in comparison["pairwise_margins"]:
            left, right = [records[root, action] for action in margin["actions"]]
            for field, label in [
                ("u", "parent_u_margin"),
                ("residual", "parent_residual_margin"),
                ("sum_f32", "parent_sum_margin"),
                ("value_stm", "parent_value_margin"),
                ("D_only_tanh", "parent_D_only_margin"),
            ]:
                assert margin[label] == right[field] - left[field]
            margin_checks += 1
            d, total, value = [
                margin[k] for k in ["parent_u_margin", "parent_sum_margin", "parent_value_margin"]
            ]
            if sign(d) * sign(total) < 0:
                strict_reversals.append(margin)
            if d == 0 and total != 0:
                d_ties_separated.append(margin)
            if total != 0 and value == 0:
                sum_distinct_value_ties.append(margin)
            assert sign(total) * sign(value) >= 0
        roots.append(
            {
                "root": root,
                "run": fixed_row["run"],
                "game": fixed_row["game"],
                "absolute_ply": fixed_row["absolute_ply"],
                "absolute_STM": parent["absolute_STM"],
                "saved_action": fixed_row["saved_accepted_action"],
                "saved_search_root_STM_value": fixed_row["saved_root_value_stm"],
                "saved_completed_depth": fixed_row["saved_completed_depth"],
                "parent_components": parent,
                "parent_distance": inputs[root, None]["distance"],
                "selected_children": len(children),
                "selected_NN_value_descending_actions": comparison[
                    "parent_static_value_descending_actions"
                ],
                "strict_nonzero_D_vs_sum_reversals": strict_reversals,
                "D_ties_separated": d_ties_separated,
                "sum_distinct_value_ties": sum_distinct_value_ties,
                "partial_child_scope": comparison["scope"],
            }
        )
    fixed_by_id = {row["id"]: row for row in fixed["rows"]}
    genuine_transitions = []
    for before, after in [("R1", "R2"), ("R2", "R3"), ("R4", "R5"), ("R5", "R6")]:
        previous, following = fixed_by_id[before], fixed_by_id[after]
        assert previous["run"] == following["run"] and previous["game"] == following["game"]
        assert (
            previous["prefix_actions"] + [previous["saved_accepted_action"]]
            == following["prefix_actions"]
        )
        child = records[before, previous["saved_accepted_action"]]
        parent = records[after, None]
        for field in ["input_SHA256", "absolute_STM", "component_f32_hex", "value_f32_hex"]:
            assert child[field] == parent[field]
        genuine_transitions.append(
            {
                "from": before,
                "action": previous["saved_accepted_action"],
                "to": after,
                "input_and_component_bits_equal": True,
            }
        )
    report = {
        "issue": "quoridor-4lc.340",
        "source": str(Path(__file__).resolve()),
        "source_SHA256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "saved_refs": {
            str(path.resolve()): {"SHA256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
            for path, data in zip(paths, payloads, strict=True)
        },
        "directed_read_bytes": sum(map(len, payloads)),
        "new_model_native_geometry_calls": 0,
        "roots": roots,
        "genuine_child_to_next_parent_checks": genuine_transitions,
        "counts": {
            "parents": 8,
            "selected_non_goal_children": 28,
            "distinct_components": 36,
            "checked_pairwise_margins": margin_checks,
            "nonzero_D_parent_sign_changed_by_residual": sum(
                sign(row["u"]) * sign(row["sum_f32"]) < 0
                for row in records.values()
                if row["action"] is None
            ),
            "nonzero_D_all_row_sign_changed_by_residual": sum(
                sign(row["u"]) * sign(row["sum_f32"]) < 0 for row in records.values()
            ),
            "absolute_v_ge_0p99": sum(abs(row["value_stm"]) >= 0.99 for row in records.values()),
            "absolute_v_exactly_1": sum(abs(row["value_stm"]) == 1 for row in records.values()),
            "strict_nonzero_D_vs_sum_pair_reversals": sum(
                len(root["strict_nonzero_D_vs_sum_reversals"]) for root in roots
            ),
            "D_ties_separated": sum(len(root["D_ties_separated"]) for root in roots),
            "sum_distinct_value_ties": sum(len(root["sum_distinct_value_ties"]) for root in roots),
        },
        "limits": [
            "Purposive fixed roots, not prevalence sample",
            "Strict FP32 margin signs include one-ULP effects; not a tolerance or decision rule",
            "Partial child static values, not completed minimax or counterfactual regrets",
            "Sensitivity is local output sensitivity, not historical gradients",
            "No teacher labels collected or causal strength conclusion",
        ],
        "whole_aggregation_seconds": time.monotonic() - started,
    }
    (ROOT / "saved-component-analysis.json").write_text(json.dumps(report, indent=2) + "\n")
    with (ROOT / "saved-components.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(
        json.dumps(
            {
                "counts": report["counts"],
                "read_bytes": report["directed_read_bytes"],
                "whole_seconds": report["whole_aggregation_seconds"],
            }
        )
    )


if __name__ == "__main__":
    main()
