"""Temporary340 guardian; reuse maintained exact child ownership, CPU only."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

from quoridor_training import cycle_process as process
from diagnostic import error_fact, finish


def allocated(root, exclude=()):
    """Only declared owned directories; no target/corpus/asset inventory."""
    root = Path(root)
    if not root.exists():
        return 0
    skip = {Path(p).resolve() for p in exclude}
    total, pending = 0, [root]
    while pending:
        path = pending.pop()
        if path.resolve() in skip:
            continue
        info = path.lstat()
        if stat.S_ISLNK(info.st_mode):
            raise ValueError("owned output symlink refused")
        total += info.st_blocks * 512
        if stat.S_ISDIR(info.st_mode):
            with os.scandir(path) as entries:
                pending.extend(Path(entry.path) for entry in entries)
    return total


def science_args(args):
    if not args:
        return False
    name = Path(args[0]).name
    return (
        name
        in {
            "cargo",
            "rustc",
            "clippy-driver",
            "perf",
            "nnue-diagnose",
            "quoridor-research",
            "quoridor-runner",
        }
        or name.startswith(
            ("nnue_search-", "research_baseline-", "feature_delta-", "criterion_bench-")
        )
        or any(
            arg.startswith(
                (
                    "quoridor_training.train",
                    "quoridor_training.qualification",
                    "quoridor_training.sigma_reference",
                    "quoridor_training.epoch_measurement",
                )
            )
            for arg in args
        )
    )


def named_physics():
    ancestors, pid = set(), os.getpid()
    while pid and pid not in ancestors:
        ancestors.add(pid)
        info = process.process_info(pid)
        pid = info["parent"] if info else 0
    found = []
    for path in Path("/proc").iterdir():
        if not path.name.isdigit() or int(path.name) in ancestors:
            continue
        try:
            args = [os.fsdecode(x) for x in (path / "cmdline").read_bytes().split(b"\0") if x]
        except FileNotFoundError:
            continue
        if not args:
            continue
        name = Path(args[0]).name
        if science_args(args):
            info = process.process_info(int(path.name))
            if info and info["state"] != "Z":
                found.append({"identity": process.identity(info), "executable": name})
    return {
        "named_foreign_science": found,
        "available_RAM_B": process.available_memory(),
        "scope": "fresh one-shot names/modules; other workload UNKNOWN; direct peer coordination also required",
    }


class Resources(process.CycleResources):
    def __init__(self, guard):
        super().__init__(guard, guard["phase_root"], None)
        self.guard = guard
        self.observed = {"sampled_family_RSS_with_controller_B": 0, "sampled_owned_allocated_B": {}}

    def check(self, owned=()):
        super().check(owned)
        infos = [
            process.process_info(os.getpid()),
            *(process.process_info(x["pid"]) for x in owned),
        ]
        rss = sum(info["rss"] for info in infos if info) + self.guard["controller_reserve_bytes"]
        self.observed["sampled_family_RSS_with_controller_B"] = max(
            rss, self.observed["sampled_family_RSS_with_controller_B"]
        )
        if rss > self.memory_limit:
            raise process.CycleStopped("CPU family2GiB including controller reserve")
        for category, spec in self.guard["owned_categories"].items():
            amount = spec.get("external_reserved_B", 0) + sum(
                allocated(item["path"], item.get("exclude", [])) for item in spec["roots"]
            )
            previous = self.observed["sampled_owned_allocated_B"].get(category, 0)
            self.observed["sampled_owned_allocated_B"][category] = max(previous, amount)
            if amount > spec["upper_B"]:
                raise process.CycleStopped("owned category capacity: " + category)


def run(guard, result, output):
    if guard["issue"] != "quoridor-4lc.340" or guard["goal_issue"] != "quoridor-4lc":
        raise ValueError("340 issue/goal binding")
    if any(guard[key] is not None for key in ("end_at", "notify_until", "max_runtime_seconds")):
        raise ValueError("scientific horizons must remain null")
    os.sched_setaffinity(0, {2, 3})
    result["CPU"] = sorted(os.sched_getaffinity(0))
    for path, expected in guard["expected_files_SHA256"].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise ValueError("source/private/admission changed: " + path)
    proof = json.loads(Path(guard["proof"]).read_text())
    if (
        proof["whole_B"] != 2097152
        or proof["CPU"] != [2, 3]
        or proof["family_RAM_B"] != 2147483648
        or proof["GPU"] != 0
        or sum(proof["components_B"].values()) != 2097152
        or proof["finite_counts"] != {"geometry_attempts": 1680, "model_forward_max": 48}
    ):
        raise ValueError("exact typed admission")
    if {k: v["upper_B"] for k, v in guard["owned_categories"].items()} != proof["components_B"]:
        raise ValueError("inclusive category forecast/admission")
    result["phase"] = "related_review"
    acceptance = json.loads(Path(guard["related_acceptance"]).read_text())
    if acceptance["blockers"] != 0 or not acceptance["reader_STOP"]:
        raise ValueError("narrow related review/reader STOP unresolved")
    for path, expected in guard["reviewed_files_SHA256"].items():
        if acceptance["reviewed_files_SHA256"].get(path) != expected:
            raise ValueError("related review version mismatch: " + path)
    result["related_review"] = acceptance
    result["phase"] = "fresh_physics"
    result["physics"] = named_physics()
    if result["physics"]["named_foreign_science"]:
        raise process.CycleStopped("actual foreign named science at entry")
    if result["physics"]["available_RAM_B"] < guard["max_memory_bytes"] + guard["host_ram_reserve"]:
        raise process.CycleStopped("family2GiB plus host reserve admission")
    resources = Resources(guard)
    result["observed"] = resources.observed
    resources.check()
    temporary = output / "tmp"
    temporary.mkdir()
    os.environ.update(
        OPENBLAS_NUM_THREADS="1",
        OMP_NUM_THREADS="1",
        MKL_NUM_THREADS="1",
        NUMEXPR_NUM_THREADS="1",
        CUDA_VISIBLE_DEVICES="",
        PYTHONDONTWRITEBYTECODE="1",
        TMPDIR=str(temporary),
        PYTHONPATH=guard["python_source"],
    )
    process.LOG_MAX_BYTES = 16384
    result["phase"] = "component_child"
    record = process.execute(
        [sys.executable, "-B", guard["worker"], guard["config"]],
        output / "component.log",
        None,
        resources=resources,
    )
    result["child_process"] = record
    if (
        not record["cleanup_complete"]
        or not record["direct_child_reaped"]
        or record["remaining"]
        or process.alive(record["child"])
    ):
        raise process.CycleStopped("exact owned child cleanup incomplete")
    result["phase"] = "completion_validation"
    child = json.loads((output / "data" / "component-result.json").read_text())
    g, m = child["geometry"], child["model"]
    if (
        child["status"] != "PASS_COMPONENTS"
        or g["attempted"] != 1680
        or g["returned"] != 1680
        or g["validated"] + g["invalid_replay"] != 1680
        or any(
            m[key] != child["expected_model_calls"]
            for key in ("attempted", "returned", "validated")
        )
        or not 16 <= child["expected_model_calls"] <= 48
        or m["failed_or_partial_UNKNOWN"]
        or m["rejected_before_invocation"]
        or not child["observer_restored"]
        or child["native_head_calls"] != 0
        or child["fit_gradient_search_export_ORT_calls"] != 0
    ):
        raise ValueError("finite completed component receipt refused")
    result["worker_receipt"] = child
    resources.check()
    result.update(status="PASS_GUARD_COMPONENTS", phase="COMPLETED")


def main():
    result = {
        "status": "STARTED",
        "phase": "configuration",
        "child_process": "NOT_STARTED",
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
    output, primary, secondary = None, None, []
    started = time.perf_counter()
    try:
        with process.cancellation_signals():
            guard = json.loads(Path(sys.argv[1]).read_text())
            candidate = Path(guard["entry_output"])
            candidate.mkdir(exist_ok=False)
            output = candidate
            run(guard, result, output)
    except BaseException as error:
        primary = error
    finally:
        if output is not None:
            if result["phase"] == "component_child":
                try:
                    record = output / "component.process.json"
                    result["child_process"] = (
                        json.loads(record.read_text())
                        if record.exists()
                        else "NOT_RECORDED; no cleanup success inferred"
                    )
                except BaseException as error:
                    secondary.append(("child_process_receipt", error))
                    result["child_process_error"] = error_fact(error)
            try:
                temporary = output / "tmp"
                if temporary.exists():
                    # Preserve any nonempty importer output; do not claim or delete unrecorded TMP.
                    if any(temporary.iterdir()):
                        result["TMP_cleanup"] = "retained_nonempty_UNKNOWN"
                        raise process.CycleStopped("temporary import residue retained")
                    temporary.rmdir()
                result["TMP_cleanup"] = "empty_owned_directory_removed_or_not_created"
            except BaseException as error:
                secondary.append(("TMP_cleanup", error))
            result["stopped_at"] = datetime.now(timezone.utc).isoformat()
            result["whole_guard_seconds"] = time.perf_counter() - started
            finish(result, output / "guard-result.json", primary, secondary)
        elif primary:
            raise primary
    print(
        json.dumps(
            {"status": result["status"], "whole_guard_seconds": result["whole_guard_seconds"]}
        )
    )


if __name__ == "__main__":
    main()
