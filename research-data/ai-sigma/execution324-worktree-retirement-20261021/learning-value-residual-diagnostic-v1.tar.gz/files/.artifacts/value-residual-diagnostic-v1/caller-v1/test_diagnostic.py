"""Affected ABI/capture/finalization NN0; refuse all model/native imports/calls."""

import ctypes
import importlib.abc
import math
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock


class NoModels(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {"torch", "numpy", "onnxruntime"}:
            raise AssertionError("model/backend import refused: " + fullname)
        return None


sys.meta_path.insert(0, NoModels())
import diagnostic as caller  # noqa: E402

sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "python"))
import guardian  # noqa: E402


class Boundaries(unittest.TestCase):
    def tearDown(self):
        self.assertIsNone(sys.getprofile())
        self.assertFalse(any(name in sys.modules for name in ("torch", "numpy", "onnxruntime")))

    def counter(self):
        return {
            "attempted": 0,
            "returned": 0,
            "validated": 0,
            "invalid_replay": 0,
            "return_codes": {},
        }

    def fake_abi(self, *, code=0, seen=None):
        def function(actions, length, offsets, rows, x, d, side):
            self.assertEqual(rows, 1)
            self.assertEqual(list(offsets), [0, length])
            self.assertEqual(len(x), 624)
            self.assertEqual(len(d), 2)
            self.assertEqual(len(side), 1)
            self.assertGreaterEqual(len(actions), 1)
            if seen is not None:
                seen.append(
                    (
                        ctypes.addressof(x),
                        ctypes.addressof(d),
                        ctypes.addressof(side),
                        list(actions)[:length],
                    )
                )
            if code:
                return code
            for i in range(624):
                x[i] = 0
            for offset in (0, 312):
                for i in (4, 157, 300, 311):
                    x[offset + i] = 1
            d[0], d[1], side[0] = 0.125, 0.25, 1
            return 0

        return function

    def test_actual_empty_prefix_and_owned_live_abi_buffers(self):
        seen, counter = [], self.counter()
        with mock.patch.object(ctypes, "CDLL", side_effect=AssertionError("native load refused")):
            oracle = caller.BulkOracle(self.fake_abi(seen=seen), counter)
            root = oracle.call([])
            child = oracle.call([13])
        self.assertEqual(seen[0][3], [])
        self.assertEqual(seen[1][3], [13])
        for values in seen:
            self.assertEqual(len(set(values[:3])), 3)
        self.assertEqual(root, child)
        self.assertEqual(counter["attempted"], 2)
        self.assertEqual(counter["validated"], 2)
        self.assertEqual(root["distance"], [0.125, 0.25])
        self.assertEqual(root["ids"], [[4, 157, 300, 311]] * 2)

    def test_invalid_replay_vs_abi_errors_counted_exactly(self):
        for code in (1, 2, 3, 4):
            counter = self.counter()
            oracle = caller.BulkOracle(self.fake_abi(code=code), counter)
            if code == 3:
                self.assertIsNone(oracle.call([13], allow_invalid=True))
                self.assertEqual(counter["invalid_replay"], 1)
            else:
                with self.assertRaisesRegex(ValueError, "return code"):
                    oracle.call([13], allow_invalid=True)
            self.assertEqual(counter["attempted"], 1)
            self.assertEqual(counter["returned"], 1)
            self.assertEqual(counter["validated"], 0)
        counter = self.counter()
        with self.assertRaises(ValueError):
            caller.BulkOracle(self.fake_abi(code=3), counter).call([])

    def test_malformed_inputs_and_ceiling_refuse_before_call(self):
        for prefix in ([209], [-1], [True], [13] * 201):
            counter = self.counter()
            with self.assertRaises(ValueError):
                caller.BulkOracle(mock.Mock(), counter).call(prefix)
            self.assertEqual(counter["attempted"], 0)
        counter = self.counter()
        counter["attempted"] = 1680
        with self.assertRaises(ValueError):
            caller.BulkOracle(mock.Mock(), counter).call([])

    def test_bad_native_values_or_stm_refuse_before_validation(self):
        for name, value in (("feature", math.nan), ("distance", math.inf), ("side", 0)):
            valid = self.fake_abi()

            def fake(*args):
                valid(*args)
                args[{"feature": 4, "distance": 5, "side": 6}[name]][0] = value
                return 0

            counter = self.counter()
            with self.assertRaises(ValueError):
                caller.BulkOracle(fake, counter).call([])
            self.assertEqual(counter["validated"], 0)

    def test_actual_selection_no_fallback_and_goal_scope(self):
        self.assertEqual(caller.choose_ids([13, 22, 90, 170], 22), [22, 13, 90, 170])
        self.assertEqual(caller.choose_ids([13], 13), [13])
        with self.assertRaises(ValueError):
            caller.choose_ids([13], 22)
        for turn, goal in ((0, 72), (1, 0)):
            parent = {"geometry": {"turn": turn}}
            self.assertTrue(caller.known_goal(parent, goal))
            self.assertFalse(caller.known_goal(parent, 90))

    def test_child_to_parent_component_margins_and_terminal_exclusion(self):
        rows = [
            {
                "root": "R1",
                "action": action,
                "u": u,
                "residual": r,
                "sum_f32": u + r,
                "value_stm": value,
                "D_only_tanh": math.tanh(u),
            }
            for action, u, r, value in ((13, 0.2, 0.3, 0.5), (22, 0.1, 0.4, 0.4))
        ]
        selected = [{"root": "R1", "picked": [{"action": 72, "known_goal": True}]}]
        out = caller.action_comparisons(rows, selected)[0]
        self.assertEqual(out["parent_static_value_descending_actions"], [22, 13])
        self.assertEqual(out["known_goal_actions_not_model_ranked"], [72])
        self.assertAlmostEqual(out["pairwise_margins"][0]["parent_value_margin"], -0.1)
        self.assertAlmostEqual(out["pairwise_margins"][0]["parent_u_margin"], -0.1)

    def test_exact_return_refs_noninterference_and_restoration(self):
        calls = []

        def other():
            return 7

        def forward():
            logit, residual, raw_distance = object(), object(), object()
            self.assertEqual(len((logit, residual, raw_distance)), 3)
            calls.append(other())
            return {"same_object": True}

        result, captured = caller.observe_return(forward, forward)
        self.assertIs(captured[3], result)
        self.assertEqual(calls, [7])
        self.assertIsNone(sys.getprofile())
        existing = lambda *args: None
        sys.setprofile(existing)
        try:
            with self.assertRaisesRegex(RuntimeError, "existing profiler"):
                caller.observe_return(forward, forward)
            self.assertIs(sys.getprofile(), existing)
        finally:
            sys.setprofile(None)

    def test_actual_forward_primary_failure_and_profile_restore(self):
        primary = KeyboardInterrupt("owned cancellation")

        def forward():
            logit, residual, raw_distance = 1, 2, 3
            self.assertEqual((logit, residual, raw_distance), (1, 2, 3))
            raise primary

        with self.assertRaises(KeyboardInterrupt) as caught:
            caller.observe_return(forward, forward)
        self.assertIs(caught.exception, primary)
        self.assertIsNone(sys.getprofile())
        real = sys.setprofile
        count = 0

        def failing_restore(profile):
            nonlocal count
            count += 1
            if count == 2:
                raise OSError("restore failed")
            real(profile)

        try:
            with mock.patch.object(sys, "setprofile", failing_restore):
                with self.assertRaises(BaseExceptionGroup) as group:
                    caller.observe_return(forward, forward)
                self.assertIs(group.exception.exceptions[0], primary)
                self.assertIsInstance(group.exception.exceptions[1], OSError)
        finally:
            real(None)

    def test_actual_invocation_counter_never_counts_profiler_refusal(self):
        counter = {"attempted": 0, "returned": 0}

        def forward():
            logit, residual, raw_distance = 1, 2, 3
            return logit + residual + raw_distance

        existing = lambda *args: None
        sys.setprofile(existing)
        try:
            with self.assertRaises(RuntimeError):
                caller.observe_return(
                    forward, lambda: caller.invoke_model_once(forward, (), counter)
                )
        finally:
            sys.setprofile(None)
        self.assertEqual(counter, {"attempted": 0, "returned": 0})
        self.assertEqual(caller.invoke_model_once(forward, (), counter), 6)
        self.assertEqual(counter, {"attempted": 1, "returned": 1})
        primary = OSError("fake model failure")

        def failing():
            raise primary

        with self.assertRaises(OSError) as caught:
            caller.invoke_model_once(failing, (), counter)
        self.assertIs(caught.exception, primary)
        self.assertEqual(counter, {"attempted": 2, "returned": 1})

    def test_missing_or_multiple_forward_capture_refuses(self):
        def missing():
            return 0

        with self.assertRaises(BaseExceptionGroup):
            caller.observe_return(missing, missing)

        def forward(n):
            logit, residual, raw_distance = 1, 2, 3
            self.assertEqual((logit, residual, raw_distance), (1, 2, 3))
            return forward(0) if n else 4

        with self.assertRaisesRegex(ValueError, "one exact"):
            caller.observe_return(forward, lambda: forward(1))

    def test_actual_final_receipt_failure_preserves_primary_and_stage(self):
        primary, secondary = KeyboardInterrupt("cancel"), OSError("disk")
        receipt = {"status": "STARTED", "phase": "finite_readonly_forward"}
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "result.json"
            with mock.patch.object(caller, "save_new", side_effect=secondary):
                with self.assertRaises(BaseExceptionGroup) as caught:
                    caller.finish(receipt, path, primary)
            self.assertIs(caught.exception.exceptions[0], primary)
            self.assertIs(caught.exception.exceptions[1], secondary)
            self.assertEqual(receipt["failed_phase"], "finite_readonly_forward")
            self.assertEqual(receipt["primary_error"]["type"], "KeyboardInterrupt")
        for bad in (math.nan, math.inf, -math.inf):
            with self.assertRaises(ValueError):
                caller.components_finite(0, bad, 0, 0)
        with self.assertRaises(ValueError):
            caller.components_finite(0, 0, 0, 1.01)

    def test_actual_quiet_predicate_and_owned_storage(self):
        for args in (
            ["/private/nnue_search-deadbeef"],
            ["/private/criterion_bench-1"],
            ["perf", "stat"],
            ["cargo"],
            ["python", "-m", "quoridor_training.train"],
        ):
            self.assertTrue(guardian.science_args(args))
        self.assertFalse(guardian.science_args([]))
        self.assertFalse(guardian.science_args(["/usr/bin/python", "small-metadata.py"]))
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "x").write_bytes(b"abc")
            self.assertGreaterEqual(guardian.allocated(root), 4096)
            self.assertEqual(guardian.allocated(root, [root]), 0)
            (root / "alias").symlink_to(root / "x")
            with self.assertRaisesRegex(ValueError, "symlink"):
                guardian.allocated(root)


if __name__ == "__main__":
    unittest.main()
