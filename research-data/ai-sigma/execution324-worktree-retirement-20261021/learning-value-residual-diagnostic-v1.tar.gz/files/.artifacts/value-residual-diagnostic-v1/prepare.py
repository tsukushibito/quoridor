"""Freeze saved RuleA roots without model, library, corpus or evaluator calls."""

import collections
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import time

ROOT = Path(__file__).resolve().parent
ARENA = Path(
    "/workspaces/quoridor/.worktree/arena-evaluation/.artifacts/trained-reference-v1/native-final-v1/distance-final-v1"
)
SELECTION = [
    ("R1", "run-main", 3, 25, "documented positive-to-terminal defeat, before pawn57"),
    ("R2", "run-main", 3, 26, "genuine next-opponent turn after recorded57"),
    ("R3", "run-main", 3, 27, "genuine negative turn before recorded wall151"),
    ("R4", "run-main", 5, 55, "documented saturated positive search value before pawn30"),
    ("R5", "run-main", 5, 56, "genuine next-opponent turn after recorded30"),
    ("R6", "run-main", 5, 57, "genuine negative turn before pawn21"),
    ("C1", "run-initial", 0, 0, "initial-state control using trained BEST51, not INITIAL weights"),
    ("C2", "run-main", 4, 70, "winning pawn-race control, no model-output-based selection"),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def history_key(state):
    def anchors(bits):
        return ";".join(sorted(f"{n % 8},{n // 8}" for n in range(64) if bits & (1 << n)))

    a, b = state["pawns"]
    return f"{a % 9},{a // 9}|{b % 9},{b // 9}|{state['turn']}|{anchors(state['horizontal'])}|{anchors(state['vertical'])}"


def apply_accepted(state, action):
    assert 0 <= action <= 208
    side = state["turn"]
    if action < 81:
        state["pawns"][side] = action
    else:
        name, bit = ("horizontal", action - 81) if action < 145 else ("vertical", action - 145)
        assert not state[name] & (1 << bit)
        state[name] |= 1 << bit
        state["stocks"][side] -= 1
        assert state["stocks"][side] >= 0
    state["turn"] ^= 1


def main():
    start = time.monotonic()
    start_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
    resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
    signal.alarm(120)
    reads = {}
    observations = collections.defaultdict(dict)
    games = {}
    total_read = 0
    total_decoded = 0
    for run in ["run-initial", "run-main"]:
        for name in ["completed.jsonl", "moves.jsonl.gz"]:
            p = ARENA / run / name
            before = p.stat()
            assert before.st_size <= 2097152
            blob = p.read_bytes()
            assert p.stat().st_mtime_ns == before.st_mtime_ns
            total_read += len(blob)
            reads[str(p)] = {"bytes": len(blob), "SHA256": sha(blob)}
            if name == "completed.jsonl":
                for line in blob.splitlines():
                    d = json.loads(line)
                    games[(run, d["game"])] = d
            else:
                text = gzip.decompress(blob)
                total_decoded += len(text)
                assert total_read + total_decoded < 33554432
                for line in text.splitlines():
                    d = json.loads(line)
                    observations[(run, d["game"])][d["observation"]["ply"]] = d["observation"]
    rows = []
    for identity, run, game, ply, rationale in SELECTION:
        completed = games[(run, game)]
        observation = observations[(run, game)][ply]
        assert (
            observation["accepted"]
            and not observation["engine_error"]
            and not observation["failure"]
        )
        prefix = completed["moves"][:ply]
        assert completed["moves"][ply] == observation["action"]
        state = {"pawns": [4, 76], "stocks": [10, 10], "horizontal": 0, "vertical": 0, "turn": 0}
        history = collections.Counter({history_key(state): 1})
        for action in prefix:
            apply_accepted(state, action)
            history[history_key(state)] += 1
        assert state["turn"] == observation["side"]
        root_history = sorted(history.items())
        row = {
            "id": identity,
            "run": run,
            "game": game,
            "absolute_ply": ply,
            "family": completed["family"],
            "candidate_color": completed["candidate_color"],
            "rationale": rationale,
            "position_status": "normal recorded chronology under historical RuleA",
            "prefix_actions": prefix,
            "prefix_binding_SHA256": sha(json.dumps(prefix, separators=(",", ":")).encode()),
            "geometry": state,
            "full_history_encoding": "all genuine chronology in prefix_actions from initial; no synthetic history",
            "history_distinct_states": len(root_history),
            "history_max_prior_count": max(history.values()),
            "history_binding_definition": "sorted Sigma-string/count pairs; own canonical JSON, not substituted for producer serialization SHA",
            "history_binding_SHA256": sha(json.dumps(root_history, separators=(",", ":")).encode()),
            "saved_accepted_action": observation["action"],
            "saved_root_value_stm": observation["value_stm"],
            "saved_completed_depth": observation["completed_depth"],
            "saved_PV": observation["pv"],
            "saved_root_value_scope": "completed alpha-beta root minimax; no fresh static prediction",
            "observation_binding_SHA256": sha(
                json.dumps(observation, sort_keys=True, separators=(",", ":")).encode()
            ),
            "authoritative_move_file": str(ARENA / run / "moves.jsonl.gz"),
            "authoritative_move_file_SHA256": reads[str(ARENA / run / "moves.jsonl.gz")]["SHA256"],
            "legal_candidate_scope": "unexecuted; classify all209 via frozen RuleA bulk ABI, select actual +min legal pawn/H/V excluding prior picks, <=4",
        }
        assert len(prefix) == ply < 200
        rows.append(row)
    assert len(rows) == 8 and sum(row["geometry"]["turn"] == 0 for row in rows) == 4
    output = {
        "issue": "quoridor-4lc.340",
        "rules": "Sigma-RuleA-full-history-terminal-ply-v1",
        "game_source_commit": "ed168d3fb713493c9d8c99cde33fef9da59edebc",
        "selection_frozen_before_component_outputs": True,
        "selection_basis": "documented332 cases plus two controls, purposive not generalization sample",
        "rows": rows,
        "saved_files": reads,
        "model_calls": 0,
        "legal_geometry_library_calls": 0,
    }
    encoded = json.dumps(output, ensure_ascii=False, indent=2) + "\n"
    assert len(encoded.encode()) <= 32768
    (ROOT / "fixed-set-v1.json").write_text(encoded)
    status = {
        k: v.strip()
        for k, v in (
            line.split(":", 1)
            for line in Path("/proc/self/status").read_text().splitlines()
            if ":" in line
        )
        if k in ["VmHWM", "VmRSS", "VmPeak", "VmSize"]
    }
    control = {
        "issue": "quoridor-4lc.340",
        "phase": "source-only fixed-set preparation",
        "START_UTC": start_utc,
        "STOP_UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "wall_s": time.monotonic() - start,
        "rusage_maxrss_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "kernel_memory": status,
        "CPU": sorted(os.sched_getaffinity(0)),
        "pid": os.getpid(),
        "pid_start_ticks": Path("/proc/self/stat").read_text().split(") ", 1)[1].split()[19],
        "directed_source_read_B": total_read,
        "decoded_saved_moves_B": total_decoded,
        "all_directed_read_upper_B": total_read + total_decoded + 2097152,
        "output_bytes": len(encoded.encode()),
        "model_library_corpus_calls": 0,
        "readers_children_remaining": [],
        "new_numeric_reservation": "NONE",
    }
    (ROOT / "control.json").write_text(json.dumps(control, ensure_ascii=False, indent=2) + "\n")
    print(
        json.dumps(
            {
                "fixed_roots": [
                    (r["id"], r["run"], r["game"], r["absolute_ply"], r["geometry"]["turn"])
                    for r in rows
                ],
                "control": control,
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()
