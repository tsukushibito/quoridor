"""Current source AST/fake ports only; no numerical/runtime modules."""

import ast
import copy
import hashlib
import importlib.abc
import json
import math
import resource
import sys
import time
from pathlib import Path
from types import SimpleNamespace


class RefuseRuntime(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {
            "torch",
            "numpy",
            "onnxruntime",
            "ctypes",
            "quoridor_training",
        }:
            raise AssertionError("runtime/model import blocked: " + fullname)
        return None


sys.meta_path.insert(0, RefuseRuntime())
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
start = time.monotonic()
base = Path("/workspaces/quoridor/.worktree/learning-million")
q = base / ".artifacts/value-residual-diagnostic-v1/caller-v3"
diagnostic = ast.parse((q / "diagnostic.py").read_text())
guardian = ast.parse((q / "guardian.py").read_text())
common = ast.parse((base / "python/quoridor_training/common.py").read_text())
results = []


def extract(tree, name):
    return next(
        n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name
    )


class FakePath:
    blobs = {}

    def __init__(self, name):
        self.name = str(name)

    def read_bytes(self):
        return self.blobs[self.name]

    def read_text(self):
        return self.read_bytes().decode()


namespace = {"copy": copy, "json": json, "math": math, "Path": FakePath}
defaults = next(
    n
    for n in common.body
    if isinstance(n, ast.Assign)
    and any(isinstance(t, ast.Name) and t.id == "DEFAULTS" for t in n.targets)
)
exec(
    compile(
        ast.Module(body=[defaults, extract(common, "resolve_config")], type_ignores=[]),
        "<actual-resolver>",
        "exec",
    ),
    namespace,
)
raw_model = {
    "architecture": "distance_residual",
    "transformer_width": 32,
    "hidden_width": 32,
    "dropout": 0,
    "distance_a": 0,
    "distance_b": 8,
}
FakePath.blobs["fit"] = json.dumps({"model": raw_model}).encode()
resolved = namespace["resolve_config"]("fit")
assert resolved["model"] == {**raw_model, "feature_version": "QF1"}
check = next(
    n
    for n in extract(diagnostic, "run").body
    if isinstance(n, ast.If)
    and any(
        isinstance(x, ast.Constant)
        and x.value == "trained BEST51/config/T-only scale/position provenance"
        for x in ast.walk(n)
    )
)
condition = compile(ast.Expression(check.test), "<actual-checkpoint-condition>", "eval")
scale = {"mu_f32": [0, 0], "sigma_f32": [1, 1]}
cfg = {
    "cache_manifest_SHA256": "cache",
    "position": {"step": 1},
    "model_config": resolved["model"],
}
checkpoint = {
    "model_config": resolved["model"],
    "dataset_sha": "cache",
    "target": "z",
    "position": cfg["position"],
    "scale": scale,
}
env = {"checkpoint": checkpoint, "fit": resolved, "cfg": cfg, "scale": scale}
assert eval(condition, env) is False
for key, value in [
    ("model_config", raw_model),
    ("dataset_sha", "other"),
    ("target", "rootmean"),
    ("position", {"step": 2}),
    ("scale", {"mu_f32": [1, 0], "sigma_f32": [1, 1]}),
]:
    assert eval(condition, {**env, "checkpoint": {**checkpoint, key: value}}) is True
results.append(
    {
        "group": "production resolver/provenance",
        "positive": 1,
        "negative": 5,
        "PASS": True,
    }
)

nodes = [
    extract(diagnostic, name)
    for name in ("digest", "choose_ids", "known_goal", "recover_inputs")
]
recover = {"json": json, "hashlib": hashlib, "Path": FakePath}
exec(
    compile(ast.Module(body=nodes, type_ignores=[]), "<actual-recovery>", "exec"),
    recover,
)
fixed = {
    "rules": "toy-only",
    "rows": [
        {
            "id": "R" + str(i),
            "geometry": {"turn": 0},
            "prefix_actions": [],
            "saved_accepted_action": 3,
        }
        for i in range(8)
    ],
}
FakePath.blobs["fixed"] = json.dumps(fixed).encode()
sha = lambda b: hashlib.sha256(b).hexdigest()
frozen = {
    "rules": "toy-only",
    "fixed_set_SHA256": sha(FakePath.blobs["fixed"]),
    "parents": [],
    "selected": [],
    "catalogue": [],
    "model_forward_expected": 24,
}
for r in fixed["rows"]:
    frozen["parents"].append({"root": r["id"], "absolute_STM": 0})
    frozen["selected"].append(
        {
            "root": r["id"],
            "picked": [
                {
                    "root": r["id"],
                    "prefix_actions": [3],
                    "absolute_STM": 1,
                    "action": 3,
                    "known_goal": False,
                }
            ],
        }
    )
    frozen["catalogue"].append({"root": r["id"], "qualified_ids": [3]})
FakePath.blobs["freeze"] = json.dumps(frozen).encode()
prior = {
    "status": "FAILED",
    "failed_phase": "trained_BEST51_loading",
    "model": {
        k: 0
        for k in ("attempted", "returned", "validated", "failed_or_partial_UNKNOWN")
    },
    "geometry": {
        "attempted": 1680,
        "returned": 1680,
        "validated": 500,
        "invalid_replay": 1180,
        "failed_or_partial_UNKNOWN": 0,
    },
    "input_freeze_SHA256": sha(FakePath.blobs["freeze"]),
}
FakePath.blobs["receipt"] = json.dumps(prior).encode()
rcfg = {
    "prior_receipt": "receipt",
    "prior_input_freeze": "freeze",
    "prior_input_freeze_SHA256": prior["input_freeze_SHA256"],
    "fixed_set": "fixed",
    "forward_expected": 24,
}
receipt = {}
_, parents, selected, candidates = recover["recover_inputs"](rcfg, fixed, receipt)
assert (
    len(parents) == 8
    and len(candidates) == 8
    and receipt["reused_geometry"]["not_new_exposure"] is True
)
for altered, expected in [
    (
        dict(rcfg, prior_input_freeze_SHA256="0" * 64),
        "prior input freeze bytes changed",
    ),
    (dict(rcfg, forward_expected=25), "exact pre-forward invocation plan changed"),
]:
    try:
        recover["recover_inputs"](altered, fixed, {})
    except ValueError as e:
        assert str(e) == expected
    else:
        raise AssertionError("bad recovery accepted")
results.append(
    {
        "group": "toy-only actual saved recovery helper",
        "positive": 1,
        "negative": 2,
        "PASS": True,
        "canonical_geometry_claim": False,
    }
)


class Stopped(RuntimeError):
    pass


class EmptyOwned:
    def __init__(self):
        self.removed = False

    def is_symlink(self):
        return False

    def exists(self):
        return True

    def iterdir(self):
        return iter(())

    def rmdir(self):
        self.removed = True

    def __str__(self):
        return "fake-new-owned-empty-tmp"


cleanup_ns = {
    "process": SimpleNamespace(CycleStopped=Stopped, alive=lambda identity: False)
}
exec(
    compile(
        ast.Module(body=[extract(guardian, "remove_empty_owned_tmp")], type_ignores=[]),
        "<actual-TMP-helper>",
        "exec",
    ),
    cleanup_ns,
)
valid = {
    "direct_child_reaped": True,
    "cleanup_complete": True,
    "remaining": [],
    "child": {"pid": 1, "start": "toy", "boot": "toy"},
}
for label, rec in [
    ("valid-empty", valid),
    ("UNKNOWN-None", {**valid, "remaining": None}),
    ("UNKNOWN-missing", {k: v for k, v in valid.items() if k != "remaining"}),
]:
    target = EmptyOwned()
    caught = None
    try:
        cleanup_ns["remove_empty_owned_tmp"](target, rec)
    except BaseException as e:
        caught = repr(e)
    results.append(
        {
            "group": "actual cleanup counterexample",
            "case": label,
            "actual_rmdir_called": target.removed,
            "expected_rmdir_allowed": label == "valid-empty",
            "error": caught,
            "matches_expected": target.removed == (label == "valid-empty"),
        }
    )
assert any(r.get("matches_expected") is False for r in results)
print(
    json.dumps(
        {
            "scope": "source AST/stdlb fake ports; observed unknown-census counterexample, no numerical imports/calls",
            "wall": time.monotonic() - start,
            "VmHWM_KiB": next(
                int(l.split()[1])
                for l in Path("/proc/self/status").read_text().splitlines()
                if l.startswith("VmHWM:")
            ),
            "results": results,
            "blocker_counterexamples": 2,
        },
        indent=2,
    )
)
