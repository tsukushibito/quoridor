"""Temporary, admitted RuleA/BEST51 component caller; never changes model.forward."""

from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def save_new(path, value, limit=262144):
    blob = json.dumps(value, indent=2, allow_nan=False).encode() + b"\n"
    if len(blob) > limit:
        raise ValueError(f"bounded JSON refused: {path.name}")
    with path.open("xb") as stream:
        stream.write(blob)
    return digest(blob)


def error_fact(error):
    try:
        message = str(error)
    except BaseException:
        message = "<exception stringification failed>"
    return {"type": type(error).__name__, "message": message}


def finish(receipt, path, primary, stages=()):
    """One nonrecursive receipt attempt; preserve every original exception object."""
    errors = list(stages)
    receipt["primary_error"] = error_fact(primary) if primary else None
    receipt["secondary_errors"] = [{"stage": stage, **error_fact(error)} for stage, error in errors]
    if primary or errors:
        receipt.update(status="FAILED", failed_phase=receipt["phase"])
    try:
        save_new(path, receipt)
    except BaseException as error:
        errors.append(("receipt_persist", error))
    if errors:
        facts = [{"stage": stage, **error_fact(error)} for stage, error in errors]
        group = BaseExceptionGroup(
            "component caller primary/finalization failures",
            ([primary] if primary else []) + [error for _, error in errors],
        )
        group.add_note("nonrecursive fallback facts: " + json.dumps(facts, allow_nan=False))
        raise group
    if primary:
        raise primary


def observe_return(forward, invoke):
    """Only keep references from the exact Python forward's return event."""
    previous = sys.getprofile()
    if previous is not None:
        raise RuntimeError("existing profiler refused")
    code = forward.__func__.__code__ if hasattr(forward, "__func__") else forward.__code__
    captured, callback_errors = [], []

    def observer(frame, event, returned):
        if frame.f_code is code and event == "return":
            try:
                local = frame.f_locals
                captured.append(
                    (local["logit"], local["residual"], local["raw_distance"], returned)
                )
            except BaseException as error:
                callback_errors.append(error)

    primary, result, restoration_errors = None, None, []
    try:
        sys.setprofile(observer)
        result = invoke()
    except BaseException as error:
        primary = error
    finally:
        try:
            if sys.getprofile() is not observer:
                restoration_errors.append(RuntimeError("observer replaced during invocation"))
        except BaseException as error:
            restoration_errors.append(error)
        try:
            sys.setprofile(previous)
            if sys.getprofile() is not previous:
                raise RuntimeError("profile restoration mismatch")
        except BaseException as error:
            restoration_errors.append(error)
    errors = callback_errors + restoration_errors
    if errors:
        raise BaseExceptionGroup(
            "forward/capture/restoration failures", ([primary] if primary else []) + errors
        )
    if primary:
        raise primary
    if len(captured) != 1 or captured[0][3] is not result:
        raise ValueError("one exact successful production return required")
    return result, captured[0]


def choose_ids(qualified, actual):
    if qualified != sorted(set(qualified)) or any(not 0 <= x <= 208 for x in qualified):
        raise ValueError("ordered unique candidate catalogue")
    if actual not in qualified:
        raise ValueError("saved accepted action must qualify under historical RuleA")
    chosen = [actual]
    for lo, hi in ((0, 81), (81, 145), (145, 209)):
        match = next((x for x in qualified if lo <= x < hi and x not in chosen), None)
        if match is not None:
            chosen.append(match)
    return chosen


def known_goal(parent, action):
    # Only a qualified pawn action can reach its mover's fixed goal row.
    return action < 81 and action // 9 == (8 if parent["geometry"]["turn"] == 0 else 0)


def components_finite(u, residual, total, value):
    if any(not math.isfinite(v) for v in (u, residual, total, value)) or not -1 <= value <= 1:
        raise ValueError("finite FP32 logit/residual/sum/bounded value")


def invoke_model_once(model, tensors, counter):
    if counter["attempted"] >= 48:
        raise ValueError("48 invocation ceiling")
    counter["attempted"] += 1
    value = model(*tensors)
    counter["returned"] += 1
    return value


def action_comparisons(results, selected):
    """Compare only selected model-evaluated children, in their parent's perspective."""
    report = []
    for group in selected:
        children = [
            row for row in results if row["root"] == group["root"] and row["action"] is not None
        ]
        margins = []
        for i, left in enumerate(children):
            for right in children[i + 1 :]:
                margins.append(
                    {
                        "actions": [left["action"], right["action"]],
                        "parent_u_margin": right["u"] - left["u"],
                        "parent_residual_margin": right["residual"] - left["residual"],
                        "parent_sum_margin": right["sum_f32"] - left["sum_f32"],
                        "parent_value_margin": right["value_stm"] - left["value_stm"],
                        "parent_D_only_margin": right["D_only_tanh"] - left["D_only_tanh"],
                        "scope": "FP64 differences of saved components; left-minus-right after child-to-parent negation",
                    }
                )
        report.append(
            {
                "root": group["root"],
                "pairwise_margins": margins,
                "parent_static_value_descending_actions": [
                    row["action"]
                    for row in sorted(children, key=lambda row: (row["value_stm"], row["action"]))
                ],
                "known_goal_actions_not_model_ranked": [
                    row["action"] for row in group["picked"] if row["known_goal"]
                ],
                "known_goal_parent_search_terminal_value": 2.0,
                "scope": "partial static ranking; no all-legal/terminal-aware minimax/best-move/regret claim",
            }
        )
    return report


def input_tensors(row, np, torch):
    x = np.zeros((1, 2, 312), dtype="<f4")
    for view, ids in enumerate(row["ids"]):
        x[0, view, ids] = 1
    d = np.array([row["distance"]], dtype="<f4", order="C", copy=True)
    side = np.array([1], dtype="<i8")
    if digest(x.tobytes() + d.tobytes() + side.tobytes()) != row["input_SHA256"]:
        raise ValueError("owned model input bytes changed")
    return tuple(torch.from_numpy(a) for a in (x, d, side))


def recover_inputs(cfg, fixed, receipt):
    """Reuse only the exact durable, pre-forward inputs from the stopped refusal."""
    prior = json.loads(Path(cfg["prior_receipt"]).read_text())
    frozen_blob = Path(cfg["prior_input_freeze"]).read_bytes()
    if digest(frozen_blob) != cfg["prior_input_freeze_SHA256"]:
        raise ValueError("prior input freeze bytes changed")
    frozen = json.loads(frozen_blob)
    geometry = prior["geometry"]
    if (
        prior["status"] != "FAILED"
        or prior["failed_phase"] != "trained_BEST51_loading"
        or any(
            prior["model"][key]
            for key in ("attempted", "returned", "validated", "failed_or_partial_UNKNOWN")
        )
        or geometry["attempted"] != 1680
        or geometry["returned"] != 1680
        or geometry["validated"] + geometry["invalid_replay"] != 1680
        or geometry["failed_or_partial_UNKNOWN"]
        or prior["input_freeze_SHA256"] != cfg["prior_input_freeze_SHA256"]
        or frozen["fixed_set_SHA256"] != digest(Path(cfg["fixed_set"]).read_bytes())
        or frozen["rules"] != fixed["rules"]
    ):
        raise ValueError("stopped pre-forward input provenance")
    parents, selected = frozen["parents"], frozen["selected"]
    candidates = []
    for root, parent, group, catalog in zip(
        fixed["rows"], parents, selected, frozen["catalogue"], strict=True
    ):
        if any(row["root"] != root["id"] for row in (parent, group, catalog)):
            raise ValueError("saved root order changed")
        if parent["absolute_STM"] != root["geometry"]["turn"]:
            raise ValueError("saved parent STM")
        actions = [row["action"] for row in group["picked"]]
        if actions != choose_ids(catalog["qualified_ids"], root["saved_accepted_action"]):
            raise ValueError("prebound result-blind action selection changed")
        for row in group["picked"]:
            if (
                row["root"] != root["id"]
                or row["prefix_actions"] != root["prefix_actions"] + [row["action"]]
                or row["absolute_STM"] != root["geometry"]["turn"] ^ 1
                or row["known_goal"] != known_goal(root, row["action"])
            ):
                raise ValueError("saved child full-prefix/STM/goal changed")
            if not row["known_goal"]:
                candidates.append(row)
    if (
        frozen["model_forward_expected"] != 16 + len(candidates)
        or frozen["model_forward_expected"] != cfg["forward_expected"]
    ):
        raise ValueError("exact pre-forward invocation plan changed")
    receipt["reused_geometry"] = {
        "counts": geometry,
        "prior_receipt": cfg["prior_receipt"],
        "input_freeze": cfg["prior_input_freeze"],
        "not_new_exposure": True,
    }
    receipt["input_freeze_SHA256"] = cfg["prior_input_freeze_SHA256"]
    return frozen, parents, selected, candidates


def run(cfg, receipt, output):
    # Pure binding checks precede both library loading and model imports.
    receipt["phase"] = "immutable_bindings"
    receipt["CPU"] = sorted(os.sched_getaffinity(0))
    if receipt["CPU"] != [2, 3]:
        raise ValueError("actual caller CPU2,3 affinity")
    for path, expected in cfg["expected_files_SHA256"].items():
        if digest(Path(path).read_bytes()) != expected:
            raise ValueError("immutable source/input/model binding: " + path)
    fixed = json.loads(Path(cfg["fixed_set"]).read_text())
    if fixed["rules"] != "Sigma-RuleA-full-history-terminal-ply-v1" or len(fixed["rows"]) != 8:
        raise ValueError("frozen eight historical RuleA roots")
    roots = fixed["rows"]
    if [row["id"] for row in roots] != ["R1", "R2", "R3", "R4", "R5", "R6", "C1", "C2"]:
        raise ValueError("frozen root order")
    for row in roots:
        if digest(canonical(row["prefix_actions"])) != row["prefix_binding_SHA256"]:
            raise ValueError("full historical prefix binding")
    receipt["phase"] = "saved_input_recovery"
    frozen_inputs, parent_inputs, selected, candidates = recover_inputs(cfg, fixed, receipt)
    # Retained pre-forward freeze is reused by exact SHA; geometry is not replayed.
    receipt["phase"] = "Torch_import_and_input_correspondence"
    import numpy as np
    import torch
    from quoridor_training.common import resolve_config
    from quoridor_training.public_features import GEOMETRY
    from quoridor_training.test_public_features import scalar_reference
    from quoridor_training.residual_model import DistanceResidualModel

    model_source = Path(DistanceResidualModel.forward.__code__.co_filename).resolve()
    if (
        str(model_source) not in cfg["expected_files_SHA256"]
        or digest(model_source.read_bytes()) != cfg["expected_files_SHA256"][str(model_source)]
    ):
        raise ValueError("actual imported production forward source")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    if torch.__version__ != cfg["Torch_version"] or torch.get_num_threads() != 1:
        raise ValueError("qualified Torch backend/version/thread scope")
    receipt["framework"] = {
        "Torch": torch.__version__,
        "NumPy": np.__version__,
        "threads": torch.get_num_threads(),
        "interop_threads": torch.get_num_interop_threads(),
        "dtype": "CPU FP32",
        "actual_model_source": str(model_source),
    }
    for root, row in zip(roots, parent_inputs, strict=True):
        position = np.zeros(1, dtype=GEOMETRY)
        for key in ("pawns", "stocks", "horizontal", "vertical"):
            position[key][0] = root["geometry"][key]
        expected = scalar_reference(position[0])
        if root["geometry"]["turn"] == 1:
            expected = expected[::-1].copy()
        x, _, _ = input_tensors(row, np, torch)
        if not np.array_equal(x.numpy().view(np.uint32)[0], expected.view(np.uint32)):
            raise ValueError("genuine absolute geometry to STM-first QF1 views")
    receipt["phase"] = "trained_BEST51_loading"
    fit = resolve_config(cfg["fit_config"])
    scale = json.loads(Path(cfg["scale"]).read_text())
    checkpoint = torch.load(cfg["checkpoint"], map_location="cpu", weights_only=True)
    receipt["checkpoint_metadata"] = {
        "model_config": checkpoint["model_config"],
        "dataset_sha": checkpoint["dataset_sha"],
        "target": checkpoint["target"],
        "position": checkpoint["position"],
        "scale_mu_f32": checkpoint["scale"]["mu_f32"],
        "scale_sigma_f32": checkpoint["scale"]["sigma_f32"],
        "effective_model": fit["model"],
    }
    if (
        checkpoint["model_config"] != fit["model"]
        or checkpoint["dataset_sha"] != cfg["cache_manifest_SHA256"]
        or checkpoint["target"] != "z"
        or checkpoint["position"] != cfg["position"]
        or any(checkpoint["scale"][k] != scale[k] for k in ("mu_f32", "sigma_f32"))
        or fit["model"] != cfg["model_config"]
    ):
        raise ValueError("trained BEST51/config/T-only scale/position provenance")
    torch.manual_seed(fit["training"]["seed"])
    model = DistanceResidualModel(fit["model"], scale, a=0.0, b=8.0).eval()
    model.load_state_dict(checkpoint["model"], strict=True)
    parameters = b"".join(
        value.detach().numpy().astype("<f4").tobytes()
        for value in (
            model.ft.weight,
            model.ft.bias,
            model.h.weight,
            model.h.bias,
            model.out.weight,
            model.out.bias,
        )
    )
    if digest(parameters) != cfg["weights_SHA256"]:
        raise ValueError("ordered trained parameter bytes before forward")
    count, results = receipt["model"], []

    def invoke(row, captured):
        count["last_call_returned"] = False
        before = count["attempted"]
        returned = False

        def actual():
            nonlocal returned
            value = invoke_model_once(model, tensors, count)
            returned = True
            count["last_call_returned"] = True
            return value

        try:
            if count["attempted"] >= 48:
                raise ValueError("48 forward ceiling")
            tensors = input_tensors(row, np, torch)
            if captured:
                value, (logit, residual, raw_distance, observed_value) = observe_return(
                    model.forward, actual
                )
            else:
                value = actual()
            if value.dtype != torch.float32 or tuple(value.shape) != (1,):
                raise ValueError("batch1 FP32 model return")
            v = float(value.item())
            if not math.isfinite(v) or not -1 <= v <= 1:
                raise ValueError("finite bounded model return")
            item = {
                "root": row["root"],
                "action": row.get("action"),
                "value_stm": v,
                "value_f32_hex": value.numpy().astype("<f4").tobytes().hex(),
                "input_SHA256": row["input_SHA256"],
                "absolute_STM": row["absolute_STM"],
            }
            if captured:
                if observed_value is not value or any(
                    t.dtype != torch.float32 or tuple(t.shape) != (1,) for t in (logit, residual)
                ):
                    raise ValueError("captured component dtype/shape/identity")
                if not np.array_equal(
                    raw_distance.numpy().view(np.uint32), tensors[1].numpy().view(np.uint32)
                ):
                    raise ValueError("captured raw distance must equal original STM input")
                total = logit + residual
                reconstructed = torch.tanh(total)
                if not np.array_equal(
                    reconstructed.numpy().view(np.uint32), value.numpy().view(np.uint32)
                ):
                    raise ValueError("FP32 captured add+tanh does not match actual production bits")
                u, r, combined = float(logit.item()), float(residual.item()), float(total.item())
                components_finite(u, r, combined, v)
                item.update(
                    u=u,
                    residual=r,
                    sum_f32=combined,
                    D_only_tanh=math.tanh(u),
                    D_only_scope="FP64 report tanh of actual captured FP32 u; not a new model call",
                    sensitivity_1_minus_v_squared=1.0 - v * v,
                    sensitivity_scope="FP64 of saved FP32 v; local output sensitivity, not training gradient",
                    component_f32_hex={
                        k: t.numpy().astype("<f4").tobytes().hex()
                        for k, t in (("u", logit), ("r", residual), ("sum", total))
                    },
                )
                if row.get("action") is not None:
                    item["parent_perspective"] = {
                        "u": -u,
                        "residual": -r,
                        "sum_f32": -combined,
                        "value": -v,
                        "D_only_tanh": -item["D_only_tanh"],
                        "scope": "negation of child STM components; no fabricated opposite-history forward",
                    }
            count["validated"] += 1
            return item
        except BaseException:
            if count["attempted"] > before:
                count["failed_or_partial_UNKNOWN"] += 1
            else:
                count["rejected_before_invocation"] += 1
            count["last_call_returned"] = returned
            raise

    receipt["phase"] = "finite_readonly_forward"
    started = time.perf_counter()
    with torch.inference_mode():
        references = [invoke(row, False) for row in parent_inputs]
        for row, reference in zip(parent_inputs, references, strict=True):
            item = invoke(row, True)
            if item["value_f32_hex"] != reference["value_f32_hex"]:
                raise ValueError("profile observer changed parent output bits")
            item["unprofiled_reference_f32_hex"] = reference["value_f32_hex"]
            results.append(item)
        results.extend(invoke(row, True) for row in candidates)
    receipt["forward_seconds"] = time.perf_counter() - started
    expected_count = 16 + len(candidates)
    if any(count[key] != expected_count for key in ("attempted", "returned", "validated")):
        raise ValueError("exact finite forward accounting")
    if sys.getprofile() is not None:
        raise ValueError("observer retained after model stage")
    receipt["phase"] = "component_persistence"
    receipt["components_SHA256"] = save_new(
        output / "components.json",
        {
            "input_freeze_SHA256": receipt["input_freeze_SHA256"],
            "fixed_set_SHA256": frozen_inputs["fixed_set_SHA256"],
            "rows": results,
            "action_comparisons": action_comparisons(results, selected),
            "weights_SHA256": cfg["weights_SHA256"],
            "static_scope": "actual production leaf components; not saved root minimax",
            "derivative_scope": "local output sensitivity only; no historical gradient observation",
            "ordering": "partial selected legal child comparisons in parent perspective require negation; known goals separate",
        },
    )
    receipt.update(
        status="PASS_COMPONENTS",
        phase="COMPLETED",
        expected_model_calls=expected_count,
        observer_restored=True,
        extra_add_tanh_recomputations=len(results),
    )


def main():
    from quoridor_training.cycle_process import cancellation_signals

    receipt = {
        "status": "STARTED",
        "phase": "configuration",
        "geometry": {
            "attempted": 0,
            "returned": 0,
            "validated": 0,
            "invalid_replay": 0,
            "return_codes": {},
        },
        "model": {
            "attempted": 0,
            "returned": 0,
            "validated": 0,
            "failed_or_partial_UNKNOWN": 0,
            "rejected_before_invocation": 0,
        },
        "native_head_calls": 0,
        "fit_gradient_search_export_ORT_calls": 0,
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
    primary, output = None, None
    started = time.perf_counter()
    try:
        with cancellation_signals():
            cfg = json.loads(Path(sys.argv[1]).read_text())
            candidate = Path(cfg["output"])
            candidate.mkdir(exist_ok=False)
            output = candidate
            (output / "inputs").mkdir()
            run(cfg, receipt, output)
    except BaseException as error:
        primary = error
    finally:
        receipt["geometry"]["failed_or_partial_UNKNOWN"] = (
            receipt["geometry"]["attempted"] - receipt["geometry"]["returned"]
        )
        receipt["geometry"]["returned_unvalidated"] = (
            receipt["geometry"]["returned"]
            - receipt["geometry"]["validated"]
            - receipt["geometry"]["invalid_replay"]
        )
        receipt["whole_worker_seconds"] = time.perf_counter() - started
        receipt["stopped_at"] = datetime.now(timezone.utc).isoformat()
        if output is not None:
            finish(receipt, output / "component-result.json", primary)
        elif primary:
            raise primary
    print(
        json.dumps(
            {
                "status": receipt["status"],
                "model": receipt["model"],
                "geometry": receipt["geometry"],
            }
        )
    )


if __name__ == "__main__":
    main()
