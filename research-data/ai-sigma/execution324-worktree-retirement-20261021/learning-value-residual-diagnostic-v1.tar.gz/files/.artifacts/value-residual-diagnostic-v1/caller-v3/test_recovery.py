"""Affected stdlib-only recovery boundaries; no model/library invocation."""

import ast
import importlib.abc
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest


class RefuseModels(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {"torch", "numpy", "onnxruntime", "ctypes"}:
            raise AssertionError("model/library imports refused: " + fullname)
        return None


sys.meta_path.insert(0, RefuseModels())
sys.path.insert(0, str(Path(__file__).resolve().parents[3] / "python"))
import diagnostic
from quoridor_training.common import resolve_config


guardian_tree = ast.parse((Path(__file__).resolve().parent / "guardian.py").read_text())
cleanup_node = next(
    node
    for node in guardian_tree.body
    if isinstance(node, ast.FunctionDef) and node.name == "remove_empty_owned_tmp"
)


class CycleStopped(RuntimeError):
    pass


cleanup_ports = {"process": SimpleNamespace(CycleStopped=CycleStopped, alive=lambda child: False)}
exec(
    compile(
        ast.Module(body=[cleanup_node], type_ignores=[]), "<actual-cleanup-helper-AST>", "exec"
    ),
    cleanup_ports,
)
guardian = SimpleNamespace(
    process=cleanup_ports["process"], remove_empty_owned_tmp=cleanup_ports["remove_empty_owned_tmp"]
)

ROOT = Path(__file__).resolve().parent
CFG = json.loads((ROOT / "config.json").read_text())
FIXED = json.loads(Path(CFG["fixed_set"]).read_text())


class Recovery(unittest.TestCase):
    def test_actual_loading_condition_resolved_config(self):
        tree = ast.parse((ROOT / "diagnostic.py").read_text())
        run = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "run")
        fit_assignment = next(
            n
            for n in run.body
            if isinstance(n, ast.Assign)
            and any(isinstance(t, ast.Name) and t.id == "fit" for t in n.targets)
        )
        self.assertEqual(ast.unparse(fit_assignment.value), "resolve_config(cfg['fit_config'])")
        check = next(
            n
            for n in run.body
            if isinstance(n, ast.If)
            and any(
                isinstance(x, ast.Constant)
                and x.value == "trained BEST51/config/T-only scale/position provenance"
                for x in ast.walk(n)
            )
        )
        condition = compile(
            ast.Expression(check.test), "<actual-production-provenance-condition>", "eval"
        )
        scale = json.loads(Path(CFG["scale"]).read_text())
        resolved = resolve_config(CFG["fit_config"])
        checkpoint = {
            "model_config": resolved["model"],
            "dataset_sha": CFG["cache_manifest_SHA256"],
            "target": "z",
            "position": CFG["position"],
            "scale": scale,
        }
        env = {"checkpoint": checkpoint, "fit": resolved, "cfg": CFG, "scale": scale}
        self.assertFalse(eval(condition, env))
        env["fit"] = json.loads(Path(CFG["fit_config"]).read_text())
        self.assertTrue(eval(condition, env))

    def test_exact_saved_inputs_only_no_geometry(self):
        receipt = {}
        frozen, parents, selected, candidates = diagnostic.recover_inputs(CFG, FIXED, receipt)
        self.assertEqual(
            [r["root"] for r in parents], ["R1", "R2", "R3", "R4", "R5", "R6", "C1", "C2"]
        )
        self.assertEqual(16 + len(candidates), 44)
        self.assertEqual(frozen["selected"], selected)
        self.assertEqual(receipt["reused_geometry"]["counts"]["attempted"], 1680)
        self.assertTrue(receipt["reused_geometry"]["not_new_exposure"])
        self.assertFalse(
            any(
                isinstance(n, ast.Call)
                and isinstance(n.func, ast.Attribute)
                and n.func.attr == "CDLL"
                for n in ast.walk(ast.parse((ROOT / "diagnostic.py").read_text()))
            )
        )

    def test_saved_freeze_hash_refusal(self):
        altered = dict(CFG, prior_input_freeze_SHA256="0" * 64)
        with self.assertRaisesRegex(ValueError, "prior input freeze bytes changed"):
            diagnostic.recover_inputs(altered, FIXED, {})

    def test_empty_importer_dirs_cleanup_and_file_retention(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            parent = Path(directory)
            scratch = parent / "importer"
            (scratch / "torchinductor_vscode" / "empty").mkdir(parents=True)
            record = {
                "direct_child_reaped": True,
                "cleanup_complete": True,
                "remaining": [],
                "child": {"fixture_only": True},
            }
            removed = guardian.remove_empty_owned_tmp(scratch, record)
            self.assertEqual(len(removed), 3)
            self.assertFalse(scratch.exists())
            scratch.mkdir()
            sentinel = scratch / "retained-error.bin"
            sentinel.write_bytes(b"new toy fixture only")
            with self.assertRaisesRegex(guardian.process.CycleStopped, "file/symlink retained"):
                guardian.remove_empty_owned_tmp(scratch, record)
            self.assertEqual(sentinel.read_bytes(), b"new toy fixture only")
            alias = parent / "symlink"
            alias.symlink_to(scratch, target_is_directory=True)
            with self.assertRaisesRegex(guardian.process.CycleStopped, "symlink retained"):
                guardian.remove_empty_owned_tmp(alias, record)
            self.assertTrue(sentinel.exists())
            alias.unlink()

    def test_tmp_retained_if_child_stop_incomplete(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            scratch = Path(directory) / "importer"
            scratch.mkdir()
            with self.assertRaisesRegex(guardian.process.CycleStopped, "exact owned child STOP"):
                guardian.remove_empty_owned_tmp(scratch, {"direct_child_reaped": False})
            self.assertTrue(scratch.exists())

    def test_C1_unknown_missing_malformed_census_refuses(self):
        valid = {
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "child": {
                "pid": 999999999,
                "start_ticks": "1",
                "boot_id": "00000000-0000-0000-0000-000000000000",
            },
        }
        missing = dict(valid)
        del missing["remaining"]
        cases = [missing] + [
            dict(valid, remaining=value)
            for value in (None, False, 0, "", (), {}, [None], [valid["child"]])
        ]
        original = cleanup_ports["process"].alive

        def forbidden_alive(child):
            raise AssertionError("UNKNOWN census must refuse before child port")

        cleanup_ports["process"].alive = forbidden_alive
        try:
            for record in cases:
                with (
                    self.subTest(record=record),
                    tempfile.TemporaryDirectory(dir=ROOT) as directory,
                ):
                    scratch = Path(directory) / "empty-owned-TMP"
                    scratch.mkdir()
                    with self.assertRaisesRegex(
                        guardian.process.CycleStopped, "exact owned child STOP"
                    ):
                        guardian.remove_empty_owned_tmp(scratch, record)
                    self.assertTrue(scratch.is_dir())
        finally:
            cleanup_ports["process"].alive = original

    def test_C1_completion_and_reap_require_exact_true(self):
        valid = {
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "child": {
                "pid": 999999999,
                "start_ticks": "1",
                "boot_id": "00000000-0000-0000-0000-000000000000",
            },
        }
        original = cleanup_ports["process"].alive

        def forbidden_alive(child):
            raise AssertionError("unverified completion/reap must refuse before child port")

        cleanup_ports["process"].alive = forbidden_alive
        try:
            for field in ("direct_child_reaped", "cleanup_complete"):
                missing = dict(valid)
                del missing[field]
                cases = [missing] + [
                    {**valid, field: value} for value in (None, False, 1, "true", [], {})
                ]
                for record in cases:
                    with (
                        self.subTest(field=field, record=record),
                        tempfile.TemporaryDirectory(dir=ROOT) as directory,
                    ):
                        scratch = Path(directory) / "empty-owned-TMP"
                        scratch.mkdir()
                        with self.assertRaisesRegex(
                            guardian.process.CycleStopped, "exact owned child STOP"
                        ):
                            guardian.remove_empty_owned_tmp(scratch, record)
                        self.assertTrue(scratch.is_dir())
        finally:
            cleanup_ports["process"].alive = original

    def test_C1_non_dict_record_refuses(self):
        for record in (None, [], "UNKNOWN", True):
            with self.subTest(record=record), tempfile.TemporaryDirectory(dir=ROOT) as directory:
                scratch = Path(directory) / "empty-owned-TMP"
                scratch.mkdir()
                with self.assertRaisesRegex(
                    guardian.process.CycleStopped, "exact owned child STOP"
                ):
                    guardian.remove_empty_owned_tmp(scratch, record)
                self.assertTrue(scratch.is_dir())

    def test_C1_verified_empty_census_allows_empty_dirs_only(self):
        valid = {
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "child": {
                "pid": 999999999,
                "start_ticks": "1",
                "boot_id": "00000000-0000-0000-0000-000000000000",
            },
        }
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            scratch = Path(directory) / "empty-owned-TMP"
            (scratch / "empty-importer-dir").mkdir(parents=True)
            removed = guardian.remove_empty_owned_tmp(scratch, valid)
            self.assertEqual(len(removed), 2)
            self.assertFalse(scratch.exists())


if __name__ == "__main__":
    unittest.main()
