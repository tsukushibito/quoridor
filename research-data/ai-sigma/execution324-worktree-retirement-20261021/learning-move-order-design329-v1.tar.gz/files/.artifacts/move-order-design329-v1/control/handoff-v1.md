Beads quoridor-4lc.329 / stopped design handoff

328 actual main3664ad6a acceptance/result562a9c05 and14:07:02.634317Z STOP verified; owner closed ONLY328.330 fixed16 fixture already completed/delivered; no replay.

329 source-grounded DESIGN ONLY completed. Bundle root /workspaces/quoridor/.worktree/learning-million/.artifacts/move-order-design329-v1; fixed control/binding-v1.json holds artifactSHA and sourceSTOP. Maintained target docs/design/lightweight-move-ordering-v1.md supplied as design/lightweight-move-ordering-v1.md. Minimal design/research-findings.patch is bound to current findings base/expectedSHA in control/verification-v1.json; no main/Git writer.

FIRST recommendation: currenthistory ties only, one-step bounded continuation history; keep TT/PV/killer/policy/history ordering, alllegal/value/TT/history math, additional NN/teacher/train0. Hypothetical209x209 i16 costs87362B/root init and lookups; benefit/strength UNKNOWN. Compare four alternatives (zero-training/tiny parent+move/frozenFT orderhead/child incremental value), whole costs and falsifiable wholeSearch then same-time-strength plan. Stockfish/YaneuraOu/Lc0/Sigma official pinned sources and AlphaZero primaryv1 links documented. No implementation or experiment adopted.

Four retainedNPZ central directory+NPY headers show float32 policy136 and no raw visits; array payload0, not all43/sourcequality qualification.66B cache has no policy; learned proposals require originalID/action/STM/legalmask/game-lineage and future teacher/storage/math decisions. No sealednewE/oldopened/fullfit/default changes.

All changed handwritten docs/JSON Prettier PASS,8 named main sourceSHA match pinned3664; hypothetical arithmetic checked. Source CPU2/RAM512MiB/GPU0; no sciencejob/build/model/train/benchmark. All own source commands/readers reaped; machine currentquiet is not inferred for others. One short initial formatter command was unpinned administrative work, explicitly recorded; no fairclock proof.

Typed57e7e6d0 unchanged128KiB: actual projected own69632B plus held mainGit16384+rounding16384 =102400B<131072 margin28672. Oldassets/UNKNOWN/fees unchanged, no extra allocation or globalwalk. Complete analysis wall/RSSpeak NOT_RECORDED; primaryAPI/rawread toolwalls retained without scientific speed claim.

Please accept/integrate stopped design doc+minimalfindings at your owned main and relay next human choice (FIRST A implementation vs learnedB/C with whole costs).329 remains in_progress until your design acceptance; no additional experiment will run. Routine324 ONLY.
