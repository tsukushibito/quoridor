"""Once-only affected NN0 entry through existing finite guardian and directwait."""

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

parser = argparse.ArgumentParser()
parser.add_argument("--test", default="test_public_replay.py")
parser.add_argument("--method")
parser.add_argument("--version", default="v1")
args = parser.parse_args()
ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).parent.resolve()
# Use the canonical lock before importing current publisher code.
import fcntl

lockpath = ROOT / ".artifacts/rust-migration/target/arena-software-writer.lock"
facts = {
    "issue": "quoridor-4lc.381.1",
    "scope": "new affected NN0 software only; zero actual model forwards/fit updates",
    "primary": None,
    "secondary": [],
    "owned_readers_children_jobs_TMP_remaining": [],
}
start = time.monotonic()
lock = lockpath.open("a")
refs = []


def ref(p):
    b = p.read_bytes()
    st = p.stat()
    return {
        "path": str(p),
        "sha256": hashlib.sha256(b).hexdigest(),
        "bytes": len(b),
        "mode": f"{st.st_mode & 511:04o}",
    }


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


try:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    facts["canonical_lease_acquired_at"] = stamp()
    source_paths = list((OWN / "source").glob("*.py")) + [
        ROOT / "scripts/dev/research-lifecycle.py",
        ROOT / "scripts/dev/project-env.sh",
        ROOT / "python/quoridor_training/cycle_process.py",
        ROOT / "python/quoridor_training/snapshot.py",
        ROOT / "python/quoridor_training/common.py",
        ROOT / "python/quoridor_training/__init__.py",
    ]
    refs = [ref(p) for p in source_paths]
    spec = importlib.util.spec_from_file_location(
        "current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
    )
    lifecycle = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lifecycle)
    limits = {
        "family_B": 4 * 1024**3,
        "host_reserve_B": 4 * 1024**3,
        "worker_cpu": 2,
        "guardian_cpu": 4,
    }
    lifecycle.physical_and_quiet({"kind": "run", "limits": limits})
    facts["fresh_physical_guard"] = {
        "at": stamp(),
        "limits": limits,
        "RAM_available_B": lifecycle.process.available_memory(),
        "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
    }
    for r in refs:
        lifecycle.read_ref(r, max(r["bytes"], 1024**2))
    facts["source_before"] = refs
    tmp = OWN / "TMP"
    tmp.mkdir(exist_ok=False)
    deadline = time.monotonic() + 300
    resources = lifecycle.process.CycleResources(
        {"max_memory_bytes": 4 * 1024**3 - 64 * 1024**2, "host_ram_reserve": 4 * 1024**3},
        OWN,
        deadline,
    )
    env = dict(os.environ)
    env.update(
        {
            k: "1"
            for k in [
                "OMP_NUM_THREADS",
                "OPENBLAS_NUM_THREADS",
                "MKL_NUM_THREADS",
                "NUMEXPR_NUM_THREADS",
                "PYTHONDONTWRITEBYTECODE",
            ]
        }
    )
    env["CUDA_VISIBLE_DEVICES"] = ""
    command = [
        "/usr/bin/bash",
        str(ROOT / "scripts/dev/project-env.sh"),
        "python",
        "-B",
        str(OWN / "source" / args.test),
        "--source",
        str(OWN / "source"),
        "--TMP",
        str(tmp),
        "--result",
        str(OWN / ("qualification-" + args.version + ".json")),
    ]
    if args.method:
        command.extend(("--method", args.method))
    facts["command"] = command
    capture = lifecycle.Capture(OWN / ("qualification-" + args.version + ".full.log"), 1024**2)
    facts["actual_command_START"] = stamp()
    try:
        facts["guardian_return"] = lifecycle.process.execute(
            command,
            OWN / ("qualification-" + args.version + ".tail.log"),
            deadline,
            cpu_core=2,
            resources=resources,
            cwd="/workspaces/quoridor/.worktree/learning-million",
            env=env,
            output_sink=capture,
        )
    except BaseException as e:
        facts["primary"] = lifecycle.error_fact(e)
    finally:
        try:
            capture.close()
        except BaseException as e:
            facts["secondary"].append(lifecycle.error_fact(e))
    facts["directwait_returned_at"] = stamp()
    facts["TMP_remaining"] = [str(p) for p in tmp.rglob("*")]
    if not facts["TMP_remaining"]:
        tmp.rmdir()
    for r in refs:
        lifecycle.read_ref(r, max(r["bytes"], 1024**2))
    facts["source_reader_STOP"] = stamp()
    facts["source_before_after_MATCH"] = True
    facts["owned_readers_children_jobs_TMP_remaining"] = facts["TMP_remaining"]
except BaseException as error:
    fact = {"type": type(error).__name__, "message": str(error)}
    if facts["primary"] is None:
        facts["primary"] = fact
    else:
        facts["secondary"].append(fact)
finally:
    lock.close()
    facts["canonical_lease_release_at"] = stamp()
facts["controller_wall_seconds"] = time.monotonic() - start
facts["status"] = (
    "PASS" if facts["primary"] is None and not facts["secondary"] else "FAILED_OR_REFUSED"
)
facts["continuous_peak_RSS_B"] = "UNKNOWN"
(OWN / ("qualification-" + args.version + ".STOP.json")).write_text(
    json.dumps(facts, indent=2) + "\n"
)
print(
    json.dumps({k: facts[k] for k in ["status", "primary", "actual_command_START"] if k in facts})
)
raise SystemExit(0 if facts["status"] == "PASS" else 1)
