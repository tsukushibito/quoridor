"""Strict owned-source patch and inverse proof; ephemeral tree is removed."""

import ast
import difflib
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

OWN = Path(__file__).parents[1]
files = [
    "common.py",
    "train.py",
    "sampling.py",
    "public_replay.py",
    "test_public_replay.py",
    "test_mixed_entry.py",
    "test_mixed_lineage.py",
    "test_mixed_reflection.py",
]
proof = {
    "scope": "strict forward/inverse/gzip plus unchanged owning AST; not numerical qualification",
    "files": {},
    "unchanged": {},
    "changed": {},
    "retired": {},
    "new": {},
}
patch = []
for name in files:
    old = OWN / "before" / f"{name}.gz"
    before = gzip.decompress(old.read_bytes()) if old.exists() else b""
    after = (OWN / "source" / name).read_bytes()
    rel = "python/quoridor_training/" + name
    patch.extend(
        difflib.unified_diff(
            before.decode().splitlines(True),
            after.decode().splitlines(True),
            fromfile="a/" + rel if before else "/dev/null",
            tofile="b/" + rel,
        )
    )
    proof["files"][rel] = {
        "before_sha256": hashlib.sha256(before).hexdigest() if before else None,
        "before_bytes": len(before),
        "post_sha256": hashlib.sha256(after).hexdigest(),
        "post_bytes": len(after),
        "mode": "0644",
    }
    bnodes = {
        n.name: ast.dump(n, include_attributes=False)
        for n in ast.parse(before).body
        if isinstance(n, (ast.FunctionDef, ast.ClassDef))
    }
    anodes = {
        n.name: ast.dump(n, include_attributes=False)
        for n in ast.parse(after).body
        if isinstance(n, (ast.FunctionDef, ast.ClassDef))
    }
    proof["unchanged"][name] = sorted(
        k for k in bnodes.keys() & anodes.keys() if bnodes[k] == anodes[k]
    )
    proof["changed"][name] = sorted(
        k for k in bnodes.keys() & anodes.keys() if bnodes[k] != anodes[k]
    )
    proof["retired"][name] = sorted(bnodes.keys() - anodes.keys())
    proof["new"][name] = sorted(anodes.keys() - bnodes.keys())
for key in ["warmstart_model_inputs", "ordered_parameter_values", "bound_file_bytes"]:
    assert key in proof["unchanged"]["common.py"]
for key in [
    "build_model",
    "export",
    "restore_warmstart_parameters",
    "verify_native_parameters",
    "_finalize_training",
    "append_curve_record",
]:
    assert key in proof["unchanged"]["train.py"]
for key in ["EpochSampler", "FullBatchSampler", "EarlyStopping", "ReflectionBatches"]:
    assert key in proof["unchanged"]["sampling.py"]
(OWN / "learner.patch").write_text("".join(patch))
tmp = OWN / "proof/reconstruct"
tmp.mkdir(exist_ok=False)
for rel, refs in proof["files"].items():
    if refs["before_bytes"]:
        p = tmp / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(gzip.decompress((OWN / "before" / f"{p.name}.gz").read_bytes()))
capture = []
try:
    for reverse in (False, True):
        command = [
            "patch",
            "--batch",
            "--fuzz=0",
            "-p1",
            str("--reverse") if reverse else "--forward",
        ]
        result = subprocess.run(
            command,
            input=(OWN / "learner.patch").read_bytes(),
            cwd=tmp,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            check=True,
        )
        capture.append(result.stdout.decode())
        for rel, refs in proof["files"].items():
            p = tmp / rel
            if reverse and not refs["before_bytes"]:
                assert not p.exists()
            else:
                assert (
                    hashlib.sha256(p.read_bytes()).hexdigest()
                    == refs["before_sha256" if reverse else "post_sha256"]
                )
    proof["strict_forward"] = proof["strict_inverse"] = proof["gzip_before_reconstruct"] = "PASS"
finally:
    shutil.rmtree(tmp)
(OWN / "proof/reconstruction.log").write_text("".join(capture))
(OWN / "proof/unchanged-ast.json").write_text(json.dumps(proof, indent=2) + "\n")
print("STRICT_FORWARD_INVERSE_GZIP_AST_PASS; temporary reconstruct tree removed")
