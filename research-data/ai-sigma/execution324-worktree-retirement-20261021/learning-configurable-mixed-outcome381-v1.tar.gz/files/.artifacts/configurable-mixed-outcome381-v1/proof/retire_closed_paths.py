"""Apply the retired paired-warmstart branch deletion to OWN derivative only."""

import ast
from pathlib import Path

p = Path(__file__).parents[1] / "source/train.py"
s = p.read_text()


def offsets(text):
    result = [0]
    for line in text.splitlines(True):
        result.append(result[-1] + len(line))
    return result


class Constants(ast.NodeTransformer):
    def visit_Compare(self, n):
        if (
            isinstance(n.left, ast.Name)
            and n.left.id == "warm_admission"
            and len(n.ops) == 1
            and isinstance(n.comparators[0], ast.Constant)
            and n.comparators[0].value is None
        ):
            return ast.Constant(isinstance(n.ops[0], ast.Is))
        return self.generic_visit(n)

    def visit_BoolOp(self, n):
        n = self.generic_visit(n)
        values = []
        for v in n.values:
            if isinstance(v, ast.Constant) and type(v.value) is bool:
                if isinstance(n.op, ast.And) and not v.value:
                    return ast.Constant(False)
                if isinstance(n.op, ast.Or) and v.value:
                    return ast.Constant(True)
                continue
            values.append(v)
        return (
            values[0]
            if len(values) == 1
            else (
                ast.Constant(isinstance(n.op, ast.And))
                if not values
                else ast.BoolOp(op=n.op, values=values)
            )
        )


while True:
    tree = ast.parse(s)
    candidates = []
    for n in ast.walk(tree):
        if isinstance(n, (ast.If, ast.IfExp)) and any(
            isinstance(x, ast.Name) and x.id == "warm_admission" for x in ast.walk(n.test)
        ):
            candidates.append(n)
    if not candidates:
        break
    n = max(candidates, key=lambda v: (v.lineno, v.col_offset))
    table = offsets(s)

    def span(n):
        return table[n.lineno - 1] + n.col_offset, table[n.end_lineno - 1] + n.end_col_offset

    t = Constants().visit(n.test)
    if isinstance(t, ast.Constant) and type(t.value) is bool:
        if isinstance(n, ast.IfExp):
            keep = n.body if t.value else n.orelse
            lo, hi = span(keep)
            replacement = s[lo:hi]
        else:
            keep = n.body if t.value else n.orelse
            if keep:
                start = table[keep[0].lineno - 1]
                end = table[keep[-1].end_lineno]
                chunk = s[start:end]
                remove = keep[0].col_offset - n.col_offset
                replacement = "".join(
                    line[remove:] if line.strip() else line for line in chunk.splitlines(True)
                ).rstrip("\n")
                lo, hi = span(n)
                replacement = replacement[n.col_offset :]
            else:
                replacement = ""
        lo, hi = span(n)
        s = s[:lo] + replacement + s[hi:]
    else:
        lo, hi = span(n.test)
        s = s[:lo] + ast.unparse(t) + s[hi:]
# Remove the obsolete input authority call, not its unrelated normal input guard.
tree = ast.parse(s)
table = offsets(s)
for n in ast.walk(tree):
    if isinstance(n, ast.Assign) and any(
        isinstance(t, ast.Name) and t.id == "warm_admission" for t in n.targets
    ):
        lo = table[n.lineno - 1]
        hi = table[n.end_lineno]
        s = s[:lo] + s[hi:]
        break
s = s.replace("    warmstart_inputs,\n", "")
# Guard calls current input admission only for current mixture mode; no old paired fallback.
a = s.index("    else:\n        warmstart_inputs(", s.index("def guarded_train"))
b = s.index("    from .cycle_process", a)
s = s[:a] + s[b:]
# Frozen old-teacher artifacts are now historical evidence, not a current route.
a = s.index("WARMSTART_ARTIFACTS =")
b = s.index("def verify_freeze", a)
s = s[:a] + s[b:]
a = s.index("    required = FROZEN_ARTIFACTS + (", s.index("def verify_freeze"))
b = s.index("    if not isinstance(digests", a)
s = s[:a] + "    required = FROZEN_ARTIFACTS\n" + s[b:]
# Only still-used current model freeze inputs are parsed here.
s = s.replace('    config = json.loads((training / "config.json").read_text())\n', "")
s = s.replace("warm_admission is not None", "False").replace("warm_admission is None", "True")
assert "warm_admission" not in s and "warmstart_inputs" not in s and "WARMSTART_ARTIFACTS" not in s
ast.parse(s)
p.write_text(s)
p = Path(__file__).parents[1] / "source/common.py"
s = p.read_text()
s = s.replace('WARMSTART_STUDY = "common-corpus-warmstart-v1"\n', "")
s = s.replace(
    "validate_warmstart_config(result, incoming, overrides)",
    "validate_mixed_config(result, incoming, overrides)",
).replace("def validate_warmstart_config(", "def validate_mixed_config(")
s = s.replace(
    'config["experiment"]["study"] not in (WARMSTART_STUDY, "mixed-outcome")',
    'config["experiment"]["study"] != "mixed-outcome"',
)
a = s.index('    if e["study"] == "mixed-outcome":')
b = s.index('    m = config["model"]', a)
s = s[:a] + "    validate_mixture_config(config, incoming)\n" + s[b:]
a = s.index("def warmstart_inputs(")
b = s.index("def warmstart_model_inputs(", a)
s = s[:a] + s[b:]
s = s.replace(
    '    e = config["experiment"]\n    validate_mixture_config',
    '    e = config["experiment"]\n    validate_mixture_config',
)
# e is needed below for warm-start descriptor.
ast.parse(s)
p.write_text(s)
