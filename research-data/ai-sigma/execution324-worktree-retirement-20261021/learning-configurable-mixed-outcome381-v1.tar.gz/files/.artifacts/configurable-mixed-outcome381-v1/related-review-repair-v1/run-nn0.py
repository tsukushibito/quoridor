"""Finite related NN0 entry. Execute only after supplied actual diagnostic STOP."""

import importlib.util
import json
import os
from pathlib import Path
import time

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).parent.resolve()
spec = importlib.util.spec_from_file_location(
    "current_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
lifecycle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(lifecycle)
facts = {
    "issue": "quoridor-4lc.381.1",
    "scope": "R1/R2 new NN0 only; no real model/fit",
    "primary": None,
    "secondary": [],
}
started = time.monotonic()
binding = json.loads((OWN / "source-STOP-binding.json").read_bytes())
refs = [binding["changed_source"], binding["new_test"]]
for name in ("common.py", "train.py", "sampling.py", "test_public_replay.py"):
    path = OWN.parent / "source" / name
    data = path.read_bytes()
    refs.append(
        {
            "path": str(path),
            "sha256": lifecycle.sha(data),
            "bytes": len(data),
            "mode": f"{path.stat().st_mode & 511:04o}",
        }
    )
try:
    with lifecycle.lease():
        limits = {
            "family_B": 4 * 1024**3,
            "host_reserve_B": 4 * 1024**3,
            "worker_cpu": 2,
            "guardian_cpu": 4,
        }
        lifecycle.physical_and_quiet({"kind": "run", "limits": limits})
        facts["fresh_physical_guard"] = {
            "at": lifecycle.stamp(),
            "limits": limits,
            "RAM_available_B": lifecycle.process.available_memory(),
            "boot_id": Path("/proc/sys/kernel/random/boot_id").read_text().strip(),
        }
        for ref in refs:
            lifecycle.read_ref(ref, max(ref["bytes"], 1024**2))
        facts["source_before"] = refs
        tmp = OWN / "TMP"
        tmp.mkdir(exist_ok=False)
        deadline = time.monotonic() + 300
        resources = lifecycle.process.CycleResources(
            {"max_memory_bytes": 4 * 1024**3 - 64 * 1024**2, "host_ram_reserve": 4 * 1024**3},
            OWN,
            deadline,
        )
        command = [
            "/usr/bin/bash",
            str(ROOT / "scripts/dev/project-env.sh"),
            "python",
            "-B",
            str(OWN / "source/test_mixed_update_observations.py"),
            "--source",
            str(OWN / "source"),
            "--TMP",
            str(tmp),
            "--result",
            str(OWN / "qualification.json"),
        ]
        env = dict(os.environ)
        env.update(
            {
                key: "1"
                for key in (
                    "OMP_NUM_THREADS",
                    "OPENBLAS_NUM_THREADS",
                    "MKL_NUM_THREADS",
                    "NUMEXPR_NUM_THREADS",
                    "PYTHONDONTWRITEBYTECODE",
                )
            }
        )
        env["CUDA_VISIBLE_DEVICES"] = ""
        capture = lifecycle.Capture(OWN / "qualification.full.log", 1024**2)
        facts["actual_command_START"] = lifecycle.stamp()
        try:
            facts["guardian_return"] = lifecycle.process.execute(
                command,
                OWN / "qualification.tail.log",
                deadline,
                cpu_core=2,
                resources=resources,
                cwd="/workspaces/quoridor/.worktree/learning-million",
                env=env,
                output_sink=capture,
            )
        except BaseException as error:
            facts["primary"] = lifecycle.error_fact(error)
        finally:
            try:
                capture.close()
            except BaseException as error:
                facts["secondary"].append(lifecycle.error_fact(error))
        facts["directwait_returned_at"] = lifecycle.stamp()
        facts["TMP_remaining"] = [str(path) for path in tmp.rglob("*")]
        if not facts["TMP_remaining"]:
            tmp.rmdir()
        for ref in refs:
            lifecycle.read_ref(ref, max(ref["bytes"], 1024**2))
        facts["source_reader_STOP"] = lifecycle.stamp()
        facts["source_before_after_MATCH"] = True
        facts["owned_readers_children_jobs_TMP_remaining"] = facts["TMP_remaining"]
except BaseException as error:
    if facts["primary"] is None:
        facts["primary"] = lifecycle.error_fact(error)
    else:
        facts["secondary"].append(lifecycle.error_fact(error))
facts["canonical_release_at"] = lifecycle.stamp()
facts["controller_wall_seconds"] = time.monotonic() - started
facts["status"] = (
    "PASS" if facts["primary"] is None and not facts["secondary"] else "FAILED_OR_REFUSED"
)
facts["continuous_peak_RSS_B"] = "UNKNOWN"
(OWN / "NN0-STOP.json").write_text(json.dumps(facts, indent=2) + "\n")
print(json.dumps({key: facts[key] for key in ("status", "primary")}))
raise SystemExit(0 if facts["status"] == "PASS" else 1)
