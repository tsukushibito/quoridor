"""Select only the unfinished R1 definition; no module-wide suite."""

import argparse
import importlib.util
import json
from pathlib import Path
import sys
import unittest

parser = argparse.ArgumentParser()
parser.add_argument("--source", type=Path, required=True)
parser.add_argument("--TMP", type=Path, required=True)
parser.add_argument("--result", type=Path, required=True)
args = parser.parse_args()
import quoridor_training

original = args.source.parents[2] / "source"
quoridor_training.__path__.insert(0, str(args.source))
quoridor_training.__path__.insert(1, str(original))
for name in ("public_replay", "train", "sampling", "common"):
    sys.modules.pop("quoridor_training." + name, None)
spec = importlib.util.spec_from_file_location(
    "affected_R1_only", args.source / "test_mixed_update_observations.py"
)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.TMP = args.TMP
definition = "test_R1_mutated_throw_and_nonfinite_current_state_unknown_nn0"
suite = unittest.TestSuite([module.RelatedBoundaries(definition)])
result = unittest.TextTestRunner(verbosity=2).run(suite)
args.result.write_text(
    json.dumps(
        {
            "status": "PASS" if result.wasSuccessful() else "FAILED",
            "definition": definition,
            "tests_run": result.testsRun,
            "actual_model_forwards": 0,
            "actual_fit_updates": 0,
            "fake_framework_model_and_cache": True,
            "R2_and_original_11_executed": False,
            "failures": [v for _, v in result.failures],
            "errors": [v for _, v in result.errors],
        },
        indent=2,
    )
    + "\n"
)
raise SystemExit(0 if result.wasSuccessful() else 1)
