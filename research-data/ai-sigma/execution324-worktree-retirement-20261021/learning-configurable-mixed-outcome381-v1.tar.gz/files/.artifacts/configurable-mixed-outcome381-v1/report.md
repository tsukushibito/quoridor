# Configurable mixed-outcome learner: stopped source/software handoff

Issue quoridor-4lc.381.1. Source and NN0 software only; no new generation, model forward, fit or science. Main/Git/index/Cargo remain Root324.

Normal trainer dispatch selects functional experiment.study=mixed-outcome with ordinary train --cache PATH --output PATH --config CONFIG. Optional input binding contains distinct lineage refs only. Closed371 literal two-arm/batch64/200-update/CPU/prior-result gates and retired362 paired-teacher plan route are removed. Existing model/head, restore, frozen incumbent statistics and export/finalizer primitives remain AST exact. The existing FP32 deterministic CPU/CUDA setup is shared, including TF32-off/device reserve. No evaluator/environment/public-corpus copy exists.

All mixture fields in interface-draft.json are explicit. Source counts sum to full batch; added>0/public>=0. Horizon=min(max updates,ceil(added exposures × actual T-view rows / added rows)); tails continue the same shuffled stream. Family cap null means all rows; positive cap selects chronological floor(j\*(L-1)/(m-1)), preserving endpoints. V is uncapped and family leakage refuses. Uniform replacement trains on public T only. Separate source reflection probabilities/seeds use default_rng and public PCG64 jump domains; public consumption does not advance added.

Producer contract: outcome_only, v3 physical seven files, same sampling API. Raw ±2/signedzero never masks admitted z; UNKNOWN is mask0/NaN z. Always-array ordered Content/bindings and consecutive actual batch union join schedule/partition. Consumer never reads Game/history/gzip. Public indexed accepted custody opens only T/opened V, never sealedE or a whole public hash/global groups.

INITIAL is immutable BEST43 reference. BEST strictly improves new V with optional explicit public-V nonregression; otherwise INITIAL. Configured significant new-V patience uses full observation points. LAST persists actual final update when possible. Separate added/public T diagnostics and full V curves include family views and frozen T-only constant/analytic-D guides. Config/scale, curves/CSV, exposures, LR and result are durable. All attempted rows are charged before placement/forward; returned finite rows separately expose partial failures. Output/time/forward caps and cancellation retain partials/marker/errors; existing all-actions finalizer preserves primary/secondary/cleanup facts.

Verification: eleven genuinely new NN0 definitions passed once in five finite directwait commands. Actual model forwards=0; actual scientific fit updates=0. Real NumPy batch/sampler arithmetic and labelled fake framework/GPU/tensor/model/export ports; no Torch, weights, checkpoint or actual corpus payload loaded. Configured-loop fixture simulates two updates solely for wiring/checkpoint/counter/cleanup proof, not a real fit. Real GPU kernels, produced-cache integration and native publication are UNRUN. Old successful framework/head/model/native suites were not replayed.

- Seven settings/sampler/loss/T-V/source-reflection/fake-device/selector/cancel-partial definitions.
- One configured loop/checkpoint/counter/finalizer fake fixture.
- One ordered aggregate lineage/interval/manifest definition.
- One independent reflection jump/prefix definition.
- One attempted-versus-returned finite-forward/refusal definition.

Original command walls once: 0.7026728330019978, 0.5010412890042062, 0.1692964280009619, 0.31734520299505675, 0.2295326280000154 seconds; sum 1.919888381002238 seconds. Controller/admin scopes separate; continuous peaks/whole LLM costs UNKNOWN. Each returned direct reap, cleanup true/remaining[], source-after MATCH and lease release. Latest reader STOP 2026-10-13T16:55:01.514707+00:00; release 2026-10-13T16:55:01.515271+00:00. All owned readers/children/jobs/TMP/leases remaining[].

Strict zero-fuzz forward/inverse matches all eight postimages/gzip beforeimages; current Main before refs match and new test paths are absent. Project Ruff no-cache and scoped Prettier verified. Initial unused-fixture-import lint refusal, retirement-proof assertion refusal, pre-tool orchestration syntax refusals and Docker Errno5/project/session/formatter refusals remain history; none entered science or was retargeted.

Example envelope is PROPOSED/UNSELECTED and deliberately not runnable config/Experiment. No new cache/candidate refs fabricated. Root presents unresolved important choices once: cap64 versus allrows, public-V nonregression versus new-V-only, bulk whole capacity/partial-stop/missing-family policy. 380 quantities/exposure/LR/node limits remain proposed, never chosen by source readiness. No323/default/seal/fullN/fits96 changes.

If Root needs one changed-boundary review: do configured source shares, chronological view, T-only split/reflection/FP32 loss and explicit selector/output/error handling retain cache/initializer/scale trust? No author reviewer dispatch/per-run certificate. Root joins381.2 and current normal caller; parent/scientific entry remains Root-owned.
