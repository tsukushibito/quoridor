# Two current loaded NNUE identities

Both approved models were observed once through the unchanged qualified quoridor-runner-v3 model-check command. Format was residual; exact 32 integer bytes were validated and normalized in two explicitly different domains.

| Model  | Native raw32 fingerprint (hex)                                   | Typed evaluator content SHA256                                   |
| ------ | ---------------------------------------------------------------- | ---------------------------------------------------------------- |
| BEST51 | 34c332141c7c76938c5ac9f5c64dfd3b21698457ffa8352a3a1839e05594e632 | 519410ed5eb0b340d1d25df8626d67f508bee7706cbd4ba8a7175bf4e613e645 |
| BEST43 | b3ada29c2922f5b19b701451479e832a60db64ab21e53655a63d33a5b962cdef | 96a5f41f875022d1752b9c999595ad58bfb2d42687a8f06de08d42b1c4215875 |

The typed content is SHA256 of the 32 binary fingerprint bytes, matching maintained runtime::typed_identity for nnue-residual-f32. It is neither the raw32 hex nor SHA256 of the hex text. Both typed identities match the supplied approved IDs. The isolated actual normalizer passed saved-raw/typed/hex-text discriminator checks and refused 11 malformed cases, including Boolean, float, string, out-of-range bytes and wrong format/shape. No target helper/model function was executed by these checks.

BEST51 reuses its exactly-one successful native load from b289ebdc-a14c-4f87-89c5-a9c61632f33b. That whole job remains FAILED, 3.8542422800092027 seconds; its incorrect historical evaluator_SHA256 label and guard comparison remain unchanged. The 9d9b34e8 pre-model operational failure remains FAILED, 3.941186376963742 seconds. No BEST51 reload occurred.

Only still-unentered BEST43 was run in new job 87d06f99-f699-49cf-b648-fa981fa644c6: START 2026-10-10T10:54:20.312330+00:00, STOP 2026-10-10T10:54:24.229857+00:00, authoritative whole controller 3.917932740994729 seconds, succeeded/exit0. Its native command returned exit0, directwait/reap and process/selector/pipe/pidfd/log cleanup complete, signal mask restored and final process receipt persisted. Native command 0.007978259003721178 seconds is nested and is not added to whole costs. All individual original outcomes and fees are separate.

Actual BuildManifest714314, private9c376, compiled35 plus critical Cargo manifest/lock/toolchain/config/dependencies, current bound control helpers, actual five libraries, both raw descriptors and full weights matched before/after. Saved BEST51 inputs/native/software/library correspondences were checked without model replay. Historical unrelated Python/docs65 bytes were not required as current loaded-binary equality. BEST51 retains a0/b8 and BEST43 a0/b0, original descriptor/weight modes and scales. No source/model/private copies or changes were made.

Canonical nonblocking lease covered model readers, native directwait, all before/after checks and cleanup/STOP; terminal receipt confirms release. Asset/source/library readerSTOP 2026-10-10T10:54:20.813872+00:00; final saved collection readerSTOP 2026-10-10T10:56:02.470095+00:00. Owned model readers/native children/guardian work/TMP remaining are empty. Final metadata-notifier identity facts follow administrative closure.

Sampled controller peak 191578112 bytes and guardian-plus-children peak 37883904 bytes are sampled maxima; continuous family peak remains UNKNOWN. Corrected whole family ceiling was 512 MiB, native-plus-guardian448 MiB, CPU2/4 distinct, GPU0, operational120 seconds, fullstdout8 KiB per command; no extra administrative-descendant64 MiB ceiling was imposed. Inclusive own evidence remains within1 MiB with all prior failures held.

This accepts only descriptor/weights/current-image loaded identities. No forward, Search, game, geometry, model/PT import, library probe, numerical reference, current input/history/rules/clock or phase PASS was performed or granted. Only leaf355.11 can close; parent355 remains conditional.
