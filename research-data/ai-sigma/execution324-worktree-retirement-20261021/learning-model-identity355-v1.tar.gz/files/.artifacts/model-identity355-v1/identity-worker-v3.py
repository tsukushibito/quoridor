"""Finite model-check glue; maintained lifecycle capture and cycle_process own children."""

import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import sys
import time

ROOT = Path("/workspaces/quoridor")
OWN = Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
module = importlib.util.spec_from_file_location(
    "maintained_lifecycle", ROOT / "scripts/dev/research-lifecycle.py"
)
L = importlib.util.module_from_spec(module)
module.loader.exec_module(L)
P = L.process


def check_peers():
    for path in Path("/proc").iterdir():
        if not path.name.isdigit() or int(path.name) == os.getpid():
            continue
        try:
            args = path.joinpath("cmdline").read_bytes().split(b"\0")
            info = P.process_info(int(path.name))
        except OSError:
            continue
        if not info or info["state"] == "Z" or not args or not args[0]:
            continue
        name = Path(os.fsdecode(args[0])).name
        active = name in {
            "cargo",
            "rustc",
            "cc1plus",
            "quoridor-runner",
            "chromium",
            "chrome",
        }
        active |= name.startswith(("quoridor-runner-", "nnue_search-"))
        active |= any(
            a
            in {
                b"quoridor_training.train",
                b"quoridor_training.sigma_reference",
                b"quoridor_training.sigma_reference_control",
            }
            for a in args
        )
        active |= name.startswith("python") and any(
            Path(os.fsdecode(a)).name == "research-lifecycle.py" and b"run" in args
            for a in args
            if a
        )
        L.require(not active, "actual compute peer active: " + path.name)


class IdentityResources(P.CycleResources):
    """Use the maintained guardian hook; add this leaf's allocated-byte/controller checks."""

    def __init__(self, supervisor, deadline):
        super().__init__(
            {
                "host_ram_reserve": 4 * 1024**3,
                "max_memory_bytes": 448 * 1024**2,
                "max_output_bytes": 1024**2,
            },
            OWN,
            deadline,
        )
        self.supervisor = supervisor
        self.sampled_guardian_children_peak_B = 0
        self.sampled_controller_peak_B = 0

    def check(self, owned=()):
        super().check(owned)
        parent = P.process_info(self.supervisor["pid"])
        L.require(
            parent is not None and P.identity(parent) == self.supervisor,
            "controller identity unavailable/drift",
        )
        root = P.identity(P.process_info(os.getpid()))
        ours = P.members(root, [root, *owned])
        own_ids = {x["pid"] for x in ours}
        controller_members = P.members(self.supervisor, [self.supervisor])
        controller_infos = [
            P.process_info(x["pid"])
            for x in controller_members
            if x["pid"] not in own_ids
        ]
        controller_rss = sum(x["rss"] for x in controller_infos if x)
        group = [P.process_info(x["pid"]) for x in ours]
        rss = sum(x["rss"] for x in group if x)
        self.sampled_controller_peak_B = max(
            self.sampled_controller_peak_B, controller_rss
        )
        self.sampled_guardian_children_peak_B = max(
            self.sampled_guardian_children_peak_B, rss
        )
        L.require(
            rss + controller_rss <= 512 * 1024**2,
            "whole observed family512MiB exceeded",
        )
        L.require(L.allocated(OWN) <= 1024**2, "leaf allocated1MiB cap")
        L.require(L.allocated(OWN / "TMP-v3") <= 128 * 1024, "owned TMP128KiB cap")


def normalized_identity(out):
    if (
        type(out) is not dict
        or set(out) != {"format", "fingerprint"}
        or out["format"] != "residual"
    ):
        raise ValueError("returned residual format")
    fp = out["fingerprint"]
    if (
        type(fp) is not list
        or len(fp) != 32
        or not all(type(x) is int and 0 <= x <= 255 for x in fp)
    ):
        raise ValueError("exact32 integer fingerprint bytes")
    raw = bytes(fp)
    return {
        "format": "residual",
        "native_fingerprint_raw32_hex": raw.hex(),
        "typed_evaluator_content_SHA256": hashlib.sha256(raw).hexdigest(),
    }


def current_native_build(ref):
    manifest = L.document(ref)
    L.require(
        not Path(ref["path"]).with_name("INCOMPLETE").exists(), "provisional manifest"
    )
    L.require(
        manifest["schema"] == L.BUILD_SCHEMA and manifest["status"] == "PASS",
        "accepted build required",
    )
    L.require(
        manifest["cleanup_complete"] is True and manifest["remaining"] == [],
        "build completion required",
    )
    L.require(
        {r["role"] for r in manifest["checks"]}
        >= {"test", "lint", "build", "bindings"},
        "affected build evidence",
    )
    L.read_ref(manifest["artifact"], 32 * 1024 * 1024)
    source = dict(manifest["source"])
    compiled = {r["path"] for r in source["compiled_sources"].values()}
    source["files"] = [
        r
        for r in source["files"]
        if r["path"] in compiled
        or Path(r["path"]).name in {"Cargo.toml", "Cargo.lock", "rust-toolchain.toml"}
    ]
    L.source_check(source)
    for dep in manifest["dependency_refs"]:
        L.read_ref(dep, max(L.CONTROL_BYTES, dep["bytes"]))
    return manifest, source


def main():
    raw = Path(sys.argv[1]).read_bytes()
    L.require(hashlib.sha256(raw).hexdigest() == sys.argv[2], "frozen control SHA")
    cfg = json.loads(raw)
    runtime = Path(os.environ["QUORIDOR_RESEARCH_JOB_DIR"])
    job = json.loads((runtime / "config.json").read_bytes())
    state = json.loads((runtime / "state.json").read_bytes())
    L.require(
        job["issue"] == "quoridor-4lc.355.11"
        and job["argv"][:-1] == cfg["job_argv"]
        and job["argv"][-1] == sys.argv[2],
        "actual originating job argv/issue",
    )
    L.require(
        state["config_sha256"] == L.sha(json.dumps(job, sort_keys=True).encode()),
        "actual originating config fingerprint",
    )
    supervisor = state["supervisor"]
    L.require(
        supervisor["pid"] == os.getppid() and P.alive(supervisor),
        "actual originating supervisor",
    )
    deadline = time.monotonic() + 115
    spec = {"limits": cfg["limits"], "env": cfg["env"], "cwd": cfg["cwd"]}
    result = {
        "scope": "current loaded model identity only",
        "status": "UNKNOWN",
        "started_at": L.stamp(),
        "job_id": state["job_id"],
        "supervisor": supervisor,
        "guardian": P.identity(P.process_info(os.getpid())),
        "checks": [],
        "models": [],
        "primary": None,
        "secondary": [],
        "numerical_reference_history_clock_phase_PASS": False,
    }
    primary = None
    lock = None
    held = False
    tmp_created = False
    resources = None
    refs = []
    operation = OWN / "operation-v3"

    def attempt(stage, action):
        nonlocal primary
        try:
            return action()
        except BaseException as error:
            result["secondary"].append({"stage": stage, **L.error_fact(error)})
            if primary is None:
                primary = error
            else:
                primary.add_note(stage + ": " + repr(error))
            return None

    try:
        check_peers()
        L.physical_and_quiet(spec)
        quota = Path("/sys/fs/cgroup/cpu.max").read_text().split()
        L.require(
            quota[0] == "max" or int(quota[0]) / int(quota[1]) >= 2,
            "CPU quota for native/guardian",
        )
        lock = L.LEASE.open("a")
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        held = True
        result["lease_acquired_at"] = L.stamp()
        resources = IdentityResources(supervisor, deadline)
        resources.check()
        for ref in cfg["helper_refs"]:
            L.read_ref(ref, max(L.CONTROL_BYTES, ref["bytes"]))
        manifest, native_source = current_native_build(cfg["BuildManifest"])
        L.require(
            manifest["artifact"] == cfg["artifact"], "exact current manifest artifact"
        )
        L.require(
            manifest["compiled_sources"]
            == {
                k: r["sha256"]
                for k, r in manifest["source"]["compiled_sources"].items()
            },
            "current compiled source projection",
        )
        library = L.document(cfg["libraries"])
        L.require(
            library["BuildManifest"] == cfg["BuildManifest"]
            and library["artifact"] == manifest["artifact"],
            "same current library/artifact binding",
        )
        L.require(
            len(library["dynamic_libraries"]) == 5, "five actual library references"
        )
        refs = [
            cfg["BuildManifest"],
            cfg["libraries"],
            cfg["approved_facts"],
            *cfg["helper_refs"],
            manifest["artifact"],
            *native_source["files"],
            *manifest["dependency_refs"],
            *cfg["saved_BEST51_refs"],
            *(x["file"] for x in library["dynamic_libraries"]),
        ]
        for item in library["dynamic_libraries"]:
            L.read_ref(item["file"], item["file"]["bytes"])
        L.read_ref(cfg["approved_facts"])
        result["BuildManifest"] = cfg["BuildManifest"]
        result["artifact"] = manifest["artifact"]
        result["compiled_sources"] = manifest["compiled_sources"]
        result["native_compiled35_and_critical_source_before_match"] = True
        result["current_source_scope"] = native_source["files"]
        result["libraries"] = library["dynamic_libraries"]
        for expected in cfg["models"]:
            ref = expected["descriptor"]
            raw_descriptor = L.read_ref(ref)
            descriptor = json.loads(raw_descriptor)
            L.require(
                descriptor["weights_SHA"] == expected["weights_SHA256"]
                and descriptor["weights_B"] == 49284,
                "descriptor declared weights",
            )
            name = descriptor["weights"]
            L.require(
                type(name) is str
                and Path(name).name == name
                and name not in {"", ".", ".."},
                "descriptor-declared basename",
            )
            weight = Path(ref["path"]).parent / name
            L.require(
                weight.resolve() == weight
                and weight.parent == Path(ref["path"]).parent,
                "canonical exact owned model asset",
            )
            wref, _ = L.bound(weight, 49284)
            L.require(
                wref["sha256"] == expected["weights_SHA256"] and wref["bytes"] == 49284,
                "whole weights SHA/size",
            )
            L.require(
                descriptor["distance_fit"] == {"a": 0.0, "b": expected["b"]},
                "original distance fit unchanged",
            )
            L.require(
                descriptor["value_perspective"] == "side-to-move",
                "original STM perspective",
            )
            refs += [ref, wref]
            result["models"].append(
                {
                    "name": expected["name"],
                    "descriptor": ref,
                    "weights": wref,
                    "distance_fit": descriptor["distance_fit"],
                    "mu_f32": descriptor["mu_f32"],
                    "sigma_f32": descriptor["sigma_f32"],
                    "route_mode": descriptor["route_mode"],
                    "expected_evaluator_SHA256": expected["evaluator_SHA256"],
                    "loaded_identity": "NOT_RUN",
                }
            )
        saved = L.document(cfg["saved_BEST51_STOP"])
        old_result = L.document(cfg["saved_BEST51_job_result"])
        L.require(
            old_result["outcome"] == "failed"
            and saved["after_all_refs_match"] is True
            and saved["artifact"] == manifest["artifact"]
            and saved["compiled_sources"] == manifest["compiled_sources"],
            "saved BEST51 current native provenance",
        )
        L.require(
            saved["models"][0]["descriptor"] == result["models"][0]["descriptor"]
            and saved["models"][0]["weights"] == result["models"][0]["weights"],
            "saved BEST51 input correspondence",
        )
        old_check = saved["checks"][0]
        L.require(
            old_check["name"] == "BEST51"
            and len(saved["checks"]) == 1
            and old_check["guardian_return"]["exit_code"] == 0
            and old_check["guardian_return"]["direct_child_reaped"] is True
            and old_check["guardian_return"]["cleanup_complete"] is True,
            "saved actual BEST51 return",
        )
        observed51 = normalized_identity(
            json.loads(L.read_ref(old_check["full_log"], 8192))
        )
        L.require(
            observed51["typed_evaluator_content_SHA256"]
            == cfg["models"][0]["evaluator_SHA256"],
            "saved BEST51 typed domain match",
        )
        result["models"][0]["loaded_identity"] = {
            **observed51,
            "raw_stdout": old_check["full_log"],
            "originating_job_id": saved["job_id"],
            "originating_whole_status": "FAILED",
            "native_invocations_this_job": 0,
        }
        L.require(not operation.exists(), "fresh operation, no retry")
        operation.mkdir()
        (OWN / "TMP-v3").mkdir()
        tmp_created = True
        result["input_and_library_before_match"] = True
        L.new_json(operation / "START.json", result)
        for expected, model in zip(
            cfg["models"][1:], result["models"][1:], strict=True
        ):
            check_peers()
            resources.check()
            row = {
                "name": expected["name"],
                "role": "model-check",
                "argv": [
                    cfg["artifact"]["path"],
                    "model-check",
                    "--model",
                    expected["descriptor"]["path"],
                ],
            }
            returned, full = L.command(
                spec, row, operation, resources, ledger=result["checks"]
            )
            out = json.loads(full.read_bytes())
            observed = normalized_identity(out)
            model["loaded_identity"] = {
                **observed,
                "raw_stdout": L.bound(full, 8192)[0],
                "originating_job_id": state["job_id"],
                "native_invocations_this_job": 1,
            }
            L.require(
                observed["typed_evaluator_content_SHA256"]
                == expected["evaluator_SHA256"],
                "actual loaded typed evaluator identity mismatch",
            )
            L.require(
                returned["handle_closes_complete"] is True
                and returned["process_cleanup_complete"] is True,
                "actual process/handle cleanup",
            )
        result["status"] = "IDENTITY_MATCH"
    except BaseException as error:
        primary = error
    finally:
        if held:
            if "native_source" in locals():
                attempt(
                    "after_native_config_scope", lambda: L.source_check(native_source)
                )
            for ref in refs:
                attempt(
                    "after_identity:" + ref["path"],
                    lambda ref=ref: L.read_ref(ref, max(L.CONTROL_BYTES, ref["bytes"])),
                )
            result["after_all_refs_match"] = not any(
                x["stage"].startswith("after_identity:") for x in result["secondary"]
            )
            if tmp_created:
                attempt("owned_TMP_rmdir", lambda: (OWN / "TMP-v3").rmdir())
            if resources:
                attempt("final_resources", resources.check)
                result["sampled_guardian_children_peak_B"] = (
                    resources.sampled_guardian_children_peak_B
                )
                result["sampled_controller_peak_B"] = (
                    resources.sampled_controller_peak_B
                )
            result["continuous_peak"] = "UNKNOWN; sampled guardian checks only"
            result["source_asset_library_reader_STOP"] = L.stamp()
            result["primary"] = L.error_fact(primary) if primary else None
            result["status"] = "FAILED" if primary else result["status"]
            result["owned_TMP_remaining"] = (
                [] if not (OWN / "TMP-v3").exists() else [str(OWN / "TMP-v3")]
            )
            result["lease_held_through_checks_directwait_inputs_source_logs_STOP"] = (
                True
            )
            attempt(
                "STOP_save", lambda: L.new_json(OWN / "worker-STOP-v3.json", result)
            )
            attempt("lease_unlock", lambda: fcntl.flock(lock, fcntl.LOCK_UN))
        if lock:
            attempt("lease_close", lock.close)
        result["lease_release_returned"] = not any(
            x["stage"] in {"lease_unlock", "lease_close"} for x in result["secondary"]
        )
        result["primary"] = L.error_fact(primary) if primary else None
        result["status"] = "FAILED" if primary else result["status"]
        attempt(
            "terminal_receipt_stdout",
            lambda: print(
                json.dumps(
                    {
                        "status": result["status"],
                        "primary": result["primary"],
                        "secondary": result["secondary"],
                        "lease_release_returned": result["lease_release_returned"],
                    }
                ),
                flush=True,
            ),
        )
    if primary:
        raise primary


if __name__ == "__main__":
    main()
