"""New NN0 Python stdlib interoperability fixtures, NOT execution of Rust producer."""

import gzip
import hashlib
import io
import json
import struct
import unittest
import zlib


def fixture():
    return b"".join(
        json.dumps(
            {"row": i, "raw": v, "raw_bits": struct.unpack("<I", struct.pack("<f", v))[0]},
            separators=(",", ":"),
        ).encode()
        + b"\n"
        for i, v in enumerate([-0.0, 2.0, -2.0, 0.125])
    )


class EncodingInteroperability(unittest.TestCase):
    def test_exact_raw_bits_labels_order_and_content_domain(self):
        raw = fixture()
        compressed = io.BytesIO()
        with gzip.GzipFile(fileobj=compressed, mode="wb", compresslevel=1, mtime=0) as writer:
            for i in range(0, len(raw), 7):
                writer.write(raw[i : i + 7])
        encoded = compressed.getvalue()
        self.assertEqual(gzip.decompress(encoded), raw)
        self.assertNotEqual(hashlib.sha256(raw).digest(), hashlib.sha256(encoded).digest())
        rows = [json.loads(line) for line in raw.splitlines()]
        self.assertEqual([r["row"] for r in rows], [0, 1, 2, 3])
        for r in rows:
            self.assertEqual(struct.unpack("<I", struct.pack("<f", r["raw"]))[0], r["raw_bits"])

    def test_index_offsets_are_uncompressed_and_include_lf(self):
        raw = fixture()
        encoded = gzip.compress(raw, compresslevel=1, mtime=0)
        with gzip.GzipFile(fileobj=io.BytesIO(encoded), mode="rb") as reader:
            lines, offsets = [], []
            while True:
                offset = reader.tell()
                line = reader.readline(2049)
                if not line:
                    break
                self.assertTrue(line.endswith(b"\n"))
                offsets.append(offset)
                lines.append(line)
            self.assertEqual(b"".join(lines), raw)
            self.assertEqual(offsets[1], len(lines[0]))
            reader.seek(offsets[2])
            self.assertEqual(reader.readline(2049), lines[2])

    def test_truncated_crc_and_extra_member_are_not_complete(self):
        raw = fixture()
        encoded = gzip.compress(raw, compresslevel=1, mtime=0)
        for bad in [encoded[:-3], encoded[:-8] + bytes([encoded[-8] ^ 1]) + encoded[-7:]]:
            with self.assertRaises((EOFError, OSError)):
                gzip.decompress(bad)
        # Python gzip accepts concatenated streams; the contract REQUIRES single member.
        decoder = zlib.decompressobj(wbits=31)
        self.assertEqual(decoder.decompress(encoded + encoded), raw)
        self.assertTrue(decoder.eof)
        self.assertEqual(decoder.unused_data, encoded)
        self.assertNotEqual(decoder.unused_data, b"")


if __name__ == "__main__":
    unittest.main(verbosity=2)
