"""One finite saved stdlib phase, excluding all neural/search execution."""

import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import stat
import sys
import time

ROOT = Path(__file__).resolve().parent
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
PROCESS_SOURCE = Path(
    "/workspaces/quoridor/.worktree/learning-million/python/quoridor_training/cycle_process.py"
)
PATTERN = re.compile(
    r"(^|/)(cargo|rustc|perf|quoridor-runner|nnue-diagnose|chromium|chrome)(\s|$)|inspect_open_rows|torchrun|statistics-runtime|finite-driver"
)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def quiet():
    competitors = []
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) in (os.getpid(), os.getppid()):
            continue
        try:
            argv = (entry / "cmdline").read_bytes().split(b"\0")
            # Ignore shell command text: it may quote source names without executing them.
            executable = Path(os.fsdecode(argv[0])).name
            text = " ".join(os.fsdecode(a) for a in argv if a)
            if executable in ("bash", "sh", "timeout"):
                continue
            if PATTERN.search(text):
                fields = (entry / "stat").read_text().rsplit(")", 1)[1].split()
                competitors.append(
                    {"pid": int(entry.name), "start_ticks": fields[19], "argv": text[:512]}
                )
        except (OSError, IndexError, ValueError):
            continue
    if competitors:
        raise RuntimeError("Named competitors: " + json.dumps(competitors))
    return competitors


def physical():
    memory = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
    available = int(memory["MemAvailable"].split()[0]) * 1024
    fs = os.statvfs(ROOT)
    free = fs.f_bavail * fs.f_frsize
    if available < 4 * 1024**3 + 512 * 1024**2 or free < 536870912:
        raise RuntimeError("Fresh RAM/storage headroom")
    if 3 not in os.sched_getaffinity(0) or 5 not in os.sched_getaffinity(0):
        raise RuntimeError("CPU3/5 affinity")
    identities = []
    for cpu in (3, 5):
        base = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
        identities.append(
            (
                (base / "physical_package_id").read_text().strip(),
                (base / "core_id").read_text().strip(),
            )
        )
    if identities[0] == identities[1]:
        raise RuntimeError(
            "Compiler-independent saved controller/worker need distinct physical cores"
        )
    return {
        "MemAvailable_B": available,
        "filesystem_free_B": free,
        "worker_controller_CPU": [3, 5],
        "topology": identities,
    }


def main():
    started = time.monotonic()
    # NB lease precedes numerical/framework imports, owned TMP and child Popen.
    with LOCK.open("a+b") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        frozen = json.loads((ROOT / "saved-source-binding.json").read_text())
        for path, identity in frozen["map"].items():
            p = Path(path)
            if (
                p.is_symlink()
                or p.stat().st_size != identity["bytes"]
                or digest(p) != identity["SHA256"]
                or f"{stat.S_IMODE(p.stat().st_mode):04o}" != identity["mode"]
            ):
                raise RuntimeError("Frozen source identity: " + path)
        if (
            digest(PROCESS_SOURCE)
            != "afe32d2601d8e4bd02bf2dd057e22fddd1d1a64dab3ac1adb6e9d71c2d7ccc2c"
        ):
            raise RuntimeError("Maintained process ownership source")
        competitors = quiet()
        facts = physical()
        proof = Path(
            "/workspaces/quoridor/research-data/ai-sigma/teacher-distance-tanh-v1/causal-resources-v2.json"
        )
        if digest(proof) != "a380de4b0db484763a8353acda7ade7abeece8bb48151901db9a7193c5a7370a":
            raise RuntimeError("Whole-phase proof")
        phase = json.loads(proof.read_text())["phases"]["learner"]
        if sum(phase["components_B"].values()) != phase["whole_B"] or phase["whole_B"] != 536870912:
            raise RuntimeError("Whole-phase arithmetic")
        os.sched_setaffinity(0, {5})
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024**2, 512 * 1024**2))
        sys.path.insert(0, str(PROCESS_SOURCE.parent))
        import cycle_process as process

        class SavedResources:
            def __init__(self):
                self.peak_family_sample_B = 0
                self.deadline = time.monotonic() + 120

            def check(self, owned=()):
                if time.monotonic() >= self.deadline:
                    raise RuntimeError("Finite saved command120s limit")
                infos = [
                    process.process_info(os.getpid()),
                    *(process.process_info(x["pid"]) for x in owned),
                ]
                rss = sum(i["rss"] for i in infos if i) + 64 * 1024**2
                self.peak_family_sample_B = max(self.peak_family_sample_B, rss)
                if rss > 512 * 1024**2:
                    raise RuntimeError("Saved family RSS including64MiB controller reserve")
                allocated = 0
                for path in ROOT.rglob("*"):
                    if path.is_symlink():
                        raise RuntimeError("Owned phase symlink")
                    allocated += path.stat().st_blocks * 512
                if allocated > 8 * 1024**2:
                    raise RuntimeError("Initial saved/source/raw upper8MiB, whole512MiB held")

        resources = SavedResources()
        resources.check()

        runtime = ROOT / "saved-stdlib-v1"
        runtime.mkdir()
        tmp = runtime / "TMP"
        tmp.mkdir()
        os.environ["TMPDIR"] = str(tmp)
        os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
        os.environ["PYTHONPATH"] = str(ROOT)
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (runtime / "START.json").write_text(
            json.dumps(
                {
                    "START": start,
                    "identity": process.identity(process.process_info(os.getpid())),
                    "physics": facts,
                    "named_competitors": competitors,
                    "parent_scope": "fresh direct347.3 NONE/notready supplied, new entries fail closed on canonical lock",
                },
                indent=2,
            )
            + "\n"
        )
        primary = None
        returned = []
        secondary = []
        try:
            for name, argv in [
                ("new-boundary-fixtures", [sys.executable, "-B", str(ROOT / "test_open_rows.py")]),
                (
                    "OPEN-census",
                    [
                        sys.executable,
                        "-B",
                        str(ROOT / "inspect_open_rows.py"),
                        "--plan",
                        str(ROOT / "OPEN-subset-plan.json"),
                        "--output",
                        str(runtime / "OPEN-census.json"),
                    ],
                ),
            ]:
                quiet()
                resources.deadline = time.monotonic() + 120
                result = process.execute(
                    argv,
                    runtime / (name + ".log"),
                    time.monotonic() + 120,
                    cpu_core=3,
                    resources=resources,
                )
                returned.append({"name": name, "returned": result})
        except BaseException as error:
            primary = error
        finally:
            for path, identity in frozen["map"].items():
                if digest(path) != identity["SHA256"]:
                    secondary.append({"stage": "source_after", "path": path})
            remaining = []
            census_known = primary is None
            for item in returned:
                r = item["returned"]
                if (
                    r.get("direct_child_reaped") is not True
                    or r.get("cleanup_complete") is not True
                    or r.get("remaining") != []
                ):
                    secondary.append({"stage": "returned_cleanup", "name": item["name"]})
                if r.get("child") and process.alive(r["child"]):
                    remaining.append(r["child"])
            if primary is not None:
                # Failed execute raises instead of returning; preserve its raw receipt.
                failed_records = list(runtime.glob("*.process.json"))
                census_known = bool(failed_records)
                for path in failed_records:
                    r = json.loads(path.read_text())
                    if (
                        r.get("direct_child_reaped") is not True
                        or r.get("cleanup_complete") is not True
                        or type(r.get("remaining")) is not list
                    ):
                        census_known = False
                    remaining.extend(r.get("remaining") or [])
            # Only successful synchronous waits and truly empty owned TMP permit rmdir.
            if primary is None and not secondary and not remaining:
                try:
                    tmp.rmdir()
                except OSError as error:
                    secondary.append(
                        {
                            "stage": "empty_owned_TMP",
                            "type": type(error).__name__,
                            "message": str(error),
                        }
                    )
            stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
            receipt = {
                "schema": "quoridor.nnue-causal.saved-STOP.v1",
                "issue": "quoridor-4lc.342.9",
                "START": start,
                "STOP": stop,
                "whole_controller_seconds": time.monotonic() - started,
                "returned_commands": returned,
                "primary": None
                if primary is None
                else {"type": type(primary).__name__, "message": str(primary)},
                "secondary": secondary,
                "remaining": remaining if census_known else None,
                "TMP_retained": tmp.exists(),
                "new_geometry_forward_gradient_Search_calls": 0,
                "source_after_match": not any(e["stage"] == "source_after" for e in secondary),
                "continuous_family_peak": "UNKNOWN",
                "sampled_family_RSS_including64MiB_B": resources.peak_family_sample_B,
                "parent_scope": "saved stdlib only; no live model/input replay qualification",
                "old_failures_assets_fees_UNKNOWN": "held",
            }
            (runtime / "STOP.json").write_text(
                json.dumps(receipt, indent=2, allow_nan=False) + "\n"
            )
        if primary is not None:
            raise primary
        if secondary or remaining:
            raise RuntimeError("Honest finalization refusal: " + json.dumps(secondary))
        print(
            json.dumps(
                {
                    "START": start,
                    "STOP": stop,
                    "receipt": str(runtime / "STOP.json"),
                    "geometry_forward_gradient_Search": 0,
                }
            )
        )


if __name__ == "__main__":
    main()
