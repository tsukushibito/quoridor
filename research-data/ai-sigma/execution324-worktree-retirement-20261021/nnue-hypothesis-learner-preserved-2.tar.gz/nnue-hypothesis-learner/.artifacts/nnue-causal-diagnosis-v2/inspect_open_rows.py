"""Directed saved-record census; invocation requires external finite admission.

No geometry/model library is imported. Exact 28-byte model keys reuse the
qualified maintained injective QF1+D representation, not a board hash.
History, family, original training gradients and off-policy labels are unknown.
"""

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import struct

RECORD = struct.Struct("<4BQQ2fbBI32s")
assert RECORD.size == 66


def sha(data):
    return hashlib.sha256(data).hexdigest()


def decode(raw):
    if len(raw) != RECORD.size:
        raise ValueError("Record framing")
    p0, p1, s0, s1, h, v, d0, d1, z, shard, row, input_sha = RECORD.unpack(raw)
    if p0 >= 81 or p1 >= 81 or p0 == p1 or max(s0, s1) > 10:
        raise ValueError("Qualified canonical geometry bounds")
    if z not in (-1, 0, 1) or not all(math.isfinite(d) and 0 <= d <= 1 for d in (d0, d1)):
        raise ValueError("Label/distance bounds")
    return {
        "pawns": [p0, p1],
        "stocks": [s0, s1],
        "horizontal": h,
        "vertical": v,
        "distance": [d0, d1],
        "z": z,
        "source_shard": shard,
        "source_row": row,
        "original_input_SHA256": input_sha.hex(),
        "model_key_28B_hex": raw[:28].hex(),
        "record_SHA256": sha(raw),
    }


def inspect(plan):
    named = plan["validation"]
    source = Path(named["path"])
    if source.is_symlink() or source.stat().st_size != named["bytes"]:
        raise ValueError("Named regular validation source/size")
    ordinals = plan["ordinals"]
    if len(ordinals) != len(set(ordinals)) or len(ordinals) > 4096:
        raise ValueError("Fixed unique subset")
    if ordinals != sorted(ordinals) or any(
        type(i) is not int or not 0 <= i < named["rows"] for i in ordinals
    ):
        raise ValueError("Fixed ordinal bounds")
    selected = set(ordinals)
    digest = hashlib.sha256()
    output = []
    with source.open("rb") as stream:
        for ordinal in range(named["rows"]):
            raw = stream.read(RECORD.size)
            if len(raw) != RECORD.size:
                raise ValueError("Partial source")
            digest.update(raw)
            if ordinal in selected:
                value = decode(raw)
                value.update(ordinal=ordinal, raw_record_hex=raw.hex())
                output.append(value)
        if stream.read(1):
            raise ValueError("Trailing source")
    if digest.hexdigest() != named["SHA256"]:
        raise ValueError("Full named source digest mismatch")
    groups = defaultdict(list)
    for row in output:
        groups[row["model_key_28B_hex"]].append(row)
    label_counts = Counter(str(row["z"]) for row in output)
    phase_counts = Counter(
        "stock16plus"
        if sum(row["stocks"]) >= 16
        else "stock6to15"
        if sum(row["stocks"]) >= 6
        else "stock0to5"
        for row in output
    )
    conflicting = []
    for key, members in groups.items():
        if len({row["z"] for row in members}) > 1:
            conflicting.append(
                {
                    "model_key_28B_hex": key,
                    "ordinals": [row["ordinal"] for row in members],
                    "labels": [row["z"] for row in members],
                }
            )
    return {
        "schema": "quoridor.nnue-causal.OPEN-record-census.v1",
        "input_plan": plan,
        "observed_rows": len(output),
        "source_hashed_bytes": named["bytes"],
        "selected_decoded_bytes": len(output) * RECORD.size,
        "labels": dict(label_counts),
        "stock_phase_proxy": dict(phase_counts),
        "exact_model_input_unique": len(groups),
        "exact_key_definition": "raw first28B = geometry20B + original two FP32 D/80 values; maintained qualified model_keys injective QF1 equality proof reused",
        "observed_label_disagreements_same_actual_input": conflicting,
        "history_explanation_of_disagreements": "UNKNOWN; no original history stored",
        "family_split_leakage": "UNKNOWN; source shard/row are not genuine game families",
        "mainline_vs_offtrajectory": "UNKNOWN pending shared campaign; no alternative winning labels created",
        "coverage": "deterministically spaced original opened validation subset, not full corpus/frequency or independent evaluation",
        "new_geometry_model_gradient_Search_calls": 0,
        "rows": output,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    plan = json.loads(args.plan.read_text())
    result = inspect(plan)
    # Publish only after the complete source digest and all selected rows validate.
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()
