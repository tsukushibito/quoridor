"""Execute only changed finalization/receipt AST with stdlib and synthetic ports.

No production module body, model/framework/native library, forward or gradient
is imported or called. Synthetic review receipts exist only in owned fixtureTMP.
"""

import ast
import datetime
import hashlib
import json
from pathlib import Path
import stat
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent


def functions(tree, names, namespace):
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    if {node.name for node in nodes} != set(names):
        raise AssertionError("Exact changed source functions")
    exec(compile(ast.Module(body=nodes, type_ignores=[]), "actual-source-ports", "exec"), namespace)


class PublicationPort:
    def __init__(self, error=None):
        self.error = error
        self.text = ""

    def open(self, _mode):
        if self.error is not None:
            raise self.error
        return self

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def write(self, text):
        self.text += text

    def __truediv__(self, _name):
        return self

    def write_text(self, text):
        if self.error is not None:
            raise self.error
        self.text = text


class RepairPorts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.caller = ast.parse((ROOT / "current_gradients.py").read_text())
        cls.guard = ast.parse((ROOT / "numeric_guard.py").read_text())

    def caller_finalize(self, primary, snapshot_error, publication_error):
        port = PublicationPort(publication_error)

        def snapshot():
            if snapshot_error is not None:
                raise snapshot_error
            return b"held"

        ns = {
            "json": json,
            "Path": lambda _path: port,
            "primary": primary,
            "secondary": [],
            "parameter_bytes": snapshot,
            "buffer_bytes": lambda: b"buffers",
            "before": b"held",
            "buffers": b"buffers",
            "parameters": [],
            "counters": {},
            "results": [],
            "config": {"bindings": {}, "output": "SYNTHETIC_PORT"},
        }
        functions(self.caller, ["raise_retained_errors"], ns)
        run = next(
            node
            for node in self.caller.body
            if isinstance(node, ast.FunctionDef) and node.name == "run"
        )
        actual_try = next(node for node in run.body if isinstance(node, ast.Try) and node.finalbody)
        actual_raise = next(
            node
            for node in run.body
            if isinstance(node, ast.Expr)
            and isinstance(node.value, ast.Call)
            and isinstance(node.value.func, ast.Name)
            and node.value.func.id == "raise_retained_errors"
        )
        code = compile(
            ast.Module(body=actual_try.finalbody + [actual_raise], type_ignores=[]),
            "actual-caller-finalization",
            "exec",
        )
        return ns, port, code

    def test_R1_two_errors_preserve_first_and_later_without_prior_primary(self):
        first, later = OSError("snapshot-port"), OSError("publication-port")
        ns, _port, code = self.caller_finalize(None, first, later)
        with self.assertRaises(OSError) as raised:
            exec(code, ns)
        self.assertIs(raised.exception, first)
        self.assertEqual(first.retained_secondary_errors, (later,))

    def test_R1_original_primary_keeps_all_later_errors(self):
        original, snapshot, publication = (
            ValueError("original-port"),
            OSError("snapshot-port"),
            OSError("publication-port"),
        )
        ns, _port, code = self.caller_finalize(original, snapshot, publication)
        with self.assertRaises(ValueError) as raised:
            exec(code, ns)
        self.assertIs(raised.exception, original)
        self.assertEqual(original.retained_secondary_errors, (snapshot, publication))

    def test_R1_successful_publication_exposes_snapshot_failure(self):
        error = OSError("snapshot-port")
        ns, port, code = self.caller_finalize(None, error, None)
        with self.assertRaises(OSError) as raised:
            exec(code, ns)
        self.assertIs(raised.exception, error)
        report = json.loads(port.text)
        self.assertEqual(report["status"], "FAILED")
        self.assertEqual(
            report["secondary_errors"], [{"type": "OSError", "message": "snapshot-port"}]
        )

    def receipt_case(self, mutate_actual=None, mutate_summary=None):
        with tempfile.TemporaryDirectory(prefix="synthetic-review-port-") as temp:
            repair = Path(temp)
            for name in ("caller-source-STOP.json", "guard-source-STOP.json"):
                (repair / name).write_text("SYNTHETIC SOURCE BINDING " + name)
            receipt = {
                "schema": "quoridor.current-gradient.source-review.v1",
                "issue": "quoridor-4lc.342.12",
                "reviewed_boundary": "current-known-label-loss-gradient",
                "target_binding_SHA256": hashlib.sha256(
                    (repair / "caller-source-STOP.json").read_bytes()
                ).hexdigest(),
                "guard_binding_SHA256": hashlib.sha256(
                    (repair / "guard-source-STOP.json").read_bytes()
                ).hexdigest(),
                "source_clear": True,
                "blockers": 0,
                "actual_reader_STOP": "2026-10-09T11:49:06.614917+00:00",
                "owned_remaining": [],
                "owned_children_jobs_readers_TMP": [],
                "SYNTHETIC_ONLY": True,
            }
            summary = dict(receipt)
            if mutate_actual is not None:
                mutate_actual(receipt)
            if mutate_summary is not None:
                mutate_summary(summary)
            path = repair / "SYNTHETIC-review.json"
            path.write_text(json.dumps(receipt))
            summary.update(
                path=str(path),
                identity={
                    "SHA256": hashlib.sha256(path.read_bytes()).hexdigest(),
                    "bytes": path.stat().st_size,
                    "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
                },
            )
            ns = {
                "json": json,
                "Path": Path,
                "stat": stat,
                "hashlib": hashlib,
                "datetime": datetime,
                "REPAIR": repair,
            }
            functions(self.guard, ["check_identity", "verify_related_clear"], ns)
            return ns["verify_related_clear"](summary)

    def test_R2_receipt_itself_controls_admission(self):
        mutations = [
            lambda r: r.update(
                schema="quoridor.target-only.source-review.v1", issue="quoridor-4lc.342.11"
            ),
            lambda r: r.update(source_clear=False, blockers=3),
            lambda r: r.update(guard_binding_SHA256="0" * 64),
            lambda r: r.update(actual_reader_STOP=None),
            lambda r: r.update(owned_remaining=None),
            lambda r: r.update(blockers=False),
        ]
        for mutation in mutations:
            with self.subTest(mutation=mutation), self.assertRaises((ValueError, TypeError)):
                self.receipt_case(mutate_actual=mutation)

    def test_R2_matching_hash_bound_receipt_and_summary_required(self):
        self.assertTrue(self.receipt_case()["source_clear"])
        with self.assertRaises(ValueError):
            self.receipt_case(
                mutate_summary=lambda r: r.update(actual_reader_STOP="2026-10-09T11:49:07+00:00")
            )

    def test_R3_failed_STOP_IO_exposes_all_collected_facts(self):
        actual_try = next(
            node
            for node in ast.walk(self.guard)
            if isinstance(node, ast.Try)
            and any(
                isinstance(n, ast.Constant) and n.value == "STOP_publication"
                for handler in node.handlers
                for n in ast.walk(handler)
            )
        )
        for original in (None, ValueError("original-child-port")):
            io_error = OSError("STOP-IO-port")
            facts = [
                {"stage": "source_after", "message": "source-port"},
                {"stage": "retain_nonempty_or_failed_TMP", "message": "TMP-port"},
            ]
            ns = {
                "json": json,
                "directory": PublicationPort(io_error),
                "receipt": {"SYNTHETIC": True},
                "primary": original,
                "secondary": list(facts),
            }
            functions(self.guard, ["raise_finalization_facts"], ns)
            with self.subTest(original=original), self.assertRaises(BaseException) as raised:
                exec(
                    compile(
                        ast.Module(body=[actual_try], type_ignores=[]),
                        "actual-STOP-publication",
                        "exec",
                    ),
                    ns,
                )
                ns["raise_finalization_facts"](ns["primary"], ns["secondary"])
            self.assertIs(raised.exception, original if original is not None else io_error)
            self.assertEqual(list(raised.exception.retained_finalization_facts)[:2], facts)
            self.assertEqual(
                raised.exception.retained_finalization_facts[-1]["stage"], "STOP_publication"
            )


if __name__ == "__main__":
    unittest.main()
