"""Bounded current known-label loss gradients on held BEST51, never training.

Caller requires a reviewed frozen admission and fresh numerical lifetime guard.
The production model/features are imported only after every source/input binding
passes. No historical gradients, alternative winning labels, or optimizer exist.
"""

import argparse
import hashlib
import json
from pathlib import Path
import sys


def digest(data):
    return hashlib.sha256(data).hexdigest()


def raise_retained_errors(primary, secondary):
    """Raise the original first failure while retaining every later exception."""
    if primary is None and not secondary:
        return
    first = primary if primary is not None else secondary[0]
    later = tuple(secondary if primary is not None else secondary[1:])
    first.retained_secondary_errors = tuple(getattr(first, "retained_secondary_errors", ())) + later
    for error in later:
        first.add_note("secondary finalization error: " + repr(error))
    raise first


def run(config):
    for path, identity in config["bindings"].items():
        p = Path(path)
        if (
            p.is_symlink()
            or p.stat().st_size != identity["bytes"]
            or digest(p.read_bytes()) != identity["SHA256"]
        ):
            raise ValueError("Frozen identity before imports: " + path)
    census = json.loads(Path(config["census"]).read_text())
    rows = {r["ordinal"]: r for r in census["rows"]}
    ids = config["ordinals"]
    if len(ids) > 32 or len(set(ids)) != len(ids) or any(i not in rows for i in ids):
        raise ValueError("Fixed <=32 current-gradient rows, included in256 forwards")
    sys.path.insert(0, config["production_python"])
    import numpy as np
    import torch
    from quoridor_training.common import resolve_config
    from quoridor_training.public_features import RECORD, features
    from quoridor_training.residual_model import DistanceResidualModel

    if torch.__version__ != config["torch_version"]:
        raise ValueError("Held qualified framework version mismatch")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    fit = resolve_config(config["fit_config"])
    scale = json.loads(Path(config["scale"]).read_text())
    checkpoint = torch.load(config["checkpoint"], map_location="cpu", weights_only=True)
    if (
        checkpoint["model_config"] != fit["model"]
        or checkpoint["dataset_sha"] != config["cache_manifest_SHA256"]
        or checkpoint["target"] != "z"
        or checkpoint["position"] != config["position"]
        or any(checkpoint["scale"][k] != scale[k] for k in ("mu_f32", "sigma_f32"))
        or fit["training"]["target"] != "z"
        or fit["training"]["loss_weighting"] != "row"
    ):
        raise ValueError("Original objective/config/BEST51/scale lineage")
    torch.manual_seed(fit["training"]["seed"])
    model = DistanceResidualModel(fit["model"], scale, a=0.0, b=8.0).eval()
    model.load_state_dict(checkpoint["model"], strict=True)
    parameters = (
        model.ft.weight,
        model.ft.bias,
        model.h.weight,
        model.h.bias,
        model.out.weight,
        model.out.bias,
    )
    names = ("ft.weight", "ft.bias", "h.weight", "h.bias", "out.weight", "out.bias")

    def parameter_bytes():
        return b"".join(p.detach().numpy().astype("<f4").tobytes() for p in parameters)

    def buffer_bytes():
        return b"".join(
            b.detach().numpy().astype("<f4").tobytes()
            for b in (model.mu, model.sigma, model.coefficient)
        )

    before = parameter_bytes()
    buffers = buffer_bytes()
    if digest(before) != config["weights_SHA256"]:
        raise ValueError("Ordered held BEST51 parameters before forward")
    if sys.getprofile() is not None:
        raise ValueError("Existing profile observer; refuse without replacement")
    counters = {
        "attempted": 0,
        "returned": 0,
        "validated": 0,
        "gradient_attempted": 0,
        "gradient_returned": 0,
        "gradient_validated": 0,
        "rejected_before_invocation": 0,
    }
    results = []
    primary = None
    secondary = []
    try:
        for ordinal in ids:
            try:
                if counters["attempted"] >= 32:
                    raise ValueError("Exact32 invocation cap before preparation")
                row = rows[ordinal]
                raw = bytes.fromhex(row["raw_record_hex"])
                if (
                    digest(raw) != row["record_SHA256"]
                    or len(raw) != RECORD.itemsize
                    or row["z"] not in (-1, 0, 1)
                ):
                    raise ValueError("Actual frozen labelled record")
                records = np.frombuffer(raw, dtype=RECORD).copy()
                if int(records["z"][0]) != row["z"]:
                    raise ValueError("Compatible label mismatch")
                x = torch.from_numpy(features(records["geometry"]))
                # Explicit owned C-order copy, preserving the qualified66B adapter fix.
                distance = torch.from_numpy(
                    np.array(records["distance"], dtype=np.float32, order="C", copy=True)
                )
                side = torch.tensor([1], dtype=torch.int64)
                target = torch.tensor([row["z"]], dtype=torch.float32)
                actual_input_SHA256 = digest(
                    x.numpy().tobytes() + distance.numpy().tobytes() + side.numpy().tobytes()
                )
            except BaseException:
                counters["rejected_before_invocation"] += 1
                raise
            captured = []

            def observer(frame, event, arg, observed=captured):
                if (
                    event == "return"
                    and arg is not None
                    and frame.f_code is DistanceResidualModel.forward.__code__
                    and frame.f_locals.get("self") is model
                ):
                    observed.append((frame.f_locals["logit"], frame.f_locals["residual"]))

            previous = sys.getprofile()
            try:
                sys.setprofile(observer)
            except BaseException:
                counters["rejected_before_invocation"] += 1
                raise
            call_error = None
            restoration_error = None
            try:
                counters["attempted"] += 1
                prediction = model(x, distance, side)
                counters["returned"] += 1
            except BaseException as error:
                call_error = error
            finally:
                try:
                    sys.setprofile(previous)
                except BaseException as error:
                    restoration_error = error
            if call_error is not None:
                if restoration_error is not None:
                    call_error.add_note("profile restoration failure: " + repr(restoration_error))
                raise call_error
            if restoration_error is not None:
                raise restoration_error
            if (
                len(captured) != 1
                or prediction.shape != (1,)
                or prediction.dtype != torch.float32
                or not torch.isfinite(prediction).all()
            ):
                raise ValueError("Single production forward/observer return validation")
            counters["validated"] += 1
            logit, residual = captured[0]
            loss = torch.nn.functional.mse_loss(prediction, target, reduction="mean")
            counters["gradient_attempted"] += 1
            gradients = torch.autograd.grad(
                loss, (residual, *parameters), retain_graph=False, create_graph=False
            )
            counters["gradient_returned"] += 1
            if not torch.isfinite(loss) or not all(torch.isfinite(g).all() for g in gradients):
                raise ValueError("Finite actual current known-label loss gradients")
            counters["gradient_validated"] += 1
            v = float(prediction.detach()[0])
            results.append(
                {
                    "ordinal": ordinal,
                    "record_SHA256": row["record_SHA256"],
                    "actual_QF1_D_STM_input_SHA256": actual_input_SHA256,
                    "model_key_28B_hex": row["model_key_28B_hex"],
                    "z": row["z"],
                    "u": float(logit.detach()[0]),
                    "r": float(residual.detach()[0]),
                    "v": v,
                    "current_row_MSE_FP32": float(loss.detach()),
                    "local_sensitivity_FP64_from_FP32_v": 1 - v * v,
                    "actual_autograd_dloss_dresidual_FP32": float(gradients[0][0]),
                    "parameter_gradient_norms_FP64": {
                        name: {
                            "L2": float(torch.linalg.vector_norm(g.double())),
                            "maxabs": float(g.double().abs().max()),
                            "nonzero": int(torch.count_nonzero(g)),
                        }
                        for name, g in zip(names, gradients[1:], strict=True)
                    },
                    "perspective": "native canonical STM0, Torchside1; original unreflected geometry",
                    "history_family": "NOT_SAVED",
                    "gradient_scope": "CURRENT specified singleton original row-MSE in eval mode; not past training or batch gradient",
                }
            )
            del gradients, loss, prediction, captured, x, distance, side, target
    except BaseException as error:
        primary = error
    finally:
        parameters_unchanged = statistics_unchanged = optimizer_or_grad_accumulation = None
        try:
            parameters_unchanged = parameter_bytes() == before
            statistics_unchanged = buffer_bytes() == buffers
            optimizer_or_grad_accumulation = any(p.grad is not None for p in parameters)
        except BaseException as error:
            secondary.append(error)
        report = {
            "schema": "quoridor.nnue-causal.current-gradients.v1",
            "counters": counters,
            "rows": results,
            "parameters_bit_unchanged": parameters_unchanged,
            "statistics_bit_unchanged": statistics_unchanged,
            "optimizer_present": False,
            "parameter_grad_accumulated": optimizer_or_grad_accumulation,
            "new_geometry_Search": 0,
            "historical_training_gradients": "NOT_SAVED",
            "history_causation": "UNKNOWN",
            "model_source": config["bindings"],
            "current_vs_historical": "actual current compatible original objective gradient, not a historical-gradient reconstruction",
            "status": "FAILED"
            if primary is not None or secondary
            else "RETURNED_PENDING_EXECUTION_VERIFICATION",
            "primary_error": None
            if primary is None
            else {"type": type(primary).__name__, "message": str(primary)},
            "secondary_errors": [
                {"type": type(error).__name__, "message": str(error)} for error in secondary
            ],
        }
        try:
            with Path(config["output"]).open("x") as stream:
                json.dump(report, stream, indent=2, allow_nan=False)
                stream.write("\n")
        except BaseException as error:
            secondary.append(error)
    raise_retained_errors(primary, secondary)
    if not parameters_unchanged or not statistics_unchanged or optimizer_or_grad_accumulation:
        raise ValueError("Read-only diagnostic model/statistics invariant")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    arguments = parser.parse_args()
    run(json.loads(arguments.config.read_text()))
