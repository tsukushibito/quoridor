"""Finite32-gradient entry; immutable admission and related clear are required.

No numerical imports occur here. Reuses the maintained exact child ownership
helper and this phase's named census; source-only until an actual admission is
supplied. This is a scoped temporary task caller, not a new science controller.
"""

import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time

ROOT = Path(__file__).resolve().parent
LOCK = Path("/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock")
REPAIR = ROOT / "gradient-repair-v2"


def check_identity(path, identity):
    p = Path(path)
    s = p.lstat()
    if not stat.S_ISREG(s.st_mode) or s.st_size != identity["bytes"]:
        raise ValueError("Regular exact source/input: " + str(p))
    raw = p.read_bytes()
    if hashlib.sha256(raw).hexdigest() != identity["SHA256"]:
        raise ValueError("Exact source/input digest: " + str(p))
    if f"{stat.S_IMODE(s.st_mode):04o}" != identity["mode"]:
        raise ValueError("Exact source/input mode: " + str(p))
    return raw


def verify_related_clear(summary):
    """Consume the hash-bound receipt itself; copied admission fields cannot clear it."""
    actual = json.loads(check_identity(summary["path"], summary["identity"]))
    if (
        actual.get("schema") != "quoridor.current-gradient.source-review.v1"
        or actual.get("issue") != "quoridor-4lc.342.12"
        or actual.get("reviewed_boundary") != "current-known-label-loss-gradient"
        or actual.get("source_clear") is not True
        or type(actual.get("blockers")) is not int
        or actual["blockers"] != 0
        or type(actual.get("owned_remaining")) is not list
        or actual["owned_remaining"] != []
        or type(actual.get("owned_children_jobs_readers_TMP")) is not list
        or actual["owned_children_jobs_readers_TMP"] != []
    ):
        raise ValueError("Actual gradient+guard receipt is not source clear")
    expected = {
        "target_binding_SHA256": hashlib.sha256(
            (REPAIR / "caller-source-STOP.json").read_bytes()
        ).hexdigest(),
        "guard_binding_SHA256": hashlib.sha256(
            (REPAIR / "guard-source-STOP.json").read_bytes()
        ).hexdigest(),
    }
    for field, value in expected.items():
        if actual.get(field) != value:
            raise ValueError("Actual reviewed binding differs: " + field)
    stop = actual.get("actual_reader_STOP")
    if not isinstance(stop, str):
        raise ValueError("Actual reviewer STOP missing")
    moment = datetime.datetime.fromisoformat(stop)
    if moment.tzinfo is None or moment > datetime.datetime.now(datetime.timezone.utc):
        raise ValueError("Actual reviewer STOP invalid/future")
    for field in (
        "reviewed_boundary",
        "target_binding_SHA256",
        "guard_binding_SHA256",
        "source_clear",
        "blockers",
        "actual_reader_STOP",
        "owned_remaining",
        "owned_children_jobs_readers_TMP",
    ):
        if (
            field not in summary
            or type(summary[field]) is not type(actual[field])
            or summary[field] != actual[field]
        ):
            raise ValueError("Admission summary differs from actual receipt: " + field)
    return actual


def raise_finalization_facts(primary, secondary):
    """Retain facts even when the STOP artifact itself cannot be published."""
    if primary is None and not secondary:
        return
    first = primary if primary is not None else RuntimeError("Finalization facts")
    first.retained_finalization_facts = tuple(secondary)
    if secondary:
        first.add_note("all retained finalization facts: " + json.dumps(secondary))
    raise first


def run(admission):
    beginning = time.monotonic()
    with LOCK.open("a+b") as lease:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        for path, identity in admission["source_input_map"].items():
            check_identity(path, identity)
        for path, identity in admission["framework_identity"].items():
            check_identity(path, identity)
        # Related clear is bound to an actual reviewed caller version, never task closure.
        verify_related_clear(admission["related_clear"])
        proof_path = Path(
            "/workspaces/quoridor/research-data/ai-sigma/teacher-distance-tanh-v1/causal-resources-v2.json"
        )
        raw_proof = proof_path.read_bytes()
        if (
            hashlib.sha256(raw_proof).hexdigest()
            != "a380de4b0db484763a8353acda7ade7abeece8bb48151901db9a7193c5a7370a"
        ):
            raise ValueError("Issued whole proof")
        phase = json.loads(raw_proof)["phases"]["learner"]
        if phase["whole_B"] != 536870912 or sum(phase["components_B"].values()) != phase["whole_B"]:
            raise ValueError("Whole allocation")
        from run_saved import quiet

        quiet()
        mem = dict(line.split(":", 1) for line in Path("/proc/meminfo").read_text().splitlines())
        available = int(mem["MemAvailable"].split()[0]) * 1024
        fs = os.statvfs(ROOT)
        free = fs.f_bavail * fs.f_frsize
        if available < 6 * 1024**3 or free < phase["whole_B"]:
            raise ValueError("Fresh family2GiB+host4GiB/filesystem")
        if not {1, 3}.issubset(os.sched_getaffinity(0)):
            raise ValueError("CPU1 worker/CPU3 controller")
        pairs = []
        for cpu in (1, 3):
            topology = Path(f"/sys/devices/system/cpu/cpu{cpu}/topology")
            pairs.append(
                tuple(
                    (topology / name).read_text().strip()
                    for name in ("physical_package_id", "core_id")
                )
            )
        if pairs[0] == pairs[1]:
            raise ValueError("Distinct physical controller/worker cores")
        os.sched_setaffinity(0, {3})
        sys.path.insert(0, "/workspaces/quoridor/.worktree/learning-million/python")
        import quoridor_training.cycle_process as process

        class Family:
            def __init__(self):
                self.deadline = time.monotonic() + 120
                self.peak_sample_B = 0
                self.allocated_sample_B = 0

            def check(self, owned=()):
                if time.monotonic() >= self.deadline:
                    raise RuntimeError("Finite diagnostic operational120s")
                infos = [
                    process.process_info(os.getpid()),
                    *(process.process_info(x["pid"]) for x in owned),
                ]
                rss = sum(i["rss"] for i in infos if i) + 64 * 1024**2
                self.peak_sample_B = max(self.peak_sample_B, rss)
                if rss > 2 * 1024**3:
                    raise RuntimeError("Family2GiB including64MiB controller reserve")
                total = 0
                for path in ROOT.rglob("*"):
                    if path.is_symlink():
                        raise RuntimeError("Owned phase symlink")
                    # A disappearing owned temporary file is already below this census.
                    try:
                        total += path.stat().st_blocks * 512
                    except FileNotFoundError:
                        continue
                self.allocated_sample_B = max(self.allocated_sample_B, total)
                if (
                    total > admission["inclusive_phase_prewrite_upper_B"]
                    or total > phase["whole_B"]
                ):
                    raise RuntimeError("Inclusive named phase allocation")

        family = Family()
        family.check()
        directory = ROOT / "current-gradient-runtime-v1"
        directory.mkdir()
        tmp = directory / "TMP"
        tmp.mkdir()
        os.environ.update(
            TMPDIR=str(tmp),
            PYTHONDONTWRITEBYTECODE="1",
            OMP_NUM_THREADS="1",
            OPENBLAS_NUM_THREADS="1",
            MKL_NUM_THREADS="1",
            CUDA_VISIBLE_DEVICES="",
        )
        argv = [
            admission["interpreter"],
            "-B",
            str(ROOT / "current_gradients.py"),
            str(ROOT / "current-gradient-plan.json"),
        ]
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (directory / "START.json").write_text(
            json.dumps(
                {
                    "START": start,
                    "identity": process.identity(process.process_info(os.getpid())),
                    "argv": argv,
                    "source_input_map": admission["source_input_map"],
                    "framework_identity": admission["framework_identity"],
                    "fresh_peer_fact": admission["peer_fact"],
                    "physics": {
                        "available_B": available,
                        "filesystem_free_B": free,
                        "CPU_pair": pairs,
                    },
                    "forward_gradient_plan": [32, 32],
                },
                indent=2,
            )
            + "\n"
        )
        returned = None
        primary = None
        secondary = []
        try:
            returned = process.execute(
                argv, directory / "gradient.log", family.deadline, cpu_core=1, resources=family
            )
        except BaseException as error:
            primary = error
        finally:
            cleanup_record = returned
            if cleanup_record is None:
                try:
                    cleanup_record = json.loads((directory / "gradient.process.json").read_text())
                except BaseException as error:
                    secondary.append(
                        {
                            "stage": "failed_raw_census",
                            "type": type(error).__name__,
                            "message": str(error),
                        }
                    )
            verified_empty = bool(
                cleanup_record
                and cleanup_record.get("direct_child_reaped") is True
                and cleanup_record.get("cleanup_complete") is True
                and type(cleanup_record.get("remaining")) is list
                and cleanup_record["remaining"] == []
                and cleanup_record.get("child")
                and not process.alive(cleanup_record["child"])
            )
            for path, identity in admission["source_input_map"].items():
                try:
                    check_identity(path, identity)
                except BaseException as error:
                    secondary.append(
                        {
                            "stage": "source_after",
                            "type": type(error).__name__,
                            "message": str(error),
                        }
                    )
            if verified_empty:
                try:
                    tmp.rmdir()
                except BaseException as error:
                    secondary.append(
                        {
                            "stage": "retain_nonempty_or_failed_TMP",
                            "type": type(error).__name__,
                            "message": str(error),
                        }
                    )
            else:
                secondary.append({"stage": "cleanup_census_UNKNOWN_or_nonempty;TMPretained"})
            stop = datetime.datetime.now(datetime.timezone.utc).isoformat()
            receipt = {
                "START": start,
                "STOP": stop,
                "whole_controller_s": time.monotonic() - beginning,
                "returned_process": returned,
                "primary": None
                if primary is None
                else {"type": type(primary).__name__, "message": str(primary)},
                "secondary": secondary,
                "remaining": [] if verified_empty else None,
                "TMP_retained": tmp.exists(),
                "sample_family_RSS_with64MiB_B": family.peak_sample_B,
                "sample_allocated_B": family.allocated_sample_B,
                "continuous_peaks": "UNKNOWN",
                "nested_spans_not_added": True,
                "old_assets_fees_masks_UNKNOWN": "held",
                "scientific_result": "NOT_INFERRED; verify caller counters/input/bits/report separately",
            }
            try:
                (directory / "STOP.json").write_text(
                    json.dumps(receipt, indent=2, allow_nan=False) + "\n"
                )
            except BaseException as error:
                secondary.append(
                    {
                        "stage": "STOP_publication",
                        "type": type(error).__name__,
                        "message": str(error),
                    }
                )
                if primary is None:
                    primary = error
        raise_finalization_facts(primary, secondary)
        print(json.dumps({"START": start, "STOP": stop, "receipt": str(directory / "STOP.json")}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("admission", type=Path)
    args = parser.parse_args()
    run(json.loads(args.admission.read_text()))
