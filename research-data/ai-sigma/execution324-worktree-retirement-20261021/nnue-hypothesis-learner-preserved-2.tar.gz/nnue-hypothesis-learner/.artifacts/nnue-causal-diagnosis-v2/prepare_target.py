"""Freeze one shared result-blind diagnostic selection from directed metadata.

No numerical framework, geometry library, model, search, or corpus payload is used.
Pending replay/input/proposal qualifications are never converted to success here.
"""

import hashlib
import json
import stat
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path(
    "/workspaces/quoridor/.worktree/learning-million/.artifacts/value-residual-diagnostic-v1"
)
CONTRACT = Path("/workspaces/quoridor/research-data/ai-sigma/teacher-distance-tanh-v1")
ANCHOR_SOURCE = Path(
    "/workspaces/quoridor/.worktree/nnue-hypothesis-learner/"
    "crates/quoridor-data/tests/terminal_teachers.rs"
)
SELECTED = ("R3", "R6", "C1", "C2")
CURRENT_RULES = "research-standard-2p-threefold-goal-first-v1"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def compact_sha(value):
    return digest(json.dumps(value, separators=(",", ":")).encode())


def read_bound(path, expected=None):
    path = Path(path)
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > 2 * 1024 * 1024:
        raise ValueError(f"Not a bounded regular metadata source: {path}")
    data = path.read_bytes()
    identity = {
        "path": str(path),
        "SHA256": digest(data),
        "bytes": len(data),
        "mode": f"{stat.S_IMODE(info.st_mode):04o}",
    }
    if expected is not None and identity["SHA256"] != expected:
        raise ValueError(f"Source binding mismatch: {path}")
    return data, identity


def proposal_stage(original, kind):
    return {
        "original": {
            "action": original,
            "kind": kind,
            "qualification": "historical accepted or synthetic expected; current legality PENDING",
        },
        "D": {"action": None, "status": "PENDING_DEPTH2"},
        "NNUE": {"action": None, "status": "PENDING_DEPTH2"},
        "union": None,
        "union_status": "NOT_FROZEN",
    }


def build():
    refs = []

    def load(path, expected=None):
        data, identity = read_bound(path, expected)
        refs.append(identity)
        return json.loads(data)

    fixed = load(
        OLD / "fixed-set-v1.json",
        "d80dd87d75495f5a4743d38d60439bc94f6d9296c0a8ffdebe8cbbf7aedc1d28",
    )
    binding = load(OLD / "binding.json")
    freeze = load(OLD / "entry-v2/data/inputs/input-freeze.json")
    if freeze["fixed_set_SHA256"] != refs[0]["SHA256"]:
        raise ValueError("Input freeze belongs to another historical selection")
    resource = load(
        CONTRACT / "causal-resources-v2.json",
        "a380de4b0db484763a8353acda7ade7abeece8bb48151901db9a7193c5a7370a",
    )
    load(
        CONTRACT / "causal-gradient-contract-v3.json",
        "481a33d08d372578c006795a21ca33831c24245ed4776d3bcd76e606c09d8167",
    )
    corrected = load(OLD / "caller-v3/report-r2-STOP-binding.json")
    for path, identity in corrected["refs"].items():
        if path.endswith(("report-r2.md", "components.json", "saved-component-analysis.json")):
            _, actual = read_bound(path, identity["SHA256"])
            refs.append(actual)
    anchor_bytes, anchor_identity = read_bound(ANCHOR_SOURCE)
    refs.append(anchor_identity)
    anchors = [
        (
            "G1",
            "synthetic_legal_goal_anchor",
            [3, 77, 12, 68, 21, 59, 30, 50, 39, 41, 48, 32, 57, 23, 66, 14],
            75,
            "Goal",
            [0, 1],
        ),
        (
            "T1",
            "synthetic_legal_threefold_anchor",
            [13, 75, 14, 76, 13, 75, 14, 76],
            13,
            "Threefold",
            [7, 8],
        ),
    ]
    # Source guards prove these are selected existing fixtures, not newly invented histories.
    source = anchor_bytes.decode()
    if "3, 77, 12, 68, 21, 59, 30, 50, 39, 41, 48, 32, 57, 23, 66, 14, 75" not in source:
        raise ValueError("Goal fixture changed")
    if "13, 75, 14, 76, 13, 75, 14, 76, 13" not in source:
        raise ValueError("Threefold fixture changed")
    rows = {row["id"]: row for row in fixed["rows"]}
    inputs = {row["root"]: row for row in freeze["parents"]}
    parents = []
    for parent_id in SELECTED:
        row = rows[parent_id]
        prefix = row["prefix_actions"]
        if compact_sha(prefix) != row["prefix_binding_SHA256"]:
            raise ValueError(f"Prefix digest mismatch: {parent_id}")
        parents.append(
            {
                "id": parent_id,
                "stratum": "historical_failure"
                if parent_id.startswith("R")
                else "historical_control",
                "selection_basis": row["rationale"],
                "original_open_evidence": {
                    k: row[k]
                    for k in [
                        "run",
                        "game",
                        "family",
                        "candidate_color",
                        "observation_binding_SHA256",
                        "authoritative_move_file",
                        "authoritative_move_file_SHA256",
                        "saved_root_value_stm",
                        "saved_completed_depth",
                        "saved_PV",
                        "saved_root_value_scope",
                    ]
                },
                "original_source_commit": fixed["game_source_commit"],
                "original_ruleset": fixed["rules"],
                "prefix_actions": prefix,
                "prefix_SHA256": row["prefix_binding_SHA256"],
                "ply": row["absolute_ply"],
                "original_geometry": row["geometry"],
                "native_side": row["geometry"]["turn"],
                "absolute_player": row["geometry"]["turn"] + 1,
                "full_counted_history": {
                    "encoding": "complete genuine prefix from initial, including initial and every accepted state",
                    "materialized_pairs": None,
                    "materialized_status": "NOT_SAVED_IN_EXCERPT; exact current replay required",
                    "historical_SHA256": row["history_binding_SHA256"],
                    "historical_definition": row["history_binding_definition"],
                    "historical_distinct_states": row["history_distinct_states"],
                    "historical_max_prior_count": row["history_max_prior_count"],
                },
                "historical_input": inputs[parent_id],
                "current_mapping": {
                    "ruleset": CURRENT_RULES,
                    "status": "PENDING",
                    "requirements": [
                        "all prefix actions accepted from genuine initial state",
                        "same geometry/STM/ply and counted chronology",
                        "parent nonterminal under goal-first/legal-third/200 policy",
                        "exact two-view QF1 and FP32 D/80 bits match historical input",
                    ],
                    "refusal": "UNKNOWN in original planned slot; no replacement or invented history",
                    "historical_outcome_relabelled_current": False,
                },
                "candidates": proposal_stage(row["saved_accepted_action"], "historical_actual"),
                "teacher_label": {
                    "status": "NOT_SAVED_COMPATIBLE_ORIGINAL_OBJECTIVE",
                    "value": None,
                },
            }
        )
    for parent_id, stratum, prefix, action, terminal, distances in anchors:
        parents.append(
            {
                "id": parent_id,
                "stratum": stratum,
                "selection_basis": "existing maintained terminal fixture, selected before diagnostic output",
                "original_open_evidence": {
                    "kind": "SYNTHETIC_LEGAL_FIXTURE",
                    "source": anchor_identity,
                    "terminal_after_original_action": terminal,
                    "terminal_D_p1_p2": distances,
                },
                "original_ruleset": CURRENT_RULES,
                "prefix_actions": prefix,
                "prefix_SHA256": compact_sha(prefix),
                "ply": len(prefix),
                "native_side": len(prefix) % 2,
                "absolute_player": len(prefix) % 2 + 1,
                "full_counted_history": {
                    "encoding": "complete synthetic legal prefix from initial",
                    "materialized_pairs": None,
                    "materialized_status": "PENDING_EXACT_REPLAY",
                },
                "current_mapping": {
                    "ruleset": CURRENT_RULES,
                    "status": "PENDING",
                    "requirements": [
                        "exact legal prefix replay and complete counted history",
                        "parent nonterminal, expected action reaches bound terminal",
                        "qualified QF1+FP32 D/80 input",
                    ],
                    "refusal": "UNKNOWN; no replacement",
                },
                "historical_input": None,
                "candidates": proposal_stage(action, "synthetic_terminal_expected"),
                "teacher_label": {"status": "NO_ORIGINAL_TRAINING_TEACHER", "value": None},
            }
        )
    model = binding["trained_model_expected_metadata_only"]
    return {
        "schema": "quoridor.nnue-causal.diagnostic-target.v1",
        "issue": "quoridor-4lc.342.9",
        "engineering_issue": "quoridor-4lc.342.10",
        "stage": "SELECTION_FROZEN_MAPPING_AND_PROPOSALS_PENDING",
        "selection_frozen_before_new_outputs": True,
        "selection": {
            "parent_ids": [p["id"] for p in parents],
            "purpose": "two documented failures, neutral/winning controls, legal goal/threefold anchors",
            "population_limitations": "purposive correlated historical RuleA observations plus synthetic anchors; no universal cause, regret, strength or current-clock cohort inference",
            "no_fallback_parents": True,
        },
        "parents": parents,
        "model": {
            "name": "trained BEST51 legacy residual",
            "expected": model,
            "source_and_scale_refs": binding["metadata_and_sources"],
            "units": "fixed u=8*(d_opp-d_STM), d=wall-only D/80 before T standardization; residual uses T-only (d-mu)/sigma; output tanh(u+r), not future raw-step F80",
            "teacher_objective": "original known decisive z MSE on tanh(u+r); arena outcome not automatically a compatible training label",
            "coupling_status": "REUSED_METADATA; actual runtime payload/framework/input/source qualification required",
        },
        "candidate_selection": {
            "engines": ["fixedD(a0,b8)", "BEST51 NNUE"],
            "existing_genuine_search_proposals_available": False,
            "procedure": "after exact mapping, depth2 natural D and NN searches select proposals; reuse matching results in depth ladder; deduplicate original+D+NN in that order, at most3; freeze actions and source/input/result identities before forced/deeper/100ms outcomes",
            "old340_min_pawn_H_V_are_search_proposals": False,
            "incomplete": "retain parent/candidate planned denominator UNKNOWN; no fallback/retry",
        },
        "campaign_envelope": {
            "parents": 6,
            "depths": [2, 4, 6],
            "engines_per_parent": 2,
            "natural_depth2_proposal_calls_included": 12,
            "natural_plus_forced_search_calls_upper": 144,
            "formula": "6 parents * 2 engines * 3 depths * (1 natural + at most3 forced)",
            "same_parent_100ms_windows_upper": 12,
            "aggregate_nodes_upper": 256000000,
            "per_search_nodes_upper": 8000000,
            "common_depth2_tree_expanded_or_leaf_nodes_upper": 1000000,
            "complete_all_legal_responses_or_INCOMPLETE": True,
            "trace_paths_upper": 128,
            "standalone_scores_upper": 256,
            "exact_schedule_status": "PENDING_ENGINEERING_BOUND_IMAGE_AND_MAPPING; no numeric entry from packet alone",
        },
        "learner_envelope": {
            "OPEN_known_labelled_rows_upper": 4096,
            "offtrajectory_inputs_upper": 128,
            "new_BEST51_fullforwards_upper": 256,
            "current_loss_gradients_upper_included_in_forwards": 32,
            "actual_subset_input_metrics_callcount": "PENDING separate fixed admission before model execution",
            "historical_gradients": "NOT_SAVED; 1-v*v is local sensitivity only",
        },
        "resource_proof": {
            "path": str(CONTRACT / "causal-resources-v2.json"),
            "SHA256": "a380de4b0db484763a8353acda7ade7abeece8bb48151901db9a7193c5a7370a",
            "learner_whole_B": resource["phases"]["learner"]["whole_B"],
        },
        "references": refs,
        "new_execution_counts": {
            "geometry": 0,
            "forward": 0,
            "gradient": 0,
            "search": 0,
            "caller_window": 0,
        },
        "not_authorized": [
            "N/fullschedule/pilot inclusion",
            "generation/fit/cache/export",
            "sealed labels or paused323 resume",
            "changed weights/teacher/features/TT/search/clock/default",
        ],
    }


def main():
    packet = build()
    target = ROOT / "diagnostic-target.json"
    with target.open("x") as output:
        json.dump(packet, output, indent=2)
        output.write("\n")
    print(
        json.dumps(
            {
                "path": str(target),
                "SHA256": digest(target.read_bytes()),
                "parent_ids": packet["selection"]["parent_ids"],
                "stage": packet["stage"],
            }
        )
    )


if __name__ == "__main__":
    main()
