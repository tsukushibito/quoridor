# Fixed32 current loss-gradient observation

Executed once: 2026-10-09T12:56:28.604282+00:00 through 2026-10-09T12:56:30.548643+00:00. Thirty-two planned singleton forwards and actual autograd calls were attempted, returned and validated. The exact ordinal, original 66-byte record SHA, known label and QF1+D key match the frozen census. Parameters and T-only statistics remained bit unchanged; no optimizer, accumulated parameter.grad, geometry, native or Search calls occurred.

This fixed subset has mean original row MSE 0.405828829; correct/wrong/zero signs 27/5/0. 8/32 outputs have |v| >= .99, 2/32 equal +/-1. The measured residual loss derivative is exactly zero on 2/32 rows, including 0 wrong-sign rows. These are saved FP32 execution observations on a small fixed subset, not a general calibration or ranking claim.

The loss is the original singleton MSE on tanh(u+r) against the existing +/-1 outcome label. Local 1-v² is computed in FP64 from saved FP32 v and is reported separately from actual autograd. Current eval gradients do not reconstruct historical training gradients, the optimizer trajectory, batch gradients or defeat causation. A same-state action-ranking diagnosis still needs the common engineering campaign; adjacent positions and different teacher outcomes are not counterfactual regret.

| Original ordinal |   z |      saved v | current MSE | sensitivity 1-v² | actual dloss/dr |
| ---------------: | --: | -----------: | ----------: | ---------------: | --------------: |
|                0 |   1 | -0.896939099 |   3.5983777 |      0.195500253 |    -0.741704106 |
|           189256 |  -1 |  0.324342281 |  1.75388241 |      0.894802085 |      2.37004852 |
|            81066 |   1 | -0.190368205 |  1.41697645 |      0.963759946 |     -2.29445839 |
|           202767 |  -1 | 0.0947929695 |  1.19857168 |      0.991014293 |      2.16991091 |

The 4096 permitted OPEN rows have 3443 exact QF1+D keys and 70 mixed-outcome groups. Different outcomes for the same input are normal in collected selfplay and are descriptive teacher variation; missing original history/family/policy-model chronology prevents attribution. No deletion, deduplication, relabelling or deterministic-teacher preference follows.

Direct wait/reap and exact guard/child identity absence were verified; owned TMP is gone and source/input SHA-size-mode match after execution. Whole controller cost is 2.033726436 seconds; nested child 1.926882264 seconds is not added. Family sampled RSS including64MiB controller reserve is773111808B; continuous peak remains UNKNOWN. Returned signal-mask/final-record completion and persisted pending/attempted remain distinct. Old failures/assets/caps/fees/UNKNOWN remain held.

Current model/Cargo/fair reservation is NONE. This report is a bounded execution observation; the six-parent same-depth/forced/trace/time campaign and combined causal interpretation remain pending. No N, fit, export, labels, model, teacher, feature, clock or default choice was changed.
