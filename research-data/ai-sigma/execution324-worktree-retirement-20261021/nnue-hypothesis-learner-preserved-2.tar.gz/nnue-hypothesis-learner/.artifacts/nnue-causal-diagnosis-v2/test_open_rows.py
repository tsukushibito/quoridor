"""New saved-record boundary regressions; synthetic records only."""

import json
from pathlib import Path
import tempfile
import unittest

from inspect_open_rows import RECORD, decode, inspect, sha


def record(label=1, distance=0.1):
    return RECORD.pack(4, 76, 10, 10, 0, 0, distance, 0.2, label, 0, 3, bytes(32))


class SavedBoundaryTests(unittest.TestCase):
    def test_framing_and_invalid_fields_refuse(self):
        for raw in (record()[:-1], record(label=2), record(distance=float("nan"))):
            with self.subTest(raw=raw.hex()), self.assertRaises(ValueError):
                decode(raw)

    def test_model_key_keeps_distance_bits_and_drops_label_identity(self):
        first = decode(record(1))
        second = decode(record(-1))
        self.assertEqual(first["model_key_28B_hex"], second["model_key_28B_hex"])
        self.assertNotEqual(first["record_SHA256"], second["record_SHA256"])
        self.assertNotEqual(
            first["model_key_28B_hex"], decode(record(distance=0.3))["model_key_28B_hex"]
        )

    def test_conflict_is_observation_with_history_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "synthetic.bin"
            raw = record(1) + record(-1)
            source.write_bytes(raw)
            plan = {
                "validation": {
                    "path": str(source),
                    "bytes": len(raw),
                    "rows": 2,
                    "SHA256": sha(raw),
                },
                "ordinals": [0, 1],
                "synthetic": True,
            }
            result = inspect(plan)
            self.assertEqual(result["exact_model_input_unique"], 1)
            self.assertEqual(len(result["observed_label_disagreements_same_actual_input"]), 1)
            self.assertIn("UNKNOWN", result["history_explanation_of_disagreements"])
            self.assertEqual(result["new_geometry_model_gradient_Search_calls"], 0)
            self.assertTrue(json.dumps(result))

    def test_digest_and_duplicate_subset_refuse(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / "synthetic.bin"
            raw = record()
            source.write_bytes(raw)
            plan = {
                "validation": {
                    "path": str(source),
                    "bytes": len(raw),
                    "rows": 1,
                    "SHA256": "0" * 64,
                },
                "ordinals": [0],
            }
            with self.assertRaises(ValueError):
                inspect(plan)
            plan["ordinals"] = [0, 0]
            with self.assertRaises(ValueError):
                inspect(plan)


if __name__ == "__main__":
    unittest.main()
