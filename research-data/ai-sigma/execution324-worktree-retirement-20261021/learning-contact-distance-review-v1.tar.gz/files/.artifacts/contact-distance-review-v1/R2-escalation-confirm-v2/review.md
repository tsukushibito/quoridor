# Contact-distance337 remaining R2 confirmation

**R2 resolved in source/fake-port scope; blockers0, ordinary0.** Binding `8998a2f45443c8a5cd603d67afc2f92b58bc6a01edfe648502711e32f756e4c6`; STOP `bf9894ecc573edf159c2f7b664f581debec342adb3825ae164eff5227dd747ed`. All35 bound paths retain exact SHA/mode/size before/after. Worker `729f5c6a0000f0d636cf121d5aff814cc41627d123e9c713e360b8e7c476cd32`.

`worker.py:280–308` now records initial timeout, independently attempts group KILL, direct-handle KILL and second wait. Each failure is retained without skipping the next stage; group refusal marks descendant UNKNOWN. Reap success is set only after returned wait. Existing primary-object preservation, stream/selector/log/STOP attempts and outer unresolved cleanup refusal remain unchanged.

Independent actual `run`+`finish_child` AST fake-port cases: group refusal; direct refusal; both refusals plus second-wait IO. All attempted direct KILL once and wait twice, preserved the original START exception object, and attempted stdout close/STOP. The final case retained direct_child_reaped=false and descendant UNKNOWN and all three individual failures. No real Popen occurred. `probe.json` wall 0.020302646s, VmHWM19440KiB, CPU3/AS512MiB/GPU0; this is not live fault recovery or a family-peak certificate.

Delta SHA `6e28a63162116a951cbb4ba89f880bc997bd11e9fe9192a5119d94b1c83be785` reverse-applied in memory reproduces exact prior worker SHA8e689084; normalized AST outside only wait_direct is equal. No copied source or product/main/Git/index writes. Supplied three mock PASS cases/times are separate evidence, not replayed; old11 mocks and broad suites were not rerun.

Prior R1 normal-prefix and R3 canonical-controller source clear, contact/FP/rules/core/plan scopes are reused only unchanged. Nine library+one inlet Rust definitions, compiler/private/livefault/numeric remain NOT_RUN/unqualified. Prepared admissions stay false; this review alone submits/adopts nothing. Parent337 remains qualification/cost pending; 342.2,333,323 USERPAUSE/seals/defaults unaffected. All old64KiB+32KiB uppers/RAW/failures/fees/UNKNOWN held without reset/refund.

Reader/substantial-analysis STOP **2026-10-08T15:29:51.944450+00:00**, synchronous probes directly returned; owned readers/children/jobs remaining **[]**. New inclusive prewrite16384B; final allocation/admin costs in control. Permissions/cwd/model and fresh named quiet were checked before entry. Report once to337+324, close only review leaf and backup; no new role/method ACK.
