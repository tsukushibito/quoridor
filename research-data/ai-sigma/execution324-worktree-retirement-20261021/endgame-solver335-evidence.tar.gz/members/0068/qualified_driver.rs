//! Finite native qualification of the production solver, never a second rules engine.
//! The page allocator bounds user-space mappings, headers and rounding. Kernel VMA
//! accounting and process RSS are separate guardian facts, not a System proof.
use quoridor_ai::endgame::{
    AllocationBounds, SolverControl, SolverLimits, SolverOutcome, SolverRequest, Wdl, solve,
};
use quoridor_core::research::{Ruleset, SigmaContext};
use std::alloc::{GlobalAlloc, Layout};
use std::ffi::c_void;
use std::mem::size_of_val;
use std::ptr::null_mut;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::time::{Duration, Instant};

#[cfg(not(all(target_os = "linux", target_pointer_width = "64")))]
compile_error!("qualification allocator is Linux64 only");

unsafe extern "C" {
    fn mmap(p: *mut c_void, n: usize, prot: i32, flags: i32, fd: i32, off: i64) -> *mut c_void;
    fn munmap(p: *mut c_void, n: usize) -> i32;
    fn getpagesize() -> i32;
}

const PAGE: usize = 4096;
static ACTIVE: AtomicBool = AtomicBool::new(false);
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
static REQUESTED: AtomicUsize = AtomicUsize::new(0);
static CALLS: AtomicUsize = AtomicUsize::new(0);
static FAILED: AtomicUsize = AtomicUsize::new(0);

struct PageAllocator;
#[global_allocator]
static ALLOCATOR: PageAllocator = PageAllocator;

// Each mapping has one header page plus ceil(request/PAGE) payload pages.
// Alignment<=PAGE is supported. Reserve growth/realloc is accounted through
// GlobalAlloc's allocate-copy-free default; the solver reserves each vector once.
unsafe impl GlobalAlloc for PageAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        if layout.align() > PAGE {
            FAILED.fetch_add(1, Ordering::Relaxed);
            return null_mut();
        }
        let Some(bytes) = layout
            .size()
            .checked_add(PAGE - 1)
            .map(|n| n / PAGE * PAGE)
            .and_then(|n| n.checked_add(PAGE))
        else {
            FAILED.fetch_add(1, Ordering::Relaxed);
            return null_mut();
        };
        // Linux MAP_PRIVATE|MAP_ANONYMOUS and PROT_READ|PROT_WRITE.
        let base = unsafe { mmap(null_mut(), bytes, 3, 0x22, -1, 0) };
        if base as isize == -1 {
            FAILED.fetch_add(1, Ordering::Relaxed);
            return null_mut();
        }
        let tracked = ACTIVE.load(Ordering::Relaxed);
        let header = base.cast::<usize>();
        unsafe {
            header.write(bytes);
            header.add(1).write(usize::from(tracked));
        }
        if tracked {
            CALLS.fetch_add(1, Ordering::Relaxed);
            REQUESTED.fetch_add(layout.size(), Ordering::Relaxed);
            let live = LIVE.fetch_add(bytes, Ordering::Relaxed) + bytes;
            PEAK.fetch_max(live, Ordering::Relaxed);
        }
        unsafe { base.cast::<u8>().add(PAGE) }
    }

    unsafe fn dealloc(&self, ptr: *mut u8, _layout: Layout) {
        let base = unsafe { ptr.sub(PAGE) };
        let header = base.cast::<usize>();
        let bytes = unsafe { header.read() };
        let tracked = unsafe { header.add(1).read() } != 0;
        let status = unsafe { munmap(base.cast(), bytes) };
        if status != 0 {
            // A failed release is never silently treated as freed.
            FAILED.fetch_add(1, Ordering::Relaxed);
        } else if tracked {
            LIVE.fetch_sub(bytes, Ordering::Relaxed);
        }
    }
}

const PREFIX: [u16; 60] = [
    145, 146, 150, 151, 152, 161, 162, 166, 167, 168, 177, 178, 182, 183, 184, 193, 194, 198, 199,
    200, 3, 67, 4, 58, 3, 49, 4, 40, 3, 31, 4, 22, 3, 13, 4, 22, 13, 31, 22, 13, 21, 22, 20, 13,
    11, 22, 2, 13, 3, 22, 4, 21, 3, 12, 4, 13, 3, 22, 4, 13,
];

fn run_case(name: &str, prefix: &[u16], backing: usize, expected: Wdl) -> bool {
    // Preconditions must be canonical and genuine. A refusal is retained as such.
    let root = match SigmaContext::from_prefix_with_rules(prefix, Ruleset::Standard2pThreefold) {
        Ok(root) => root,
        Err(error) => {
            println!("REFUSAL name={name} error={error:?}");
            return false;
        }
    };
    let legal = root.legal_ids();
    let before = root.position();
    for invocation in 0..2 {
        LIVE.store(0, Ordering::Relaxed);
        PEAK.store(0, Ordering::Relaxed);
        REQUESTED.store(0, Ordering::Relaxed);
        CALLS.store(0, Ordering::Relaxed);
        let failures_before = FAILED.load(Ordering::Relaxed);
        let cancelled = || false;
        let control = SolverControl {
            cancelled: &cancelled,
            operational_ply_cap: Some(200),
            allocation_bounds: Some(AllocationBounds {
                source_ref: "QUALIFIED_LINUX4096_PAGEALLOC_SOURCE_BOUND",
                path_overhead_bytes: 2 * PAGE,
                kernel_overhead_bytes: 4 * 2 * PAGE,
            }),
        };
        let request = SolverRequest {
            rules_id: Ruleset::Standard2pThreefold.id(),
            context: prefix,
            context_retained_bytes: Some(backing),
            limits: SolverLimits {
                max_nodes: 4096,
                max_edges: 4096,
                max_frames: 32,
                max_history_entries: 128,
                max_memo_entries: 256,
                max_heap_bytes: 4 * 1024 * 1024,
                max_elapsed: Duration::from_millis(100),
            },
        };
        ACTIVE.store(true, Ordering::Relaxed);
        let start = Instant::now();
        let report = solve(request, &control);
        let elapsed = start.elapsed();
        ACTIVE.store(false, Ordering::Relaxed);
        let calls = CALLS.load(Ordering::Relaxed);
        let peak = PEAK.load(Ordering::Relaxed);
        let requested = REQUESTED.load(Ordering::Relaxed);
        let live = LIVE.load(Ordering::Relaxed);
        let failures = FAILED.load(Ordering::Relaxed) - failures_before;
        let allocations_valid = calls <= 5
            && peak <= requested + calls * 2 * PAGE
            && peak <= report.work.heap_bytes_peak
            && live == 0
            && failures == 0;
        let correct = match &report.outcome {
            SolverOutcome::Proven(proof) => {
                proof.value() == expected
                    && match proof.best_move() {
                        Some(action) => legal.contains(&action.id()),
                        None => root.terminal_value().is_some(),
                    }
            }
            // A finite refusal is retained; it never certifies the candidate WDL.
            SolverOutcome::Unknown { .. } => true,
            SolverOutcome::NotApplicable(_) => false,
        };
        println!(
            "CASE name={name} invocation={invocation} correct={correct} allocation_valid={allocations_valid} calls={calls} requested={requested} mapped_peak={peak} live={live} failed={failures} whole_ns={} report={report:?}",
            elapsed.as_nanos()
        );
        if !correct || !allocations_valid || root.position() != before {
            return false;
        }
    }
    true
}

fn main() {
    assert_eq!(unsafe { getpagesize() }, PAGE as i32);
    let mut draw = [0u16; 62];
    draw[..60].copy_from_slice(&PREFIX);
    draw[60..].copy_from_slice(&[3, 4]);
    let mut goal = [0u16; 58];
    goal[..56].copy_from_slice(&PREFIX[..56]);
    goal[56..].copy_from_slice(&[3, 4]);
    let mut near = [0u16; 34];
    near[..20].copy_from_slice(&PREFIX[..20]);
    near[20..].copy_from_slice(&[13, 75, 22, 66, 31, 57, 40, 48, 49, 39, 58, 30, 67, 21]);
    let mut obstructed = near;
    obstructed[19] = 141;
    let cases = [
        ("loss56", &PREFIX[..56], size_of_val(&PREFIX), Wdl::Loss),
        ("draw60", &PREFIX[..], size_of_val(&PREFIX), Wdl::Draw),
        ("turn57", &PREFIX[..57], size_of_val(&PREFIX), Wdl::Win),
        ("draw61", &draw[..61], size_of_val(&draw), Wdl::Draw),
        ("goal58", &goal[..], size_of_val(&goal), Wdl::Loss),
        ("near34", &near[..], size_of_val(&near), Wdl::Win),
        (
            "obstructed34",
            &obstructed[..],
            size_of_val(&obstructed),
            Wdl::Win,
        ),
    ];
    let mut passed = true;
    for (name, prefix, backing, expected) in cases {
        passed &= run_case(name, prefix, backing, expected);
    }
    assert!(
        passed,
        "fixed cases/refusals retained; no fabricated outcome"
    );
}
