# Fixed depth6 TT admission interpretation review

**Blockers0; ordinary findings0 for the frozen interpretation.** The claim that the listed completed zero-hit suffixes refused every attempted result insertion is supported by the compiled control flow and saved counters. This accepts a bounded interpretation of existing evidence; it grants no TT change, measured speed benefit, runtime qualification or new scientific entry.

Target: [interpretation-binding.json](/workspaces/quoridor/.worktree/search-optimization/.artifacts/depth6-tail-analysis-v1/interpretation-binding.json), SHA256 `da498ce8b00d810d2ebde664bd6cc42e45192f43d025c796b6126cd98051ff49`. Reviewed report English UTF8 SHA256 `0a5257b3351dd9971757560de6cc294049161ead4da8ce5020dfb0c28d89130e`; producer handoff `8be5860ff2ade34e2a356c2050dea69e59832f466dba00864027fbee1b2443e8`.

## Source and admission argument

The actual saved stream's second record identifies executable `a45b94d9423f25b7a5f8c03d79f00b6c1cd23a3798ff40f23033d828e395d4c9`. Its compiled map agrees with all seven selected source hashes and the supplied private/software STOP metadata. No private executable was opened and no current-Main identity was substituted. Thirty-one selected artifact/source/input references, 1,432,589 bytes altogether, matched SHA256/size/mode before and after. The seven source files total235881 bytes. The map includes alphabeta `bc7c25dd`, core research `b7897456` and execution `98889813`; the full digests and paths are in input-before.json and input-after-stop.json.

[alphabeta.rs](/workspaces/quoridor/.worktree/deeper-teacher-scheduling/crates/quoridor-ai/src/alphabeta.rs:747) enters recursive nodes, then returns terminal or depth-zero evaluations before constructing/probing a TT key. Every remaining node probes once. A successful TT cutoff can return before insertion, but requires a full-key hit. Otherwise a normally completed node, including an ordinary alpha-beta cutoff, reaches one result insertion. Root-depth calls similarly probe once and, absent a successful TT hit, insert once on normal completion. PVS retries are new invocations with their own probe/insertion pair. Invalid/empty moves, cancellation, evaluation/rule errors and failed child/undo paths exit through interruption; this argument is deliberately restricted to accepted DepthComplete returns.

Let P be probes, I attempted insertions and S byte-refusals for one such zero-hit completed call. The control flow gives I=P. Each invocation of insert can record at most one capacity skip, so S<=I. Thus the saved S=P implies S=I: every attempted result insertion reached the byte-budget refusal. This uses the source/completion preconditions, not counter equality alone. An interrupted search could have probes without corresponding insertion attempts; replacement0 alone also says nothing about admission into previously empty slots.

Independent arithmetic was limited to the reported suffix predicates and counts. Every listed row has positive probes, hits/replacements/bound-cutoffs/order-only/usable-depth0, capacity_skips=probes, retained bytes1048576. Additional counter corroboration is hashes=2*probes and constructed keys=probes+6, consistent with one instrumented probe and one insertion hash per attempted result, plus six rebuilt root insertion keys. It is not an independent timing aggregation.

| Game | P1 first suffix ply / rows | P2 first suffix ply / rows |
| --- | --- | --- |
| 000 | 10 /27 | 9 /28 |
| 001 | 12 /22 | 13 /22 |
| 002 | 16 /17 | 17 /17 |
| 003 | 20 /14 | 21 /14 |

These161 rows match the producer's table. The supplied178 depth6 returns, four goals, chronology and timing totals remain producer-verified evidence; they were not scientifically recomputed or replayed here.

## Memory, key and session boundaries

[Table::insert](/workspaces/quoridor/.worktree/deeper-teacher-scheduling/crates/quoridor-ai/src/alphabeta.rs:584) hashes to one slot, first protects a deeper current-generation entry, then tests `retained - that_slot_old_payload + candidate_payload > byte_limit`. A refusal leaves the old entry untouched and increments capacity_skips once. An accepted overwrite increments replacements only if that slot was occupied. No budget-driven global eviction or alternative slot appears in this path. For the verified suffixes S=I excludes both accepted admissions and the earlier deeper-entry protection return. At the1MiB ceiling alone, replacing with equal/smaller payload can still succeed; neither ceiling nor skips proves all4096 slots occupied.

The table accounts its header, allocated slot capacity and committed history-vector payload using the exact source accounting tuple. This is not a universal physical heap/RSS bound. Metadata, allocator overhead, temporary keys/history maps and other search storage remain outside it. Built-key history_items and key_history_capacity_bytes sum repeated construction work/capacities during an invocation; the reported19.687950984GB therefore is not peak live memory or a measured allocation/time share. Uninstrumented PV get/Key::of lookups further prevent treating probe/hash/key counters as a census of all TT-related work.

[Key::of](/workspaces/quoridor/.worktree/deeper-teacher-scheduling/crates/quoridor-ai/src/alphabeta.rs:446) includes ruleset, pawn/wall/side/winner state, absolute ply, synthetic provenance and complete sorted counted history, including both stocks. A probe collision means an occupied modulo index with unequal full keys. It does not distinguish different64-bit hashes sharing an index from a true64-bit hash collision. Full-key equality remains the acceptance condition; this review does not propose history removal or weaker repetition semantics.

[play_with_policy](/workspaces/quoridor/.worktree/deeper-teacher-scheduling/crates/quoridor-runner/src/teacher_pilot_execution.rs:334) constructs two separately owned per-colour sessions for each game and chooses by native side0/1. No per-turn reset occurs. Tables persist across that colour's turns; stats reset per search. Each iterative depth advances generation before its search and commits after normal completion, yielding six advances per supplied complete call. Reset, generation wrap, interrupted-generation discard and failed root restoration are separate source paths. The completed suffix interpretation does not generalize to cancellation/error returns, opaque lost work or different callers.

## Timing and qualification limits

The report correctly separates native game000157.588321221s, its supplied completed-search sum157.568024898s, indexed game span157.588765090s, native parallel pipeline175.159873507s and external175.884201586s. Search elapsed includes validation, scratch/preparation, iterative search and TT/key/history work together; it ends before implicit local destruction. Native game timing excludes session construction and later destruction. Indexed timing ends before channel send. Worker0/2 and1/3 groups overlap; their durations cannot be added into external wall time. Queue1 and index-ordered consumption allow blocked sends, but offsets, blocked-send/idle durations, CPU attribution and exclusive serialization/setup costs remain UNKNOWN.

No profile allocates a causal fraction of158 seconds to byte admission, history construction, hashing or PVS. The identical all-skip pattern in short games directly limits such an inference. No reset/resize comparison was performed; improvement, output equivalence under an alternative and full-volume rates are unqualified. The report's prospective diagnostics remain unexecuted suggestions. This review neither selects nor implements them and does not expand the human's conditional follow-up.

Existing rule/math/TT soundness, labels, native qualification and supplied producer totals were reused at their existing scopes. No producer/analyzer/engine code was imported or executed; no test, framework, model/library/private payload, native Search, Cargo, profiler, geometry, game or worker ran. Only stdlib metadata/hash/CSV predicate arithmetic and own evidence formatting were used.

## Preservation and stop

Permissions/model/effort/cwd were verified from actual turn_context before ordinary commands: gpt-6.1-sol/high, endgame-solver335, danger-full-access/never. Beads ready/show/claim used the absolute shared wrapper. CPU3/std-lib AS512MiB/GPU0; no new worker or clock reservation. Fresh directed347.3 metadata showed source-review preparation/current job-fair NONE; canonical nonblocking lifetime lock was held only during finite binding/counter-read blocks and released synchronously. No physical/kernel/permission probe or foreign interruption occurred; these observations are not a future quiet certificate.

Input reader/source STOP: **2026-10-09T06:23:54.710711+00:00**. Owned readers/children/jobs/TMP remaining[]; each tool command returned synchronously. Current-next job/lock/clock reservation NONE. Authored evidence/admin completion follows this source STOP. Exact measured stdlib blocks, supplied tool wall fields, output accounting and administrative costs are recorded separately in control.json; unmeasured light-read wall/family continuous peaks remain UNKNOWN. Old fees/raw/masks/UNKNOWN are retained, without refund or reset.

Only351.1 is closed after verification and backup. Parent351 awaits canonical intake; no Sigma gate, N/full-generation/fits/game/default change, paused323 wake or seal change follows.
