"""Finite command guard; reuse existing exact-identity cleanup, no scheduler."""

import importlib.util
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone

HERE = Path(__file__).parent.resolve()
SPEC = importlib.util.spec_from_file_location(
    "job", "/workspaces/quoridor/scripts/dev/research-job.py"
)
JOB = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(JOB)


def stamp():
    return datetime.now(timezone.utc).isoformat()


def rss(pid):
    try:
        return next(
            int(row.split()[1]) * 1024
            for row in Path(f"/proc/{pid}/status").read_text().splitlines()
            if row.startswith("VmRSS:")
        )
    except (OSError, StopIteration):
        return 0


def allocated():
    total, seen = 0, set()
    for path in HERE.rglob("*"):
        try:
            info = path.stat()
        except FileNotFoundError:
            continue
        key = (info.st_dev, info.st_ino)
        if key not in seen:
            total += info.st_blocks * 512
            seen.add(key)
    return total


def completed_notification(pid, args):
    """Exclude only this canonical controller's verified post-worker phase."""
    expected = "/workspaces/quoridor/scripts/dev/research-job.py"
    if (
        len(args) != 6
        or not Path(args[0]).name.startswith("python")
        or args[1:5] != ["-B", expected, "run", "--state-dir"]
    ):
        return False
    try:
        directory = Path(args[5])
        state_bytes = (directory / "state.json").read_bytes()
        result_bytes = (directory / "result.json").read_bytes()
        state, result = json.loads(state_bytes), json.loads(result_bytes)
        identity = JOB.runtime.process_identity(pid)
        return (
            identity is not None
            and state.get("supervisor") == identity
            and state.get("phase") == "finished"
            and isinstance(state.get("job_id"), str)
            and bool(state["job_id"])
            and state["job_id"] == result.get("job_id")
            and result.get("direct_child_reaped") is True
            and result.get("cleanup_complete") is True
            and result.get("remaining") == []
            and result.get("cleanup_errors") == []
            and state_bytes == (directory / "state.json").read_bytes()
            and result_bytes == (directory / "result.json").read_bytes()
            and identity == JOB.runtime.process_identity(pid)
        )
    except (OSError, ValueError, TypeError, AttributeError):
        return False


def competitors(owned):
    result = []
    for directory in Path("/proc").iterdir():
        if not directory.name.isdigit() or int(directory.name) in owned:
            continue
        try:
            args = (directory / "cmdline").read_bytes().split(b"\0")
            executable = Path(os.fsdecode(args[0])).name
            command = " ".join(os.fsdecode(arg) for arg in args if arg)
            if executable in {"cargo", "rustc", "clippy-driver", "perf"} or (
                executable.startswith("python")
                and any(
                    marker in command
                    for marker in ["guardian.py", "train.py", "research-job.py run"]
                )
            ):
                if completed_notification(
                    int(directory.name), [os.fsdecode(arg) for arg in args if arg]
                ):
                    continue
                result.append(
                    {
                        "identity": JOB.runtime.process_identity(int(directory.name)),
                        "command": command[:512],
                    }
                )
        except (OSError, ValueError):
            pass
    return result


def main():
    label, *command = sys.argv[1:]
    assert command and "/" not in label
    # Match the existing331/334 shared writer lock across independent targets.
    # Keep this file description alive through exact child/private collection STOP.
    lease = None
    if Path(command[0]).name == "cargo":
        lease = Path(
            "/workspaces/quoridor/.artifacts/rust-migration/target/arena-software-writer.lock"
        ).open("a")
        try:
            fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit("PRESTART refusal: canonical Cargo writer lock held")
    os.sched_setaffinity(0, {2})
    available = next(
        int(row.split()[1]) * 1024
        for row in Path("/proc/meminfo").read_text().splitlines()
        if row.startswith("MemAvailable:")
    )
    external = competitors({os.getpid(), os.getppid()})
    if available < 3 * 1024**3 or external:
        raise SystemExit(
            f"PRESTART refusal: available={available} competitors={external}"
        )
    env = os.environ.copy()
    env.update(
        CARGO_TARGET_DIR=str(HERE / "target"),
        TMPDIR=str(HERE / "tmp"),
        CARGO_INCREMENTAL="0",
        CARGO_BUILD_JOBS="1",
        RUSTUP_TOOLCHAIN="stable",
        OPENBLAS_NUM_THREADS="1",
        OMP_NUM_THREADS="1",
        PYTHONDONTWRITEBYTECODE="1",
    )
    for key in [
        "RUSTFLAGS",
        "CARGO_ENCODED_RUSTFLAGS",
        "RUSTC_WRAPPER",
        "RUSTC_WORKSPACE_WRAPPER",
    ]:
        env.pop(key, None)
    log_path = HERE / "raw" / f"{label}.log"
    started = time.monotonic()
    started_utc = stamp()
    peak = rss(os.getpid())
    known, refused = [], None
    child, identity, primary = None, None, None
    failures = []
    direct_wait = False

    def attempt(stage, operation):
        try:
            return operation()
        except BaseException as error:
            failures.append({"stage": stage, "error": repr(error)})
            return None

    log = log_path.open("xb")
    try:
        try:
            # The protected lifetime starts at spawn, before identity/START IO.
            child = subprocess.Popen(
                command,
                stdout=log,
                stderr=subprocess.STDOUT,
                env=env,
                start_new_session=True,
            )
            identity = JOB.runtime.process_identity(child.pid)
            known = [identity] if identity else []
            (HERE / "raw" / f"{label}-START.json").write_text(
                json.dumps(
                    {"START_UTC": stamp(), "identity": identity, "command": command},
                    indent=2,
                )
                + "\n"
            )
            if identity is None and child.poll() is None:
                raise RuntimeError("live owned child identity unavailable")
            while child.poll() is None:
                known = JOB.track_descendants(identity, known)
                owned = {item["pid"] for item in known} | {os.getpid(), os.getppid()}
                peak = max(
                    peak,
                    rss(os.getpid())
                    + sum(
                        rss(item["pid"]) for item in known if JOB.runtime.alive(item)
                    ),
                )
                external = competitors(owned)
                if peak > 2 * 1024**3:
                    refused = "sampled familyRSS2GiB"
                elif allocated() > 460 * 1024**2:
                    refused = "owned allocated460MiB before52MiB margin"
                elif log_path.stat().st_size > 1024**2:
                    refused = "bounded log1MiB"
                elif time.monotonic() - started > 110:
                    refused = "command horizon110s within120s"
                elif external:
                    refused = "competing actual Cargo/perf/science process"
                if refused:
                    break
                time.sleep(0.05)
        except BaseException as error:
            primary = error
        finally:
            if child is not None:
                if primary is not None or refused is not None:
                    attempt(
                        "owned_TERM", lambda: JOB.signal_members(known, signal.SIGTERM)
                    )
                    attempt("direct_TERM", child.terminate)
                try:
                    child.wait(timeout=3)
                    direct_wait = True
                except BaseException as error:
                    failures.append({"stage": "first_wait", "error": repr(error)})
                    attempt(
                        "owned_KILL", lambda: JOB.signal_members(known, signal.SIGKILL)
                    )
                    attempt("direct_KILL", child.kill)
                    try:
                        child.wait(timeout=3)
                        direct_wait = True
                    except BaseException as error:
                        failures.append({"stage": "final_wait", "error": repr(error)})
    finally:
        attempt("log_close", log.close)
    remaining = attempt(
        "remaining_census", lambda: [item for item in known if JOB.runtime.alive(item)]
    )
    # Unlock/close must not be skipped if a later STOP record cannot be saved.
    if lease is not None:
        attempt("lease_unlock", lambda: fcntl.flock(lease, fcntl.LOCK_UN))
        attempt("lease_close", lease.close)
    result = {
        "command": command,
        "START_UTC": started_utc,
        "STOP_UTC": stamp(),
        "elapsed_s": time.monotonic() - started,
        "direct_wait": direct_wait,
        "exit": child.returncode if child is not None else None,
        "identities": known,
        "remaining": remaining,
        "refusal": refused,
        "primary_error": repr(primary) if primary is not None else None,
        "failures": failures,
        "sampled_family_RSS_B": peak,
        "continuous_family_peak": "UNKNOWN",
        "owned_allocated_B": attempt("final_allocated", allocated),
        "competitors": external,
    }
    attempt(
        "STOP_record",
        lambda: (HERE / "raw" / f"{label}.json").write_text(
            json.dumps(result, indent=2) + "\n"
        ),
    )
    attempt("terminal_stdout", lambda: print(json.dumps(result)))
    if primary is not None:
        primary.add_note("guard cleanup/receipt failures: " + repr(failures))
        raise primary
    if (
        child is None
        or child.returncode
        or remaining is None
        or remaining
        or refused
        or failures
        or not direct_wait
    ):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
