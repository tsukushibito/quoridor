# Related R1/R2/C1 source confirmation

**Blockers0; ordinary findings0 on the fixed related source. R1, R2 and C1 are resolved.** Source clear applies to this stopped repair boundary, with the unchanged production/private assessment reused at its prior scope. It does not qualify Rust types, tests, allocation/fault behavior, software, timing or production Zobrist adoption.

Fixed [source-binding.json](/workspaces/quoridor/.worktree/tt-hash-reuse351/.artifacts/tt-hash-reuse351/source-control-repair-v2/source-binding.json) SHA256 `968b6a881de304c8d1791a9688f4a2045ca6dffffa902e3965f4fdb60e93070b`; producer source STOP SHA256 `c37c8973e85fd8ffdc772d878efa6e2645a2303e0aea17d798c4bb13e11e0094` /2026-10-09T08:37:52.881490Z. New private module SHA256 `966d455341714c37808993a15274fd97bf4781d5fa1595fc55b8435b1072191a`,30184B,0644. Production alpha remains `b976df272b273a147596f36ec503a2801b802b45389d8169ca62468d7a02b335` without a repeated production review.

## R1: ordered restoration facts and the affected definition

BranchError now retains an ordered Vec of RestorationFailure with stage, requested parent depth, observed depth and cause. [with_child](/workspaces/quoridor/.worktree/tt-hash-reuse351/crates/quoridor-ai/src/tt_hash_reuse351_tests.rs:323) saves the requested depth before consuming undo. After the returned work and unmake attempt, it appends the current failure to an existing error rather than overwriting earlier facts. The original primary is preserved. Successful work followed by a failed undo creates an error and records that failure's attribution. Existing error plus successful restoration returns the original error unchanged.

The one new [definition](/workspaces/quoridor/.worktree/tt-hash-reuse351/crates/quoridor-ai/src/tt_hash_reuse351_tests.rs:806) directly targets the former loss. Its nested callbacks perform the existing legal13/75 transitions, then deliberately remove only the inner arrival from the private key and return `returned work error`. By the unchanged unmake control flow, the inner arrival lookup refuses before cursor/key restoration; the outer attempt then refuses the LIFO check. The expected ordered facts are:

| Order | Stage | Requested parent depth | Observed depth | Cause |
| --- | --- | ---: | ---: | --- |
| 1 | unmake | 1 | 2 | arrival missing |
| 2 | unmake | 0 | 2 | owner/LIFO |

The assertions retain the original primary, both ordered facts, depth2/cursor ply2, non-restored cursor/key mismatch and untouched immutable original root. The fixture explicitly drops only its partial private scratch and does not call verify or claim restored parent state. This would discriminate the prior overwrite. It is an unexecuted definition and static control-flow check; actual legality/type/assertion/fault outcomes are not certified. The Vec can allocate on the failure path, and its append does not promise preservation under OOM/panic/process faults.

## R2 and C1

The [forced-hash lookup fixture](/workspaces/quoridor/.worktree/tt-hash-reuse351/crates/quoridor-ai/src/tt_hash_reuse351_tests.rs:607) now changes only history[0].count. Replacing just that history with the original reproduces the exact original Key, checking all other fields remain identical. The forced same64-bit hash goes through the existing actual full-key lookup. An equality regression ignoring history would accept the otherwise-identical key and fail the required miss. The fixture is explicitly raw equality data rather than an admitted chronological replay; collision freedom is not inferred. The old synthetic mutation is gone.

The setup comment now reserves only Key.history growth and explicitly states that the ordinary canonical cursor may reserve its separate overlay during make_move. That path allocation remains update/whole cost, alongside full owned-key copying. This resolves the allocation-scope wording without inventing a new cursor API or allocation-free contract.

## Exact changed scope and unqualified prerequisites

The supplied comparison-only gzip decoded to27305B with original SHA256 `ec5d891d1a4f40d8d96c473245f973d52974183aa99eb03769a46ce42e6c3461`. Applying the supplied related patch in memory reconstructed the new module exactly. The five hunks are only restoration representation, the reservation comment, with_child error preservation, the history-only forced fixture and the appended thirteenth definition. Every outside range is exact. No source mirror, producer/source edit or executable was created/read.

The old twelve definitions were not semantically re-reviewed or executed. Their names persist; only the thirteenth is new. All13 remain NOT_BUILT/NOT_TYPECHECKED/NOT_RUN. The same seven argv lists, environment and unset-environment lists match the original software plan exactly; no command was launched. Current compiler/dependencies/private/config/physical/peer/lifetime/finalization admission remains the producer's future entry obligation. The plan is not a built caller or a numerical grant.

Unchanged production token ownership/layout/root/PV/full-equality/admission/generation/counter and private field/seed/oracle/math assessment is reused from [the prior review](/workspaces/quoridor/.worktree/endgame-solver335/.artifacts/tt-hash-review351-v1/review.md). Its original findings and withheld-clear packet remain immutable historical evidence, not retroactively retargeted. No old351.1 analysis, core/rules survey, private/native/model/library/ELF, source archive outside this explicit comparison, geometry, port, Rust/Cargo, Search, profiler or game proof was replayed.

## Binding, costs and source release

Sixteen selected source/metadata references206069B matched SHA256/size/mode before and after. The comparison decompresses27305B in memory; encoded+decoded input remains below2MiB. Exact maps and static facts are in this namespace's input-before.json, input-after-stop.json and related-static-facts.json. Old review/control SHA/size/mode also match unchanged; their bodies were not used for a new broad assessment.

Applied turn_context2026-10-09T08:39:41.172Z verified gpt-6.1-sol/high, original endgame-solver335 cwd, danger-full-access/never before ordinary commands. Shared Beads ready/show/claim used the absolute wrapper. Source/stdlib CPU3/AS512MiB/GPU0. Directed347.3 metadata described source repair/no runtime; finite source hash/delta blocks acquired the canonical LOCK_EX|LOCK_NB lease and released it synchronously. No foreign job interruption, permanent clock hold, physical/kernel/compiler probe or future-quiet certificate follows.

**Actual reader/source STOP2026-10-09T08:42:51.299869+00:00**, after final input comparison and lease release. Owned readers/children/jobs/TMP remaining[]; current-next Cargo/model/fair/lease reservation NONE. Authored evidence formatting, closure, backup and one report each to351/324 are administration after source release. No producer reader lease is retained through them.

Prior review first-phase upper524288B and prior110592B sample/65536B notice allowance remain held; new262144B prewrite gives a conservative forward upper786432B inside the same2MiB reviewer phase/4MiB component/624MiB whole3fad. No old fees/raw/masks/UNKNOWN refund. Measured static/format/admin costs and UNKNOWN unmeasured light-read/LLM/scheduler/continuous peaks are in control.json, with nested scopes not added as separate whole fees. V8 formatting has its own practical heap/RSS guard rather than a512MiB virtual-address limit.

Close only351.2 after this assessed confirmation and backup. Parent351 stays in progress; no per-run/human/Root reply ACK gate, Sigma priority change, N/full-generation/fits96/default/teacher decision, paused323 wake or seal change follows.
