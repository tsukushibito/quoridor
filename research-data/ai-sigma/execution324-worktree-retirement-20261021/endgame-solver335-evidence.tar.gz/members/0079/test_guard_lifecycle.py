"""Fault-inject actual guard.main AST; no process, geometry or model execution."""

import ast
from contextlib import redirect_stdout
import io
import json
from pathlib import Path
import signal
import subprocess
from types import SimpleNamespace
import unittest

SOURCE = Path(__file__).with_name("guard.py")


def scenario(
    *,
    start_fault=False,
    secondary_faults=False,
    identity_fault=False,
    wait_fault=False,
    stop_fault=False,
):
    tree = ast.parse(SOURCE.read_text())
    main = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    events = []
    primary = OSError("START receipt refused")
    identity_error = PermissionError("identity refused")
    output = io.StringIO()

    class FakePath:
        def __init__(self, value):
            self.value = str(value)

        def __truediv__(self, value):
            return FakePath(self.value + "/" + str(value))

        @property
        def name(self):
            return self.value.rsplit("/", 1)[-1]

        def read_text(self):
            assert self.value == "/proc/meminfo"
            return "MemAvailable: 8388608 kB\n"

        def open(self, mode):
            assert mode == "xb"
            events.append("log_open")
            return self

        def close(self):
            events.append("log_close")
            if secondary_faults:
                raise OSError("log close refused")

        def write_text(self, text):
            if self.value.endswith("-START.json"):
                events.append("START_write")
                if start_fault:
                    raise primary
            else:
                events.append("STOP_write")
                if secondary_faults or stop_fault:
                    raise PermissionError("STOP receipt refused")

    class FakeChild:
        pid = 999
        returncode = None
        waits = 0

        def poll(self):
            return 0

        def terminate(self):
            events.append("direct_TERM")

        def kill(self):
            events.append("direct_KILL")

        def wait(self, **kwargs):
            events.append("direct_wait")
            self.waits += 1
            if wait_fault and self.waits == 1:
                raise subprocess.TimeoutExpired("fake child", kwargs["timeout"])
            self.returncode = 0

    def spawn(*args, **kwargs):
        events.append("spawn")
        return FakeChild()

    def identity(pid):
        events.append("identity")
        if identity_fault:
            raise identity_error
        return {"pid": pid}

    def signal_members(*args):
        events.append("owned_signal")
        if secondary_faults:
            raise OSError("owned signal refused")

    namespace = {
        "sys": SimpleNamespace(argv=["guard.py", "mock", "/fake/driver"]),
        "Path": FakePath,
        "HERE": FakePath("/fake/owned"),
        "os": SimpleNamespace(
            sched_setaffinity=lambda *args: None,
            getpid=lambda: 1,
            getppid=lambda: 2,
            environ={},
        ),
        "competitors": lambda owned: [],
        "rss": lambda pid: 0,
        "allocated": lambda: 0,
        "stamp": lambda: "mock-time",
        "time": SimpleNamespace(monotonic=lambda: 0.0),
        "subprocess": SimpleNamespace(Popen=spawn, STDOUT=-2),
        "signal": signal,
        "JOB": SimpleNamespace(
            runtime=SimpleNamespace(
                process_identity=identity, alive=lambda item: False
            ),
            signal_members=signal_members,
        ),
        "json": json,
    }
    exec(
        compile(ast.Module(body=[main], type_ignores=[]), str(SOURCE), "exec"),
        namespace,
    )
    caught = None
    with redirect_stdout(output):
        try:
            namespace["main"]()
        except BaseException as error:
            caught = error
    receipt = json.loads(output.getvalue())
    return events, caught, receipt, primary, identity_error


class GuardLifecycle(unittest.TestCase):
    def test_start_write_failure_still_signals_waits_and_retains_primary(self):
        events, error, receipt, primary, _ = scenario(start_fault=True)
        self.assertIs(error, primary)
        self.assertEqual(events.count("direct_wait"), 1)
        self.assertIn("owned_signal", events)
        self.assertIn("direct_TERM", events)
        self.assertIn("STOP_write", events)
        self.assertTrue(receipt["direct_wait"])
        self.assertEqual(receipt["primary_error"], repr(primary))

    def test_primary_and_secondary_io_faults_do_not_skip_later_attempts(self):
        events, error, receipt, primary, _ = scenario(
            start_fault=True, secondary_faults=True
        )
        self.assertIs(error, primary)
        self.assertEqual(events.count("direct_wait"), 1)
        self.assertIn("direct_TERM", events)
        self.assertIn("log_close", events)
        self.assertIn("STOP_write", events)
        self.assertEqual(
            {failure["stage"] for failure in receipt["failures"]},
            {"owned_TERM", "log_close", "STOP_record"},
        )

    def test_identity_failure_is_inside_owned_child_lifetime(self):
        events, error, receipt, _, identity_error = scenario(identity_fault=True)
        self.assertIs(error, identity_error)
        self.assertIn("direct_TERM", events)
        self.assertEqual(events.count("direct_wait"), 1)
        self.assertEqual(receipt["primary_error"], repr(identity_error))

    def test_initial_wait_fault_attempts_kill_and_second_wait(self):
        events, error, receipt, _, _ = scenario(wait_fault=True)
        self.assertIsInstance(error, SystemExit)
        self.assertEqual(events.count("direct_wait"), 2)
        self.assertIn("direct_KILL", events)
        self.assertTrue(receipt["direct_wait"])
        self.assertEqual(receipt["failures"][0]["stage"], "first_wait")

    def test_stop_record_failure_has_fallback_receipt_and_failed_status(self):
        events, error, receipt, _, _ = scenario(stop_fault=True)
        self.assertIsInstance(error, SystemExit)
        self.assertEqual(events.count("direct_wait"), 1)
        self.assertEqual(receipt["failures"][0]["stage"], "STOP_record")


class GuardNotificationClassification(unittest.TestCase):
    def classify(
        self, *, state_changes=None, result_changes=None, fault=None, args=None
    ):
        identity = {"pid": 12, "start_ticks": "34", "boot_id": "56"}
        state = {"supervisor": identity, "phase": "finished", "job_id": "job"}
        result = {
            "job_id": "job",
            "direct_child_reaped": True,
            "cleanup_complete": True,
            "remaining": [],
            "cleanup_errors": [],
        }
        state.update(state_changes or {})
        result.update(result_changes or {})
        reads = []

        class FakePath:
            def __init__(self, path):
                self.path = str(path)

            @property
            def name(self):
                return self.path.rsplit("/", 1)[-1]

            def __truediv__(self, name):
                return FakePath(self.path + "/" + name)

            def read_bytes(self):
                reads.append(self.path)
                if fault == "read":
                    raise PermissionError("refused")
                if fault == "JSON":
                    return b"{"
                if fault == "change" and len(reads) > 2:
                    return b"{}"
                return json.dumps(
                    state if self.name == "state.json" else result
                ).encode()

        identities = []

        def identify(pid):
            identities.append(pid)
            if fault == "identity_change" and len(identities) > 1:
                return {**identity, "start_ticks": "reused"}
            return identity if fault != "identity_missing" else None

        node = next(
            item
            for item in ast.parse(SOURCE.read_text()).body
            if isinstance(item, ast.FunctionDef)
            and item.name == "completed_notification"
        )
        scope = {
            "Path": FakePath,
            "json": json,
            "JOB": SimpleNamespace(runtime=SimpleNamespace(process_identity=identify)),
        }
        exec(
            compile(ast.Module(body=[node], type_ignores=[]), str(SOURCE), "exec"),
            scope,
        )
        arguments = args or [
            "/env/bin/python",
            "-B",
            "/workspaces/quoridor/scripts/dev/research-job.py",
            "run",
            "--state-dir",
            "/owned/runtime",
        ]
        return scope["completed_notification"](12, arguments)

    def test_exact_completed_controller_only(self):
        self.assertTrue(self.classify())
        self.assertFalse(self.classify(state_changes={"phase": "running"}))
        self.assertFalse(self.classify(state_changes={"supervisor": {"pid": 12}}))
        self.assertFalse(self.classify(state_changes={"job_id": ""}))
        self.assertFalse(self.classify(result_changes={"job_id": "other"}))

    def test_incomplete_or_unknown_cleanup_refuses_exclusion(self):
        for change in [
            {"direct_child_reaped": False},
            {"direct_child_reaped": 1},
            {"cleanup_complete": False},
            {"remaining": [12]},
            {"remaining": None},
            {"cleanup_errors": ["fault"]},
            {"cleanup_errors": None},
        ]:
            with self.subTest(change=change):
                self.assertFalse(self.classify(result_changes=change))

    def test_io_json_and_reused_identity_refuse_exclusion(self):
        for fault in ["read", "JSON", "change", "identity_missing", "identity_change"]:
            with self.subTest(fault=fault):
                self.assertFalse(self.classify(fault=fault))

    def test_foreign_or_noncanonical_command_refuses_exclusion(self):
        base = [
            "/env/bin/python",
            "-B",
            "/workspaces/quoridor/scripts/dev/research-job.py",
            "run",
            "--state-dir",
            "/owned/runtime",
        ]
        for index, replacement in [
            (0, "/bin/cargo"),
            (2, "/foreign/job.py"),
            (3, "submit"),
            (4, "--other"),
        ]:
            changed = base.copy()
            changed[index] = replacement
            self.assertFalse(self.classify(args=changed))
        self.assertFalse(self.classify(args=base + ["extra"]))


if __name__ == "__main__":
    unittest.main()
