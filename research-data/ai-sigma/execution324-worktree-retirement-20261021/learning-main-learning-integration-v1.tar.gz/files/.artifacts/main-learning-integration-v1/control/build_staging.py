"""One-off source staging for328; no scientific entry or maintained mirror."""

import ast
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path("/workspaces/quoridor")
WT = Path("/workspaces/quoridor/.worktree/learning-million")
PHASE = WT / ".artifacts/main-learning-integration-v1"
STAGE = PHASE / "source/staging"
PACKAGE = "python/quoridor_training"


def archive_sources(paths):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode="w") as archive:
        for name, data in paths.items():
            entry = tarfile.TarInfo(name)
            entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
            archive.addfile(entry, io.BytesIO(data))
    compressed = gzip.compress(buffer.getvalue(), mtime=0)
    with tarfile.open(fileobj=io.BytesIO(compressed)) as archive:
        assert all(archive.extractfile(n).read() == d for n, d in paths.items())
    return compressed


class RemoveMeasurement(ast.NodeTransformer):
    """Keep production update/evaluation math; remove only optional experiment spans."""

    def visit_If(self, node):
        if any(isinstance(n, ast.Name) and n.id == "measurement" for n in ast.walk(node.test)):
            assert not node.orelse
            return []
        return self.generic_visit(node)

    def visit_With(self, node):
        node = self.generic_visit(node)
        if len(node.items) == 1 and isinstance(node.items[0].context_expr, ast.Call):
            call = node.items[0].context_expr
            if isinstance(call.func, ast.Name) and call.func.id == "measure":
                return node.body
        return node

    def visit_Assign(self, node):
        if any(isinstance(n, ast.Name) and n.id == "measure" for n in node.targets):
            return []
        return self.generic_visit(node)


def source(tree, name):
    return copy.deepcopy(
        next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == name)
    )


def main():
    assert not STAGE.exists()
    main_files = {
        str(p.relative_to(ROOT)): p.read_bytes() for p in (ROOT / PACKAGE).glob("*") if p.is_file()
    }
    docs = [
        "docs/development/nnue-training.md",
        "docs/development/ai-research-code.md",
        "scripts/dev/check-research.py",
    ]
    for name in docs:
        main_files[name] = (ROOT / name).read_bytes()
    boundary = json.loads(
        (WT / ".artifacts/learning-supply-v1/main-integration-boundary.json").read_bytes()
    )
    for path, expected in boundary["current_main_source"].items():
        if expected:
            assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
    mt = ast.parse(main_files[PACKAGE + "/train.py"])
    wt = ast.parse((WT / PACKAGE / "train.py").read_bytes())
    names = {
        "_attempt_finalization",
        "_exception_record",
        "_finalize_training",
        "append_curve_record",
        "write_sampling_counts",
        "train",
        "compact_measurements",
        "verify_initial_binding",
        "_curve_csv",
        "training_statistics",
        "prepare_statistics",
        "verify_test_cache_before_open",
    }
    originals = {
        n.name: hashlib.sha256(ast.dump(n).encode()).hexdigest()
        for n in mt.body
        if isinstance(n, ast.FunctionDef)
    }
    replacement = {name: source(wt, name) for name in names}
    train = RemoveMeasurement().visit(replacement["train"])
    pairs = [
        (arg, default)
        for arg, default in zip(train.args.kwonlyargs, train.args.kw_defaults)
        if arg.arg != "measurement"
    ]
    train.args.kwonlyargs = [arg for arg, _ in pairs]
    train.args.kw_defaults = [default for _, default in pairs]
    for arg, default in zip(train.args.kwonlyargs, train.args.kw_defaults):
        if arg.arg == "supply_workers":
            default.value = None
    config_at = next(
        i
        for i, n in enumerate(train.body)
        if isinstance(n, ast.Assign)
        and any(isinstance(t, ast.Name) and t.id == "cfg" for t in n.targets)
    )
    glue = ast.parse("""if supply_workers is None:
    supply_workers = cfg["training"]["supply_workers"]
if type(supply_workers) is not int or supply_workers not in (0, 2):
    raise ValueError("supply workers must be 0 (synchronous) or 2 (qualified prefetch)")
if input_binding and supply_workers != cfg["training"]["supply_workers"]:
    raise ValueError("bound input requires the configured supply worker mode")
cfg["training"]["supply_workers"] = supply_workers
""").body
    train.body[config_at + 1 : config_at + 1] = glue
    replacement["train"] = train
    assert not any(
        isinstance(n, ast.Name) and n.id in {"measurement", "measure"} for n in ast.walk(train)
    )
    # Other main functions remain current. export's existing arithmetic only gains named overwrite.
    newbody = []
    for node in mt.body:
        if isinstance(node, ast.FunctionDef) and node.name in replacement:
            newbody.append(replacement.pop(node.name))
        else:
            newbody.append(node)
    insert_at = next(i for i, n in enumerate(newbody) if isinstance(n, ast.FunctionDef))
    newbody[insert_at:insert_at] = list(replacement.values())
    mt.body = newbody
    mt.body.insert(insert_at, ast.Import(names=[ast.alias(name="io"), ast.alias(name="sys")]))
    export = next(n for n in mt.body if isinstance(n, ast.FunctionDef) and n.name == "export")
    mkdir = next(
        n
        for n in ast.walk(export)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == "mkdir"
    )
    mkdir.keywords = [ast.keyword(arg="exist_ok", value=ast.Constant(True))]
    guard = next(n for n in mt.body if isinstance(n, ast.FunctionDef) and n.name == "guarded_train")
    # Minimal normal guardian null-horizon repair; retain main's control entry rather than WT controllers.
    gs = ast.unparse(guard).replace(
        "deadline = time.monotonic() + cfg['seconds']",
        "started = time.monotonic()\n    deadline = None if cfg['seconds'] is None else started + cfg['seconds']",
    )
    gs = gs.replace(
        "cfg['seconds'] - max(0, deadline - time.monotonic())", "time.monotonic() - started"
    )
    mt.body[mt.body.index(guard)] = ast.parse(gs).body[0]
    cli = next(n for n in mt.body if isinstance(n, ast.FunctionDef) and n.name == "main")
    cs = ast.unparse(cli).replace(
        "choices=['train', 'test']", "choices=['train', 'test', 'statistics']"
    )
    cs = cs.replace(
        "args = parser.parse_args()",
        "parser.add_argument('--supply-workers', type=int, choices=(0, 2), help='0: synchronous (default); 2: qualified ordered prefetch')\n    args = parser.parse_args()",
    )
    cs = cs.replace(
        "if args.command == 'train':",
        "if args.command == 'statistics':\n        if args.guard_config or args.supply_workers is not None:\n            parser.error('statistics does not use a fit guard or supply workers')\n        print(json.dumps(prepare_statistics(args.cache, args.output)))\n        return\n    if args.command == 'train':",
    )
    cs = cs.replace(
        "if args.guard_config:\n            guarded_train",
        "if args.guard_config:\n            if args.supply_workers is not None or args.steps is not None or args.scale is not None:\n                parser.error('guarded training uses only its fixed config/input binding')\n            guarded_train",
    )
    cs = cs.replace(
        "input_binding=args.input_binding",
        "input_binding=args.input_binding, supply_workers=args.supply_workers",
    )
    mt.body[mt.body.index(cli)] = ast.parse(cs).body[0]
    files = dict(main_files)
    files[PACKAGE + "/train.py"] = (ast.unparse(ast.fix_missing_locations(mt)) + "\n").encode()
    copied = [
        "public_features.py",
        "compact_cache.py",
        "sampling.py",
        "public_sigma.py",
        "supply.py",
        "plotting.py",
        "common.py",
        "cache.py",
        "test_public_features.py",
        "test_public_sigma.py",
        "test_supply.py",
    ]
    for name in copied:
        files[PACKAGE + "/" + name] = (WT / PACKAGE / name).read_bytes()
    # Copy only maintained NN0 observations; retain main's opt-in live fixture separately for later caller updates.
    mtest = ast.parse(main_files[PACKAGE + "/test_observation.py"])
    wtest = ast.parse((WT / PACKAGE / "test_observation.py").read_bytes())
    contracts = next(
        n for n in wtest.body if isinstance(n, ast.ClassDef) and n.name == "ObservationContracts"
    )
    mtest.body = [
        contracts if isinstance(n, ast.ClassDef) and n.name == "ObservationContracts" else n
        for n in mtest.body
    ]
    # Add imports used by current NN0 contracts, not WT live training experiments.
    mtest.body[1:1] = ast.parse(
        "import csv\nimport gzip\nfrom .sampling import ReflectionBatches, ConvergenceObservations, update_steps"
    ).body
    files[PACKAGE + "/test_observation.py"] = (
        ast.unparse(ast.fix_missing_locations(mtest)) + "\n"
    ).encode()
    preserved = {
        PACKAGE + "/" + n: (WT / PACKAGE / n).read_bytes()
        for n in copied + ["train.py", "test_observation.py"]
    }
    current_archive = archive_sources(main_files)
    wt_archive = archive_sources(preserved)
    total = (
        sum(((len(v) + 4095) // 4096) * 4096 for v in files.values())
        + ((len(current_archive) + 4095) // 4096) * 4096
        + ((len(wt_archive) + 4095) // 4096) * 4096
    )
    assert total < 851968, total
    STAGE.mkdir(parents=True)
    for name, data in files.items():
        target = STAGE / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    (PHASE / "source/main-base.tar.gz").write_bytes(current_archive)
    (PHASE / "source/accepted-WT-used-source.tar.gz").write_bytes(wt_archive)
    (PHASE / "control/source-selection.json").write_text(
        json.dumps(
            {
                "preserved_main_files": {
                    n: hashlib.sha256(v).hexdigest() for n, v in main_files.items()
                },
                "selected_WT_production_functions": sorted(names),
                "selected_WT_modules": copied,
                "excluded_WT_entries": [
                    "epoch_measurement",
                    "measurement hooks",
                    "guarded_statistics",
                    "qualification controllers",
                    "sigma_reference",
                    "experiment job scripts",
                ],
                "preserved_main_function_AST": originals,
                "prewrite_allocated_upper_B": total,
                "artifact_staging_only": True,
            },
            indent=2,
        )
        + "\n"
    )
    print("STAGED", total, "bytes; same science, measurement hooks removed")


if __name__ == "__main__":
    main()
