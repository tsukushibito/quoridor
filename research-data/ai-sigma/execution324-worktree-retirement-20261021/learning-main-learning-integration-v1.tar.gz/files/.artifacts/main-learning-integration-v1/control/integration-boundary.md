# 328 current-main learning integration boundary

The patch targets actual main training sources ae6cde/787aee/c460/276f. Execution324 alone applies/commits it. Staging is temporary patch preparation; the maintained destination is main `python/quoridor_training`.

## Required dependency alignment

- `public_sigma` retains every original observation from the frozen full corpus, exact source-ID split/opened quarantine, streaming flush/close and 66B native QF1 geometry. The historical174B opened-ID reader remains intake evidence; the old174B production decoder/reservoir is removed.
- `public_features`, `compact_cache`, `cache` align the canonical geometry schema, model-input groups, both312-feature views, original distances/z, bounded records and sealed test paths. All unchanged numerical/native/loader proofs are reused.
- `sampling` keeps independent original epoch order and train-only50% reflection RNG. `supply` is the already qualified contiguousFP32/fused expansion/event-owned bounded prefetch; CLI/config default0 and explicit2 only. Input-bound jobs reject conflicting mode overrides before corpus/model access.
- Current-main `train` integrates only necessary production functions for T-only statistics, INITIAL identity, named INITIAL/BEST/LAST, original fullV selector/scientific stopping, attempted/successful exposure, lossless JSONL.gz/CSV/v2 visits, and finalization. Optional epoch measurement hooks, its diagnostic stop, statistics job controllers, Sigma reference, and experiment observer/controller modules are excluded.
- Model/scaled/residual/binding implementation is byte-identical to main. Production train update/evaluate math is AST-identical to accepted WT after removing optional observer calls and normalizing explicit worker-entry glue. Main export changes only maintained directory reuse; tensors/layout/arithmetic stay unchanged.
- `cycle_process` needs the accepted null-deadline and exception-safe persistence/handle/signal-mask finalization to make this real guarded entry work. Main `cycle`, qualification and its independent ordinary callers remain. The guarded train CLI uses fixed config/input-binding and rejects overrides.
- `plotting` reads the single canonical JSONL.gz representation. On-demand image generation remains an explicit CLI; trainer init/epoch/final/export/freeze never generates PNG/SVG. Affected tests/CLI/docs are migrated together, without a legacy record-format fallback.

## Verification boundary

Affected NN0 contracts47PASS, no Torch/ORT/native/model imports or calls; CPU2,3/RAM2GiB, peakRSS631016KiB. Related import/three actual CLI help passes use no runtime model. The first import list incorrectly included unchanged eager-Torch model.py; the NN0 import guard refused it before CLI/model calls. That administrative refusal and raw output are preserved. No live fit, gradient, corpus scan, fullV/MSE, native parity, Rust/Cargo build or checkpoint generation was performed.

Use existing accepted full-input/native/reflection/exactCPU-CUDA/2-versus4 diagnostics, r3 handler and r4 process-finalization evidence for unchanged boundaries. This review concerns new main-to66B glue, entry/RNG/records/supply ownership and null-control dependency, not a replay of those proofs or a strength/default adoption.

All old assets/fees/UNKNOWN are retained. New phase cap3145728B/proof7f0b01 is inclusive of source, verification, related review and execution324 integration. Parent323 remains paused and sealed labels remain closed. Issue328 closes only after actual maintained-main entry/tests/review/integration commit is accepted by324; queued329 is not started.
