"""Bounded maintained-entry NN0 verification, no model/native/large corpus."""

import importlib.abc
import json
import os
from pathlib import Path
import resource
import sys
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
STAGE = ROOT / "source/staging"
DENIED = {"torch", "onnxruntime", "onnx"}


class RefuseModelImports(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in DENIED:
            raise AssertionError("NN0 refuses model runtime import: " + fullname)
        return None


def main():
    os.sched_setaffinity(0, {2, 3})
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
    sys.path.insert(0, str(STAGE / "python"))
    sys.meta_path.insert(0, RefuseModelImports())
    import numpy  # existing NumPy only; no device state
    import ctypes

    def refuse_library(*args, **kwargs):
        raise AssertionError("NN0 refuses native CDLL")

    ctypes.CDLL = refuse_library
    evidence = ROOT / "evidence"
    temp = ROOT / "tmp"
    evidence.mkdir(exist_ok=True)
    temp.mkdir(exist_ok=True)
    import tempfile

    tempfile.tempdir = str(temp)
    targets = [
        "quoridor_training.test_learning_integration.IntegrationContracts",
        "quoridor_training.test_observation.ObservationContracts",
        "quoridor_training.test_supply.WorkerContracts",
        "quoridor_training.test_supply.FinalizationContracts",
        "quoridor_training.test_image_policy.ImagePolicyTests",
        "quoridor_training.test_public_sigma.CompactBoundary",
        "quoridor_training.test_public_sigma.PublicSigmaContracts.test_scale_and_constant_use_only_original_train_without_test_or_torch",
        "quoridor_training.test_public_sigma.PublicSigmaContracts.test_progress_flushes_payload_and_rejects_inconsistent_counts",
        "quoridor_training.test_public_sigma.PublicSigmaContracts.test_legacy_opened_ID_import_is_exact_blob_original_not_input_match",
    ]
    started = time.monotonic()
    suite = unittest.defaultTestLoader.loadTestsFromNames(targets)
    with (evidence / "NN0-unittest.log").open("x") as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    receipt = {
        "issue": "quoridor-4lc.328",
        "targets": targets,
        "tests": result.testsRun,
        "errors": len(result.errors),
        "failures": len(result.failures),
        "success": result.wasSuccessful(),
        "wall_seconds": time.monotonic() - started,
        "peak_RSS_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "CPU": sorted(os.sched_getaffinity(0)),
        "RAMfamily_limit_B": 2 * 1024**3,
        "Torch_ORΤ_model_imported": sorted(DENIED.intersection(sys.modules)),
        "native_model_forward_gradient_fit_Cargo_GPU": 0,
        "numpy": numpy.__version__,
        "owned_child_processes": "tests use mocks/threads only; unittest synchronous returned",
    }
    (evidence / "NN0-result.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
