"""Four bounded actual-entry/record cases, no runtime models."""

import ctypes
import importlib.abc
import json
import os
from pathlib import Path
import resource
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parent
resource.setrlimit(resource.RLIMIT_AS, (536870912, 536870912))
assert os.sched_getaffinity(0) == {3}
sys.path.insert(0, str(ROOT.parent / "source/staging/python"))


class Deny(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {"torch", "onnx", "onnxruntime"}:
            raise AssertionError("model import blocked: " + fullname)
        return None


sys.meta_path.insert(0, Deny())
import numpy as _numpy


def deny_library(*args, **kwargs):
    raise AssertionError("CDLL blocked")


ctypes.CDLL = deny_library
targets = [
    "quoridor_training.test_learning_integration.IntegrationContracts.test_actual_CLI_routes_workers_without_loading_any_model",
    "quoridor_training.test_learning_integration.IntegrationContracts.test_bound_worker_override_fails_before_corpus_or_model",
    "quoridor_training.test_learning_integration.IntegrationContracts.test_guarded_caller_binds_null_deadline_and_fixed_input",
    "quoridor_training.test_image_policy.ImagePolicyTests.test_actual_persist_keeps_all_points_and_never_launches_a_plotter",
]
with tempfile.TemporaryDirectory(prefix="nn0-", dir=ROOT) as tmp:
    tempfile.tempdir = tmp
    started = time.monotonic()
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromNames(targets)
    )
    elapsed = time.monotonic() - started
assert not ({"torch", "onnx", "onnxruntime"} & sys.modules.keys())
print(
    json.dumps(
        {
            "targets": targets,
            "tests": result.testsRun,
            "success": result.wasSuccessful(),
            "wall": elapsed,
            "RSS_KiB": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            "affinity": sorted(os.sched_getaffinity(0)),
            "model_native_GPU": 0,
            "children": 0,
            "numpy_version": _numpy.__version__,
        }
    )
)
raise SystemExit(0 if result.wasSuccessful() else 1)
