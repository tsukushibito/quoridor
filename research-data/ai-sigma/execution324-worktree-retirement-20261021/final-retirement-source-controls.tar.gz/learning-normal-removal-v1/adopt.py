"""Retire the arena checkout after scoped metadata coverage and current-reader checks."""

from collections import Counter
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
TARGET = ROOT / ".worktree/learning-million"
PUBLIC = ROOT / "research-data/ai-sigma/execution324-worktree-retirement-20261021"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run(argv, cwd=ROOT):
    r = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=150)
    assert r.returncode == 0, r.stdout + r.stderr
    return r.stdout, r.stderr


def put(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def main():
    source_report = json.loads((PUBLIC / "learning-million-source-preservation.json").read_bytes())
    prior = json.loads(
        (PUBLIC / "learning-artifact-coverage-and-ended-payload-custody-v1.json").read_bytes()
    )
    final = json.loads(
        (PUBLIC / "learning-final-six-control-and-payload-custody.json").read_bytes()
    )
    meta = source_report["original_metadata"]
    coverage = {r["original_path"]: r for r in source_report["source_manifest"]["rows"]}
    for namespace in prior["source_metadata_packet"]["namespaces"]:
        for row in namespace["saved_correspondence"]:
            proof = row["restoration"]
            assert "bytes" in proof and "mode" in proof, row["path"]
            coverage[row["path"]] = proof
    for original, proof in final["original_preparation"]["restoration_by_original_path"].items():
        if "bytes" in proof and "mode" in proof:
            coverage[original] = proof
        elif "restoration" in proof and isinstance(proof["restoration"], dict):
            coverage[original] = proof["restoration"]
        else:
            assert (
                proof["kind"]
                == "historical_original_archive_to_committed_Git_binding_NO_current_payload_hash"
            )
            coverage[original] = dict(bytes=proof["bytes"], mode=proof["committed_Git"]["mode"])
    for row in coverage.values():
        assert "bytes" in row and "mode" in row
        row["mode"] = row["mode"][-4:]
    # The one remaining inline historical binding is migrated to its exact member.
    original = str(
        TARGET
        / ".artifacts/learning-supply-v1/worker4-preparation/sigma-reference-preparation-v1/r3/review-binding-r3.json"
    )
    ref = final["original_preparation"]["restoration_by_original_path"][original]
    package = next(
        r for r in final["components"] if r["namespace"] == ".artifacts/learning-supply-v1/"
    )
    import hashlib
    import tarfile

    destination = (
        PUBLIC
        / "readable/learning-million/learning-supply-v1/worker4-preparation/sigma-reference-preparation-v1/r3/review-binding-r3.json"
    )
    # No checkout source or old body is reopened.
    with tarfile.open(ROOT / package["archive"]["path"], "r|gz") as bundle:
        for info in bundle:
            if info.name == ref["member"]:
                with bundle.extractfile(info) as stream:
                    body = stream.read()
                break
        else:
            raise AssertionError("Inline binding member absent")
    assert len(body) == ref["bytes"] and hashlib.sha256(body).hexdigest() == ref["sha256"]
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as stream:
        stream.write(body)
    document = ROOT / "docs/research-findings.md"
    text = document.read_text()
    literal = "`" + str(Path(original).relative_to(ROOT)) + "`"
    assert literal in text
    document.write_text(
        text.replace(
            literal, "[保存済みbinding](" + os.path.relpath(destination, document.parent) + ")"
        )
    )
    run(["tools/research-quality/node_modules/.bin/prettier", "--write", str(document)])
    run(["tools/research-quality/node_modules/.bin/prettier", "--check", str(document)])
    put(
        OUT / "inline-binding-paths.json",
        [str(destination.relative_to(ROOT)), str(document.relative_to(ROOT))],
    )
    inline_saved = run(
        [
            sys.executable,
            "-B",
            "scripts/dev/research-save.py",
            "save",
            "--paths-file",
            str(OUT / "inline-binding-paths.json"),
            "--issue",
            "quoridor-4lc.324.12.6",
            "--actor",
            "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--message",
            "Migrate the final stopped learning binding citation",
            "--writers-stopped",
        ]
    )[0]
    (OUT / "inline-save.stdout").write_text(inline_saved)
    expected = {r[3:] for r in meta["reads"]["status"]["stdout"] if r and not r.startswith("!! ")}
    generated = [
        TARGET / ".ruff_cache",
        TARGET / "node_modules",
        TARGET / "python/quoridor_training/__pycache__",
        TARGET / ".artifacts/value-residual-diagnostic-v1/caller-v2/__pycache__",
    ]
    helper = load("learning_retirement_helpers", OUT.parent / "frame22-v1/adopt.py")
    helper.TARGET = TARGET
    lc = load("learning_retirement_source_lease", ROOT / "scripts/dev/research-lifecycle.py")
    with lc.lease():
        before_main = run(["git", "status", "--porcelain=v1", "--untracked-files=all"])[0]
        assert not before_main
        status = run(
            ["git", "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching"],
            TARGET,
        )[0]
        records = status.splitlines()
        changed = [r for r in records if not r.startswith("!! ")]
        assert {r[3:] for r in changed} == expected
        assert all(r[:3] in {" M ", "?? "} for r in changed)
        assert not run(["git", "diff", "--cached", "--name-only"], TARGET)[0]
        ignored = {r[3:] for r in records if r.startswith("!! ")}
        assert ignored <= {r[3:] for r in meta["reads"]["status"]["stdout"] if r.startswith("!! ")}
        branch = run(["git", "symbolic-ref", "HEAD"], TARGET)[0].strip()
        head = run(["git", "rev-parse", "HEAD"], TARGET)[0].strip()
        assert head == meta["reads"]["HEAD"]["stdout"].strip()
        assert branch == meta["reads"]["branch"]["stdout"].strip()
        flags = Counter(line[0] for line in run(["git", "ls-files", "-v"], TARGET)[0].splitlines())
        assert set(flags) <= {"H", "S"}
        caller = subprocess.run(
            [
                "rg",
                "-n",
                "-F",
                ".worktree/learning-million",
                "scripts",
                "python",
                "configs",
                "tools",
                ".devcontainer",
                "docs/design",
                "docs/development",
                "docs/research-findings.md",
                "research-paths.json",
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=40,
        )
        assert caller.returncode == 1 and not caller.stdout, caller.stdout
        readers = helper.current_readers()
        assert not readers["matches"]
        roots, symlinks, observed, uncovered = [], [], [], []
        for name in ignored:
            p = TARGET / name.rstrip("/")
            if ".artifacts/" in name or name == ".artifacts/":
                roots.append(p)
            else:
                assert any(p == cache or cache in p.parents for cache in generated), name
        for name in expected:
            p = TARGET / name
            row = coverage[str(p)]
            assert p.is_file() and not p.is_symlink()
            assert (
                p.stat().st_size == row["bytes"]
                and f"{stat.S_IMODE(p.stat().st_mode):04o}" == row["mode"]
            )
        excluded = {str(p) for p in generated}
        for root in roots:
            assert not root.is_symlink()
            for directory, dirs, files in os.walk(root, followlinks=False):
                retained = []
                for name in dirs:
                    p = Path(directory) / name
                    if name in {".ruff_cache", "__pycache__"}:
                        # Concrete generated caches discovered under these ended
                        # artifact namespaces; never enter/copy their payloads.
                        generated.append(p)
                        excluded.add(str(p))
                        continue
                    if str(p) in excluded:
                        continue
                    if p.is_symlink():
                        symlinks.append(
                            dict(
                                path=str(p),
                                target=os.readlink(p),
                                policy="Link text preserved; target never followed/deleted",
                            )
                        )
                    else:
                        retained.append(name)
                dirs[:] = retained
                for name in files:
                    p = Path(directory) / name
                    if p.is_symlink():
                        symlinks.append(
                            dict(
                                path=str(p),
                                target=os.readlink(p),
                                policy="Link text preserved; target never followed/deleted",
                            )
                        )
                        continue
                    row = coverage.get(str(p))
                    s = p.stat()
                    if row is None:
                        uncovered.append(
                            dict(
                                path=str(p), bytes=s.st_size, mode=f"{stat.S_IMODE(s.st_mode):04o}"
                            )
                        )
                        continue
                    assert (
                        s.st_size == row["bytes"]
                        and f"{stat.S_IMODE(s.st_mode):04o}" == row["mode"]
                    ), str(p)
                    observed.append(str(p))
                    assert len(observed) <= 40000
        put(
            OUT / "coverage-preflight.json",
            dict(
                covered=len(observed),
                uncovered=uncovered,
                generated_caches=[str(p) for p in generated],
            ),
        )
        assert not uncovered, "Unpreserved finite files; see coverage-preflight.json"
        config = {}
        for name in ["HEAD", "config.worktree", "info/sparse-checkout", "info/exclude"]:
            p = ROOT / ".git/worktrees/learning-million" / name
            config[name] = (
                dict(text=p.read_text(), mode=f"{stat.S_IMODE(p.stat().st_mode):04o}")
                if p.exists()
                else None
            )
        before = dict(
            branch=branch,
            head=head,
            original_status=status,
            flags=dict(flags),
            config=config,
            current_callers=[],
            readers=readers,
            covered_current_noncache_files=len(observed),
            covered_file_paths=observed,
            cache_exclusions=[str(p) for p in generated],
            symlinks=symlinks,
            preserved_original_bodies="40+51 exact original data/checkpoint/model/input bodies in classified shared assets; sealed reference preserved unchanged, opaque/hash UNKNOWN",
            historical_RAW_failed_and_UNKNOWN_unchanged=True,
        )
        put(OUT / "before.json", before)
        tracked = [r[3:] for r in changed if r.startswith(" M ")]
        if tracked:
            run(["git", "restore", "--source=HEAD", "--worktree", "--", *tracked], TARGET)
        for line in changed:
            if line.startswith("?? "):
                (TARGET / line[3:]).unlink()
        for root in roots:
            shutil.rmtree(root)
        for p in generated:
            if p.is_symlink():
                p.unlink()
            elif p.exists():
                shutil.rmtree(p)
        assert not run(
            ["git", "status", "--porcelain=v1", "--untracked-files=all", "--ignored"], TARGET
        )[0]
        removed = run(["bash", "scripts/dev/manage_worktree.sh", "remove", "learning-million"])
        (OUT / "remove.stdout").write_text(removed[0])
        (OUT / "remove.stderr").write_text(removed[1])
        listing = run(["git", "worktree", "list", "--porcelain"])[0]
        assert not TARGET.exists() and f"worktree {TARGET}\n" not in listing
        assert run(["git", "show-ref", "--verify", "--hash", branch])[0].strip() == head
        assert run(["git", "status", "--porcelain=v1", "--untracked-files=all"])[0] == before_main
    for name in [
        "search-optimization",
        "value-search-strength-arena355",
        "value-search-strength-engineering355",
        "assets",
    ]:
        assert (ROOT / ".worktree" / name).is_dir()
    report_path = PUBLIC / "learning-million-normal-removal.json"
    put(
        report_path,
        dict(
            issue="quoridor-4lc.324.12.6",
            candidate="learning-million",
            status="REMOVED_BY_NORMAL_MANAGED_HELPER",
            at=datetime.now(timezone.utc).isoformat(),
            before=before,
            actual_remove_exit_code=0,
            stdout=removed[0],
            stderr=removed[1],
            branch_retained=branch,
            branch_HEAD=head,
            current_registered_worktrees=listing.count("worktree "),
            cumulative_removed=21,
            remaining_candidate="NONE; current four protected areas unchanged",
            Main_dirty_unchanged=True,
            force=False,
            scientific_replays=0,
        ),
    )
    run(["tools/research-quality/node_modules/.bin/prettier", "--write", str(report_path)])
    run(["tools/research-quality/node_modules/.bin/prettier", "--check", str(report_path)])
    put(OUT / "paths.json", [str(report_path.relative_to(ROOT))])
    saved = run(
        [
            sys.executable,
            "-B",
            "scripts/dev/research-save.py",
            "save",
            "--paths-file",
            str(OUT / "paths.json"),
            "--issue",
            "quoridor-4lc.324.12.6",
            "--actor",
            "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--message",
            "Retire preserved learning checkout normally\n\nRetain source versions, controls, models, sealed reference and original paused RAW outside the checkout. Verify current member custody and reader STOP, then use the normal managed helper; preserve branch and all original failure/unknown facts.",
            "--writers-stopped",
        ]
    )[0]
    (OUT / "save.stdout").write_text(saved)
    commit = json.loads(saved)["commit"]
    assert (
        subprocess.check_output(
            ["git", "show", commit + ":" + str(report_path.relative_to(ROOT))], cwd=ROOT
        )
        == report_path.read_bytes()
    )
    pushed = run(["git", "push", "origin", "main"])
    (OUT / "push.stdout").write_text(pushed[0])
    (OUT / "push.stderr").write_text(pushed[1])
    assert run(["git", "ls-remote", "origin", "refs/heads/main"])[0].split()[0] == commit
    assert not run(["git", "status", "--porcelain=v1", "--untracked-files=all"])[0]
    put(
        OUT / "push-result.json",
        dict(
            commit=commit,
            remote_main=commit,
            push_exit_code=0,
            remaining_dirty=[],
            removed="learning-million",
            registered=4,
            cumulative_removed=21,
        ),
    )
    run(
        [
            "bash",
            "scripts/dev/beads.sh",
            "update",
            "quoridor-4lc.324.12.6",
            "--append-notes",
            f"Actual learning-million normal managed removal completed, branchcodex/learning-milliond61a91d retained. All present noncache files matched exact source/control/Git/member custody; current scoped callers0, controlled A readers stopped and fresh supporting proc matches0 (denied UNKNOWN). Original91 payload bodies including sealed reference retained under classified assets without body decode/hash/copy; paused342.17 original RAW stays outside checkout/native directwaitUNKNOWN unchanged. Canonical learning-million-normal-removal.json at{commit}, normal push remote main exact/Main clean. Cumulative21 removed/registered4=current protected Main/searchopt/arena355/engineering355; no unused candidate remains.12.6 final acceptance/owner closures follow,12.9 not yet started.",
        ]
    )
    run(["bash", "scripts/dev/beads.sh", "backup", "sync"])
    print(json.dumps(dict(commit=commit, removed="learning-million", registered=4)))


if __name__ == "__main__":
    main()
