"""Retire the arena checkout after scoped metadata coverage and current-reader checks."""

from collections import Counter
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys

ROOT = Path("/workspaces/quoridor")
OUT = Path(__file__).resolve().parent
TARGET = ROOT / ".worktree/arena-evaluation"
PUBLIC = ROOT / "research-data/ai-sigma/execution324-worktree-retirement-20261021"


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run(argv, cwd=ROOT):
    r = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=150)
    assert r.returncode == 0, r.stdout + r.stderr
    return r.stdout, r.stderr


def put(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def main():
    report = json.loads((PUBLIC / "arena-evaluation-finite-control-preservation.json").read_bytes())
    other = json.loads((PUBLIC / "arena-other-named-roots-preservation.json").read_bytes())
    meta = json.loads((ROOT / report["original_metadata"]).read_bytes())
    coverage = {}
    for package in report["components"]:
        manifest = json.loads((ROOT / package["member_manifest"]["path"]).read_bytes())
        for row in manifest["members"]:
            original = row.get("original", row.get("path", row.get("original_path")))
            assert original and original.startswith(str(TARGET) + "/")
            coverage[original] = row
        for row in manifest.get("reused", []):
            coverage[row["path"]] = row
    members = json.loads((ROOT / other["member_manifest"]).read_bytes())
    for row in members["members"]:
        original = row.get("original", row.get("path", row.get("original_path")))
        assert original and original.startswith(str(TARGET) + "/")
        coverage[original] = row
    for row in other["coverage_plan"]["existing_coverage"]:
        coverage[row["path"]] = row
    expected = {r[3:] for r in meta["reads"]["status"]["stdout"] if r and not r.startswith("!! ")}
    generated = [
        TARGET / ".artifacts/build-provenance379-v1/__pycache__",
        TARGET / ".artifacts/common-corpus-warmstart-study/pilot-v1/inlet-repair-v2/.ruff_cache",
        TARGET / ".artifacts/sigma-timed-v1/current-compiler-software-recovery-v2/target",
        TARGET / ".artifacts/sigma-timed-v1/current-compiler-software-v1/target",
        TARGET / ".ruff_cache",
        TARGET / "node_modules",
    ]
    helper = load("arena_retirement_helpers", OUT.parent / "frame22-v1/adopt.py")
    helper.TARGET = TARGET
    lc = load("arena_retirement_source_lease", ROOT / "scripts/dev/research-lifecycle.py")
    with lc.lease():
        before_main = run(["git", "status", "--porcelain=v1", "--untracked-files=all"])[0]
        assert not before_main
        status = run(
            ["git", "status", "--porcelain=v1", "--untracked-files=all", "--ignored=matching"],
            TARGET,
        )[0]
        records = status.splitlines()
        changed = [r for r in records if not r.startswith("!! ")]
        assert {r[3:] for r in changed} == expected
        assert all(r[:3] in {" M ", "?? "} for r in changed)
        assert not run(["git", "diff", "--cached", "--name-only"], TARGET)[0]
        ignored = {r[3:] for r in records if r.startswith("!! ")}
        assert ignored <= {r[3:] for r in meta["reads"]["status"]["stdout"] if r.startswith("!! ")}
        branch = run(["git", "symbolic-ref", "HEAD"], TARGET)[0].strip()
        head = run(["git", "rev-parse", "HEAD"], TARGET)[0].strip()
        assert head == meta["reads"]["HEAD"]["stdout"].strip()
        assert branch == meta["reads"]["branch"]["stdout"].strip()
        flags = Counter(line[0] for line in run(["git", "ls-files", "-v"], TARGET)[0].splitlines())
        assert set(flags) <= {"H", "S"}
        caller = subprocess.run(
            [
                "rg",
                "-n",
                "-F",
                ".worktree/arena-evaluation",
                "scripts",
                "python",
                "configs",
                "tools",
                ".devcontainer",
                "docs/design",
                "docs/development",
                "docs/research-findings.md",
                "research-paths.json",
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=40,
        )
        assert caller.returncode == 1 and not caller.stdout, caller.stdout
        readers = helper.current_readers()
        assert not readers["matches"]
        roots, symlinks, observed = [], [], []
        for name in ignored:
            p = TARGET / name.rstrip("/")
            if ".artifacts/" in name or name == ".artifacts/":
                roots.append(p)
            else:
                assert p in generated, name
        for name in expected:
            p = TARGET / name
            row = coverage[str(p)]
            assert p.is_file() and not p.is_symlink()
            assert (
                p.stat().st_size == row["bytes"]
                and f"{stat.S_IMODE(p.stat().st_mode):04o}" == row["mode"]
            )
        excluded = {str(p) for p in generated}
        for root in roots:
            assert not root.is_symlink()
            for directory, dirs, files in os.walk(root, followlinks=False):
                retained = []
                for name in dirs:
                    p = Path(directory) / name
                    if str(p) in excluded:
                        continue
                    if p.is_symlink():
                        symlinks.append(
                            dict(
                                path=str(p),
                                target=os.readlink(p),
                                policy="Link text preserved; target never followed/deleted",
                            )
                        )
                    else:
                        retained.append(name)
                dirs[:] = retained
                for name in files:
                    p = Path(directory) / name
                    if p.is_symlink():
                        symlinks.append(
                            dict(
                                path=str(p),
                                target=os.readlink(p),
                                policy="Link text preserved; target never followed/deleted",
                            )
                        )
                        continue
                    row = coverage[str(p)]
                    s = p.stat()
                    assert (
                        s.st_size == row["bytes"]
                        and f"{stat.S_IMODE(s.st_mode):04o}" == row["mode"]
                    ), str(p)
                    observed.append(str(p))
                    assert len(observed) <= 40000
        config = {}
        for name in ["HEAD", "config.worktree", "info/sparse-checkout", "info/exclude"]:
            p = ROOT / ".git/worktrees/arena-evaluation" / name
            config[name] = (
                dict(text=p.read_text(), mode=f"{stat.S_IMODE(p.stat().st_mode):04o}")
                if p.exists()
                else None
            )
        before = dict(
            branch=branch,
            head=head,
            original_status=status,
            flags=dict(flags),
            config=config,
            current_callers=[],
            readers=readers,
            covered_current_noncache_files=len(observed),
            covered_file_paths=observed,
            cache_exclusions=[str(p) for p in generated],
            symlinks=symlinks,
            preserved_original_bodies="57+5+19 exact same-inode originals in shared assets; separate disposition/custody manifests",
            historical_RAW_failed_and_UNKNOWN_unchanged=True,
        )
        put(OUT / "before.json", before)
        tracked = [r[3:] for r in changed if r.startswith(" M ")]
        if tracked:
            run(["git", "restore", "--source=HEAD", "--worktree", "--", *tracked], TARGET)
        for line in changed:
            if line.startswith("?? "):
                (TARGET / line[3:]).unlink()
        for root in roots:
            shutil.rmtree(root)
        for p in generated:
            if p.is_symlink():
                p.unlink()
            elif p.exists():
                shutil.rmtree(p)
        assert not run(
            ["git", "status", "--porcelain=v1", "--untracked-files=all", "--ignored"], TARGET
        )[0]
        removed = run(["bash", "scripts/dev/manage_worktree.sh", "remove", "arena-evaluation"])
        (OUT / "remove.stdout").write_text(removed[0])
        (OUT / "remove.stderr").write_text(removed[1])
        listing = run(["git", "worktree", "list", "--porcelain"])[0]
        assert not TARGET.exists() and f"worktree {TARGET}\n" not in listing
        assert run(["git", "show-ref", "--verify", "--hash", branch])[0].strip() == head
        assert run(["git", "status", "--porcelain=v1", "--untracked-files=all"])[0] == before_main
    for name in [
        "search-optimization",
        "value-search-strength-arena355",
        "value-search-strength-engineering355",
        "assets",
        "learning-million",
    ]:
        assert (ROOT / ".worktree" / name).is_dir()
    report_path = PUBLIC / "arena-evaluation-normal-removal.json"
    put(
        report_path,
        dict(
            issue="quoridor-4lc.324.12.6",
            candidate="arena-evaluation",
            status="REMOVED_BY_NORMAL_MANAGED_HELPER",
            at=datetime.now(timezone.utc).isoformat(),
            before=before,
            actual_remove_exit_code=0,
            stdout=removed[0],
            stderr=removed[1],
            branch_retained=branch,
            branch_HEAD=head,
            current_registered_worktrees=listing.count("worktree "),
            cumulative_removed=20,
            remaining_candidate="learning-million only; current four protected areas unchanged",
            Main_dirty_unchanged=True,
            force=False,
            scientific_replays=0,
        ),
    )
    run(["tools/research-quality/node_modules/.bin/prettier", "--write", str(report_path)])
    run(["tools/research-quality/node_modules/.bin/prettier", "--check", str(report_path)])
    put(OUT / "paths.json", [str(report_path.relative_to(ROOT))])
    saved = run(
        [
            sys.executable,
            "-B",
            "scripts/dev/research-save.py",
            "save",
            "--paths-file",
            str(OUT / "paths.json"),
            "--issue",
            "quoridor-4lc.324.12.6",
            "--actor",
            "codex:01a1376a-bfd3-75d2-bd64-61e9416b3b13",
            "--message",
            "Retire preserved arena evaluation worktree normally\n\nVerify current scoped metadata coverage and reader/source lease, preserve branch, original assets, failures and costs, then use the normal managed helper. Twenty old worktrees retired; learning custody remains independently active.",
            "--writers-stopped",
        ]
    )[0]
    (OUT / "save.stdout").write_text(saved)
    commit = json.loads(saved)["commit"]
    assert (
        subprocess.check_output(
            ["git", "show", commit + ":" + str(report_path.relative_to(ROOT))], cwd=ROOT
        )
        == report_path.read_bytes()
    )
    pushed = run(["git", "push", "origin", "main"])
    (OUT / "push.stdout").write_text(pushed[0])
    (OUT / "push.stderr").write_text(pushed[1])
    assert run(["git", "ls-remote", "origin", "refs/heads/main"])[0].split()[0] == commit
    assert not run(["git", "status", "--porcelain=v1", "--untracked-files=all"])[0]
    put(
        OUT / "push-result.json",
        dict(
            commit=commit,
            remote_main=commit,
            push_exit_code=0,
            remaining_dirty=[],
            removed="arena-evaluation",
            registered=5,
            cumulative_removed=20,
        ),
    )
    run(
        [
            "bash",
            "scripts/dev/beads.sh",
            "update",
            "quoridor-4lc.324.12.6",
            "--append-notes",
            f"Actual arena-evaluation normal managed removal completed, branchcodex/arena-evaluation2bb906b retained. All present noncache files matched published source/control or prior immutable member custody; current scoped callers0, controlled B readers stopped and fresh supporting proc matches0 (denied UNKNOWN). Original81 opaque bodies in assets, old failures/RAW/UNKNOWN preserved; duplicates/tools separately documented. Canonical arena-evaluation-normal-removal.json at{commit}, normal push remote main exact/Main clean. Cumulative20 removed/registered5=protected4+learning-million. Only learning six-namespace/pause custody continues;12.6 remainsin_progress,12.9 not started.",
        ]
    )
    run(["bash", "scripts/dev/beads.sh", "backup", "sync"])
    print(json.dumps(dict(commit=commit, removed="arena-evaluation", registered=5)))


if __name__ == "__main__":
    main()
