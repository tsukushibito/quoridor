import collections
import hashlib
import json
import pathlib
import statistics

ROOT = pathlib.Path(__file__).resolve().parent
FIELDS = [
    "action",
    "value_bits",
    "completed_depth",
    "completed",
    "stop",
    "nodes",
    "evaluations",
    "terminal",
    "cutoffs",
    "tt_hits",
    "tt_cutoffs",
    "delta_updates",
    "pvs_researches",
    "pv",
]
original = {
    (r["name"], r["engine"]): r
    for line in (ROOT / "profile-r1/stdout.log").read_text().splitlines()
    if (r := json.loads(line))["kind"] == "search"
}
result = {
    "task": "frame22-search-efficiency-275-v1",
    "schema": "scratch-comparison-analysis-v1",
    "jobs": {},
}
for job in ["comparison-r1", "comparison-r2", "comparison-final-r1", "comparison-final-r2"]:
    path = ROOT / job
    rows = [json.loads(line) for line in (path / "stdout.log").read_text().splitlines()]
    searches = [r for r in rows if r["kind"] == "search"]
    total = rows[-1]
    assert total["kind"] == "job"
    assert sum(r["nodes"] for r in searches) == total["processed"]
    assert sum(r["evaluations"] for r in searches if r["engine"] == "L") == total["native_nn"]
    baseline = {
        (r["name"], r["sample"]): r
        for r in searches
        if r["engine"] == "L" and r["variant"] == "baseline"
    }
    for r in searches:
        assert r["root_restored"]
        assert r["completed_depth"] == 2
        snapshot = next(
            s for s in original[(r["name"], r["engine"])]["completed"] if s["depth"] == 2
        )
        assert (r["action"], r["value_bits"], r["nodes"]) == (
            snapshot["action"],
            snapshot["value_bits"],
            snapshot["nodes"],
        )
        if r["engine"] == "L":
            b = baseline[(r["name"], r["sample"])]
            assert all(r[f] == b[f] for f in FIELDS), (r["name"], r["variant"])
    groups = collections.defaultdict(list)
    for r in searches:
        if r["engine"] == "L" and not r["warmup"]:
            groups[(r["name"], r["variant"])].append(r)
    statistics_rows = []
    sums = collections.defaultdict(float)
    for (name, variant), rs in groups.items():
        ns = [r["elapsed_ns"] for r in rs]
        b = statistics.median([r["elapsed_ns"] for r in groups[(name, "baseline")]])
        ratio = [r["elapsed_ns"] / baseline[(name, r["sample"])]["elapsed_ns"] for r in rs]
        median = statistics.median(ns)
        sums[variant] += median
        statistics_rows.append(
            dict(
                root=name,
                variant=variant,
                n=len(ns),
                min_ns=min(ns),
                median_ns=median,
                max_ns=max(ns),
                ratio_of_medians=median / b,
                paired_ratio_median=statistics.median(ratio),
                paired_ratio_min=min(ratio),
                paired_ratio_max=max(ratio),
            )
        )
    process = json.loads((path / "process.json").read_text())
    assert (
        process["exit_code"] == 0
        and process["waited"]
        and process["current_exact_absent"]
        and not process["remaining"]
    )
    result["jobs"][job] = dict(
        native_nn=total["native_nn"],
        processed=total["processed"],
        guardian_wall_s=process["wall_seconds"],
        model_load_ns=total["load_ns"],
        executable_job_ns=total["job_ns"],
        comparisons=len(searches),
        complete_bit_counter_parity=True,
        original_depth2_snapshot_parity=True,
        statistics=statistics_rows,
        sum_root_steady_medians_ns=dict(sums),
        weighted_median_time_ratio={k: v / sums["baseline"] for k, v in sums.items()},
        source_payload_sha=hashlib.sha256((path / "stdout.log").read_bytes()).hexdigest(),
    )
result["limits"] = [
    "four correlated roots, repeated same host and model",
    "same-binary wrappers include common new search scaffold",
    "no original-vs-new D speed inference",
    "no full-game/time-limited depth or playing-strength claim",
    "no equivalence margin preset; report ratios and ranges",
    "advance feature/maps allocations remain; caller span is not internal exclusive breakdown",
]
(ROOT / "comparison-analysis.json").write_text(json.dumps(result, indent=2) + "\n")
for job, row in result["jobs"].items():
    print(job, row["weighted_median_time_ratio"], row["native_nn"], "parityPASS")
