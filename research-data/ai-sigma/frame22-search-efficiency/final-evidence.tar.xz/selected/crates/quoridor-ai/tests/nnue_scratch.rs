#![cfg(feature = "research")]
use quoridor_ai::alphabeta::{self as ab, EvalAccumulator, StaticEvaluator};
use quoridor_core::research::SigmaContext;
use quoridor_nnue::{DistanceFit, EvaluationMode, Model, Topology};
use std::sync::{
    Arc,
    atomic::{AtomicBool, AtomicU64, Ordering},
};
fn model(width: usize) -> Model {
    let t = Topology {
        ft_width: width,
        hidden_width: 5,
    };
    let weights = (0..t.parameter_count().unwrap())
        .map(|i| ((i % 17) as f32 - 8.) * 0.003)
        .collect();
    Model::from_parts(
        t,
        weights,
        [0.10, 0.09],
        [0.05, 0.06],
        DistanceFit { a: 0.06, b: 7.9 },
    )
    .unwrap()
}
#[test]
fn reused_delta_matches_owned_values_without_mutating_parent() {
    let m = model(4);
    let other = model(7);
    let mut count = 0;
    for prefix in [
        vec![],
        vec![13, 67, 81, 66, 14, 65],
        vec![13, 67, 81, 66, 14, 65, 143, 126, 150, 64, 141, 151],
        vec![13, 67, 22, 58, 31, 49, 40],
    ] {
        let c = SigmaContext::from_prefix(&prefix).unwrap();
        for mode in [EvaluationMode::Scalar, EvaluationMode::Simd] {
            let parent = m.full_context(&c, mode).unwrap();
            let before = parent.values.clone();
            let mut out = other.full_context(&c, EvaluationMode::Scalar).unwrap();
            let pointers = [out.values[0].as_ptr(), out.values[1].as_ptr()];
            for action in c.legal_ids() {
                let child = c.play(action).unwrap();
                let owned = m.delta_context(&parent, &child).unwrap();
                m.delta_context_into(&parent, &child, &mut out).unwrap();
                assert_eq!(owned.values, out.values);
                assert_eq!(pointers, [out.values[0].as_ptr(), out.values[1].as_ptr()]);
                assert_eq!(owned.features, out.features);
                assert_eq!(
                    m.evaluate(&owned).unwrap().to_bits(),
                    m.evaluate(&out).unwrap().to_bits()
                );
                count += 2;
                assert_eq!(parent.values, before);
            }
        }
    }
    println!("scratch_parity_native_nn={count}");
}
struct Owned<'a>(&'a ab::NnueEvaluator);
impl StaticEvaluator for Owned<'_> {
    fn prepare_context(&self, c: &SigmaContext) -> ab::Result<Option<EvalAccumulator>> {
        self.0.prepare_context(c)
    }
    fn advance_context(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
    ) -> ab::Result<Option<EvalAccumulator>> {
        self.0.advance_context(a, c)
    }
    fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> ab::Result<f32> {
        self.0.evaluate(c, a)
    }
}
#[test]
fn search_scratch_preserves_horizon_actions_counters_and_root() {
    let evaluator = ab::NnueEvaluator::new(Arc::new(model(4)));
    let owned = Owned(&evaluator);
    let mut nn = 0;
    for prefix in [
        vec![],
        vec![13, 67, 81, 66, 14, 65],
        vec![13, 67, 81, 66, 14, 65, 143, 126, 150, 64, 141, 151],
        vec![13, 67, 22, 58, 31, 49, 40],
    ] {
        let c = SigmaContext::from_prefix(&prefix).unwrap();
        let before = c.history_counts();
        for cap in [2, 1500] {
            let limits = ab::SearchLimits {
                max_depth: 2,
                max_nodes: cap,
                time_limit: None,
                tt_entries: 16384,
                use_pvs: true,
                use_tt: true,
            };
            let a = ab::search(&c, &owned, &limits, &AtomicBool::new(false)).unwrap();
            let b = ab::search(&c, &evaluator, &limits, &AtomicBool::new(false)).unwrap();
            nn += a.stats.evaluations + b.stats.evaluations;
            assert_eq!(a.action, b.action);
            assert_eq!(a.value.map(f32::to_bits), b.value.map(f32::to_bits));
            assert_eq!(a.completed_depth, b.completed_depth);
            assert_eq!(a.stop, b.stop);
            assert_eq!(a.pv, b.pv);
            assert_eq!(a.stats.nodes, b.stats.nodes);
            assert_eq!(a.stats.evaluations, b.stats.evaluations);
            assert_eq!(a.stats.delta_updates, b.stats.delta_updates);
            assert_eq!(a.stats.tt_hits, b.stats.tt_hits);
            assert_eq!(before, c.history_counts());
        }
    }
    println!("scratch_search_native_nn={nn}");
}
struct FailAdvance<'a> {
    inner: &'a ab::NnueEvaluator,
    calls: AtomicU64,
}
impl StaticEvaluator for FailAdvance<'_> {
    fn prepare_context(&self, c: &SigmaContext) -> ab::Result<Option<EvalAccumulator>> {
        self.inner.prepare_context(c)
    }
    fn advance_context_into(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
        out: &mut Option<EvalAccumulator>,
    ) -> ab::Result<()> {
        self.inner.advance_context_into(a, c, out)?;
        if self.calls.fetch_add(1, Ordering::Relaxed) == 2 {
            return Err(ab::SearchError::Evaluation(
                "injected scratch update failure".into(),
            ));
        }
        Ok(())
    }
    fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> ab::Result<f32> {
        self.inner.evaluate(c, a)
    }
}
#[test]
fn scratch_error_keeps_the_rule_cursor_restored() {
    let e = ab::NnueEvaluator::new(Arc::new(model(4)));
    let failing = FailAdvance {
        inner: &e,
        calls: AtomicU64::new(0),
    };
    let c = SigmaContext::from_prefix(&[81, 163]).unwrap();
    let before = c.history_counts();
    let l = ab::SearchLimits {
        max_depth: 2,
        max_nodes: 1000,
        time_limit: None,
        tt_entries: 16384,
        use_pvs: true,
        use_tt: true,
    };
    assert!(ab::search(&c, &failing, &l, &AtomicBool::new(false)).is_err());
    assert_eq!(c.history_counts(), before);
    println!("scratch_error_native_nn=2");
}
