//! Fixed-work alpha-beta costs. Measurements do not certify playing strength.
use quoridor_ai::alphabeta::{self as ab, EvalAccumulator, StaticEvaluator};
use quoridor_core::research::SigmaContext;
use quoridor_nnue::Model;
use serde_json::{Value, json};
use std::{
    sync::{
        Arc,
        atomic::{AtomicBool, AtomicU64, Ordering},
    },
    time::Instant,
};
struct Timed<'a> {
    inner: &'a dyn StaticEvaluator,
    nanos: [AtomicU64; 3],
    calls: [AtomicU64; 3],
}
impl<'a> Timed<'a> {
    fn new(inner: &'a dyn StaticEvaluator) -> Self {
        Self {
            inner,
            nanos: std::array::from_fn(|_| AtomicU64::new(0)),
            calls: std::array::from_fn(|_| AtomicU64::new(0)),
        }
    }
    fn record(&self, kind: usize, start: Instant) {
        self.nanos[kind].fetch_add(start.elapsed().as_nanos() as u64, Ordering::Relaxed);
        self.calls[kind].fetch_add(1, Ordering::Relaxed);
    }
    fn values(&self) -> Value {
        json!({"nanos":self.nanos.iter().map(|v| v.load(Ordering::Relaxed)).collect::<Vec<_>>(),"calls":self.calls.iter().map(|v| v.load(Ordering::Relaxed)).collect::<Vec<_>>(),"order":["prepare_context","advance_context","evaluate"],"scope":"disjoint evaluator caller spans; observer overhead outside spans in remainder"})
    }
}
impl StaticEvaluator for Timed<'_> {
    fn prepare_context(&self, c: &SigmaContext) -> ab::Result<Option<EvalAccumulator>> {
        let t = Instant::now();
        let r = self.inner.prepare_context(c);
        self.record(0, t);
        r
    }
    fn advance_context(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
    ) -> ab::Result<Option<EvalAccumulator>> {
        let t = Instant::now();
        let r = self.inner.advance_context(a, c);
        self.record(1, t);
        r
    }
    fn advance_context_into(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
        out: &mut Option<EvalAccumulator>,
    ) -> ab::Result<()> {
        let t = Instant::now();
        let r = self.inner.advance_context_into(a, c, out);
        self.record(1, t);
        r
    }
    fn evaluate_with_scratch(
        &self,
        c: &SigmaContext,
        a: Option<&EvalAccumulator>,
        scratch: &mut Vec<f32>,
    ) -> ab::Result<f32> {
        let t = Instant::now();
        let r = self.inner.evaluate_with_scratch(c, a, scratch);
        self.record(2, t);
        r
    }
    fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> ab::Result<f32> {
        let t = Instant::now();
        let r = self.inner.evaluate(c, a);
        self.record(2, t);
        r
    }
}
struct Variant<'a> {
    inner: &'a ab::NnueEvaluator,
    delta: bool,
    dense: bool,
}
impl StaticEvaluator for Variant<'_> {
    fn prepare_context(&self, c: &SigmaContext) -> ab::Result<Option<EvalAccumulator>> {
        self.inner.prepare_context(c)
    }
    fn advance_context(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
    ) -> ab::Result<Option<EvalAccumulator>> {
        self.inner.advance_context(a, c)
    }
    fn advance_context_into(
        &self,
        a: Option<&EvalAccumulator>,
        c: &SigmaContext,
        out: &mut Option<EvalAccumulator>,
    ) -> ab::Result<()> {
        if self.delta {
            self.inner.advance_context_into(a, c, out)
        } else {
            *out = self.inner.advance_context(a, c)?;
            Ok(())
        }
    }
    fn evaluate(&self, c: &SigmaContext, a: Option<&EvalAccumulator>) -> ab::Result<f32> {
        self.inner.evaluate(c, a)
    }
    fn evaluate_with_scratch(
        &self,
        c: &SigmaContext,
        a: Option<&EvalAccumulator>,
        scratch: &mut Vec<f32>,
    ) -> ab::Result<f32> {
        if self.dense {
            self.inner.evaluate_with_scratch(c, a, scratch)
        } else {
            self.inner.evaluate(c, a)
        }
    }
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    assert_eq!(std::env::var("ORT_DISABLE_TELEMETRY").as_deref(), Ok("1"));
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(args.len(), 2);
    let cfg: Value = serde_json::from_slice(&std::fs::read(&args[1])?)?;
    assert_eq!(cfg["task"], "frame22-search-efficiency-275-v1");
    let job = Instant::now();
    let model = Arc::new(Model::load(cfg["model"].as_str().unwrap())?);
    let load_ns = job.elapsed().as_nanos();
    let d = ab::DistanceEvaluator::new(
        cfg["a"].as_f64().unwrap() as f32,
        cfg["b"].as_f64().unwrap() as f32,
    );
    let l = ab::NnueEvaluator::new(model);
    let limits = ab::SearchLimits {
        max_depth: cfg["depth"].as_u64().unwrap() as u16,
        max_nodes: cfg["nodes"].as_u64().unwrap(),
        time_limit: None,
        tt_entries: 16384,
        use_pvs: true,
        use_tt: true,
    };
    let timers = cfg["timers"].as_bool().unwrap();
    let (mut nodes, mut nn) = (0u64, 0u64);
    let samples = cfg["samples"].as_u64().unwrap();
    assert!(cfg["fixtures"].as_array().unwrap().len() <= 8);
    for f in cfg["fixtures"].as_array().unwrap() {
        let prefix: Vec<u16> = f["prefix"]
            .as_array()
            .unwrap()
            .iter()
            .map(|v| v.as_u64().unwrap() as u16)
            .collect();
        let c = SigmaContext::from_prefix(&prefix)?;
        let history = c.history_counts();
        let board = c.position();
        let ply = c.total_ply();
        for sample in 0..samples {
            let mut variants: Vec<&str> = cfg["variants"]
                .as_array()
                .map(|a| a.iter().map(|v| v.as_str().unwrap()).collect())
                .unwrap_or_else(|| vec!["baseline", "delta", "scratch"]);
            // Alternating prospective order reduces a fixed first/last advantage.
            if sample % 2 == 1 {
                variants.reverse();
            }
            for variant in variants {
                assert!(["baseline", "delta", "scratch"].contains(&variant));
                let evaluation = Variant {
                    inner: &l,
                    delta: variant != "baseline",
                    dense: variant == "scratch",
                };
                let engines: Vec<(&str, &dyn StaticEvaluator)> = if cfg["include_distance"]
                    .as_bool()
                    .unwrap_or(false)
                    && variant == "baseline"
                {
                    vec![("D", &d), ("L", &evaluation)]
                } else {
                    vec![("L", &evaluation)]
                };
                for (name, evaluator) in engines {
                    let timed = Timed::new(evaluator);
                    let selected = if timers {
                        &timed as &dyn StaticEvaluator
                    } else {
                        evaluator
                    };
                    let start = Instant::now();
                    let mut completed = Vec::new();
                    let r = ab::search_with_updates(
                        &c,
                        selected,
                        &limits,
                        &AtomicBool::new(false),
                        &mut |s| {
                            completed.push(json!({"depth":s.completed_depth,"action":s.action,"value_bits":s.value.map(f32::to_bits),"nodes":s.stats.nodes}))
                        },
                    )?;
                    let elapsed_ns = start.elapsed().as_nanos();
                    nodes += r.stats.nodes;
                    if name == "L" {
                        nn += r.stats.evaluations;
                    }
                    assert_eq!(c.position(), board);
                    assert_eq!(c.history_counts(), history);
                    assert_eq!(c.total_ply(), ply);
                    assert!(nn <= cfg["nn_cap"].as_u64().unwrap());
                    assert!(nodes <= cfg["processed_cap"].as_u64().unwrap());
                    println!(
                        "{}",
                        json!({"task":"frame22-search-efficiency-275-v1","schema":"alphabeta-cost-v1","kind":"search","name":f["name"],"prefix":prefix,"engine":name,"variant":variant,"sample":sample,"warmup":samples>1 && sample==0,"timers":timers,"elapsed_ns":elapsed_ns,"evaluator_spans":timed.values(),"action":r.action,"value_bits":r.value.map(f32::to_bits),"completed_depth":r.completed_depth,"completed":completed,"stop":format!("{:?}",r.stop),"nodes":r.stats.nodes,"evaluations":r.stats.evaluations,"terminal":r.stats.terminal,"cutoffs":r.stats.cutoffs,"tt_hits":r.stats.tt_hits,"tt_cutoffs":r.stats.tt_cutoffs,"delta_updates":r.stats.delta_updates,"pvs_researches":r.stats.pvs_researches,"pv":r.pv,"root_restored":true})
                    );
                }
            }
        }
    }
    println!(
        "{}",
        json!({"kind":"job","task":"frame22-search-efficiency-275-v1","schema":"alphabeta-cost-v1","native_nn":nn,"processed":nodes,"load_ns":load_ns,"job_ns":job.elapsed().as_nanos(),"games":0,"gpu":0,"strength":"NOT_MEASURED"})
    );
    Ok(())
}
