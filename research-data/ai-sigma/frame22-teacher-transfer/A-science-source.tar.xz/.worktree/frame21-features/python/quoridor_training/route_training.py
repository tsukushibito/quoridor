"""Maintained trainer adapter for hash-bound QF1 route input.

No hot-loop JSON/replay. The source train/validation input is decoded once into
bulk tensors; test is neither accepted nor opened.
"""

import argparse
import gzip
import hashlib
import json
from pathlib import Path
import numpy as np
from .cache import sha
from .cache import load as load_native_cache
from .train import train, export, write, metrics


def load_route_cache(path):
    path = Path(path)
    binding = json.loads((path / "cache.json").read_text())
    if binding["schema"] != "quoridor-qf1-route-cache-v1" or binding["allow_test"]:
        raise ValueError("route cache version/test policy")
    source = binding["sources"]
    for name in ["train", "validation", "labels", "mask"]:
        item = source[name]
        if sha(item["path"]) != item["sha256"]:
            raise ValueError("source binding changed: " + name)
    if sha(path / "routes.f32") != binding["routes_sha256"]:
        raise ValueError("route input SHA changed")
    mask = json.loads(Path(source["mask"]["path"]).read_text())
    labels = {}
    with gzip.open(source["labels"]["path"], "rt") as stream:
        for line in stream:
            row = json.loads(line)
            if row["split"] not in ("train", "validation") or row["id"] in labels:
                raise ValueError("training label split/duplicate")
            labels[row["id"]] = row
    n = binding["rows"]
    x = np.zeros((n, 2, 312), dtype=np.float32)
    d = np.empty((n, 6), dtype=np.float32)
    y = np.empty((n, 2), dtype=np.float32)
    routes = np.memmap(path / "routes.f32", dtype="<f4", mode="r", shape=(n, 4))
    rows = []
    digest = hashlib.sha256()
    seen = set()
    groups = {"train": set(), "validation": set()}
    for split in ("train", "validation"):
        with gzip.open(source[split]["path"], "rt") as stream:
            for line in stream:
                r = json.loads(line)
                if r["split"] != split or r["id"] in seen or r["side"] not in (1, 2):
                    raise ValueError("canonical split/id/side")
                seen.add(r["id"])
                index = len(rows)
                if index >= n:
                    raise ValueError("cache row count")
                digest.update((r["id"] + "\n").encode())
                mark = mask["rows"][r["id"]]
                if mark["split"] != split or mark["group"] != r["group"]:
                    raise ValueError("registered mask identity")
                if r["id"] not in labels or labels[r["id"]]["split"] != split:
                    raise ValueError("missing/mismatched training label")
                label = labels[r["id"]]
                for v, view in enumerate((r["side"] - 1, 2 - r["side"])):
                    ids = r["ids"][view]
                    if not ids or ids != sorted(set(ids)) or min(ids) < 0 or max(ids) >= 312:
                        raise ValueError("QF1 sparse input")
                    x[index, v, ids] = 1
                d[index, :2] = r["distance"]
                d[index, 2:] = routes[index]
                y[index] = [label["rootmean"], np.nan if label["z"] is None else label["z"]]
                rows.append(
                    {
                        "id": r["id"],
                        "group": r["group"],
                        "game": r["game_id"],
                        "split": split,
                        "primary_eligible": bool(mark["primary_eligible"]),
                        "teacher_type": "mcts",
                        "rootmean": label["rootmean"],
                        "z": label["z"],
                        "cohort": r["cohort"],
                        "ply": r["ply"],
                    }
                )
                groups[split].add(r["group"])
    if len(rows) != n or seen != set(labels) or digest.hexdigest() != binding["row_order_sha256"]:
        raise ValueError("cache/source row identity")
    if groups["train"] & groups["validation"]:
        raise ValueError("family leakage")
    if not np.isfinite(d).all() or not np.isfinite(y[:, 0]).all():
        raise ValueError("nonfinite route/target")
    return binding, rows, x, d, y


def detailed_metrics(rows, prediction, target, constant):
    out = metrics(rows, prediction, target, constant)
    groups = {}
    phases = {}
    for r, p in zip(rows, prediction):
        g = groups.setdefault(
            r["group"],
            {
                "rows": 0,
                "rootmean_sse": 0.0,
                "z_sse": 0.0,
                "z_rows": 0,
                "sign_correct": 0,
                "sign_rows": 0,
                "saturated": 0,
            },
        )
        g["rows"] += 1
        g["rootmean_sse"] += (float(p) - r["rootmean"]) ** 2
        if r["z"] is not None:
            g["z_sse"] += (float(p) - r["z"]) ** 2
            g["z_rows"] += 1
            if r["z"] != 0:
                g["sign_rows"] += 1
                g["sign_correct"] += float(p) * r["z"] > 0
        g["saturated"] += abs(float(p)) >= 0.9
        ply = r.get("ply")
        phase = (
            "NOT_RECORDED"
            if ply is None
            else ("opening" if ply < 20 else ("middle" if ply < 60 else "late"))
        )
        a = phases.setdefault(phase, {"rows": 0, "rootmean_sse": 0.0})
        a["rows"] += 1
        a["rootmean_sse"] += (float(p) - r["rootmean"]) ** 2
    out["groups"] = groups
    out["phase"] = phases
    return out


def parity(args, build, freeze, receipt_path=None):
    """24 preselected rows, initial/BEST/LAST; explicit additional sample charge."""
    import subprocess
    import torch

    binding, rows, x, d, _ = load_route_cache(args.cache)
    chosen = [i for i, r in enumerate(rows) if r["split"] == "train"][:12] + [
        i for i, r in enumerate(rows) if r["split"] == "validation"
    ][:12]
    if len(chosen) != 24:
        raise ValueError("parity fixed witness count")
    ids = {rows[i]["id"] for i in chosen}
    canonical = []
    for split in ("train", "validation"):
        with gzip.open(binding["sources"][split]["path"], "rt") as stream:
            for line in stream:
                r = json.loads(line)
                if r["id"] in ids:
                    canonical.append(r)
    if [r["id"] for r in canonical] != [rows[i]["id"] for i in chosen]:
        raise ValueError("parity order")
    source = "".join(json.dumps(r, separators=(",", ":")) + "\n" for r in canonical)
    cfg = json.loads((Path(args.output) / "config.json").read_text())
    stats = json.loads((Path(args.output) / "scale.json").read_text())
    model = build(cfg["model"], stats)
    reports = []
    for name in ("initial", "best", "last"):
        cp = torch.load(Path(args.output) / (name + ".pt"), map_location="cpu", weights_only=True)
        model.load_state_dict(cp["model"])
        model.eval()
        with torch.inference_mode():
            pred = model(
                torch.from_numpy(x[chosen]),
                torch.from_numpy(d[chosen]),
                torch.ones(24, dtype=torch.long),
            ).numpy()
        run = subprocess.run(
            [
                args.native_binary,
                "model",
                str(Path(args.output) / (name + "-model") / "manifest.json"),
            ],
            input=source,
            text=True,
            capture_output=True,
            timeout=30,
            check=False,
        )
        if run.returncode:
            raise RuntimeError("native parity child failed: " + run.stderr[:1000])
        native = [json.loads(line) for line in run.stdout.splitlines()]
        if len(native) != 24 or [r["id"] for r in native] != [r["id"] for r in canonical]:
            raise ValueError("native parity rows")
        error = [abs(float(p) - r["value"]) for p, r in zip(pred, native)]
        if any(e > 1e-6 + 1e-6 * abs(float(p)) for e, p in zip(error, pred)):
            raise ValueError("Torch/native numeric parity")
        if name == "initial":
            reference = torch.tanh(
                torch.from_numpy(np.float32(8) * (d[chosen, 1] - d[chosen, 0]))
            ).numpy()
            if not np.array_equal(pred, reference):
                raise ValueError("initial D bit parity")
        reports.append(
            {
                "checkpoint": name,
                "weights_sha": sha(Path(args.output) / (name + "-model") / "weights.f32"),
                "max_abs": max(error),
                "rows": native,
                "torch_prediction": pred.tolist(),
            }
        )
    write(
        receipt_path or Path(args.output) / "parity.json",
        {
            "status": "PASS",
            "task": getattr(args, "task", "frame21-route-control-268-v1"),
            "schema": "route-control-parity-v1",
            "witness_ids": [r["id"] for r in canonical],
            "reports": reports,
            "additional_Torch_samples": 72,
            "nativeNN_samples": 144,
            "learning_samples": freeze["samples"],
            "all_NN_samples": freeze["samples"] + 216,
        },
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cache", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--config", required=True)
    parser.add_argument("--routes", choices=["zero4", "enabled"], required=True)
    parser.add_argument("--native-binary", required=True)
    parser.add_argument("--repair-existing-A")
    parser.add_argument("--extra-train-cache")
    parser.add_argument("--fixed-scale")
    parser.add_argument("--evaluation-points")
    parser.add_argument("--task", default="frame21-route-control-268-v1")
    args = parser.parse_args()
    from .residual_model import DistanceResidualModel, FEATURE_VERSION, ROUTE_VERSION

    enabled = args.routes == "enabled"
    route_statistics = json.loads((Path(args.cache) / "cache.json").read_text())["route_statistics"]

    def build(config, statistics):
        return DistanceResidualModel(
            config, statistics, a=0.0, b=8.0, routes=enabled, route_statistics=route_statistics
        )

    def load_inputs(cache):
        binding, rows, x, d, y = load_route_cache(cache)
        if not args.extra_train_cache:
            return binding, rows, x, d, y
        if enabled:
            raise ValueError("extra native cache supports explicit zero4 only")
        extra_binding, extra_rows, ex, ed, ey = load_native_cache(args.extra_train_cache)
        if any(r["split"] != "train" for r in extra_rows):
            raise ValueError("extra corpus must be train-only; evaluation is sealed")
        if {r["id"] for r in rows} & {r["id"] for r in extra_rows}:
            raise ValueError("duplicate original/extra row")
        if {r["group"] for r in rows} & {r["group"] for r in extra_rows}:
            raise ValueError("family overlap original/extra")
        if not all(r["primary_eligible"] for r in extra_rows):
            raise ValueError("extra train exposure mask must be explicit and eligible")
        if not np.isfinite(ey[:, 0]).all():
            raise ValueError("extra rootmean missing")
        for r in extra_rows:
            r.setdefault("cohort", "new-independent-train")
            r.setdefault("ply", None)
        combined = dict(binding)
        combined["extra_train_binding"] = extra_binding
        combined["dataset_sha"] = hashlib.sha256(
            json.dumps([binding["dataset_sha"], extra_binding["dataset_sha"]]).encode()
        ).hexdigest()
        extra_dense = np.column_stack([ed, np.zeros((len(extra_rows), 4), dtype=np.float32)])
        return (
            combined,
            rows + extra_rows,
            np.concatenate([x, ex]),
            np.concatenate([d, extra_dense]),
            np.concatenate([y, ey]),
        )

    def export_residual(model, config, statistics, _distance_fit, path):
        manifest_path = export(model, config, statistics, {"a": 0.0, "b": 8.0}, path)
        manifest = json.loads(manifest_path.read_text())
        for name in ("transformer_width", "hidden_width", "source_kind"):
            manifest.pop(name, None)
        manifest.update(
            {
                "schema": "quoridor-nnue-distance-residual-v3",
                "feature": FEATURE_VERSION,
                "value_perspective": "side-to-move",
                "value_parameterization": "fixed-distance-logit-plus-linear-residual-tanh",
                "dense_feature_version": ROUTE_VERSION,
                "route_mode": args.routes,
                "route_mu_f32": route_statistics["mu_f32"],
                "route_sigma_f32": route_statistics["sigma_f32"],
                "topology": {
                    "ft_width": config["model"]["transformer_width"],
                    "hidden_width": config["model"]["hidden_width"],
                },
            }
        )
        write(manifest_path, manifest)
        return manifest_path

    freeze = train(
        args.cache,
        args.output,
        args.config,
        model_builder=build,
        cache_loader=load_inputs,
        model_export=export_residual,
        export_onnx=False,
        evaluation_points=(
            json.loads(Path(args.evaluation_points).read_text())
            if args.evaluation_points
            else [0, 1, 2, 5, 10, 20, 50, 100, 200, 400]
        ),
        measure=detailed_metrics,
        distance_fit_override={"a": 0.0, "b": 8.0},
        statistics_override=(
            json.loads(Path(args.fixed_scale).read_text()) if args.fixed_scale else None
        ),
    )
    parity(args, build, freeze)
    if args.repair_existing_A:
        if not enabled:
            raise ValueError("existing A repair is only in the B family")
        import copy

        old = copy.copy(args)
        old.output = args.repair_existing_A
        old.routes = "zero4"
        old_freeze = json.loads((Path(old.output) / "freeze.json").read_text())

        def build_A(config, statistics):
            return DistanceResidualModel(
                config, statistics, a=0.0, b=8.0, routes=False, route_statistics=route_statistics
            )

        parity(old, build_A, old_freeze, Path(args.output) / "parity-existing-A.json")


if __name__ == "__main__":
    main()
