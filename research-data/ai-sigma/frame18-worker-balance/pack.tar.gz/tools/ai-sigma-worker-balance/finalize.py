"""NN0 stopped-payload ledger and necessary scientific source receipt."""
from pathlib import Path
import json,datetime,hashlib,subprocess,time
R=Path.cwd();T=R/'tools/ai-sigma-worker-balance';D=R/'research-data/ai-sigma/frame18-worker-balance'
start=time.monotonic()
load=lambda p:json.loads(p.read_text())
save=lambda p,x:p.write_text(json.dumps(x,indent=2)+'\n')
def lines(p):
 if p.exists():
  for l in p.read_text().splitlines():
   if l.strip():yield json.loads(l)
models=['baseline-r2','balanced-r3','balanced-r4']
attempts=[];totalwall=0.;NNupper=0
for name in ['baseline-r1',*models]:
 J=D/'jobs'/name;p=load(J/'process.json');s=load(D/(name+'-summary.json'))
 assert p['all_child_waited'] and not p['remaining']
 exact=[]
 for q in p['tracked']:
  f=Path('/proc')/str(q['pid'])/'stat'
  if f.exists():
   try:
    tick=int(f.read_text().rsplit(')',1)[1].split()[19])
    if tick==q['tick']:exact.append(q)
   except OSError:pass
 assert not exact
 lower=sum(x['NN_completed'] for c in[2,4,6] for x in lines(J/f'core{c}/raw-rows.jsonl'))
 startup=load(J/'provider-init.json')['single_sample_equivalent'] if (J/'provider-init.json').exists() else 0
 upper=p['NN_cap'] if name in models else 0
 totalwall+=p['jobwall_seconds'];NNupper+=upper
 attempts.append(dict(run=name,model_scientific_slot=models.index(name)+1 if name in models else None,planned_games=96,original_sample=p['sample_equivalent'],NN_unknown_upper=upper,saved_completed_NN_lower=lower,startup_observed=startup,original_start=p['startUTC'],original_end=p['endUTC'],jobwall_s=p['jobwall_seconds'],exit=p['exit'],stop_reason=p['stop_reason'],all_waited=True,current_exact_absent=True,status=s['status_counts'],Rpolicy=s['Rpolicy'],Rz=s['Rz'],Rjoint=s['Rjoint'],unknown_z_rows=s['unknown_z_rows'],qualification_s=s['qualify_wall_s'],all_slot_plies=s['all_slot_plies'],offender=load(J/'foreign-compute-detected.json') if (J/'foreign-compute-detected.json').exists() else None))
# All root pairs available in censored baseline and both candidates, without asserting common full work.
def raw(name):
 return {(x['game_id'],x['new_ply']):x for c in[2,4,6] for x in lines(D/'jobs'/name/f'core{c}/raw-rows.jsonl')}
base=raw('baseline-r2');rootpairs=[]
for name in ['balanced-r3','balanced-r4']:
 other=raw(name);pairs=base.keys()&other.keys()
 fields=['state_key','features648_bits','history_counts','action209','visits136','rootN','edgeSum']
 rootpairs.append(dict(candidate=name,available_pairs=len(pairs),baseline_rows=len(base),candidate_rows=len(other),mismatch_counts={f:sum(base[k][f]!=other[k][f] for k in pairs) for f in fields},same_state_rootNN_maxabs=max([abs(base[k]['rootNN']-other[k]['rootNN']) for k in pairs if base[k]['state_key']==other[k]['state_key']]+[0.]),partial_correspondence_not_whole_work=True))
summary=dict(issue='quoridor-4lc.225',UTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='INCONCLUSIVE_CENSORED_NO_WHOLE_WORK_COMPARISON',allocation_only='fixed cohort balanced assignment; same opening/pergame RNG/K/model/provider',model_scientific_slots_used=3,management_premodel_entry_separate=True,attempts=attempts,all_attempt_guardian_wall_s=totalwall,additional_admission_management_wall_unknown=True,admission_failure_conservative_s=10,NN_physical_actual='UNKNOWN',NN_upper_charge=NNupper,NN_cap=1050000,heavy_known_s=totalwall,heavy_upper_with_management_admissions_s=totalwall+10,heavy_cap_s=1500,qualified_prefix_rows=sum(x['Rpolicy'] for x in attempts),joint_prefix_rows=sum(x['Rjoint'] for x in attempts),partial_root_correspondence=rootpairs,baseline_r3='NOT_STARTED(COORDINATOR_PRIORITY_REORDER)',no_complete96_mode=True,balancing_speed_benefit='UNCONFIRMED; no performance negative inferred from guard faults',break_even_N='UNKNOWN (no matched whole-job delta)',scenario1000_prediction='no current update; old221known52.4706min+unknown is oldhost lineage reference only',next_one_judgment='stop optimization retries; use already accepted codecGraph for independent staged generation/trainer connection under new allocation',learning_mix=False,strength_claim=False,latest_stop_delivery_race=load(D/'jobs/balanced-r4/user-priority-stop.json'),static_conservative_charge_s=110,static_cap_s=180,management_conservative_total_bound_s=150,management_cap_s=300,source_LLMed_elapsed_not_CPU_wall=True,old_caps_or_unknown_discount=False,parent_added=False)
summary['finalize_math_wall_s']=time.monotonic()-start
save(D/'compact-result.json',summary)
files={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in T.glob('*') if p.is_file()}
payload={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in D.rglob('*') if p.is_file() and p.name not in ['science-stop.json','pack.tar.gz','pack-members.json','pack-receipt.json']}
save(D/'science-stop.json',dict(UTC=summary['UTC'],issue=summary['issue'],scientific_source_write_stopped=True,science_newstart_authorized=False,all_model_children_waited=True,current_exact_absent=True,source_files=files,payload=payload,actual_model_slots=models,model_NN_UNKNOWN_preserved=True,scope_final_save_helpers_separate=True))
print(json.dumps({k:summary[k] for k in ['status','all_attempt_guardian_wall_s','NN_upper_charge','qualified_prefix_rows','joint_prefix_rows','partial_root_correspondence','finalize_math_wall_s']},indent=2))
