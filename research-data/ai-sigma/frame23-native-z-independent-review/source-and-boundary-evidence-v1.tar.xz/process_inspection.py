"""Read-only /proc point helpers; no old experiment entrypoint executed."""

from pathlib import Path

BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def proc(pid):
    try:
        p = Path("/proc") / str(pid)
        stat = (p / "stat").read_text().rsplit(")", 1)[1].split()
        status = (p / "status").read_text()
        return {
            "pid": int(pid),
            "ppid": int(stat[1]),
            "pgid": int(stat[2]),
            "tick": stat[19],
            "cpu": int(stat[11]) + int(stat[12]),
            "rss": int(status.split("VmRSS:")[1].split()[0]) * 1024 if "VmRSS:" in status else 0,
            "argv": (p / "cmdline").read_bytes().decode(errors="replace").split("\0")[:-1],
            "boot": BOOT,
        }
    except (OSError, ValueError, IndexError):
        return None


def snapshot():
    return {
        int(p.name): item
        for p in Path("/proc").iterdir()
        if p.name.isdigit() and (item := proc(p.name))
    }


def compute(item):
    argv = item["argv"]
    exe = Path(argv[0]).name if argv else ""
    if exe in {"cargo", "rustc"} or exe.startswith(
        ("nnue-diagnose", "route-feature-diagnose", "quoridor-runner")
    ):
        return True
    if exe.startswith("python"):
        script = next((p for p in argv[1:] if p.endswith(".py")), "")
        return any(k in script for k in ("frame23", "quoridor_training", "guard.py")) and not any(
            k in script for k in ("research-job", "research-team", "research-scheduler")
        )
    return False
