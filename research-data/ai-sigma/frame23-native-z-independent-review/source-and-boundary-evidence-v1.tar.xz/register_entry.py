"""Build the final single-entry registration after a frozen label release."""

import argparse
import json
from pathlib import Path

from pipeline import sha

ROOT = Path("/workspaces/quoridor")
DATA = ROOT / "research-data/ai-sigma/frame23-native-z-independent-review"
NEW = ROOT / "research-data/ai-sigma/frame23-native-outcome-z-learning"
PRODUCER = ROOT / "research-data/ai-sigma/frame23-native-z-fresh-evaluation"


def process_binding(path, expected_exit=0, producer=False):
    receipt = json.loads(Path(path).read_text())
    exit_key = "exit"
    remaining_key = "current_exact_remaining" if producer else "currentexact"
    assert receipt[exit_key] == expected_exit and receipt["waited"] is True
    assert not receipt[remaining_key]
    return {
        "path": str(path),
        "exit_key": exit_key,
        "expected_exit": expected_exit,
        "wait_key": "waited",
        "remaining_key": remaining_key,
        "identities_key": "recorded_children",
        "tick_key": "start_ticks",
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", required=True)
    args = parser.parse_args()
    releasepath = Path(args.release)
    release = json.loads(releasepath.read_text())
    freeze_path = DATA / "evaluation-freeze-v2.json"
    freeze = json.loads(freeze_path.read_text())
    # The release adapters are constructed from the actual public receipt only.
    adapter = json.loads((DATA / "release-interface-v1.json").read_text())
    assert release[adapter["release_freeze_key"]]["SHA"] == sha(freeze_path)
    newstop = NEW / "source-reader-selector-stop-final-v1.json"
    producerstop = PRODUCER / "scientific-source-stop-v1.json"
    ns, ps = json.loads(newstop.read_text()), json.loads(producerstop.read_text())
    inputs = dict(freeze["all_input_bindings"])
    # Preserve the prefreeze admission source, then bind the management-only
    # correction. This does not change model/math/mask/terminal rules.
    inputs[str(DATA / "entry_guard.py")] = sha(DATA / "entry_guard.py")
    for path in DATA.glob("*.py"):
        inputs[str(path)] = sha(path)
    for path in [
        freeze_path,
        newstop,
        producerstop,
        releasepath,
        DATA / "release-interface-v1.json",
        DATA / "owner-point-before-entry-v1.json",
        DATA / "argv-schema-fixture-final-v1.json",
        DATA / "pre-freeze-entry-guard-v1.py.gz",
        DATA / "guard-management-boundary-correction-v1.json",
    ]:
        inputs[str(path)] = sha(path)
    newprocesses = [
        process_binding(record["path"], 1 if "saved-freeze" in record["path"] else 0)
        for record in ns["stops"]
    ]
    producerprocesses = [
        process_binding(record["path"], producer=True)
        for record in ps["recorded5_processwait_currentexactabsence"]
    ]
    backgrounds_new = [NEW / "background-native-z-fit-r1/result.json"]
    backgrounds_producer = [PRODUCER / f"background-block{n:02d}-r1/result.json" for n in (0, 1)]
    for record in ns["stops"] + ps["recorded5_processwait_currentexactabsence"]:
        inputs[record["path"]] = record["SHA"]
    for path in backgrounds_new + backgrounds_producer:
        inputs[str(path)] = sha(path)
    for record in adapter["label_scalar_bindings"] + adapter["game_provenances"]:
        inputs[record["path"]] = record["SHA"]
    keeper = ROOT / "research-data/ai-sigma/frame23-steward/storage-native-z-298-300-admission.json"
    inputs[str(keeper)] = sha(keeper)
    reg = {
        "task": "native-terminal-z-independent-300-v1",
        "schema": "native-terminal-z-independent-registration-300-v1",
        "entry": str(DATA / "pipeline.py"),
        "entry_SHA": sha(DATA / "pipeline.py"),
        "guard_SHA": sha(DATA / "entry_guard.py"),
        "python": "/home/vscode/.cache/inference/envs/quoridor-training/bin/python",
        "inputs": inputs,
        "evaluation_freeze": str(freeze_path),
        "eligible_rows": freeze["eligible_input_rows"],
        "physicalNN_upper": freeze["physicalNN_upper"],
        "label_release": str(releasepath),
        "release_freeze_key": adapter["release_freeze_key"],
        "game_provenances": adapter["game_provenances"],
        "label_scalar_bindings": adapter["label_scalar_bindings"],
        "family_map": str(PRODUCER / "registered-family-map-v1.json"),
        "storage": str(keeper),
        "storage_total_key": "total",
        "storage_cap_key": "cap",
        "remaining_output_Git_temp_forecast": 245760,
        "admission_directory": "scientific-entry-r1",
        "budget": {
            "MAX": 1,
            "command_s": 180,
            "NN": 50000,
            "processed": 120000,
            "source_s": 100,
            "manage_s": 30,
            "CPU": 3,
            "RAM_guard_B": 448 * 1024**2,
            "data_cap_B": 524288,
            "newGPU": 0,
        },
        "stops": [
            {
                "path": str(newstop),
                "required_flags": [
                    "listed_source_writer_STOP",
                    "modelreader_STOP",
                    "selector_STOP",
                    "all_3_children_wait_currentexact_absent",
                    "background_cleanup",
                ],
                "processes": newprocesses,
                "backgrounds": list(map(str, backgrounds_new)),
            },
            {
                "path": str(producerstop),
                "required_flags": [
                    "sourcewriter_all5_newPython_stopped",
                    "background2_cleanup_complete",
                    "scalar_z_vsSTM_terminal_join",
                ],
                "processes": producerprocesses,
                "backgrounds": list(map(str, backgrounds_producer)),
            },
        ],
        "expected_output": str(DATA / "evaluation-r1/result-v1.json"),
        "expected_output_schema": "native-terminal-z-independent-result-300-v1",
        "native_children_max": 2,
        "native_rows_per_child": len(freeze["native_witness_indices"]),
        "native_evals_per_row": 3,
        "native_child_hard_s": 20,
        "argv_required_once": ["--registration"],
        "targets_opened_before_prediction": False,
        "prior_management_guard_source_preserved": "pre-freeze-entry-guard-v1.py.gz",
        "old_298_failed_auxiliary_expected_exit": 1,
        "no_reselection_refill_or_retry": True,
    }
    current = sum(f.stat().st_blocks * 512 for f in DATA.rglob("*") if f.is_file())
    assert current + reg["remaining_output_Git_temp_forecast"] + 32768 <= 524288, current
    (DATA / "scientific-registration-v1.json").write_text(json.dumps(reg, indent=2) + "\n")
    print(
        json.dumps(
            {
                "registered": True,
                "NN_upper": reg["physicalNN_upper"],
                "current_before_registration": current,
                "new_science_started": False,
            }
        )
    )


if __name__ == "__main__":
    main()
