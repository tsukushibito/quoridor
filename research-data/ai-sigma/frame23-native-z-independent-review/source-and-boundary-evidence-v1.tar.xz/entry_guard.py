"""300 fresh admission and one scientific entry with own child reaping."""

import argparse
import ctypes
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

from process_inspection import BOOT, compute, proc, snapshot

ROOT = Path("/workspaces/quoridor")
DATA = ROOT / "research-data/ai-sigma/frame23-native-z-independent-review"
TASK = "native-terminal-z-independent-300-v1"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    assert reg["task"] == TASK and reg["guard_SHA"] == sha(__file__)
    os.sched_setaffinity(0, {3})
    assert ctypes.CDLL(None).prctl(36, 1, 0, 0, 0) == 0
    job = DATA / reg["admission_directory"]
    job.mkdir(exist_ok=False)
    before = snapshot()
    ancestors, cursor = {os.getpid()}, os.getpid()
    while cursor in before and before[cursor]["ppid"] not in ancestors:
        cursor = before[cursor]["ppid"]
        ancestors.add(cursor)
    foreign = [v for k, v in before.items() if k not in ancestors and compute(v)]
    admission = {"task": TASK, "UTC": now(), "foreign": foreign, "NN": 0, "MAX_consumed": 0}
    if foreign:
        admission["status"] = "NOT_STARTED_FOREIGN_CPU"
        (job / "admission.json").write_text(json.dumps(admission, indent=2) + "\n")
        return 78
    for path, expected in reg["inputs"].items():
        assert sha(path) == expected, path
    for stop in reg["stops"]:
        record = json.loads(Path(stop["path"]).read_text())
        assert all(record[key] is True for key in stop["required_flags"])
        for binding in stop["processes"]:
            receipt = json.loads(Path(binding["path"]).read_text())
            assert receipt[binding["exit_key"]] == binding.get("expected_exit", 0)
            assert receipt[binding["wait_key"]] and not receipt[binding["remaining_key"]]
            for identity in receipt.get(binding["identities_key"], []):
                current = proc(identity["pid"])
                assert not current or current["tick"] != str(identity[binding["tick_key"]])
        for path in stop["backgrounds"]:
            receipt = json.loads(Path(path).read_text())
            assert receipt["cleanup_complete"] and not receipt["remaining"]
    state = json.loads(
        (ROOT / ".artifacts/research-team/frame22-extension23/scheduler/state.json").read_text()
    )
    base = (
        ROOT
        / ".artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92/frame22-extension23"
    )
    monitor = json.loads((base / "monitor-process.json").read_text())
    expectations = json.loads((base / "expectations.json").read_text())
    hashes = {p: sha(p) == h for p, h in expectations["input_hashes"].items()}
    assert len(hashes) == 24 and all(hashes.values())
    assert state["phase"] == "running" and monitor["owned_scheduler"] == state["process"]
    assert sha(state["binding"]["config_path"]) == state["config_sha256"]
    assert sha(state["binding"]["contract_file"]) == state["contract_sha256"]
    for identity in (state["process"], monitor["process"]):
        p = proc(identity["pid"])
        assert identity["boot_id"] == BOOT and p and p["tick"] == str(identity["start_ticks"])
    storage = json.loads(Path(reg["storage"]).read_text())
    assert (
        not storage["errors"]
        and storage[reg["storage_total_key"]] < storage[reg["storage_cap_key"]]
    )
    currentbytes = sum(p.stat().st_blocks * 512 for p in DATA.rglob("*") if p.is_file())
    assert currentbytes + reg["remaining_output_Git_temp_forecast"] <= 524288
    old = sum(
        p.stat().st_blocks * 512
        for name in ("frame23-independent-evaluation", "frame23-rootmean-saved-arithmetic")
        for p in (ROOT / "research-data/ai-sigma" / name).rglob("*")
        if p.is_file()
    )
    assert old + 524288 <= 3670016
    memory = {
        line.split(":")[0]: int(line.split()[1]) * 1024
        for line in Path("/proc/meminfo").read_text().splitlines()
    }
    assert memory["MemAvailable"] > 2 * 1024**3
    argv = [
        "/usr/bin/taskset",
        "-c",
        "3",
        reg["python"],
        "-B",
        reg["entry"],
        "--registration",
        str(Path(args.registration)),
    ]
    assert argv.count(str(Path(args.registration))) == 1
    admission.update(
        status="ADMITTED_POINT",
        argv=argv,
        expected_schema="native-terminal-z-independent-result-300-v1",
        entry_SHA=sha(reg["entry"]),
        registration_SHA=sha(args.registration),
        current24=hashes,
        owned=state.get("owned"),
        scheduler=state["process"],
        monitor=monitor["process"],
        boot=BOOT,
        MemAvailable=memory["MemAvailable"],
        current_data_bytes=currentbytes,
        future_forecast=reg["remaining_output_Git_temp_forecast"],
        storage_SHA=sha(reg["storage"]),
        point_only=True,
    )
    assert admission["entry_SHA"] == reg["entry_SHA"]
    (job / "admission.json").write_text(json.dumps(admission, indent=2) + "\n")
    gpu = subprocess.run(
        ["nvidia-smi", "--query-compute-apps=pid,used_memory", "--format=csv,noheader,nounits"],
        capture_output=True,
        text=True,
        timeout=5,
        check=False,
    )
    (job / "GPU-point.json").write_text(
        json.dumps(
            {
                "UTC": now(),
                "exit": gpu.returncode,
                "stdout": gpu.stdout,
                "stderr": gpu.stderr,
                "newGPU": False,
            }
        )
        + "\n"
    )
    seen, cause, peak = {}, None, 0
    start, started = time.monotonic(), now()
    with (job / "stdout.log").open("w") as out, (job / "stderr.log").open("w") as err:
        child = subprocess.Popen(argv, stdout=out, stderr=err, start_new_session=True)
        initial = proc(child.pid)
        if initial:
            seen[child.pid] = initial
        (job / "actual-start.json").write_text(
            json.dumps({"task": TASK, "started": started, "argv": argv, "identity": initial}) + "\n"
        )
        try:
            while child.poll() is None:
                current = snapshot()
                owned = {pid for pid, item in current.items() if item["pgid"] == child.pid}
                seen.update({pid: current[pid] for pid in owned})
                peak = max(peak, sum(current[pid]["rss"] for pid in owned))
                foreign = [
                    p
                    for pid, p in current.items()
                    if pid not in ancestors
                    and pid not in owned
                    and compute(p)
                    and (
                        pid not in before
                        or p["tick"] != before[pid]["tick"]
                        or p["cpu"] - before[pid]["cpu"] >= 2
                    )
                ]
                if foreign:
                    cause = "FOREIGN_COMPUTE"
                if peak > 448 * 1024**2:
                    cause = "RAM_GUARD"
                if time.monotonic() - start > 180:
                    cause = "WALL_GUARD"
                if datetime.datetime.now(datetime.timezone.utc) >= datetime.datetime(
                    2026, 10, 5, 22, 55, tzinfo=datetime.timezone.utc
                ):
                    cause = "DEADLINE"
                if cause:
                    os.killpg(child.pid, signal.SIGTERM)
                    break
                before = current
                time.sleep(0.02)
        except BaseException as exc:
            cause = "GUARD_EXCEPTION:" + type(exc).__name__
            os.killpg(child.pid, signal.SIGTERM)
        try:
            code = child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait()
    while True:
        try:
            pid, _ = os.waitpid(-1, os.WNOHANG)
            if pid == 0:
                break
        except ChildProcessError:
            break
    remaining = [
        p for pid, saved in seen.items() if (p := proc(pid)) and p["tick"] == saved["tick"]
    ]
    resultfile = DATA / "evaluation-r1/result-v1.json"
    result = json.loads(resultfile.read_text()) if resultfile.exists() else None
    valid = (
        code == 0
        and not remaining
        and result
        and result["PASS"]
        and result["task"] == TASK
        and result["schema"] == admission["expected_schema"]
    )
    receipt = {
        "task": TASK,
        "started": started,
        "ended": now(),
        "wall_seconds": time.monotonic() - start,
        "exit_code": code,
        "cause": cause,
        "waited": True,
        "recorded_identities": list(seen.values()),
        "current_exact_remaining": remaining,
        "peak_RSS": peak,
        "purpose_output_PASS": bool(valid),
        "NN": result["NN"] if valid else "UNKNOWN",
        "conservative_NN_charge": reg["physicalNN_upper"],
        "MAX_consumed": 1,
        "no_automatic_retry": True,
        "foreign_on_stop": foreign,
    }
    (job / "process.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: v for k, v in receipt.items() if k != "recorded_identities"}))
    return 0 if valid else 1


if __name__ == "__main__":
    raise SystemExit(main())
