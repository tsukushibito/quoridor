"""300 target-free namespace/OR mask and immutable evaluation-rule freeze."""

import argparse
import base64
from collections import Counter
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import sys

from evaluation_math import canonical_input, literal_history
from pipeline import row_order, sha

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-native-z-independent-review"
TASK = "native-z-targetfree-freeze-300-v1"
KEYS = {
    "id",
    "canonical_family",
    "native_family_alias",
    "partition",
    "side",
    "ply",
    "cohort",
    "cohort_pair",
    "opening_side",
    "state_key",
    "history_key",
    "history_literal",
    "history_key_format",
    "actualSTM_ids",
    "ids_order",
    "STM_distance_f32bits",
    "distance_order",
    "input_signature",
    "prefix",
    "producer_schema",
    "producer_source_SHA",
}


def rows(binding):
    assert sha(binding["path"]) == binding["SHA"]
    opener = gzip.open if binding["path"].endswith(".gz") else open
    digest = hashlib.sha256()
    with opener(binding["path"], "rb") as stream:
        for line in stream:
            digest.update(line)
            yield json.loads(line)
    if "uncompressed_SHA" in binding:
        assert digest.hexdigest() == binding["uncompressed_SHA"]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    assert reg["task"] == TASK and reg["entry_SHA"] == sha(__file__)
    assert sys.argv.count(str(Path(args.registration))) == 1
    for path, expected in reg["inputs"].items():
        assert sha(path) == expected
    states, histories, inputs = set(), set(), set()
    reference_counts = {}
    for binding in reg["reference_sets"]:
        witness_bindings, witness_cache, cached_path = {}, {}, None
        if binding.get("format") == "native_learner_actualSTM_refs":
            for witness in binding["witnesses"]:
                witness_bindings[witness["path"]] = witness
        wanted = None
        if "subset" in binding:
            wanted = {r["id"]: r for r in rows(binding["subset"])}
            assert len(wanted) == binding["subset"]["rows"]
        count = 0
        for row in rows(binding):
            if binding.get("format") == "native_learner_actualSTM_refs":
                row = dict(row)
                witness = row["prefix_witness"]
                assert witness["SHA"] == witness_bindings[witness["path"]]["SHA"]
                if cached_path != witness["path"]:
                    witness_cache = {r["id"]: r for r in rows(witness_bindings[witness["path"]])}
                    cached_path = witness["path"]
                q = witness_cache[witness["id"]]
                assert not ({"z", "rootmean", "winner", "prediction", "loss"} & set(q))
                assert q["ids_order"] == "P1_then_P2"
                assert q["side"] == row["side"]
                assert (q["ids"] if q["side"] == 1 else q["ids"][::-1]) == row["actualSTM_ids"]
                assert q["distance_bits"] == row["STM_distance_f32bits"]
                literal = json.dumps(
                    q["history_literal"], separators=(",", ":"), ensure_ascii=False
                )
                assert (
                    hashlib.sha256(literal.encode()).hexdigest()
                    == row["history_literal_SHA"]
                    == q["history_key"]
                )
                assert q["state_key"] == row["state_key"]
                row.update(
                    ids_order="STM_then_opponent",
                    distance_order="STM_then_opponent_f32_le",
                    history_literal=q["history_literal"],
                    history_key_format=q["history_format"],
                )
            if wanted is not None:
                if row["id"] not in wanted:
                    continue
                filtered = wanted.pop(row["id"])
                if binding.get("subset_signature") == "learner_byte_lengths":
                    import struct

                    ids = row["actualSTM_ids"]
                    views = [struct.pack("<" + "H" * len(view), *view) for view in ids]
                    payload = (
                        b"QF1-f32-STM-v1\0"
                        + struct.pack("<HH", *map(len, views))
                        + b"".join(views)
                        + struct.pack("<II", *row["STM_distance_f32bits"])
                    )
                    assert hashlib.sha256(payload).hexdigest() == filtered["input_signature"]
            key = canonical_input(row)
            if row.get("state_key") is not None:
                states.add(row["state_key"])
            history = literal_history(row)
            if history is not None:
                histories.add(history)
            inputs.add(key)
            count += 1
        assert wanted is None or not wanted
        assert count == binding["expected_rows"]
        reference_counts[binding["name"]] = count
    familymap = json.loads(Path(reg["family_map"]).read_text())
    families = {r["canonical_family"]: r for r in familymap["families"]}
    assert len(families) == 96
    raw = []
    keys = set()
    for binding in reg["future_inputs"]:
        for row in rows(binding):
            assert set(row) == KEYS
            assert row["partition"] == reg["future_partition"]
            family = families[row["canonical_family"]]
            assert row["native_family_alias"] == family["native_family"]
            assert (
                row["cohort"] == family["cohort"]
                and row["cohort_pair"] == family["cohort_pair"]
                and row["opening_side"] == family["opening_side"]
            )
            assert row["side"] in (1, 2) and row["ply"] == len(row["prefix"])
            assert row["side"] == 1 + row["ply"] % 2
            assert row["prefix"][: len(family["prefix"])] == family["prefix"]
            key = (row["canonical_family"], row["id"])
            assert key not in keys
            keys.add(key)
            assert canonical_input(row) == row["input_signature"]
            raw.append(row)
    assert len(raw) == reg["raw_rows"] and len(raw) <= 19200
    bitset = bytearray((len(raw) + 7) // 8)
    kept, excluded, reasons = [], Counter(), Counter()
    for i, row in enumerate(raw):
        flags = {
            "state": row.get("state_key") is not None and row["state_key"] in states,
            "history": literal_history(row) is not None and literal_history(row) in histories,
            "input": canonical_input(row) in inputs,
        }
        if any(flags.values()):
            excluded[row["canonical_family"]] += 1
            reasons.update(k for k, value in flags.items() if value)
        else:
            bitset[i // 8] |= 1 << (i % 8)
            kept.append(row)
    witnesses = {}
    for i in sorted(range(len(kept)), key=lambda j: (kept[j]["canonical_family"], kept[j]["id"])):
        row = kept[i]
        witnesses.setdefault((row["cohort"], row["opening_side"], row["side"]), i)
    indices = list(witnesses.values())[:24]
    per_raw, per_eligible = (
        Counter(r["canonical_family"] for r in raw),
        Counter(r["canonical_family"] for r in kept),
    )
    freeze = {
        "task": TASK,
        "schema": "native-z-independent-input-mask-freeze-300-v1",
        "UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "candidate_bindings": reg["candidate_bindings"],
        "models": reg["models"],
        "constant": reg["constant"],
        "terminal_schema": reg["terminal_schema"],
        "target_free_inputs": [x["path"] for x in reg["future_inputs"]],
        "all_input_bindings": reg["inputs"],
        "reference_counts": reference_counts,
        "planned_families": 96,
        "raw_rows": len(raw),
        "eligible_input_rows": len(kept),
        "per_family": {
            f: {"raw": per_raw[f], "eligible_input": per_eligible[f], "OR_excluded": excluded[f]}
            for f in families
        },
        "zeroeligible_input_families": sum(per_eligible[f] == 0 for f in families),
        "OR_reasons_overlap_not_additive": dict(reasons),
        "raw_row_order_SHA": row_order(raw),
        "eligible_row_order_SHA": row_order(kept),
        "eligible_bitset": base64.b64encode(bitset).decode(),
        "mask_encoding": "LSB-per-row raw_row_order_SHA; not label based",
        "native_witness_indices": indices,
        "physicalNN_upper": 2 * len(kept) + 6 * len(indices),
        "MAX_science": 1,
        "science_seconds": 180,
        "primary": "family-equal terminal z MSE on identical eligible rows, all96 planned/unknown/zeroeligible kept; no missing imputation",
        "secondary": "rowweighted sign/calibration/saturation/cohort/opening_side/STM/plyphase",
        "paired_bootstrap": {
            "unit": "family",
            "seed": 30080311,
            "repetitions": 2000,
            "percentiles": [0.025, 0.975],
            "fixedfits": True,
            "iid_precision_assumed": False,
        },
        "native_tolerance": {"abs": 1e-5, "rtol": 1e-4},
        "future_labels_read": False,
        "no_reselection_refill_retrain": True,
        "history_cross_public_unavailable_opaque_stateframe_limit": True,
        "state_key_literal_equal_not_full_state_independence": True,
        "literal_null_never_matches": True,
        "teachertruth_or_samewall_strength": False,
        "entry_SHA": sha(__file__),
        "registration_SHA": sha(args.registration),
    }
    path = OUT / "evaluation-freeze-v1.json"
    path.write_text(json.dumps(freeze, indent=2) + "\n")
    print(
        json.dumps(
            {
                "PASS": True,
                "NN": 0,
                "labels_read": False,
                "raw": len(raw),
                "eligible": len(kept),
                "zeroeligible": freeze["zeroeligible_input_families"],
                "SHA": sha(path),
            }
        )
    )


if __name__ == "__main__":
    main()
