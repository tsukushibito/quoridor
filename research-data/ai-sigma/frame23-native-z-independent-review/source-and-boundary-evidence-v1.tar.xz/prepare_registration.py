"""Bind only immutable input references and already selected model metadata."""

import gzip
import json
from pathlib import Path
import statistics

from pipeline import sha
from process_inspection import compute, snapshot

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-native-z-independent-review"
NEW = ROOT / "research-data/ai-sigma/frame23-native-outcome-z-learning"
FUTURE = ROOT / "research-data/ai-sigma/frame23-native-z-fresh-evaluation"


def binding(path):
    path = Path(path)
    return {"path": str(path), "SHA": sha(path)}


def main():
    import os

    processes = snapshot()
    ancestors, cursor = {os.getpid()}, os.getpid()
    while cursor in processes and processes[cursor]["ppid"] not in ancestors:
        cursor = processes[cursor]["ppid"]
        ancestors.add(cursor)
    foreign = [p for pid, p in processes.items() if pid not in ancestors and compute(p)]
    assert not foreign, foreign
    current = json.loads(
        (ROOT / ".artifacts/research-team/frame22-extension23/scheduler/state.json").read_text()
    )
    assert current["phase"] == "running"
    expectations = json.loads(
        (
            ROOT
            / ".artifacts/ai-sigma/continuation-20261001/SIGMA-RESUME-OPERATIONS-92/frame22-extension23/expectations.json"
        ).read_text()
    )
    assert len(expectations["input_hashes"]) == 24
    assert all(sha(p) == h for p, h in expectations["input_hashes"].items())
    newpath = NEW / "candidate-freeze-v1.json"
    new = json.loads(newpath.read_text())
    assert sha(newpath) == "5768486550449fda256f70de2196bc1c3e6831ec52828b984a19eacbe673e0b6"
    publicpath = Path(new["baselines"]["public_frozen_baseline"]["path"])
    old = json.loads(publicpath.read_text())
    oldrefs = json.loads(
        (
            ROOT
            / "research-data/ai-sigma/frame23-sigma-public-z-review/final-input-freeze/evaluation-freeze-v1.json"
        ).read_text()
    )
    assert sha(publicpath) == new["baselines"]["public_frozen_baseline"]["SHA"]
    stop = json.loads(Path(new["source_stop"]["path"]).read_text())
    assert sha(new["source_stop"]["path"]) == new["source_stop"]["SHA"]
    assert all(
        stop[k]
        for k in (
            "listed_source_writer_STOP",
            "modelreader_STOP",
            "selector_STOP",
            "all_3_children_wait_currentexact_absent",
            "background_cleanup",
        )
    )
    refs = []
    for name in ("Tseen", "Vraw"):
        record = dict(new["references"][name])
        witnesses = {}
        with gzip.open(record["path"], "rt") as stream:
            for line in stream:
                row = json.loads(line)
                witness = row["prefix_witness"]
                witnesses[witness["path"]] = {"path": witness["path"], "SHA": witness["SHA"]}
        record.update(
            name="native_" + name,
            expected_rows=new["references"]["Tseen_rows" if name == "Tseen" else "ALLrawV_rows"],
            format="native_learner_actualSTM_refs",
            witnesses=list(witnesses.values()),
        )
        refs.append(record)
    for name, cycle in (("Tseen", "0041"), ("Vraw", "0042")):
        record = binding(
            ROOT
            / f".worktree/assets/inputs/sigma-public-fix-z/canonical-v3/cycle_{cycle}/input-references.jsonl.gz"
        )
        record.update(
            name="public_" + name,
            expected_rows=oldrefs["Tactual_rows" if name == "Tseen" else "ALLrawV_rows"],
        )
        if name == "Tseen":
            record.update(
                subset=oldrefs["reference_bindings"][name]["canonical"],
                subset_signature="learner_byte_lengths",
            )
        refs.append(record)
    handoffpath = FUTURE / "both-blocks-target-free-handoff-v1.json"
    handoff = json.loads(handoffpath.read_text())
    assert sha(handoffpath) == "e74757a551194003723a04d6e1f66be5f0d7a54c6d7c2d0c53e5f01042cd0b38"
    future = [
        b["targetfree_refs"] | {"uncompressed_SHA": b["targetfree_uncompressed_SHA"]}
        for b in handoff["blocks"]
    ]
    constant = new["baselines"]["constant"]
    qual = json.loads(Path(constant["train_family_summary"]["path"]).read_text())
    summaries = qual["train_family_summary"]
    assert len(summaries) == 432 and len({r["canonical_family"] for r in summaries}) == 432
    assert sum(r["eligible_rows"] for r in summaries) == 14803
    assert abs(statistics.mean(r["z_mean"] for r in summaries) - constant["value"]) < 1e-15
    binary = new["model_settings"]["native_SIMD_comparison_only_binary"]
    models = {}
    for key, candidate in (("native", new["candidate"]), ("public", old["candidate"])):
        manifest = json.loads(Path(candidate["native_manifest"]["path"]).read_text())
        assert manifest["schema"] == "quoridor-nnue-distance-residual-v3"
        assert manifest["topology"] == {"ft_width": 32, "hidden_width": 32}
        assert manifest["route_mode"] == "zero4" and manifest["distance_fit"] == {
            "a": 0.0,
            "b": 8.0,
        }
        assert manifest["little_endian_f32"] == 12321
        assert (
            sha(candidate["native_weights"]["path"])
            == manifest["weights_SHA"]
            == candidate["native_weights"]["SHA"]
        )
        assert Path(candidate["native_weights"]["path"]).stat().st_size == 12321 * 4
        models[key] = {
            "manifest": candidate["native_manifest"],
            "weights": candidate["native_weights"],
            "binary": binary,
            "binary_scope": "stopped comparison Scalar/SIMD/full-delta v3 API; production-maintained parity separately source-bound",
        }
    assert sha(binary["path"]) == binary["SHA"]
    inputs = {}
    for record in refs:
        for item in (
            [record]
            + record.get("witnesses", [])
            + ([record["subset"]] if "subset" in record else [])
        ):
            inputs[item["path"]] = item["SHA"]
    for item in future + [
        binding(handoffpath),
        binding(newpath),
        binding(publicpath),
        new["source_stop"],
        constant["train_family_summary"],
        handoff["blocks"][0]["registered_family_map"],
        binding(FUTURE / "scientific-source-stop-v1.json"),
    ]:
        inputs[item["path"]] = item["SHA"]
    for model in models.values():
        for key in ("manifest", "weights", "binary"):
            inputs[model[key]["path"]] = model[key]["SHA"]
    for p in OUT.glob("*.py"):
        inputs[str(p)] = sha(p)
    reg = {
        "task": "native-z-targetfree-freeze-300-v1",
        "entry_SHA": sha(OUT / "freeze_inputs.py"),
        "inputs": inputs,
        "reference_sets": refs,
        "future_inputs": future,
        "family_map": handoff["blocks"][0]["registered_family_map"]["path"],
        "future_partition": "sealed_rulea_transfer_observation",
        "raw_rows": 3280,
        "models": models,
        "constant": {
            "value": constant["value"],
            "train_only_family_equal": True,
            "independent_summary_mean_check": True,
            "families": 432,
            "source": constant["train_family_summary"],
        },
        "candidate_bindings": {
            "native": binding(newpath),
            "public": binding(publicpath),
            "native_source_stop": new["source_stop"],
            "producer_source_stop": binding(FUTURE / "scientific-source-stop-v1.json"),
            "settings_scale": new["model_settings"]["scale"],
            "initial": new["initial"],
            "native_config": new["candidate"]["config"],
            "public_config": old["candidate"]["config"],
        },
        "terminal_schema": {
            "goal_status": "goal",
            "goal_terminal_reason": "GOAL",
            "draw_terminal_reasons": ["RULEA_200_PLY_DRAW", "RULEA_NO_HISTORY_LEGAL_DRAW"],
            "unknown_statuses": ["unknown"],
            "draw_rule_source_SHA": "66d06e2332255a01ead0d0033ecaddba0b4b812bbfc8220c4dbb5bc2726e1a29",
            "canonical_source": binding(FUTURE / "canonical_games.py"),
        },
    }
    inputs[reg["terminal_schema"]["canonical_source"]["path"]] = reg["terminal_schema"][
        "canonical_source"
    ]["SHA"]
    (OUT / "freeze-input-registration-v1.json").write_text(json.dumps(reg, indent=2) + "\n")
    (OUT / "preparation-point-v1.json").write_text(
        json.dumps(
            {
                "current24": True,
                "scheduler": current["process"],
                "foreign": foreign,
                "NN": 0,
                "future_labels_read": False,
                "constant_checked": constant["value"],
                "modelmetadata_only": True,
            },
            indent=2,
        )
        + "\n"
    )
    print(
        json.dumps(
            {
                "NN": 0,
                "registration": str(OUT / "freeze-input-registration-v1.json"),
                "references": [(r["name"], r["expected_rows"]) for r in refs],
            }
        )
    )


if __name__ == "__main__":
    main()
