"""300 one frozen two-model forward and NN0 terminal-z scoring entry."""

import argparse
import base64
from collections import Counter
import gzip
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
import sys
import time

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[variable] = "1"
os.environ["ORT_DISABLE_TELEMETRY"] = "1"

from evaluation_math import (
    MODELS,
    canonical_input,
    fixtures,
    label_match,
    metrics,
    true_z,
    unique_keys,
)

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-native-z-independent-review/evaluation-r1"
TASK = "native-terminal-z-independent-300-v1"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def jsonlines(path):
    opener = gzip.open if str(path).endswith(".gz") else open
    with opener(path, "rt") as stream:
        return [json.loads(line) for line in stream]


def row_order(rows):
    h = hashlib.sha256()
    for row in rows:
        h.update(
            json.dumps(
                [row["canonical_family"], row["id"], canonical_input(row)], separators=(",", ":")
            ).encode()
            + b"\n"
        )
    return h.hexdigest()


def predict(model, rows, np):
    path = Path(model["manifest"]["path"])
    manifest = json.loads(path.read_text())
    assert sha(path) == model["manifest"]["SHA"]
    assert manifest["schema"] == "quoridor-nnue-distance-residual-v3"
    assert manifest["feature"] == "QF1-route4-f32-STM-scaled-residual-v3"
    assert manifest["route_mode"] == "zero4"
    assert manifest["topology"] == {"ft_width": 32, "hidden_width": 32}
    assert manifest["value_perspective"] == "side-to-move"
    assert manifest["value_parameterization"] == "fixed-distance-logit-plus-linear-residual-tanh"
    assert manifest["distance_fit"] == {"a": 0.0, "b": 8.0}
    weights_path = path.parent / manifest["weights"]
    assert sha(weights_path) == manifest["weights_SHA"] == model["weights"]["SHA"]
    flat = np.frombuffer(weights_path.read_bytes(), dtype="<f4")
    assert len(flat) == 12321 and np.isfinite(flat).all()
    weights, offset = [], 0
    for shape in ((32, 312), (32,), (32, 70), (32,), (32,), (1,)):
        size = int(np.prod(shape))
        weights.append(flat[offset : offset + size].reshape(shape))
        offset += size
    assert offset == len(flat)
    mu, sigma = (
        np.asarray(manifest["mu_f32"], dtype="<f4"),
        np.asarray(manifest["sigma_f32"], dtype="<f4"),
    )
    assert np.isfinite(mu).all() and np.isfinite(sigma).all() and (sigma > 0).all()
    ft, ft_bias, hidden, hidden_bias, head, head_bias = weights
    result = np.empty(len(rows), dtype="<f4")
    for start in range(0, len(rows), 512):
        block = rows[start : start + 512]
        x = np.zeros((len(block), 2, 312), dtype="<f4")
        distances = np.empty((len(block), 2), dtype="<f4")
        for i, row in enumerate(block):
            canonical_input(row)
            for view in (0, 1):
                x[i, view, row["actualSTM_ids"][view]] = 1
            distances[i] = struct.unpack("<ff", struct.pack("<II", *row["STM_distance_f32bits"]))
        ft_values = np.maximum(x @ ft.T + ft_bias, np.float32(0))
        columns = np.concatenate(
            (
                ft_values[:, 0],
                ft_values[:, 1],
                (distances - mu) / sigma,
                np.zeros((len(block), 4), dtype="<f4"),
            ),
            axis=1,
        )
        residual = np.maximum(columns @ hidden.T + hidden_bias, np.float32(0)) @ head + head_bias[0]
        result[start : start + len(block)] = np.tanh(
            np.float32(8) * (distances[:, 1] - distances[:, 0]) + residual
        )
    assert np.isfinite(result).all() and (np.abs(result) <= 1).all()
    return result


def native_witness(model, rows, predictions, indices, key):
    binary, manifest = model["binary"], model["manifest"]
    assert sha(binary["path"]) == binary["SHA"]
    argv = ["/usr/bin/taskset", "-c", "3", binary["path"], "model", manifest["path"]]
    values = []
    for index in indices:
        row = rows[index]
        values.append(
            {
                "id": row["canonical_family"] + ":" + row["id"],
                "side": row["side"],
                "ids": row["actualSTM_ids"] if row["side"] == 1 else row["actualSTM_ids"][::-1],
                "distance": list(
                    struct.unpack("<ff", struct.pack("<II", *row["STM_distance_f32bits"]))
                ),
            }
        )
    child = subprocess.Popen(
        argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    tick = (Path("/proc") / str(child.pid) / "stat").read_text().rsplit(")", 1)[1].split()[19]
    (OUT / f"native-{key}-started.json").write_text(
        json.dumps({"pid": child.pid, "tick": tick, "argv": argv}) + "\n"
    )
    try:
        stdout, stderr = child.communicate(
            "".join(json.dumps(x) + "\n" for x in values), timeout=20
        )
    except BaseException:
        child.kill()
        child.wait()
        raise
    assert child.returncode == 0, stderr
    parsed = [json.loads(line) for line in stdout.splitlines()]
    assert len(parsed) == len(indices)
    errors = []
    for row, item, index in zip(values, parsed, indices):
        assert row["id"] == item["id"]
        tolerance = 1e-5 + 1e-4 * abs(float(predictions[index]))
        error = abs(float(predictions[index]) - item["value"])
        assert error <= tolerance
        assert abs(item["value"] - item["simd_value"]) <= tolerance
        assert abs(item["value"] - item["delta_value"]) <= tolerance
        errors.append(error)
    receipt = {
        "argv": argv,
        "pid": child.pid,
        "tick": tick,
        "exit_code": child.returncode,
        "waited": True,
        "current_exact_absent": not (Path("/proc") / str(child.pid)).exists(),
        "NN": 3 * len(indices),
        "max_abs": max(errors) if errors else None,
    }
    (OUT / f"native-{key}-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--registration", required=True)
    parser.add_argument("--fixture", action="store_true")
    args = parser.parse_args()
    reg = json.loads(Path(args.registration).read_text())
    assert reg["task"] == TASK and reg["entry_SHA"] == sha(__file__)
    assert sys.argv.count(str(Path(args.registration))) == 1
    if args.fixture:
        print(
            json.dumps(
                fixtures()
                | {
                    "task": TASK,
                    "argv_once": True,
                    "schema": "native-terminal-z-independent-result-300-v1",
                }
            )
        )
        return
    for path, expected in reg["inputs"].items():
        assert sha(path) == expected, path
    OUT.mkdir(exist_ok=False)
    start = time.monotonic()
    freeze = json.loads(Path(reg["evaluation_freeze"]).read_text())
    allrows = [row for path in freeze["target_free_inputs"] for row in jsonlines(path)]
    assert row_order(allrows) == freeze["raw_row_order_SHA"]
    mask = base64.b64decode(freeze["eligible_bitset"])
    rows = [row for i, row in enumerate(allrows) if mask[i // 8] & (1 << (i % 8))]
    assert len(rows) == reg["eligible_rows"] and len(rows) <= 19200
    assert row_order(rows) == freeze["eligible_row_order_SHA"]
    unique_keys([{"family": r["canonical_family"], "id": r["id"]} for r in allrows])
    import numpy as np

    forward_start = time.monotonic()
    native = predict(freeze["models"]["native"], rows, np)
    public = predict(freeze["models"]["public"], rows, np)
    distances = np.asarray(
        [struct.unpack("<ff", struct.pack("<II", *row["STM_distance_f32bits"])) for row in rows],
        dtype="<f4",
    ).reshape(-1, 2)
    baseline = np.tanh((np.float32(8) * (distances[:, 1] - distances[:, 0])).astype("<f8")).astype(
        "<f4"
    )
    constant = np.full(len(rows), freeze["constant"]["value"], dtype="<f4")
    predictions = np.column_stack((native, public, baseline, constant)).astype("<f4")
    predictions.tofile(OUT / "predictions.f32")
    assert np.isfinite(predictions).all()
    forward_seconds = time.monotonic() - forward_start
    indices = freeze["native_witness_indices"]
    assert len(indices) <= 24 and len(set(indices)) == len(indices)
    native_receipts = [
        native_witness(freeze["models"][key], rows, predictions[:, i], indices, key)
        for i, key in enumerate(("native", "public"))
    ]
    NN = 2 * len(rows) + sum(x["NN"] for x in native_receipts)
    assert NN == reg["physicalNN_upper"] and NN <= 50000
    (OUT / "prediction-binding.json").write_text(
        json.dumps(
            {
                "columns": list(MODELS),
                "dtype": "littlef32",
                "rows": len(rows),
                "row_order_SHA": row_order(rows),
                "prediction_SHA": sha(OUT / "predictions.f32"),
                "NN": NN,
                "futuretargets_read_by_forward": False,
                "forward_seconds": forward_seconds,
            },
            indent=2,
        )
        + "\n"
    )
    # Labels are opened only after the immutable prediction and its binding exist.
    score_start = time.monotonic()
    release = json.loads(Path(reg["label_release"]).read_text())
    assert release[reg["release_freeze_key"]]["SHA"] == sha(reg["evaluation_freeze"])
    aliases = {
        r["native_family"]: r["canonical_family"]
        for r in json.loads(Path(reg["family_map"]).read_text())["families"]
    }
    games = {}
    for binding in reg["game_provenances"]:
        data = json.loads(Path(binding["path"]).read_text())
        assert data["schema"] == "native-z-fresh-evaluation-canonical-terminated-games-v1"
        for game in data["games"]:
            assert game["canonical_family"] not in games
            games[game["canonical_family"]] = game
    assert len(aliases) == len(games) == 96
    positions = {(row["canonical_family"], row["id"]): i for i, row in enumerate(rows)}
    raw_keys = {(row["canonical_family"], row["id"]) for row in allrows}
    seen, targets, counts = set(), [], Counter()
    for binding in reg["label_scalar_bindings"]:
        digest = hashlib.sha256()
        with gzip.open(binding["path"], "rb") as stream:
            for line in stream:
                digest.update(line)
                label = json.loads(line)
                family = aliases[label["native_family"]]
                key = (family, label["id"])
                assert key in raw_keys and key not in seen
                seen.add(key)
                if key not in positions:
                    counts["input_exposed"] += 1
                    continue
                index = positions[key]
                row = rows[index]
                game = games[family]
                assert game["cohort"] == row["cohort"]
                assert game["cohort_pair"] == row["cohort_pair"]
                assert game["opening_side"] == row["opening_side"]
                z = true_z(game, row["side"], freeze["terminal_schema"])
                if z is None:
                    label_match(label["z"], None)
                    counts["unknown_target_excluded"] += 1
                    continue
                assert game["eligible_terminal_z"] is True
                assert (
                    game["source_binding_runtime_SHA"]
                    == freeze["terminal_schema"]["draw_rule_source_SHA"]
                )
                assert game["terminal_total_plies"] == len(game["terminal_full_prefix"])
                assert game["terminal_full_prefix"][: row["ply"]] == row["prefix"]
                label_match(label["z"], z)
                targets.append(
                    {
                        "family": family,
                        "z": z,
                        "prediction": dict(zip(MODELS, predictions[index].astype(float).tolist())),
                        "cohort": row["cohort"],
                        "cohort_pair": row["cohort_pair"],
                        "side": row["side"],
                        "opening_side": row["opening_side"],
                        "ply": row["ply"],
                    }
                )
                counts["metric_rows"] += 1
        assert digest.hexdigest() == binding["uncompressed_SHA"]
    assert seen == raw_keys
    result_metrics = metrics(targets, np)
    paired = {}
    for a, b in (("native", "D"), ("native", "public"), ("native", "constant"), ("public", "D")):
        for metric in ("MSE", "sign"):
            aa, bb = result_metrics[a]["pergroup"], result_metrics[b]["pergroup"]
            assert [x["family"] for x in aa] == [x["family"] for x in bb]
            delta = np.asarray([x[metric] - y[metric] for x, y in zip(aa, bb)])
            n = len(delta)
            if n < 2:
                paired[f"{a}minus{b}:{metric}"] = {
                    "status": "UNDEFINED_INSUFFICIENT_PAIRED_FAMILIES",
                    "families": n,
                }
                continue
            draws = np.mean(
                delta[np.random.default_rng(30080311).integers(0, n, size=(2000, n))], axis=1
            )
            sd = float(np.std(delta, ddof=1))
            paired[f"{a}minus{b}:{metric}"] = {
                "mean": float(delta.mean()),
                "95percentile": np.quantile(draws, [0.025, 0.975]).tolist(),
                "families": n,
                "sd": sd,
                "negative": int((delta < 0).sum()),
                "positive": int((delta > 0).sum()),
                "seed": 30080311,
                "repetitions": 2000,
                "iid_family_precision_not_assumed": True,
                "planning_N_for_halfwidth0_1_only_under_independence": float(
                    (1.96 * sd / 0.1) ** 2
                ),
            }
    groups = {}
    for field in ("cohort", "cohort_pair", "side", "opening_side", "phase"):
        bins = {}
        for row in targets:
            key = (
                ("early" if row["ply"] < 20 else "middle" if row["ply"] < 60 else "late")
                if field == "phase"
                else str(row[field])
            )
            bins.setdefault(key, []).append(row)
        groups[field] = {key: metrics(values, np) for key, values in bins.items()}
    familycount = len({r["family"] for r in targets})
    result = {
        "task": TASK,
        "schema": "native-terminal-z-independent-result-300-v1",
        "PASS": True,
        "NN": NN,
        "processed": NN,
        "planned_families": 96,
        "input_per_family": freeze["per_family"],
        "OR_reasons_overlap_not_additive": freeze["OR_reasons_overlap_not_additive"],
        "raw_rows": len(allrows),
        "eligible_input_rows": len(rows),
        "metric_families": familycount,
        "zeroeligible_metric_families": 96 - familycount,
        "status": dict(Counter(r["status"] for r in games.values())),
        "counts": dict(counts),
        "metrics": result_metrics,
        "paired": paired,
        "groups": groups,
        "freeze_SHA": sha(reg["evaluation_freeze"]),
        "row_order_SHA": row_order(rows),
        "predictions_SHA": sha(OUT / "predictions.f32"),
        "forward_seconds": forward_seconds,
        "saved_score_NN": 0,
        "saved_score_seconds": time.monotonic() - score_start,
        "body_seconds": time.monotonic() - start,
        "limits": [
            "Shared RuleA and producer finite input/terminal source dependencies, not independent complete teachertruth",
            "96 fixed cohort/lineage/family correlations, not universal IID/precision guarantee",
            "Old corpus selection is exploratory, not blind validation; training/sampler/target differences confounded",
            "No samewall strength, no future-label reselection/refill/retraining",
            "Public history unavailable and cross stateframe opaque; null never establishes complete nonexposure",
        ],
    }
    with gzip.open(OUT / "result-v1.json.gz", "wt") as stream:
        json.dump(result, stream, separators=(",", ":"), allow_nan=False)
    summary = {k: v for k, v in result.items() if k not in ("metrics", "groups")}
    summary["metrics"] = {
        key: {name: item[name] for name in ("rowweighted", "groupequal")}
        for key, item in result_metrics.items()
    }
    (OUT / "result-v1.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                k: v
                for k, v in summary.items()
                if k in ("task", "PASS", "NN", "metric_families", "counts", "metrics")
            }
        )
    )


if __name__ == "__main__":
    main()
