"""300 frozen family metrics; pure helpers and explicit z schema, no model import."""

import hashlib
import json
import math
import struct

MODELS = ("native", "public", "D", "constant")


def canonical_input(row):
    ids, bits = row["actualSTM_ids"], row["STM_distance_f32bits"]
    assert row["ids_order"] == "STM_then_opponent"
    assert row["distance_order"] in ("STM_then_opponent", "STM_then_opponent_f32_le")
    assert len(ids) == len(bits) == 2
    payload = b""
    for view in ids:
        assert view == sorted(set(view)) and all(type(x) is int and 0 <= x < 312 for x in view)
        payload += struct.pack("<H", len(view)) + struct.pack("<" + "H" * len(view), *view)
    assert all(type(x) is int and 0 <= x < 2**32 for x in bits)
    distances = struct.unpack("<ff", struct.pack("<II", *bits))
    assert all(math.isfinite(x) and 0 <= x <= 1.012501 for x in distances)
    payload += struct.pack("<II", *bits)
    return hashlib.sha256(payload).hexdigest()


def literal_history(row):
    value = row.get("history_literal")
    if value is None:
        return None
    return (
        row.get("history_key_format", row.get("history_format")),
        json.dumps(value, separators=(",", ":"), sort_keys=True),
    )


def true_z(game, side, schema):
    assert side in (1, 2)
    status, reason = game["status"], game["terminal_reason"]
    if status == "goal":
        assert (
            reason == "GOAL"
            and type(game["winner_absolute0or1"]) is int
            and game["winner_absolute0or1"] in (0, 1)
        )
        return 1.0 if game["winner_absolute0or1"] + 1 == side else -1.0
    if status == "draw":
        assert reason in schema["draw_terminal_reasons"]
        assert game["winner_absolute0or1"] is None
        assert schema["draw_rule_source_SHA"]
        assert game["raw_reason"] is None
        assert game["eligible_terminal_z"] is True
        assert game["source_binding_runtime_SHA"] == schema["draw_rule_source_SHA"]
        assert (game["terminal_total_plies"] >= 200) == (reason == "RULEA_200_PLY_DRAW")
        return 0.0
    assert status in schema["unknown_statuses"]
    return None


def unique_keys(rows):
    keys = [(row["family"], row["id"]) for row in rows]
    assert len(keys) == len(set(keys))


def label_match(actual, expected):
    if expected is None:
        assert actual is None
    else:
        assert type(actual) in (int, float) and actual in (-1.0, 0.0, 1.0) and actual == expected


def fixtures():
    schema = {
        "draw_terminal_reasons": ["RULEA_200_PLY_DRAW", "RULEA_NO_HISTORY_LEGAL_DRAW"],
        "draw_rule_source_SHA": "fixture-source-only",
        "unknown_statuses": ["unknown", "NOT_STARTED"],
    }
    assert (
        true_z({"status": "goal", "terminal_reason": "GOAL", "winner_absolute0or1": 0}, 1, schema)
        == 1
    )
    assert (
        true_z({"status": "goal", "terminal_reason": "GOAL", "winner_absolute0or1": 0}, 2, schema)
        == -1
    )
    draw = {
        "status": "draw",
        "terminal_reason": "RULEA_NO_HISTORY_LEGAL_DRAW",
        "raw_reason": None,
        "winner_absolute0or1": None,
        "source_binding_runtime_SHA": "fixture-source-only",
        "eligible_terminal_z": True,
        "terminal_total_plies": 40,
    }
    assert true_z(draw, 2, schema) == 0
    assert (
        true_z(
            draw | {"terminal_reason": "RULEA_200_PLY_DRAW", "terminal_total_plies": 200}, 1, schema
        )
        == 0
    )
    assert (
        true_z(
            {"status": "unknown", "terminal_reason": "PLY_CAP", "winner_absolute0or1": None},
            1,
            schema,
        )
        is None
    )
    bad = [
        {"status": "GOAL", "terminal_reason": "GOAL", "winner_absolute0or1": 0},
        {"status": "goal", "terminal_reason": "goal", "winner_absolute0or1": 0},
        draw | {"terminal_reason": "PLY_CAP"},
        draw | {"winner_absolute0or1": 0},
        draw | {"raw_reason": "PLY_CAP"},
    ]
    for game in bad:
        try:
            true_z(game, 1, schema)
        except AssertionError:
            pass
        else:
            raise AssertionError("unsupported terminal schema accepted")
    unique_keys([{"family": "A", "id": "1"}, {"family": "B", "id": "1"}])
    try:
        unique_keys([{"family": "A", "id": "1"}] * 2)
    except AssertionError:
        pass
    else:
        raise AssertionError("alias/row join duplicated")
    assert all(v["status"] == "UNDEFINED_ZERO_ELIGIBLE" for v in metrics([], None).values())
    label_match(1.0, 1.0)
    label_match(None, None)
    for value in (float("nan"), float("inf"), 0.5, 2, True):
        try:
            label_match(value, 1.0)
        except AssertionError:
            pass
        else:
            raise AssertionError("invalid finite/nonfinite label accepted")
    assert literal_history({"history_literal": None}) is None
    return {
        "correct_goal_draw_unknown": True,
        "wrong_case_cap_draw_rejected": True,
        "unique_alias_row": True,
        "partial_empty_denominator": True,
        "NN": 0,
        "labels_read": False,
    }


def metrics(rows, np):
    if not rows:
        return {
            model: {
                "rowweighted": {key: None for key in ("MSE", "sign", "bias", "saturation")},
                "groupequal": {key: None for key in ("MSE", "sign", "bias", "saturation")},
                "pergroup": [],
                "calibration_bins": [],
                "status": "UNDEFINED_ZERO_ELIGIBLE",
            }
            for model in MODELS
        }
    families = {}
    for row in rows:
        families.setdefault(row["family"], []).append(row)
    result = {}
    for model in MODELS:
        pergroup = []
        for family, group in sorted(families.items()):
            p = np.asarray([r["prediction"][model] for r in group], dtype="<f8")
            z = np.asarray([r["z"] for r in group], dtype="<f8")
            pergroup.append(
                {
                    "family": family,
                    "rows": len(group),
                    "MSE": float(np.mean((p - z) ** 2)),
                    "sign": float(np.mean(np.sign(p) == np.sign(z))),
                    "bias": float(np.mean(p - z)),
                    "saturation": float(np.mean(np.abs(p) >= 0.99)),
                    "z_mean": float(z.mean()),
                }
            )
        p = np.asarray([r["prediction"][model] for r in rows], dtype="<f8")
        z = np.asarray([r["z"] for r in rows], dtype="<f8")
        bins = []
        for lower, upper in zip((-1.0, -0.6, -0.2, 0.2, 0.6), (-0.6, -0.2, 0.2, 0.6, 1.0)):
            selected = (p >= lower) & ((p < upper) if upper < 1 else (p <= upper))
            bins.append(
                {
                    "lower": lower,
                    "upper": upper,
                    "rows": int(selected.sum()),
                    "mean_prediction": float(p[selected].mean()) if selected.any() else None,
                    "mean_z": float(z[selected].mean()) if selected.any() else None,
                }
            )
        result[model] = {
            "rowweighted": {
                "MSE": float(np.mean((p - z) ** 2)),
                "sign": float(np.mean(np.sign(p) == np.sign(z))),
                "bias": float(np.mean(p - z)),
                "saturation": float(np.mean(np.abs(p) >= 0.99)),
            },
            "groupequal": {
                key: float(np.mean([g[key] for g in pergroup]))
                for key in ("MSE", "sign", "bias", "saturation")
            },
            "pergroup": pergroup,
            "calibration_bins": bins,
        }
    return result
