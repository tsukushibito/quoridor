//! Exclusive fixed-root MCTS costs; no full-game throughput claim.
use quoridor_ai::sigma_mcts as mcts;
use quoridor_core::research::{SigmaContext, features};
use quoridor_inference::{InferenceBackend, OrtBackend};
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::{path::Path, time::Instant};
fn hash(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}
fn main() -> Result<(), Box<dyn std::error::Error>> {
    assert_eq!(std::env::var("ORT_DISABLE_TELEMETRY").as_deref(), Ok("1"));
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(args.len(), 2, "mcts_cost CONFIG.json");
    let config: Value = serde_json::from_slice(&std::fs::read(&args[1])?)?;
    assert_eq!(config["task"], "frame21-mcts-cost-271-v1");
    assert_eq!(config["fixtures"].as_array().unwrap().len(), 4);
    let job = Instant::now();
    let mut backend = OrtBackend::new(
        Path::new(config["onnx"].as_str().unwrap()),
        Path::new(config["ort_library"].as_str().unwrap()),
        config["onnx_sha"].as_str().unwrap(),
    )?;
    let startup_ns = job.elapsed().as_nanos();
    let (mut nn, mut processed) = (0u64, 0u64);
    for fixture in config["fixtures"].as_array().unwrap() {
        let prefix: Vec<u16> = fixture["prefix"]
            .as_array()
            .unwrap()
            .iter()
            .map(|v| v.as_u64().unwrap() as u16)
            .collect();
        let whole = Instant::now();
        let setup = Instant::now();
        let root = SigmaContext::from_prefix(&prefix)?;
        let mut tree = mcts::Search::with_limits(
            root.clone(),
            1979,
            64,
            mcts::Limits {
                max_nodes: 8449,
                max_depth: 200,
                max_bytes: 64 * 1024 * 1024,
            },
        )?;
        let setup_ns = setup.elapsed().as_nanos();
        let (mut advance_ns, mut infer_ns, mut supply_ns) = (0u128, 0u128, 0u128);
        let (mut advances, mut requests, mut advanced) = (0u64, 0u64, 0u64);
        loop {
            let t = Instant::now();
            let progress = tree.advance()?;
            advance_ns += t.elapsed().as_nanos();
            advances += 1;
            match progress {
                mcts::Progress::Complete => break,
                mcts::Progress::Advanced => {
                    advanced += 1;
                }
                mcts::Progress::NeedInference { token, features } => {
                    let t = Instant::now();
                    let out = backend.infer(&[*features])?;
                    infer_ns += t.elapsed().as_nanos();
                    requests += 1;
                    let t = Instant::now();
                    tree.supply(token, &out[0].logits, out[0].value)?;
                    supply_ns += t.elapsed().as_nanos();
                }
            }
        }
        let whole_root_ns = whole.elapsed().as_nanos();
        let measured = setup_ns + advance_ns + infer_ns + supply_ns;
        assert!(measured <= whole_root_ns);
        let s = tree.snapshot();
        let legal = root.legal_ids();
        let input = features(root.position());
        let input_bytes: Vec<u8> = input
            .iter()
            .flat_map(|v| v.to_bits().to_le_bytes())
            .collect();
        let edges: Vec<_> = s
            .edges
            .iter()
            .map(|e| json!([e.action, e.prior.to_bits(), e.visits, e.value_sum.to_bits()]))
            .collect();
        let prior_mass: f64 = s.edges.iter().map(|e| e.prior).sum();
        assert_eq!(s.root_visits, 64);
        assert_eq!(s.edges.iter().map(|e| e.visits).sum::<u32>(), 63);
        assert!(s.edges.iter().all(|e| legal.contains(&e.action)));
        assert!(s.root_mean.is_finite() && (prior_mass - 1.).abs() < 1e-8);
        assert_eq!(requests, u64::from(s.nn_calls));
        nn += requests;
        processed += s.nodes as u64;
        assert!(nn <= 10000 && processed <= 50000);
        println!(
            "{}",
            json!({"kind":"root","task":"frame21-mcts-cost-271-v1","schema":"mcts-cost-v1","name":fixture["name"],"prefix":prefix,"key":root.position().position_key(),"feature_sha":hash(&input_bytes),"legal":legal,"setup_ns":setup_ns,"advance_ns":advance_ns,"infer_ns":infer_ns,"supply_ns":supply_ns,"unattributed_ns":whole_root_ns-measured,"whole_root_ns":whole_root_ns,"advance_calls":advances,"advanced":advanced,"action":s.action,"root_visits":s.root_visits,"root_mean_bits":s.root_mean.to_bits(),"edge_visits":63,"prior_mass":prior_mass,"nodes":s.nodes,"max_depth":s.max_depth,"nn_calls":s.nn_calls,"terminal_no_nn":s.terminal_no_nn,"edges_hash":hash(&serde_json::to_vec(&edges)?)})
        );
    }
    println!(
        "{}",
        json!({"kind":"job","task":"frame21-mcts-cost-271-v1","schema":"mcts-cost-v1","startup_ns":startup_ns,"whole_job_ns":job.elapsed().as_nanos(),"actual_native_nn":nn,"allocated_tree_nodes":processed,"threads":1,"gpu":0,"fullgame_rjoint":"UNKNOWN"})
    );
    Ok(())
}
