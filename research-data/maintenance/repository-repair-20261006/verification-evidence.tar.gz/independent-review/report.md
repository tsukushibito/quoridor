# 保守修正の独立検証（2026-10-06）

受入れ予定のコード修正について、根拠のある未解決blockerは確認していない。レビュー中に見つけた3件は担当が修正し、停止版の再読取と担当の合成回帰証拠で確認した。Rootの最終統合・文書・通常dist実確認を条件として引き渡す。

担当issueは `quoridor-fwe.7`、レビュワーは `codex:/root/maintainability_reviewer`。原23所見はGit `ac82eb82cb5512fd90d5c31e146af97092827085` に保全され、現findings.jsonと保存版の全byte一致を確認した。レビューと修正の記録を混同して原所見を書き換えていない。六担当の最終STOPにある52sourceと4削除を照合し、正確なpath/size/SHAは `review.json` に保存した。

## レビューで追加した必須修正

| ID         | 修正前の問題                                                                                      | 最終確認                                                                                                                                                                                     |
| ---------- | ------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| IR-B1 / P2 | child identity取得失敗時、TERM/KILLを省いてwait timeout後にもcleanup_complete=trueとなり得た。    | Popen直後pidfdを保持し直接子を回収。identity不明はdescendant visibility unavailable / cleanup_complete=false、原エラー保持。担当12合成テストとexit=-9/direct_child_reaped=trueの証拠を確認。 |
| IR-F1 / P1 | 任意APP_OUT_DIRへemptyOutDir=trueを指定し、共有asset/証拠directoryを積極削除する設定だった。      | 固定2検証dirだけ明示empty。通常distはVite自動境界、その他custom出力はfalse。共有.artifacts/.worktree/assetsを含む担当回帰証拠を確認。実build/削除は実行していない。                          |
| IR-C1 / P2 | record以外のmetadata予約4096bytesを実検査せず、長いrun_id/errorで最終resultが出力予算を越え得た。 | identity metadata事前admission、ledger実bytes＋最終JSON長検査、omitted hashとbackend workを残す有界fallback。5000文字ID/20KB errorの担当回帰テスト成功を確認。                               |

発生条件、修正前source SHA/行番号、正常経路の保護、修正後証拠は `blockers.json` と `review.json` にある。修正したのは各担当であり、レビュワーはsourceを編集していない。

## 修正scopeと呼出境界

### learning_inputs / MR-01, MR-02, MR-14

- `python/quoridor_training/train.py:901,943,1009,1050,1107,1109`: Freeze v2 requires exact12 artifact hash keys, compares config/scale/baseline/cache binding and initial/best checkpoint/native descriptors, rejects old freezes before model construction, checks consumed inputs again before publishing result.
- `python/quoridor_training/cache.py:126,188,192,217,313,471`: Sole Corpus API with lazy row metadata, native required file/hash/schema/exact byte checks, P1/P2→STM binary IDs and f32 distance consistency, namespaces/family maps/overlays, disk-backed identity uniqueness. Dense x/d/y copied only for explicit batch; compact row/family/selector arrays remain O(rows/groups), not constant memory.
- `python/quoridor_training/sampling.py:51,81`: Loss weighting remains same group multiplicities; heap diagnostic subset uses same SHA/id/index order and no optimizer RNG. Selected train/group ordering retains insertion/stable within-family order.
- `python/quoridor_training/train.py:968,993`: Chunked f64 moments and incremental QR preserve stated least-squares objective and prior rank cutoff; f32 outputs/native correspondence covered by tiny owner fixtures. Universal BLAS bit identity not claimed.

**検証証拠:** Owner39NN0+1skip,5tiny CPUmodel cases; reviewer parser-only receipt verifies 2-row P1/P2/duplicate batching, malformed input rejection and all12 altered frozen files/old freeze rejection, model imports empty.

### cycle_cleanup / MR-03

- `python/quoridor_training/cycle.py:19,48,57,123`: All stages share cancellation_signals and CycleResources; model-check follows train before test/arena.
- `python/quoridor_training/cycle_process.py:147,322`: Launch signals masked until direct pidfd/identity capture; exact recorded identities and direct child share TERM/KILL/wait. Repeated cancellation masked during cleanup; bounded1MiB tail and deadline/pause/process RSS/output checks. Identity-unavailable cleanup is explicit unavailable/false, with direct-child reaped proof and primary failure preserved.

**検証証拠:** Owner12 synthetic process tests pass; detached descendant10 repetition evidence and identity-unavailable exit_code=-9/direct_child_reaped=true/cleanup_complete=false receipt reviewed. Reviewer starts no child/process fixtures.

### rust_runtime / MR-09, MR-10, MR-12, MR-13, MR-21, MR-22

- `crates/quoridor-nnue/src/lib.rs:13,93,215,229`: Common bounded reader opens once, checks fd metadata and read length, then loader checks exact layout/SHA. Canonical LoadedModel dispatch validates actual supported format and serves runner/model-check/dataset evaluate; float/residual/quantized remain explicit variants.
- `crates/quoridor-runner/src/runtime.rs:391,443,1443,1648`: Residual dispatch preserves native evaluator mode and typed fingerprint/TT namespace. Benchmark monitor cancels alpha within search; MCTS guards each advance/native return, flushes completed ledger, includes actual backend counters even failed setup/infer. Metadata admitted before output/search; final report plus actual ledger bytes enforced, fallback retains omission identities and backend work.
- `crates/quoridor-runner/src/config.rs:164,190`: Defaults and explicit split counts operate in complete opening families/color pairs and reject mismatched boundary before work.
- `crates/quoridor-runner/src/main.rs:58,88,141,178`: Public evaluate and model-check share loader; help describes supported evaluate/cache/inspect commands and separate sigma-import.

**検証証拠:** Owner final36PASS/1ignored: NNUE9, runner14lib/1CLI/3config/9orchestration. All-feature/all-target Clippy -D warnings and final scoped format checks PASS. Earlier harness mapping/512MiB fixture failures retained; fixture-only cap changed to1GiB within Root actual2GiB RSS cap. Reviewer did not run native/model tests.

### inference_export / MR-08, MR-11

- `tools/model-export/export.py:21,37,49,76,139`: Existing artifact/manifest/dangling links rejected before model import; TensorRT .onnx output rejected; owned same-filesystem staging intermediates and exclusive final hardlinks preserve sibling ONNX across failure/publication collisions.
- `crates/quoridor-inference/src/lib.rs:36,112,301,328`: Trait exposes cumulative logical/executed/warm/failed rows; counts pulled after native failure and output validation; physical attempted rows becomes null when capture unmeasured.
- `crates/quoridor-inference/native/aoti.cpp:62,84,146,182`: AOTI counts2 warm attempts per new size and actual logical invocation attempts; partial warm work retained. TRT counts1 warm; ORT counts each attempted batch-one Run, so partial failures distinct from logical requests.

**検証証拠:** Owner6 mocked exports, native warm helper, all-provider release compile+6NN0 tests PASS. Failures before successful harness retained. No physical GPU/export/parity/capture work measured.

### environment_cleanup / MR-06, MR-07, MR-15, MR-16

- `scripts/dev/manage_worktree.sh:4,8`: Common Git directory resolved from the invoked script checkout, giving one main-managed namespace even from a linked worktree/cwd elsewhere.
- `.devcontainer/post-create.sh:43,49`: Godot installer/update/template/gdtoolkit requirements and future unused cache mount removed; optional training setup removed from postCreate/common setup but explicit existing command retained. Installed assets/DB/volumes left untouched.
- `crates/quoridor-wasm/src/lib.rs:100,109`: Unused distance_to_goal and initial_position_json APIs removed; current Game/view contracts remain. Two old guardians and headless/Godot installers deleted.

**検証証拠:** Owner5 isolated Git repository cases and scoped syntax/format checks PASS, read only here. Main worktree/Git/env/container operations not performed. Shell/Docker manual formatting limitation disclosed.

### quality_product / MR-04, MR-05, MR-17

- `package.json:16,28`: Product package selection excludes native research; audio included. Explicit native/research and combined gates remain available.
- `scripts/dev/check-research.py:35,57,87,121,163,210`: Named maintained NN0 classes/modules cover new A/B/E regressions; model classes opt-in only with explicit admission and existing owned fixture root. No blind discovery, automatic install or live class selection in default gate.
- `scripts/verify-production.mjs:61,95`: Root/subpath builds and previews use fixed dedicated outputs, leaving normal dist separate; preview TERM/KILL/wait and spawn failure handled.
- `apps/web/vite.config.ts:6,28`: Test hooks forbidden in normal dist; proactive emptying only fixed verification paths, automatic default for normal dist and false for arbitrary custom outputs after IR-F1 repair.

**検証証拠:** Owner full gate:59training NN0,14maintenance,3routing,6assets,5worktree,6export,3JSexport,6JSproduction,35session;9audio/render. Reviewer does not rerun broad suite or build/browser.

## 原所見の扱いと残る受入れ条件

原23件のうち19件のコード修正を六担当の現在のcallerから確認した。MR-18はRootの言語別整形案内、MR-20は既存13画像の利用不能開示という承認scopeである。MR-19のasset error診断とMR-23の条件付きページ復帰は承認計画どおり延期し、修正済みとして数えない。

- Root verifies the final source hash manifest still matches after all owner formatting/tests and accepts their current-source results; historical failed harnesses remain visible.
- Root completes required actual product Rust/Wasm/TS and native integration checks under the accepted resource slot; generated rules bindings must reflect removed API.
- Root validates ordinary dist bytes/test-hook absence with dedicated production outputs. Mocked orchestration evidence is not actual browser/build success.
- Root updates environment/formatter entry documentation and MR-20 unavailable screenshot disclosure. No automatic new screenshot/browser/science run by reviewer.
- MR-19 asset failure cause retention and MR-23 conditional page recovery remain explicitly deferred; not silently marked fixed.

## 独立検証の範囲と未測事項

独立実行は既存training Pythonを使う非科学2行parser/hash fixtureだけである。P1/P2のSTM対応と重複batch順序、空hash/非binary feature/異なるdistanceの拒否、12凍結fileの変更と旧freeze拒否を確認した。Torch/モデルmodule importは空、NN0、子process fixture起動0。最初のsystem Pythonはnumpy不在で起動失敗したため、環境を取得せず既存設定のPythonへ切り替えた。詳細は `parser-fixture.json`。

担当のcompile/test/logを読んだ結果と、レビュワーが実行した検証を分けた。Cは最終36PASS/1ignoredとClippy PASS、Dは全provider compile/NN0 6PASS、AはNN0と明示許可tiny CPUモデルfixture、B/E/Fはそれぞれ合成process・一時Git・orchestrationの証拠である。先行の失敗harnessやVM/RSS fixture制約を成功へ上書きしていない。

- No real scientific input, model artifact, model initialization/forward, GPU/CUDA execution, generation/learning/game or runtime session operated by reviewer. Only tiny synthetic parser/hash fixture.
- No large-corpus RSS/throughput, universal numerical/BLAS bit identity, strength gain, actual signal stress race or hidden daemon-adoption proof; compact metadata/selectors remain linear in rows/groups.
- Synchronous native calls cannot be forced to return by in-process monitor; exact outer job owns process-level forced cleanup. Linux proc/pidfd needed; unobserved escaped descendants are outside disclosed ownership guarantee.
- Native graph capture work remains null/UNKNOWN; attempted rows are not proof of successful kernels or numerical parity. Actual backend/runtime/driver export and large workloads unmeasured.
- Shell/Docker/C++ automatic formatter tools unavailable for those owners, manually scoped formatting and limits disclosed; Root docs must record methods.
- All major repaired boundaries and reachable callers traced, not every unrelated repo line or historical raw asset; no exhaustive correctness guarantee.

統計処理はまだ距離/labelだけを使う場所でもdense feature batchを取得し、residual固定係数でも未使用QRを計算する。これは追加の有界copy/scan費であり、時間/RSS未測・非blockerの最適化候補として記録した。追加修正や科学実行を自動開始する理由にしない。

## 停止・引渡し

source/original review/docs/config/Git/indexのレビュワー変更は0。書込はこの専用directoryの検証recordだけ（合計2MiB以内）。JSON/schema/path行番号/hash・専用Prettierを範囲限定で検証し、record書込STOPを引き渡す。Beadsはin_progressのままRoot受入れ・統合・closeへ委ねる。研究再開、実装修正、runtime/session操作、外部通信をレビュワーから開始しない。
