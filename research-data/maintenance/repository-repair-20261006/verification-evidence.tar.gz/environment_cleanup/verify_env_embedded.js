const path = require('node:path');
const tools = process.argv[2];
const { chromium } = require(path.join(tools, 'node_modules', 'playwright'));
(async () => {
  const browser = await chromium.launch({ channel: 'chrome', headless: true });
  try {
    const page = await browser.newPage();
    await page.goto('data:text/html,<title>chrome-channel-smoke</title>');
    if ((await page.title()) !== 'chrome-channel-smoke') throw new Error('unexpected title');
  } finally {
    await browser.close();
  }
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
