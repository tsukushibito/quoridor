import json
import re
import subprocess
import sys

lock = json.load(open(sys.argv[1], encoding="utf-8"))
commands = {
    "node": ["node", "--version"],
    "codex": ["codex", "--version"],
    "uv": ["uv", "--version"],
    "vscode-cli": ["code-cli", "--version"],
    "playwright": [
        f"{sys.argv[2]}/.devcontainer/playwright-e2e/node_modules/.bin/playwright",
        "--version",
    ],
    "playwright-mcp": [
        f"{sys.argv[2]}/.devcontainer/playwright-mcp/node_modules/.bin/playwright-mcp",
        "--version",
    ],
}
for name, metadata in lock["tools"].items():
    if not metadata.get("explicit") or name not in commands:
        continue
    if name == "vscode-cli" and "vscode-cli" not in lock.get("enabled_tools", []):
        continue
    output = subprocess.check_output(commands[name], text=True, stderr=subprocess.STDOUT).strip()
    expected = str(metadata["version"])
    normalized_output = re.sub(r"[^0-9A-Za-z]+", ".", output).lower()
    normalized_expected = re.sub(r"[^0-9A-Za-z]+", ".", expected).lower().strip(".")
    if normalized_expected not in normalized_output:
        raise SystemExit(f"Pinned {name} version mismatch: expected {expected!r}, got {output!r}")
