# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: audio.spec.ts >> first gesture unlocks actual decoded audio; volume and mute preserve independent preferences
- Location: tests/e2e/audio.spec.ts:30:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('#resume-game-choice')
    - locator resolved to <button type="button" class="accent" id="resume-game-choice">続きから遊ぶ</button>
  - attempting click action
    - waiting for element to be visible, enabled and stable

```

# Test source

```ts
  1   | import { restartMatch } from './start-match';
  2   | import { expect, test, type Page } from '@playwright/test';
  3   | 
  4   | const key = 'quoridor.audio.settings.v1';
  5   | const initial = { schemaVersion: 1, muted: false, sfxEnabled: true, bgmEnabled: true, sfxVolume: 55, bgmVolume: 20 };
  6   | const audio = (page: Page) => page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.audio());
  7   | const state = (page: Page) => page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.state());
  8   | async function ready(page: Page) {
  9   |   await page.goto('./?forceWebGL=1');
  10  |   await expect(page.locator('#startup-new-game')).toBeEnabled();
  11  |   // Prepare a game without a trusted gesture so autoplay/unlock assertions remain meaningful.
  12  |   await page.evaluate(() => { (document.querySelector('#startup-new-game')! as HTMLElement).click();
  13  |     (document.querySelector('#dialog-start')! as HTMLElement).click(); });
  14  |   await expect.poll(() => state(page).then(value => value.phase)).toBe('humanTurn');
  15  | }
  16  | async function unlock(page: Page) {
  17  |   await page.locator('#open-menu').click();
  18  |   await expect.poll(() => audio(page).then(value => value.status)).toBe('ready');
  19  |   await expect.poll(() => audio(page).then(value => value.loaded.length)).toBe(7);
  20  | }
  21  | async function move(page: Page, id: number) {
  22  |   const point = await page.evaluate(cell => window.__QUORIDOR_APP_TEST_API__!.projectCell(cell), id);
  23  |   await page.mouse.click(point.x, point.y);
  24  |   await expect.poll(() => state(page).then(value => value.phase)).not.toBe('animating');
  25  | }
  26  | async function range(page: Page, id: string, value: number) {
  27  |   await page.locator(id).fill(String(value));
  28  | }
  29  | 
  30  | test('first gesture unlocks actual decoded audio; volume and mute preserve independent preferences', async ({ page }) => {
  31  |   await ready(page);
  32  |   expect((await audio(page)).contextState).toBeNull();
  33  |   expect((await audio(page)).counts.bgm).toBe(0);
  34  |   await unlock(page);
  35  |   expect((await audio(page)).counts.bgm).toBe(1);
  36  |   expect((await audio(page)).bgmDuration).toBeCloseTo(130.194, 1);
  37  |   const before = (await audio(page)).counts.move;
  38  |   await page.locator('#sound-preview').click();
  39  |   expect((await audio(page)).counts.move).toBe(before + 1);
  40  |   await range(page, '#sfx-volume', 73);
  41  |   await range(page, '#bgm-volume', 12);
  42  |   await expect(page.locator('#sfx-value')).toHaveText('73%');
  43  |   await expect.poll(() => audio(page).then(value => value.sfxLevel)).toBeCloseTo(0.73, 2);
  44  |   await expect.poll(() => audio(page).then(value => value.bgmLevel)).toBeCloseTo(0.12, 2);
  45  |   await page.locator('#sfx-enabled').uncheck();
  46  |   await expect(page.locator('#sound-preview')).toBeDisabled();
  47  |   await page.locator('#sound-muted').check();
  48  |   expect((await audio(page)).activeBgm).toBe(0);
  49  |   await range(page, '#sfx-volume', 74);
  50  |   expect((await audio(page)).settings.muted).toBe(true);
  51  |   await page.locator('#sound-muted').uncheck();
  52  |   expect((await audio(page)).settings.sfxEnabled).toBe(false);
  53  |   expect((await audio(page)).settings.sfxVolume).toBe(74);
  54  |   await range(page, '#bgm-volume', 0);
  55  |   expect((await audio(page)).activeBgm).toBe(0);
  56  |   await range(page, '#bgm-volume', 100);
  57  |   await expect.poll(() => audio(page).then(value => value.bgmLevel)).toBeCloseTo(1, 2);
  58  |   await page.locator('#bgm-enabled').uncheck();
  59  |   await range(page, '#bgm-volume', 20);
  60  |   expect((await audio(page)).settings.bgmEnabled).toBe(false);
  61  |   expect((await audio(page)).activeBgm).toBe(0);
  62  |   await page.locator('#close-menu').click();
  63  |   const clicks = (await audio(page)).counts.click;
  64  |   await page.locator('#sound-mute').click();
  65  |   await expect(page.locator('#sound-mute')).toHaveAttribute('aria-pressed', 'true');
  66  |   expect((await audio(page)).counts.click).toBe(clicks);
  67  |   await page.reload();
  68  |   await expect(page.locator('#startup-dialog')).toBeVisible();
> 69  |   await page.locator('#resume-game-choice').click();
      |                                             ^ Error: locator.click: Test timeout of 30000ms exceeded.
  70  |   await expect.poll(() => state(page).then(value => value.phase)).toBe('humanTurn');
  71  |   const restored = (await audio(page)).settings;
  72  |   expect(restored).toEqual({ ...initial, muted: true, sfxEnabled: false, bgmEnabled: false, sfxVolume: 74 });
  73  |   expect((await audio(page)).activeBgm).toBe(0);
  74  | });
  75  | 
  76  | test('committed human/AI moves and walls sound once; previews, undo, restore and renderer recovery do not replay', async ({ page }) => {
  77  |   await ready(page); await unlock(page);
  78  |   await page.locator('.settings summary').click();
  79  |   await page.locator('#no-animation').check();
  80  |   await page.locator('#close-menu').click();
  81  |   const before = await audio(page);
  82  |   await move(page, 0); // illegal
  83  |   expect((await audio(page)).counts.move).toBe(before.counts.move);
  84  |   await move(page, 13);
  85  |   expect((await audio(page)).counts.move).toBe(before.counts.move + 1);
  86  |   await page.locator('#mode-wall').click();
  87  |   const point = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.projectWall(27));
  88  |   await page.mouse.move(point.x, point.y);
  89  |   expect((await audio(page)).counts.wall).toBe(0);
  90  |   await page.mouse.click(point.x, point.y);
  91  |   expect((await audio(page)).counts.wall).toBe(1);
  92  |   await page.mouse.click(point.x, point.y);
  93  |   expect((await audio(page)).counts.wall).toBe(1);
  94  |   await page.locator('#undo').click();
  95  |   expect((await audio(page)).counts.undo).toBe(1);
  96  |   const saved = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.exportReplay());
  97  |   const counts = (await audio(page)).counts;
  98  |   await page.evaluate(save => window.__QUORIDOR_APP_TEST_API__!.restoreReplay(save, 'pvp', 0), saved);
  99  |   expect((await audio(page)).counts).toEqual(counts);
  100 |   await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.injectRenderFault('renderError'));
  101 |   await page.locator('#retry-renderer').click();
  102 |   await expect.poll(() => page.locator('#board canvas').count()).toBe(1);
  103 |   expect((await audio(page)).counts).toEqual(counts);
  104 |   await page.locator('#new-game').click();
  105 |   await page.locator('#match-mode').selectOption('ai');
  106 |   await page.locator('#ai-budget').selectOption('48');
  107 |   await page.locator('#dialog-start').click();
  108 |   await move(page, 13);
  109 |   await expect.poll(() => state(page).then(value => value.view?.ply)).toBe(2);
  110 |   await expect.poll(() => state(page).then(value => value.phase)).toBe('humanTurn');
  111 |   const afterAi = (await audio(page)).counts;
  112 |   expect(afterAi.move - counts.move + afterAi.wall - counts.wall).toBe(2);
  113 |   expect(afterAi.bgm).toBe(1);
  114 | });
  115 | 
  116 | test('finishing a game emits one completion cue; restoring a finished game is silent', async ({ page }) => {
  117 |   await ready(page); await unlock(page);
  118 |   await page.locator('.settings summary').click(); await page.locator('#no-animation').check();
  119 |   await page.locator('#close-menu').click();
  120 |   for (const cell of [13, 67, 22, 58, 31, 49, 40, 48, 49, 47, 58, 46, 67, 45, 76]) await move(page, cell);
  121 |   await expect.poll(() => state(page).then(value => value.phase)).toBe('finished');
  122 |   expect((await audio(page)).counts.win).toBe(1);
  123 |   const replay = await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.exportReplay());
  124 |   const counts = (await audio(page)).counts;
  125 |   await page.evaluate(save => window.__QUORIDOR_APP_TEST_API__!.restoreReplay(save, 'pvp', 0), replay);
  126 |   expect((await audio(page)).counts).toEqual(counts);
  127 | });
  128 | 
  129 | test('hidden tab stops sources and resumes music position without duplicate loops or SE backlog', async ({ page }) => {
  130 |   await ready(page); await unlock(page);
  131 |   await page.locator('#sound-preview').click();
  132 |   await expect.poll(() => audio(page).then(value => value.bgmPosition)).toBeGreaterThan(0.1);
  133 |   await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: true });
  134 |     document.dispatchEvent(new Event('visibilitychange')); });
  135 |   const paused = await audio(page);
  136 |   expect(paused.activeBgm).toBe(0); expect(paused.activeEffects).toBe(0);
  137 |   await page.locator('#sound-preview').click();
  138 |   expect((await audio(page)).counts.move).toBe(paused.counts.move);
  139 |   await page.evaluate(() => { Object.defineProperty(document, 'hidden', { configurable: true, value: false });
  140 |     document.dispatchEvent(new Event('visibilitychange')); });
  141 |   await expect.poll(() => audio(page).then(value => value.activeBgm)).toBe(1);
  142 |   expect((await audio(page)).bgmPosition).toBeGreaterThanOrEqual(paused.bgmPosition);
  143 |   expect((await audio(page)).counts.move).toBe(paused.counts.move);
  144 |   await page.locator('#close-menu').click(); await restartMatch(page);
  145 |   expect((await audio(page)).counts.bgm).toBe(2);
  146 |   await page.evaluate(() => window.__QUORIDOR_APP_TEST_API__!.disposeForTest());
  147 |   expect((await audio(page)).activeBgm).toBe(0); expect((await audio(page)).activeEffects).toBe(0);
  148 |   await expect.poll(() => audio(page).then(value => value.contextState)).toBe('closed');
  149 | });
  150 | 
  151 | test('asset HTTP/decode failure is recoverable and does not stop the game', async ({ page }) => {
  152 |   await page.route('**/assets/audio/pawn.wav', route => route.fulfill({ status: 404, body: '' }));
  153 |   await page.route('**/assets/audio/cozy-puzzle.mp3', route => route.fulfill({ status: 200, body: 'invalid audio' }));
  154 |   await ready(page); await page.locator('#open-menu').click();
  155 |   await expect.poll(() => audio(page).then(value => value.pending)).toBe(0);
  156 |   expect((await audio(page)).failures.sort()).toEqual(['bgm', 'move']);
  157 |   await expect(page.locator('#sound-status')).toContainText('対局は続けられます');
  158 |   await page.locator('#close-menu').click(); await move(page, 13);
  159 |   expect((await state(page)).view?.ply).toBe(1);
  160 |   await page.unroute('**/assets/audio/pawn.wav'); await page.unroute('**/assets/audio/cozy-puzzle.mp3');
  161 |   await page.locator('#open-menu').click(); await page.locator('#sound-retry').click();
  162 |   await expect.poll(() => audio(page).then(value => value.status)).toBe('ready');
  163 |   expect((await audio(page)).activeBgm).toBe(1);
  164 | });
  165 | 
  166 | test('autoplay denial retries from a gesture without replaying missed moves', async ({ page }) => {
  167 |   await page.addInitScript(() => {
  168 |     const original = AudioContext.prototype.resume;
  169 |     let fail = true;
```