# Rust runtime maintenance verification

Owner: `codex:/root/rust_runtime`, Beads `quoridor-fwe.3`.

The current patch uses canonical bounded native descriptor dispatch, family-level paired splits, benchmark cancellation and durable completed records, honest effective search budgets, and backend-provided cumulative work. No real model/data/GPU or research run was started.

Initial NNUE validation before the later canonical LoadedModel API addition:

- `cargo test -p quoridor-nnue --test residual`: 3 passed, compile 17.85 seconds.
- `cargo clippy -p quoridor-nnue --all-targets -- -D warnings`: passed, final check 3.07 seconds. The first check failed on the existing eight-argument residual constructor; its schema boundary now has a narrowly scoped documented allowance.
- `cargo test -p quoridor-nnue`: 9 passed, 1 ignored (requires pinned PyTorch), compile 11.09 seconds.
- Rustfmt scoped check and Git whitespace check passed after the current API addition. Final release validation of current source is pending Root resource admission.

All Cargo sessions used the shared target and one build job. Versions: rustc 1.98.1 and cargo 1.98.1. Session IDs 74536, 19192 and 33261 finished; no child build remained at retirement.

The first observed target size already included in-progress cold debug writes, so it was not a pre-build baseline. Root independently audited the new debug tree: all files dated 04:53:58 through 04:55:40 UTC on 2026-10-06, after task launch and within these builds. After Root authorization, `retired-debug-cache.json` captured exact path/length/SHA256/device/inode/mtime and allocation. Each of the 1,102 files was revalidated before unlink; unique allocated size was 224,538,624 bytes (hard links counted once). The debug tree is absent; all historical release files and scientific assets are preserved. The target subsequently measured 526,492 KiB. This retirement does not reduce historical charges or unknown reservations.

Limits: synchronous native inference cannot be forcibly interrupted by an in-process monitor; the outer research job owns process cleanup. Benchmark checks before and after native calls, cancels alpha-beta inside a search, and flushes completed JSONL records after every completed repeat. GPU/capture native execution was not tested; capture work remains explicitly unknown.

## Final current-source verification

- Full native release compilation succeeded with all features. NNUE: 9 passed, 1 ignored; runner: 14 library, 1 CLI-help and 3 configuration tests passed. Initial orchestration attempt exposed that its old 512MiB test process cap was below resident linked CUDA libraries, so it correctly returned `memory_limit` before intended test stimuli.
- The synthetic orchestration fixture cap alone was raised to 1GiB (production guard unchanged) and all 9 orchestration tests passed. Combined unique current coverage is 36 passed and 1 ignored.
- All-feature, all-target release Clippy with `-D warnings` passed in 14.23 seconds; after the one-line fixture-cap change, scoped orchestration Clippy passed in 3.30 seconds. Scoped Rustfmt and Git whitespace checks passed.
- Independent review identified a metadata output-cap gap. Benchmark now admits serialized identity metadata before work and checks exact final report bytes plus actual durable ledger bytes; oversized failure text yields a bounded report retaining failure counters and identity/report hashes. Both oversized run ID admission and oversized synthetic error regressions pass.
- CPU affinity remained two cores, shared target, one Cargo build job. Actual process-family RSS monitoring retained a 2GiB cap and 600-second wall limit. Full runtime attempt: 164.50 seconds, peak RSS 763,740,160 bytes. Successful orchestration retry: 24.13 seconds, peak RSS 734,924,800 bytes. Both ended with no live known children and no resource-cap stop.
- Earlier missing-native-environment build failure (9.11 seconds), artificial 2GiB virtual-address DLL mapping failure (219.53 seconds), and first Clippy failure (31.89 seconds) are retained in separate logs. The mapping failure was NOT_RUN for the runner harness; virtual address space was not treated as physical RAM.
- Compiler lint cleanup moved an unchanged resources test module to EOF, removed an unused diagnostic status initializer by definite assignment, and used array chunks in a regression. No production search heuristic/model math changed.
- Failed synthetic fixture files were copied with their hashes to `failed-fixtures.json` before removing only the six directories owned by the observed failed test process identity. Scientific assets and historic outputs were not touched.

Final source STOP is `STOP.json` with 12 explicit paths and SHA256 values. No source/index/commit writes remain; Root acceptance and issue closure are pending.
