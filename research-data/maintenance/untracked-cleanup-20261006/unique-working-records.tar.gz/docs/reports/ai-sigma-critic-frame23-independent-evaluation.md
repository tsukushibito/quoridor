# 入れ子増量と凍結後family評価 / quoridor-4lc.287

現在は静的レビュー段階。ready/show goal+selfの本人割当・pause無しを確認し、287をclaimした。新forward/科学jobは0、future-eval targetsは未読。旧279/277/275の成績・費・capsを変更していない。候補凍結後の一回評価まで担当を保持し、評価の結果や完了を先取りしない。

## 初期の独立確認

v2登録manifest SHA 9bda564e21e67c8294566c00d6752d9fec2d31aeae3e3735a5a317e21f08337dを読取り、1392 UID/prefix/actionseedの新集合内一意性、canonical/native alias、block/local IDとsplit、SHA domainからのactionseed、opening side、prefix SHAを別算術で確認した。train1248（P1/P2各624）、selection48（各24）、future96（各48）。29個の完整48family blockは12 opening cohort各4familyで構成される。labels/outcomesを使わない登録であり、合法prefix資格はownerのnative prepare source/proof参照に留まり、本人再生は未実行。新旧prefix/seed非重複のowner検査と、全history/実入力非露出の独立確認は別である。

入力署名のNN0 mockは、side反転+異なるids交換で同STM入力が保持されること、sideだけの変更・距離交換・version違いは区別すること、state/history/inputのいずれかでOR露出となることを確認した。これは実dataset資格ではない。literal history一致がないことをcrossformat完全非露出保証にしない。

## 重要な不足と通知

現行quoridor-dataのtensor metadata writerはrootmeanとzも出力する。そのためfutureのrows.jsonl/native cacheをlabel-freeと推測して開かない。prefreezeには対象値を除いた明示allowlistのmetadataとsealed path/SHAだけの資料が必要である。統括へ15:25台に通常activeで返した。これは生成開始の承認gateではなく、独立評価側の非開封境界である。

統括採択後のmask仕様をevaluation-preregister-v2.jsonへ結果前に登録した。Vrawは旧1248・旧392・新selection48のraw入力、Toldは旧Bの5981全seen行とする。Tseen_finalはToldと全savedstageの実used unionであり、最大train単独とは仮定しない。future除外はTseen_finalとVraw全体へのOR、finalvalはVrawからTseen_final共有行を除く同maskである。各集合のUID/rowID・predicate・version・SHAの実freezeは286からの引渡し待ち。全raw validationを参照したnewtrain除外、全実使用train（旧train・savedstageの実使用集合を含む）に対する共通final validation除外、futureに対する全train+全rawval除外を循環なしに束縛する必要がある。stage1後に除外規則が変わる場合、過去に学習した行を最終露出参照から失わせない。全予定・除外・zeroeligibleを保存し、結果後に都合よくmaskを選ばない。

native cacheはSTM→opponent順のxと距離を出力し、入力sideは1へ固定する。canonical metadataはP1→P2のidsとactual sideを保持する。side1を実gameのP1と読み替えず、実completeprefixとcanonical inputを必要witnessで対応させる。

## 評価前登録と待ち資料

旧登録v1を保存し、evaluation-preregister-v2.jsonにteacher rootmean MSEのfamily/group等重みをprimary、row平均・真z MSE/符号・cohort/side/phase・全費をsecondaryとして登録した。phaseはtotalply<20 / 20–59 / >=60。固定fitのpaired family bootstrap2000回、seed28780311、percentile95区間。family内game/row相関、opening/cohort分布、欠測・censoring、96familyの量の不確かさを保持する。独立family登録は無条件IID証明ではない。

比較はvalidationで凍結した一candidate、D(a0,b8)、旧B BEST200の最大3モデル。旧Bはresidual-v3/Zero4、weights SHA 8cb6bd48a8ca922c2cf217265a611353eee3aec44740d44713d9008ce047e0d7を参照する。v3 rawDskip、oldscale、f32、STM順、schemaを明示dispatchし、未知型を旧QF1 loaderへ入れない。Torch/nativeはfuturefreeze後の同一入力で最大24witnessへ限定し、物理NN/processed/UNKNOWNを全課金する。Dの解析変換は物理NNと区別し、事前上界は全3予測57600+witness5000で100000以内。

既quoridor_qf1_bulkは完整prefixをRuleAで再生しSTM入力を出力する。既private route-feature-diagnose model MANIFESTはPositionをQF1から再構成しfull/deltaの値を比較できるが、fullhistory再生や明示parent snapshotは出力しない。既APIを用いる有限witnessとteachertruth/history/parent全面保証を分ける。新Rust編集・buildは0。

285にはlabel-free metadata/UID/最終largestactualtrain/全slot ledger・sealed references、286には共通finalmask・全savedstage比較・singlecandidate/checkpoint/config/選定停止receiptが必要である。具体資料と担当をpending-inputs.jsonに記録した。futurelabel/config/設定凍結、producer/learner source・背景子回収、fresh frame23 current operation/loaded24hash/正identity/CPU/RAM/storageが揃うまでforwardは開始しない。全family・全稿・root ACKを他担当の開始gateにしない。

## 費と現状態

CPU3single/Torch1/GPU0/currentRAM2GiB guard1.75、科学MAX2/100000NN/100000processed/600秒・各180秒。NN0sourceprep300、compiletest60、管理180は別新配分。新8MiBは旧275未使用を自動freeとせず、92のstorage-287-admission.json（15:52:53、conservative total12349079552B < 12884901888B）へ追加計上された。科学直前にはcurrentを再確認する。現静的出力は小さいが全8MiBを予約forecastとする。モデル・inputは共有path参照、raw全copy/依存取得/Git/index操作は0。

科学/source上界22:55、保存23:10、親23:36:03。未着/未成立なら担当・理由・次機会をtyped保存し、予算や個別deadlineを延長しない。現段階はIN_PROGRESS_WAIT_IMMUTABLE_FREEZEであり、D超え・学習利益・棋力・最高目標の支持は未判断。future結果を候補選定や学習へ戻さない。

## 採択後のpublic projection対応

285 public whitelistはactualSTM_ids/order、STM_distance_f32bits/order、completeprefix、canonical/native alias、history formatを明示する。署名checkerはclosed whitelistと明示view dispatchを使い、uint32 bitsをそのままlittle-endianで束縛する。既P1/P2 metadataとの同入力対応はNN0 mockでPASS。明示public block00/01/02/26各先頭1rowのclosed whitelist・completeprefix/side・canonical alias・署名再計算もPASS_SAMPLE_ONLY（NN0、算術0.110511秒）。全rowの独立資格をここから認定しない。public first-rowサンプルの検査は全datasetの資格やfullhistory非露出を認定しない。初回ファイル探索はpublic以外のtrain/selection target-free private native metadataの各先頭行も読取ったが、future partition/raw/labelsは未読。この参照過剰を記録し、以降は明示publicファイル名だけを使用する。

## 285 public-only引渡しの全行参照照合

16:00:47のowner引渡しでpath/SHAが固定されたblock00/01/02/26の明示public projectionだけを、sourceprep枠内NN0で照合した。全6448行、train144family4803行・selection48family1645行。closed whitelist、全actualSTM sparseIDs/f32bit署名、UID一意性、canonical/native alias、登録opening prefix一致、completeprefix長/side/cohort対応はPASS_INPUT_REFERENCES_ONLY。各block48familyでzero-row family0。全GOALはproducer receiptであり、このcheckerは終局や教師値を再生していない。

正frame23 24hash/current scheduler・monitor identity、ownedとworkspace科学process/currentRSS・8MiB会計を直前point確認しCPU3singleで実行、child exit0/wait/exactabsenceを保存した。実NN0算術0.338506秒、科学MAX2のmodel job消費0、sourceprep保守180/300。publicの前後SHA一致を確認。future labels/raw/cache・旧test173は未読、future評価NN0のまま。fullhistory format互換とVraw/Told/Tseen_final最終集合・maskfreezeは未確認で、旧露出除外後の適格数やD超えをこの参照PASSから認定しない。

## sealed96公開参照の成立

285 sealed96-public-reference-handoff-v4 SHA234b99f5d2aea57c09585c206d04c107e9cc185daa6f2495a864b942b9f5cc6aをbindし、指定public二pathだけをNN0準備で確認。E27は1685行・48family、E28は1768行・48family、計3453 raw入力参照・96予定family。closed whitelist、STM IDs+f32bit署名、canonical/native alias、UID一意、登録opening prefix/completeprefix長/side/cohort、各family行数のowner集計との一致を確認しPASS_INPUT_REFERENCES_ONLY。前後public SHAも一致。全GOALはowner資格であり合法終局/教師truthの独立認証ではない。

正frame23 loaded24hash・exact scheduler/monitor・owned/current workspace CPU/RAM/storageの直前point確認からCPU3single NN0算術0.264450秒、child exit0/wait/exact不在。sourceprep保守210/300、管理45/180、compile0/60、科学0/MAX2、物理NN0を維持。new E public参照の不足は解消したが、3453はOR適格分母ではない。Told+全stage実used unionと全Vrawのfreeze、final共通validation mask/onecandidate/weights/settings/selectionsource-stopは286待ち。future labels/raw/cacheと旧openedtest/173は未読。旧history互換UNVERIFIEDとRuleA依存、quantity・teacherrootmean・真z・棋力の区別を保持する。

285現6generationのknown physicalNN522699（warm216込み）・science158.456377秒はowner累積値として参照し、旧166528/338820を再加算しない。新NNUEの学習利益はこの入力参照PASSから判断しない。

## 凍結後のlabel-free future mask

286のstage2-256k/step2000一候補、v3 Zero4/Dskip(0,8)、old B BEST200を固定する。Tseen_final25517と全Vraw3285へ独立ORを適用し、future96family/3453raw rowsは3453eligible、露出3predicate件数0、zeroeligible family0だった。最大trainだけではなく全used unionを参照し、rawvalを除外せず含めた。history形式互換と完全履歴非露出はUNVERIFIEDのまま。

最初のNN0 maskは新Tseen19536rowsのids_order欠測を拒否した。源・失敗を保存後、owner sourceのP1/P2 defaultをbindし、全19536のstate_keyから両pawn/壁anchor/残壁/180度のIDsを独自に足し戻して一致確認、明示P1/P2に正規化した。元freeze/参照bytesは変更していない。NN0であり、モデル数学・教師truth認証には広げない。

独立NumPy v3式と既native診断の一巡を結果前登録した。3453×2モデル＋24witness×2モデル×full/deltaで上界7002NN、保護済20kに収まる。Dは解析的tanh(8s)。Zero4はDAG4 dense slotだけ0で、両312 QF1 sparse FTは残る。未知モデル型を旧normal QF1へ誤読しない。

現在はproducerのsealed rootmean/z label接線と自然物理窓待ちで、model forward0/targets未開封/science MAX未消費。公開Sigma zの291とは条件・封印・費を分ける。旧287のsource費210を保持し、今のNN0準備を含む保守270/300、science360/MAX2/NN20k/data4MiBを記録する。raw/modelの複製や旧testへの選定復帰を行わない。

## 凍結後一巡予測（2026-10-05 18:13 UTC）

候補はstage2-256k/step2000、旧BはBEST200に固定し、Tseen_final 25517と全Vraw 3285のOR露出maskを候補結果前に束縛した。future全96family/3453行はこの有限predicateで全行適格、zeroeligible familyは0。history crossformatはUNVERIFIEDであり、literal不一致から完全な履歴非露出を主張しない。

専用task frame23-independent-evaluation-287-prediction-v1のguardで一巡を実行した。18:13:51.531397–18:13:52.292911、exit0/wait/current exact remaining[]、CPU3単1、peak RSS 68,403,200B。物理NN7002は独自NumPy v3Zero4式の2モデル×3453と既nativeの2モデル×24witness×full/deltaからなる。route4だけをzeroにし、両QF1 sparse FTは保持する。候補/nativeの最大絶対差1.7881393e-7、旧B/nativeは2.9802322e-8。この有限入力数値照合を全deeptruth・終局教師の独立認証へ広げない。

停止束縛はprediction-science-stop-v1.json、予測はfrozen-future-predictions-v1.jsonl.gz。ラベル解放receiptは受領済みだが、既CPU環境にpyarrow/polarsがなく、現runner入口は件数又はdense cache出力である。新依存・新build・全denseコピーを追加せず、既producer readerによるcanonical_family/id/rootmean/z小projectionを依頼した。主MSE/z/sign/paired intervalはまだNOT_RUNであり、数値改善・学習利益は未裁定である。次工程は保存済みスカラーだけのNN0算術で、追加forward・再選定をしない。

92 finish-receipt修復の新loaded/current24/exact2証拠が成立するまで次の科学入口を保留する。既一巡は自然回収済み。公開Sigma0043は別条件で封印を維持する。

## 最終算術の有限不完全終了

旧E27/E28の3453行scalar projectionをproducerから受領し、alias+family/id、元Arrow member/manifest、凍結候補、共通mask、新runtimeと現物理入場を束縛した。公開Sigma0043は未読のままである。

第二科学slotの専用score entryは2026-10-05 18:58:37.820716–18:58:37.960056、0.139360秒、exit1/wait/currentexact remaining[]だった。guardianのargvで必須registrationファイル引数を渡し忘れ、score entryのsys.argv[1]でIndexErrorとなった。NumPy import後、予測/ラベルloadや数値集計の前の検査器入口不備であり、データ・学習の科学負例ではない。元processのNN UNKNOWN/上界0表記を残し、source順序に基づく今回NN0/targets decode0の有限補足を別保存した。

旧一巡7002NNの有限数値parityは保持するが、rootmean/z/sign/familybootstrap最終裁定はNOT_RUN、独立最終PASSは0である。科学MAX2を両slot消費したため自動再計算をしない。引数追加だけのprospective修復源は別版で保全し、未実行である。原guard/entry/argv/log/process/source SHA、旧予測packとincremental failure packを停止正本finite-incomplete-final-stop-v1.jsonに束縛した。

今の次判断は学習効果不支持ではなく、原saved scalar予測/凍結条件からの独立誤差裁定が未成立という手続き上の不足である。追加モデル生成・再選定や旧結果上書きは不要で、将来明示配分があればこの有限argv修復を適用したNN0集計だけが必要となる。親の最高棋力目標は未達のまま維持する。
