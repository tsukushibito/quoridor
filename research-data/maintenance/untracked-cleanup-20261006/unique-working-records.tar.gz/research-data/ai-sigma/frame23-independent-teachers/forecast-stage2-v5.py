"""Saved counts, file allocation and command spans; no model or label selection."""

import collections
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import time


ROOT = Path(__file__).resolve().parent
ASSETS = Path("/workspaces/quoridor/.worktree/assets/inputs/frame23-independent-teachers")
BLOCKS = [0, 1, 2, 26, 27, 28]


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def allocation(root):
    seen, allocated = set(), 0
    for path in root.rglob("*"):
        if path.is_file() and not path.is_symlink():
            stat = path.stat()
            key = (stat.st_dev, stat.st_ino)
            if key not in seen:
                seen.add(key)
                allocated += stat.st_blocks * 512
    return allocated


def main():
    began = time.monotonic()
    allocated, logical, seen = collections.Counter(), collections.Counter(), set()
    for root in [ROOT, ASSETS]:
        for path in root.rglob("*"):
            if not path.is_file() or path.is_symlink():
                continue
            stat = path.stat()
            key = (stat.st_dev, stat.st_ino)
            if key in seen:
                continue
            seen.add(key)
            if path.is_relative_to(ASSETS):
                category = "dense_cache" if "-cache" in str(path) else "native_raw"
            elif "public-targetfree" in path.name:
                category = "public_input_projection"
            elif "targetfree-private" in path.name:
                category = "private_input_witness"
            elif path.name == "read-metadata-v1" or path.suffix == ".rmeta":
                category = "private_metadata_reader_binary"
            elif ".tar." in path.name:
                category = "source_archive"
            elif path.suffix in {".py", ".rs"}:
                category = "private_source"
            elif path.suffix in {".tmp", ".partial"}:
                category = "temp_partial"
            else:
                category = "config_results_runtime_logs"
            allocated[category] += stat.st_blocks * 512
            logical[category] += stat.st_size
    reports = []
    for block in BLOCKS:
        tag = f"block{block:02d}"
        generation = read(ROOT / f"{tag}-pipeline-result-v2.json")
        # Producer reads aggregate profiling fields only, never selects a row by a label.
        report = read(generation["native_report_path"])
        process = read(ROOT / f"{tag}-r1/process.json")
        ep = read(ROOT / f"{tag}-export-r1/process.json")
        pump = report["pump"]
        completions = pump["completions"]
        reports.append(
            {
                "block": block,
                "planned_completed_families": 48,
                "rows": report["rows"],
                "generation_command_s": process["command_wall_s"],
                "generation_guard_inclusive_s": process["management_inclusive_wall_s"],
                "generation_guard_outside_command_s": process["management_inclusive_wall_s"]
                - process["command_wall_s"],
                "native_whole_s": report["wall_seconds"],
                "native_backend_cold_init_s": pump["backend_initialization_seconds"],
                "native_backend_cleanup_s": pump["backend_cleanup_seconds"],
                "native_record_s": pump["recording_seconds"],
                "native_finalize_s": pump["finalization_seconds"],
                "native_queue_sum_s_overlap": pump["queue_wait_seconds_sum"],
                "first16_complete_s_partial_span": pump["first16_complete_seconds"],
                "last8_tail_native_s": report["wall_seconds"] - completions[-9]["elapsed_seconds"],
                "last24_tail_native_s": report["wall_seconds"]
                - completions[-25]["elapsed_seconds"],
                "export_cache_projection_command_s": ep["command_wall_s"],
                "export_guard_inclusive_s": ep["management_inclusive_wall_s"],
                "export_guard_outside_command_s": ep["management_inclusive_wall_s"]
                - ep["command_wall_s"],
                "NN": generation["physical_NN"],
                "warm_NN": pump["backend_warmup_nn"],
            }
        )
    allrows = sum(r["rows"] for r in reports)
    trainrows = sum(r["rows"] for r in reports if r["block"] < 26)
    cache_rows = sum(r["rows"] for r in reports if r["block"] <= 26)
    variable_per_new_train_row = (
        allocated["native_raw"]
        + allocated["public_input_projection"]
        + allocated["private_input_witness"]
    ) / allrows + allocated["dense_cache"] / cache_rows
    known = read(ROOT / "stage2-actualforecast-proposal-v4.json")["known_actual"]
    own_actual = sum(allocated.values())
    yield_raw = trainrows / 144
    mean_gen = sum(r["generation_command_s"] for r in reports) / 6
    mean_export = sum(r["export_cache_projection_command_s"] for r in reports[:4]) / 4
    mean_guard = (
        sum(
            r["generation_guard_outside_command_s"] + r["export_guard_outside_command_s"]
            for r in reports
        )
        / 6
    )
    scenarios = []
    for fraction in [0.0, 0.1, 0.2]:
        total_train = math.ceil((30000 - 5981) / (yield_raw * (1 - fraction)) / 48) * 48
        additional = (total_train - 144) // 48
        predicted_base = (
            own_actual
            + additional * 48 * yield_raw * variable_per_new_train_row
            + additional * 65536
        )
        scenarios.append(
            {
                "new_train_OR_exclusion_assumption": fraction,
                "total_train_families": total_train,
                "additional_registered_blocks": list(range(3, total_train // 48)),
                "train_rows_before_OR_estimate": total_train * yield_raw,
                "old5981_plus_new_after_OR_estimate": 5981
                + total_train * yield_raw * (1 - fraction),
                "cumulative_generation_entries": 6 + additional,
                "science_cumulative_command_s_linear_estimate": known["science_seconds"]
                + additional * mean_gen,
                "science_cumulative_hard_bound_s": known["science_seconds"] + additional * 420,
                "NN_cumulative_conservative": known["physicalNN"] + additional * 624036,
                "NN_cumulative_at_saved_mean": known["physicalNN"]
                + additional * sum(r["NN"] for r in reports) / 6,
                "new_export_projection_command_s_linear_estimate": additional * mean_export,
                "new_guard_outside_command_s_linear_estimate": additional * mean_guard,
                "data_scope_current_plus_estimated_growth_bytes": math.ceil(predicted_base),
                "data_scope_with_2p5_safety_including_possible_Git_temp_bytes": math.ceil(
                    predicted_base * 2.5
                ),
                "within_stage2_1GiB_forecast": predicted_base * 2.5 <= 1024**3,
                "unknown_management_read_Git_alias_checks_s": "UNKNOWN; linear spans are not wholepipeline guarantee",
            }
        )
    prep_remaining_known_only = 300 - known["NN0prep_known_command_seconds"]
    payload = {
        "task": "independent-teachers-285-v2",
        "schema": "actual-stage2-prefix-forecast-v5",
        "UTC": datetime.now(timezone.utc).isoformat(),
        "NN_new": 0,
        "saved_counts": {
            "train_families": 144,
            "train_rows_before_OR": trainrows,
            "selection_families": 48,
            "future_families_sealed": 96,
            "all_input_rows": allrows,
            "all_completed_families": 288,
        },
        "allocation_metric": "unique dev/inode st_blocks; reflink shared physical extents UNKNOWN",
        "current_scope_allocated_by_category": dict(allocated),
        "current_scope_logical_by_category": dict(logical),
        "current_scope_allocated_total": own_actual,
        "allocated_per_all_input_row": own_actual / allrows,
        "incremental_allocated_per_new_train_row_assumption": variable_per_new_train_row,
        "scope_in_stage1_448MiB_reservation_unused_before_new_Git_temp": 448 * 1024**2 - own_actual,
        "scope_in_stage2_1GiB_reservation_unused_before_new_Git_temp": 1024**3 - own_actual,
        "actual_uniqueGit_attribution": "UNKNOWN; 2.5 safety is a forecast, not measurement",
        "shared_release_current_allocated": allocation(
            Path("/workspaces/quoridor/.artifacts/rust-migration/target/release")
        ),
        "shared_release_growth_for_next_generation": 0,
        "shared_release_growth_guard_32MiB_retained": True,
        "current_global_Git_allocated": allocation(Path("/workspaces/quoridor/.git")),
        "per_completed_family_generation_command_s": known["science_seconds"] / 288,
        "observed_components": reports,
        "components_are_nested_or_overlapping": True,
        "one_proposed_range": {
            "next_train_blocks": list(range(3, 19)),
            "total_train_max_in_this_proposal": 912,
            "complete48_block_stop_at_about30k_after_OR": True,
            "not_authorization_or_label_loss_selection": True,
        },
        "scenarios": scenarios,
        "caps_stage1_included": {
            "science_MAX30": 30,
            "NN_cumulative": 18200000,
            "science_cumulative_seconds": 12000,
        },
        "NN0prep_remaining_from_known_commands_only": prep_remaining_known_only,
        "NN0prep_unknown_read_formatter_failure_CPU_not_discounted": True,
        "export_budget_constraint": {
            "old_export_hard60_applied_to16_blocks_s": 960,
            "within_original_prep300": False,
            "possible_prospective_export_hard9s_for16_blocks_s": 144,
            "saved_largest_export_command_s": max(
                r["export_cache_projection_command_s"] for r in reports
            ),
            "hard9s_not_yet_adopted": True,
            "remaining_unknown_commands_and_finalpack_need_headroom": True,
            "if_long_export_required": "specific prep budget gap; no cap reset, no science auto-start",
        },
        "management_available_exact_remaining": "UNKNOWN pending aggregation of report/control commands; native spans must not be double counted",
        "fixed_prefix_prepare_command_s_once_already_charged": 90.378743991,
        "storage_next_action": "92 fresh retained+allunused+UNKNOWN128MiB+learner64MiB+critic8MiB before stage2 heavy",
        "stage2_heavy_started": False,
        "future_label_distribution": False,
        "old_generation_fee_and_failed_NN0_preserved": True,
        "postOR_yield": "PENDING286; replace assumptions with actual count when received",
        "command_wall_s": time.monotonic() - began,
    }
    output = ROOT / "stage2-actual-prefix-forecast-v5.json"
    with output.open("x") as stream:
        stream.write(json.dumps(payload, indent=2, allow_nan=False) + "\n")
    print(
        json.dumps(
            {
                "output": str(output),
                "allocated": own_actual,
                "scenarios": scenarios,
                "command_wall_s": payload["command_wall_s"],
            }
        )
    )


if __name__ == "__main__":
    main()
