"""Register label-free prefixes and immutable canonical/native aliases before generation."""

import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path = Path(path)
    assert not path.exists(), str(path)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def seed(domain):
    return int.from_bytes(hashlib.sha256(domain.encode()).digest()[:8], "big")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    cfg = read(parser.parse_args().config)
    out = Path(cfg["output_dir"])
    began = time.monotonic()
    for path, expected in cfg["source_hashes"].items():
        assert sha(path) == expected, "SOURCE_SHA:" + path
    native = read(cfg["native_config"])
    assert native["seed"] == seed("frame23-285-independent-teachers-v2")
    assert not Path(native["output"]).exists()
    command = subprocess.run(cfg["argv"], check=False)
    assert command.returncode == 0, "PREPARE_FAILED"
    raw = read(native["output"])
    assert raw["task"] == "resident-teacher-273-prepare-v1"
    assert raw["schema"] == "teacher-opening-plan-v1" and raw["NN"] == 0
    assert raw["seed"] == native["seed"] and not raw["new_game_results_seen"]
    order = {length: i for i, length in enumerate(native["opening_lengths"])}
    plans = sorted(raw["plans"], key=lambda p: (p["ordinal"], order[p["cohort"]]))
    assert len(plans) == 1392
    assert {(p["cohort"], p["ordinal"]) for p in plans} == {
        (length, ordinal) for length in order for ordinal in range(116)
    }
    old = read(cfg["old_family_map"])
    used = {tuple(p["prefix"]) for p in old["families"]}
    old_seeds = {p["actionseed"] for p in old["families"]}
    seen = set()
    families = []
    configs = []
    template = read(cfg["native_template"])
    deadline = int(datetime.fromisoformat("2026-10-05T22:45:00+00:00").timestamp() * 1000)
    for i, p in enumerate(plans):
        prefix = tuple(p["prefix"])
        assert len(prefix) == p["cohort"] and prefix not in used and prefix not in seen
        assert all(type(a) is int and 0 <= a <= 208 for a in prefix)
        seen.add(prefix)
        block, local_id = divmod(i, 48)
        run_id = f"frame23-285-v2-block{block:02d}-r1"
        run_seed = seed(f"frame23-285-v2-game-rng-block{block:02d}")
        action_seed = run_seed ^ (((local_id + 1) * 0x9E3779B97F4A7C15) % (1 << 64))
        assert action_seed not in old_seeds
        split = "train" if i < 1248 else "validation" if i < 1296 else "test"
        families.append(
            dict(
                p,
                canonical_family=f"frame23-285-v2-family-{i:06d}",
                slot=i,
                block=block,
                local_id=local_id,
                native_family=f"{run_id}-family-{local_id:06d}",
                native_run_id=run_id,
                split=split,
                split_purpose={
                    "train": "train",
                    "validation": "selection",
                    "test": "sealed_futureevaluation",
                }[split],
                opening_side=1 if len(prefix) % 2 == 0 else 2,
                prefix_SHA=hashlib.sha256(
                    json.dumps(list(prefix), separators=(",", ":")).encode()
                ).hexdigest(),
                actionseed=action_seed,
                status="NOT_STARTED",
            )
        )
    assert len({p["actionseed"] for p in families}) == 1392
    for block in range(29):
        rows = families[block * 48 : (block + 1) * 48]
        split = rows[0]["split"]
        assert all(p["split"] == split for p in rows)
        c = dict(template)
        c.update(
            run_id=rows[0]["native_run_id"],
            output=str(Path(cfg["asset_root"]) / split / f"block{block:02d}-r1-native"),
            games=48,
            train_games=48 if split == "train" else 0,
            validation_games=48 if split == "validation" else 0,
            seed=seed(f"frame23-285-v2-game-rng-block{block:02d}"),
            openings=[p["prefix"] for p in rows],
            wall_seconds=390.0,
            max_memory_bytes=1879048192,
            max_output_bytes=50331648,
            deadline_unix_ms=deadline,
        )
        path = out / f"block{block:02d}-native-v2.json"
        write(path, c)
        configs.append(
            {
                "block": block,
                "path": str(path),
                "SHA": sha(path),
                "split": split,
                "physical_NN_upper": 624036,
                "planned": 48,
                "stage2_not_yet_authorized": 5 <= block <= 25,
            }
        )
    manifest = out / "registered-family-map-v2.json"
    write(
        manifest,
        {
            "task": cfg["task"],
            "schema": "independent-teacher-family-map-v2",
            "namespace": "frame23-285-v2",
            "seed": native["seed"],
            "plans_SHA": sha(native["output"]),
            "preregister_SHA": sha(cfg["preregister"]),
            "families": families,
            "configs": configs,
            "planned_family_count": 1392,
            "split_counts": {"train": 1248, "validation": 48, "test": 96},
            "labels_or_outcomes_used": False,
            "old_prefix_duplicates": 0,
            "new_exact_prefix_duplicates": 0,
            "state_share_not_proven_absent": True,
            "final_global_mask": "NOT_FROZEN",
            "history_compatibility": "UNVERIFIED",
        },
    )
    write(
        cfg["output"],
        {
            "task": cfg["task"],
            "schema": cfg["schema"],
            "NN": 0,
            "status": "REGISTERED_NO_GENERATION",
            "manifest": str(manifest),
            "manifest_SHA": sha(manifest),
            "native_helper_task_reused": raw["task"],
            "source_hashes": cfg["source_hashes"],
            "wall_s": time.monotonic() - began,
            "planned_family_count": 1392,
            "scientific_entries": 0,
        },
    )


if __name__ == "__main__":
    main()
