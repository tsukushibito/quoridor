"""One frozen v3/Zero4 evaluation on public input refs; labels remain unopened."""

import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import runpy
import struct
import subprocess
import time

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[variable] = "1"
os.environ["ORT_DISABLE_TELEMETRY"] = "1"

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-independent-evaluation"
TASK = "frame23-independent-evaluation-287-prediction-v1"
FREEZE = (
    ROOT
    / "research-data/ai-sigma/frame23-independent-teacher-learning/candidate-external-freeze-v1.json"
)
HANDOFF = (
    ROOT
    / "research-data/ai-sigma/frame23-independent-teachers/sealed96-public-reference-handoff-v4.json"
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_v3(manifest_path, np):
    manifest = json.loads(manifest_path.read_text())
    assert manifest["schema"] == "quoridor-nnue-distance-residual-v3"
    assert manifest["feature"] == "QF1-route4-f32-STM-scaled-residual-v3"
    assert manifest["route_mode"] == "zero4"
    assert manifest["topology"] == {"ft_width": 32, "hidden_width": 32}
    assert manifest["value_perspective"] == "side-to-move"
    assert manifest["value_parameterization"] == "fixed-distance-logit-plus-linear-residual-tanh"
    assert manifest["distance_fit"] == {"a": 0.0, "b": 8.0}
    weights_path = manifest_path.parent / manifest["weights"]
    assert sha(weights_path) == manifest["weights_SHA"]
    weights = np.frombuffer(weights_path.read_bytes(), dtype="<f4")
    assert len(weights) == 12321 and np.isfinite(weights).all()
    assert manifest["weights_B"] == 49284 and manifest["little_endian_f32"] == 12321
    slices = []
    offset = 0
    for shape in ((32, 312), (32,), (32, 70), (32,), (32,), (1,)):
        size = 1
        for dimension in shape:
            size *= dimension
        slices.append(weights[offset : offset + size].reshape(shape))
        offset += size
    assert offset == len(weights)
    return manifest, slices


def predict(x, distances, manifest, weights, np):
    ft, ft_bias, hidden, hidden_bias, head, head_bias = weights
    encoded = np.maximum(x @ ft.T + ft_bias, np.float32(0))
    mu = np.asarray(manifest["mu_f32"], dtype="<f4")
    sigma = np.asarray(manifest["sigma_f32"], dtype="<f4")
    assert np.isfinite(mu).all() and np.isfinite(sigma).all() and (sigma > 0).all()
    columns = np.concatenate(
        (
            encoded[:, 0],
            encoded[:, 1],
            (distances - mu) / sigma,
            np.zeros((len(x), 4), dtype="<f4"),
        ),
        axis=1,
    )
    residual = np.maximum(columns @ hidden.T + hidden_bias, np.float32(0)) @ head + head_bias[0]
    logit = np.float32(8) * (distances[:, 1] - distances[:, 0])
    result = np.tanh(logit + residual).astype("<f4")
    assert np.isfinite(result).all() and (np.abs(result) <= 1).all()
    return result


def main():
    register = json.loads((OUT / "prediction-registration-v2.json").read_text())
    assert register["task"] == TASK and register["entry_SHA"] == sha(__file__)
    assert sha(FREEZE) == register["freeze_SHA"]
    assert sha(HANDOFF) == register["public_handoff_SHA"]
    assert sha(OUT / "future-mask-v1.json.gz") == register["mask_SHA"]
    physics = runpy.run_path(
        str(ROOT / ".worktree/frame21-search/tools/research-review/sigma_input_review.py")
    )
    physics["admit"].__globals__["OUT"] = OUT
    physics["admit"].__globals__["TASK"] = TASK
    physics["admit"]()
    (OUT / "fixture-admission-v1.json").rename(OUT / "prediction-admission-v1.json")
    admission_path = OUT / "prediction-admission-v1.json"
    admission = json.loads(admission_path.read_text())
    admission["physical_helper_SHA"] = admission.pop("entry_SHA")
    admission["entry_SHA"] = sha(__file__)
    admission["synthetic_only_no_label_or_model_reader"] = False
    admission["model_GPU_or_asset_reader"] = "prospective CPU modelweights read; no GPU"
    admission["targets_opened"] = False
    admission_path.write_text(json.dumps(admission, indent=2) + "\n")
    started = time.monotonic()
    import numpy as np

    with gzip.open(OUT / "future-mask-v1.json.gz", "rt") as stream:
        mask = json.load(stream)
    by_id = {(r["canonical_family"], r["id"]): r for r in mask["rows"]}
    handoff = json.loads(HANDOFF.read_text())
    inputs = []
    for block in handoff["blocks"]:
        path = Path(block["public_target_free_metadata"])
        assert sha(path) == block["public_metadata_SHA"]
        for line in path.read_text().splitlines():
            row = json.loads(line)
            if by_id[(row["canonical_family"], row["id"])]["eligible"]:
                inputs.append(row)
    assert len(inputs) == register["eligible_rows"]
    x = np.zeros((len(inputs), 2, 312), dtype="<f4")
    distances = np.empty((len(inputs), 2), dtype="<f4")
    for index, row in enumerate(inputs):
        assert row["ids_order"] == "STM_then_opponent"
        assert row["distance_order"] == "STM_then_opponent_f32_le"
        for view in (0, 1):
            ids = row["actualSTM_ids"][view]
            assert ids == sorted(set(ids)) and all(0 <= k < 312 for k in ids)
            x[index, view, ids] = 1
        distances[index] = struct.unpack("<ff", struct.pack("<II", *row["STM_distance_f32bits"]))
    predictions = {}
    native = []
    native_NN = 0
    native_binary = Path(register["native_binary"])
    assert sha(native_binary) == register["native_binary_SHA"]
    selected = {}
    for index in sorted(
        range(len(inputs)), key=lambda i: (inputs[i]["canonical_family"], inputs[i]["id"])
    ):
        row = inputs[index]
        selected.setdefault((row["cohort"], row["side"]), index)
    witnesses = list(selected.values())[:24]
    assert len(witnesses) == register["native_witness_count"]
    for name, binding in register["models"].items():
        manifest_path = Path(binding["manifest"])
        assert sha(manifest_path) == binding["manifest_SHA"]
        manifest, weights = load_v3(manifest_path, np)
        assert manifest["weights_SHA"] == binding["weights_SHA"]
        predictions[name] = predict(x, distances, manifest, weights, np)
        native_rows = []
        for index in witnesses:
            row = inputs[index]
            views = row["actualSTM_ids"]
            if row["side"] == 2:
                views = views[::-1]
            native_rows.append(
                {
                    "id": row["canonical_family"] + ":" + row["id"],
                    "side": row["side"],
                    "ids": views,
                    "distance": distances[index].tolist(),
                }
            )
        command = ["/usr/bin/taskset", "-c", "3", str(native_binary), "model", str(manifest_path)]
        child_start = time.monotonic()
        process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        pid = process.pid
        tick = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()[19]
        stdout, stderr = process.communicate(
            "".join(json.dumps(r) + "\n" for r in native_rows), timeout=20
        )
        assert process.returncode == 0, stderr
        parsed = [json.loads(line) for line in stdout.splitlines()]
        assert len(parsed) == len(witnesses)
        errors = []
        for item, index, expected in zip(parsed, witnesses, native_rows):
            assert item["id"] == expected["id"]
            value = float(predictions[name][index])
            error = abs(value - item["value"])
            assert error <= 1e-5 + 1e-4 * abs(value)
            assert abs(item["value"] - item["delta_value"]) <= 1e-5 + 1e-4 * abs(value)
            errors.append(error)
        native_NN += 2 * len(parsed)
        native.append(
            {
                "model": name,
                "argv": command,
                "pid": pid,
                "tick": tick,
                "exit_code": process.returncode,
                "waited": True,
                "current_exact_absent": not (Path("/proc") / str(pid)).exists(),
                "NN": 2 * len(parsed),
                "max_numpy_native_abs": max(errors),
                "wall_seconds": time.monotonic() - child_start,
                "output": parsed,
            }
        )
    predictions["D"] = np.tanh(np.float32(8) * (distances[:, 1] - distances[:, 0]))
    with gzip.open(OUT / "frozen-future-predictions-v1.jsonl.gz", "wt") as stream:
        for index, row in enumerate(inputs):
            stream.write(
                json.dumps(
                    {
                        "canonical_family": row["canonical_family"],
                        "id": row["id"],
                        "input_signature": row["input_signature"],
                        "cohort": row["cohort"],
                        "side": row["side"],
                        "ply": row["ply"],
                        "prediction": {
                            name: float(values[index]) for name, values in predictions.items()
                        },
                    },
                    separators=(",", ":"),
                )
                + "\n"
            )
    result = {
        "task": TASK,
        "schema": "frozen-future-prediction-v1",
        "PASS": True,
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "rows": len(inputs),
        "families": len({r["canonical_family"] for r in inputs}),
        "physicalNN": len(inputs) * 2 + native_NN,
        "numpyNN": len(inputs) * 2,
        "nativeNN": native_NN,
        "native": native,
        "native_witness_grid": list(map(list, selected)),
        "targets_opened": False,
        "independent_game_outcome_or_deeptruth": False,
        "NumPy_formula_independent_of_producer_forward": True,
        "route4_slots": "zero after standardization; QF1 sparse FT retained",
        "wall_seconds": time.monotonic() - started,
        "prediction_SHA": sha(OUT / "frozen-future-predictions-v1.jsonl.gz"),
    }
    assert result["physicalNN"] <= register["NN_upper"] <= 20000
    (OUT / "prediction-result-v1.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k != "native"}))


if __name__ == "__main__":
    main()
