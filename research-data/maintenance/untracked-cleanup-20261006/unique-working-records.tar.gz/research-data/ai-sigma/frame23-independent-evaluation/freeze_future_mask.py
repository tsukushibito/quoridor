"""Label-free, independent future OR mask; never open label/model containers."""

import collections
import gzip
import hashlib
import json
from pathlib import Path
import runpy
import time

from label_free import input_signature, validate_public

ROOT = Path("/workspaces/quoridor")
OUT = ROOT / "research-data/ai-sigma/frame23-independent-evaluation"
FREEZE = (
    ROOT
    / "research-data/ai-sigma/frame23-independent-teacher-learning/candidate-external-freeze-v1.json"
)
HANDOFF = (
    ROOT
    / "research-data/ai-sigma/frame23-independent-teachers/sealed96-public-reference-handoff-v4.json"
)
TASK = "frame23-independent-evaluation-287-future-mask-v1"
VERSION = "QF1-f32-STM-input-v1"


def verify_p1p2_geometry(row):
    """Independent coordinate/anchor witness for reference rows lacking order."""
    fields = row["state_key"].split("|")
    assert len(fields) == 5
    pawns = [int(p.split(",")[1]) * 9 + int(p.split(",")[0]) for p in fields[:2]]
    assert int(fields[2]) == row["side"] - 1
    walls = []
    for literal, base in zip(fields[3:], (162, 226)):
        anchors = [int(p.split(",")[1]) * 8 + int(p.split(",")[0]) for p in literal.split(";") if p]
        assert all(0 <= a < 64 for a in anchors)
        walls.extend((base, a) for a in anchors)
    stocks = []
    for player in range(2):
        stock = [k - 290 for k in row["ids"][player] if 290 <= k <= 300]
        assert len(stock) == 1
        stocks.append(stock[0])
    for player in range(2):
        rotate = player == 1
        square = lambda c: 80 - c if rotate else c
        expected = [square(pawns[player]), 81 + square(pawns[player ^ 1])]
        expected += [base + (63 - a if rotate else a) for base, a in walls]
        expected += [290 + stocks[player], 301 + stocks[player ^ 1]]
        assert sorted(expected) == row["ids"][player]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def bound(reference):
    path = Path(reference["path"])
    if not path.is_absolute():
        path = ROOT / path
    assert sha(path) == reference["SHA"]
    return path


def main():
    # Reuse physical admission only; the OR checker remains this issue's code.
    physics = runpy.run_path(
        str(ROOT / ".worktree/frame21-search/tools/research-review/sigma_input_review.py")
    )
    physics["admit"].__globals__["OUT"] = OUT
    physics["admit"].__globals__["TASK"] = TASK
    physics["admit"]()
    (OUT / "fixture-admission-v1.json").rename(OUT / "future-mask-admission-v1.json")
    started = time.monotonic()
    freeze = json.loads(FREEZE.read_text())
    assert freeze["schema"] == "external-freeze-v1" and not freeze["future_labels_opened"]
    stopped = json.loads(bound(freeze["science_source_stop"]).read_text())
    assert stopped["reader_stopped"] and stopped["source_writer_stopped_for_public_transition"]
    assert not stopped["all_waited_current_exact_remaining"]
    references = {"states": set(), "histories": set(), "inputs": set()}
    reference_counts = {}
    reference_families = set()
    source_default_order_geometry_verified = 0
    for name, ref in freeze["reference_sets"].items():
        count = 0
        with gzip.open(bound(ref), "rt") as stream:
            for line in stream:
                row = json.loads(line)
                assert not any(k in row for k in ("z", "rootmean", "winner", "target"))
                count += 1
                reference_families.add(row["group"])
                if "ids_order" not in row:
                    verify_p1p2_geometry(row)
                    row["ids_order"] = "P1_then_P2"
                    source_default_order_geometry_verified += 1
                elif row["ids_order"] == "STM_then_opponent":
                    row["actualSTM_ids"] = row["ids"]
                row["distance_order"] = "STM_then_opponent_f32"
                references["states"].add(row["state_key"])
                references["histories"].add(row["history_key"])
                references["inputs"].add(input_signature(row, VERSION))
        reference_counts[name] = count
    assert reference_counts["Vraw"] == 3285
    assert reference_counts["Tseen_final"] >= 5981
    handoff = json.loads(HANDOFF.read_text())
    assert sha(HANDOFF) == "234b99f5d2aea57c09585c206d04c107e9cc185daa6f2495a864b942b9f5cc6a"
    rows = []
    groups = collections.defaultdict(lambda: {"planned_rows": 0, "eligible_rows": 0})
    reasons = collections.Counter()
    seen = set()
    for block in handoff["blocks"]:
        path = Path(block["public_target_free_metadata"])
        assert sha(path) == block["public_metadata_SHA"]
        for line in path.read_text().splitlines():
            row = json.loads(line)
            validate_public(row)
            assert row["partition"] == "sealed_futureevaluation"
            family = row["canonical_family"]
            assert family not in reference_families
            identity = (family, row["id"])
            assert identity not in seen
            seen.add(identity)
            signature = input_signature(row, VERSION)
            matches = {
                "state": row["state_key"] in references["states"],
                "history_literal": row["history_key"] in references["histories"],
                "actual_STM_f32": signature in references["inputs"],
            }
            eligible = not any(matches.values())
            groups[family]["planned_rows"] += 1
            groups[family]["eligible_rows"] += eligible
            for reason, matched in matches.items():
                reasons[reason] += matched
            rows.append(
                {
                    "canonical_family": family,
                    "id": row["id"],
                    "eligible": eligible,
                    "matches": matches,
                    "input_signature": signature[1],
                }
            )
    assert len(rows) == 3453 and len(groups) == 96
    mask = {
        "task": TASK,
        "schema": "independent-future-or-mask-v1",
        "freeze_SHA": sha(FREEZE),
        "public_handoff_SHA": sha(HANDOFF),
        "reference_counts": reference_counts,
        "source_default_P1P2_geometry_verified_rows": source_default_order_geometry_verified,
        "reference_order_gap": "19536 new Tseen rows lack ids_order; source default and independent full state/anchor/stock geometry binding recorded, not silent inference",
        "predicate": "state literal OR history literal OR actualSTM sortedIDs+f32distance/version",
        "references": "Tseen_final UNION ALL Vraw",
        "planned_families": 96,
        "actual_families": len(groups),
        "raw_rows": len(rows),
        "eligible_rows": sum(r["eligible"] for r in rows),
        "zeroeligible_families": sum(g["eligible_rows"] == 0 for g in groups.values()),
        "reason_counts_overlapping": dict(reasons),
        "groups": dict(groups),
        "rows": rows,
        "targets_opened": False,
        "NN": 0,
        "model_weights_or_checkpoint_read": False,
        "history_crossformat": "UNVERIFIED; literal matches counted without claiming fullhistory identity",
        "wall_seconds": time.monotonic() - started,
    }
    with gzip.open(OUT / "future-mask-v1.json.gz", "wt") as stream:
        json.dump(mask, stream, separators=(",", ":"))
    summary = {k: v for k, v in mask.items() if k not in ("rows", "groups")}
    summary["mask_SHA"] = sha(OUT / "future-mask-v1.json.gz")
    (OUT / "future-mask-summary-v1.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
