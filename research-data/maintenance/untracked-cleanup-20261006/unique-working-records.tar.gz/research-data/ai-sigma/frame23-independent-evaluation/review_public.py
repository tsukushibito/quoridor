"""Review only explicitly public target-free input references; no native/framework calls."""

import collections
import hashlib
import json
from pathlib import Path
import time

from label_free import input_signature, validate_public

BLOCKS = {
    0: (1527, "46b3d3f8ab385a78e92ec47d773bda3137f0805b348891add2c0d233502d466d"),
    1: (1619, "3a50d8de19e66344b8fa36bedcd471a14939d2f500824bd2c890be032234d275"),
    2: (1657, "1970625a051745ee91f84bb8a47495b30164cb439a6c06201d791aee6fe1c7f4"),
    26: (1645, "7a2a05b1ff84ca42d8c40ec937426d68ea32fc04c317291ba0be0bad6e7d78bd"),
}
SOURCE_SHA = "390fc18b796af19b2c93b5d4918f6a643594147b267315a4859d6ca80c482396"
VERSION = "QF1-f32-STM/quoridor-teacher-v1"


def review(root, sealed_handoff=None):
    started = time.monotonic()
    producer = root / "research-data/ai-sigma/frame23-independent-teachers"
    plan = producer / "registered-family-map-v2.json"
    assert hashlib.sha256(plan.read_bytes()).hexdigest() == (
        "9bda564e21e67c8294566c00d6752d9fec2d31aeae3e3735a5a317e21f08337d"
    )
    families = {row["canonical_family"]: row for row in json.loads(plan.read_text())["families"]}
    specs = BLOCKS
    handoff = None
    if sealed_handoff is not None:
        assert hashlib.sha256(sealed_handoff.read_bytes()).hexdigest() == (
            "234b99f5d2aea57c09585c206d04c107e9cc185daa6f2495a864b942b9f5cc6a"
        )
        handoff = json.loads(sealed_handoff.read_text())
        assert handoff["schema"] == "sealed-targetfree-reference-v3"
        assert handoff["planned_families"] == 96
        assert not handoff["labels_winner_pi_value_predictions_errors_in_public_projection"]
        assert not handoff["sealed_label_container_paths_distributed"]
        specs = {
            b["block"]: (b["raw_input_reference_rows"], b["public_metadata_SHA"])
            for b in handoff["blocks"]
        }
        assert set(specs) == {27, 28}
    output = []
    all_uids = set()
    for block, (expected_rows, expected_sha) in specs.items():
        path = producer / f"block{block:02d}-public-targetfree-v2.jsonl"
        if handoff:
            record = next(b for b in handoff["blocks"] if b["block"] == block)
            assert path.resolve() == Path(record["public_target_free_metadata"]).resolve()
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected_sha
        counts = collections.Counter()
        sides = collections.Counter()
        with path.open() as stream:
            for line in stream:
                row = json.loads(line)
                validate_public(row)
                input_signature(row, VERSION)
                family = families[row["canonical_family"]]
                assert family["block"] == block
                assert row["native_family_alias"] == family["native_family"]
                assert row["prefix"][: len(family["prefix"])] == family["prefix"]
                assert row["cohort"] == family["cohort"]
                partition = (
                    "sealed_futureevaluation"
                    if block in (27, 28)
                    else "selection"
                    if block == 26
                    else "train"
                )
                assert row["partition"] == partition
                assert row["producer_source_SHA"] == SOURCE_SHA
                assert row["id"] == f"game-{family['local_id']}-ply-{row['ply']}"
                uid = (row["canonical_family"], row["id"])
                assert uid not in all_uids
                all_uids.add(uid)
                counts[row["canonical_family"]] += 1
                sides[row["side"]] += 1
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected_sha
        assert sum(counts.values()) == expected_rows and len(counts) == 48
        if handoff:
            assert dict(counts) == record["rows_by_family"]
        output.append(
            dict(
                block=block,
                path=str(path),
                SHA=expected_sha,
                rows=sum(counts.values()),
                planned_families=48,
                observed_families=len(counts),
                zero_row_families=0,
                row_side_counts=dict(sides),
                counts_by_family=dict(counts),
                label_fields_absent=True,
                signatures_and_aliases_and_opening_prefixes_match=True,
            )
        )
    return dict(
        task=(
            "frame23-sealed-public-input-review-287-v1"
            if handoff
            else "frame23-public-input-reference-review-287-v1"
        ),
        schema="public-input-reference-review-v1",
        status="PASS_INPUT_REFERENCES_ONLY",
        blocks=output,
        train_rows=sum(n for b, (n, _) in specs.items() if b < 26),
        selection_rows=sum(n for b, (n, _) in specs.items() if b == 26),
        future_raw_reference_rows=sum(n for b, (n, _) in specs.items() if b > 26),
        planned_families=48 * len(specs),
        actual_uids=len(all_uids),
        native_NN=0,
        model_forward=0,
        scientific_jobs=0,
        charge_bucket="NN0 source/preparation300s; not future model evaluation",
        elapsed_s=time.monotonic() - started,
        future_labels_opened=False,
        full_prefix_replay="NOT_RUN; sequence/prefix correspondence only",
        history_crossformat="UNVERIFIED; supplied key/hash format only",
        finalmask="PENDING frozen Vraw/Told/Tseen union; no pre-OR count declared unexposed",
        teacher_quality="producer receipt only; no teachertruth certification",
    )


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--sealed-public-handoff", type=Path)
    args = parser.parse_args()
    args.output.write_text(
        json.dumps(review(args.root, args.sealed_public_handoff), indent=2) + "\n"
    )
