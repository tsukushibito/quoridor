"""Label-free signatures and immutable family-plan review; no framework import."""

import collections
import hashlib
import json
import math
from pathlib import Path
import struct

FORBIDDEN = {
    "rootmean",
    "rootNN",
    "z",
    "teacher",
    "winner",
    "loss",
    "prediction",
    "target",
    "pi",
    "π",
    "value",
    "error",
    "modelprediction",
    "modelerror",
}
PUBLIC_FIELDS = {
    "id",
    "canonical_family",
    "native_family_alias",
    "partition",
    "side",
    "ply",
    "cohort",
    "state_key",
    "history_key",
    "history_key_format",
    "actualSTM_ids",
    "ids_order",
    "STM_distance_f32bits",
    "distance_order",
    "input_signature",
    "prefix",
    "witness_reference",
    "producer_schema",
    "producer_source_SHA",
}


def validate_public(row):
    """Closed whitelist before interpreting a producer's projected row."""
    if set(row) - PUBLIC_FIELDS:
        raise ValueError("public metadata contains unregistered fields")
    required = PUBLIC_FIELDS - {"prefix", "witness_reference"}
    if required - set(row) or not ({"prefix", "witness_reference"} & set(row)):
        raise ValueError("public metadata missing required input provenance")
    if row["producer_schema"] != "quoridor-teacher-v1":
        raise ValueError("unregistered producer schema")
    if not row["history_key_format"]:
        raise ValueError("history format missing")
    if "prefix" in row and (
        len(row["prefix"]) != row["ply"]
        or row["side"] != 1 + row["ply"] % 2
        or any(type(a) is not int or not 0 <= a < 209 for a in row["prefix"])
    ):
        raise ValueError("complete prefix/ply/side inconsistent")


def input_signature(row, version):
    if FORBIDDEN.intersection(row):
        raise ValueError("explicit label-free metadata required")
    if row["side"] not in (1, 2) or not version:
        raise ValueError("side/version")
    side = row["side"] - 1
    if row.get("ids_order") == "STM_then_opponent":
        ids_views = row["actualSTM_ids"]
    elif row.get("ids_order") == "P1_then_P2":
        ids_views = (row["ids"][side], row["ids"][1 - side])
    else:
        raise ValueError("unknown IDs view")
    if len(ids_views) != 2:
        raise ValueError("two sparse views required")
    raw = bytearray()
    for ids in ids_views:
        if ids != sorted(set(ids)) or any(type(i) is not int or not 0 <= i < 312 for i in ids):
            raise ValueError("IDs sorted unique in range")
        raw.extend(struct.pack("<H", len(ids)))
        raw.extend(struct.pack("<" + "H" * len(ids), *ids))
    if "STM_distance_f32bits" in row:
        if row.get("distance_order") != "STM_then_opponent_f32_le":
            raise ValueError("unknown distance bits view")
        bits = row["STM_distance_f32bits"]
        if len(bits) != 2 or any(type(b) is not int or not 0 <= b < 2**32 for b in bits):
            raise ValueError("two uint32 distance words required")
        distance_bytes = struct.pack("<2I", *bits)
    else:
        if row.get("distance_order") != "STM_then_opponent_f32":
            raise ValueError("unknown distance float view")
        if len(row["distance"]) != 2:
            raise ValueError("two float distances required")
        distance_bytes = struct.pack("<2f", *row["distance"])
    if any(not math.isfinite(d) or not 0 <= d <= 1 for d in struct.unpack("<2f", distance_bytes)):
        raise ValueError("finite distance2")
    raw.extend(distance_bytes)
    digest = hashlib.sha256(raw).hexdigest()
    if row.get("feature_signature") not in (None, digest):
        raise ValueError("source feature signature mismatch")
    if row.get("input_signature") not in (None, digest):
        raise ValueError("source input signature mismatch")
    return version, digest


def exposure(row, refs, version):
    """Separate namespaces; literal history equality is not crossformat identity."""
    return (
        row["state_key"] in refs["states"]
        or row["history_key"] in refs["histories"]
        or input_signature(row, version) in refs["inputs"]
    )


def review_plan(manifest_path):
    path = Path(manifest_path)
    raw = path.read_bytes()
    m = json.loads(raw)
    rows = m["families"]
    assert m["schema"] == "independent-teacher-family-map-v2"
    assert not m["labels_or_outcomes_used"] and len(rows) == 1392
    assert len({r["canonical_family"] for r in rows}) == len(rows)
    assert len({r["native_family"] for r in rows}) == len(rows)
    assert len({tuple(r["prefix"]) for r in rows}) == len(rows)
    assert len({r["actionseed"] for r in rows}) == len(rows)
    counts = collections.Counter()
    blocks = collections.defaultdict(collections.Counter)
    for slot, row in enumerate(rows):
        block, local = divmod(slot, 48)
        split = "train" if slot < 1248 else "validation" if slot < 1296 else "test"
        run = f"frame23-285-v2-block{block:02d}-r1"
        seed = int.from_bytes(
            hashlib.sha256(f"frame23-285-v2-game-rng-block{block:02d}".encode()).digest()[:8], "big"
        )
        actionseed = seed ^ (((local + 1) * 0x9E3779B97F4A7C15) % (1 << 64))
        assert row["slot"] == slot and row["block"] == block and row["local_id"] == local
        assert row["split"] == split and row["native_family"] == f"{run}-family-{local:06d}"
        assert row["native_run_id"] == run and row["actionseed"] == actionseed
        assert row["opening_side"] == 1 + len(row["prefix"]) % 2
        assert len(row["prefix"]) == row["cohort"]
        assert (
            row["prefix_SHA"]
            == hashlib.sha256(json.dumps(row["prefix"], separators=(",", ":")).encode()).hexdigest()
        )
        counts[(split, row["opening_side"])] += 1
        blocks[block][row["cohort"]] += 1
    assert all(len(c) == 12 and set(c.values()) == {4} for c in blocks.values())
    return dict(
        manifest=str(path),
        manifest_SHA=hashlib.sha256(raw).hexdigest(),
        planned=1392,
        counts={f"{s}-P{p}": n for (s, p), n in counts.items()},
        complete_block_count=29,
        block_families=48,
        all_alias_and_seed_checks=True,
        legal_prefix_replay="NOT_RUN; owner native prepare source/proof only",
        outcome_or_teacher_read=False,
    )


def small_mock():
    a = dict(
        side=1,
        ids=[[4, 157, 300, 311], [76, 85, 300, 311]],
        distance=[0.1, 0.2],
        state_key="S",
        history_key="H",
        ids_order="P1_then_P2",
        distance_order="STM_then_opponent_f32",
    )
    b = dict(a, side=2, ids=list(reversed(a["ids"])))
    assert input_signature(a, "V") == input_signature(b, "V")
    assert input_signature(a, "V") != input_signature(dict(a, side=2), "V")
    changed = dict(a, distance=[0.2, 0.1])
    assert input_signature(a, "V") != input_signature(changed, "V")
    assert input_signature(a, "V") != input_signature(a, "OTHER")
    projected = dict(a)
    projected.pop("ids")
    projected.pop("distance")
    projected.update(
        actualSTM_ids=a["ids"],
        ids_order="STM_then_opponent",
        STM_distance_f32bits=list(struct.unpack("<2I", struct.pack("<2f", 0.1, 0.2))),
        distance_order="STM_then_opponent_f32_le",
    )
    assert input_signature(projected, "V") == input_signature(a, "V")
    refs = {"states": {"S"}, "histories": set(), "inputs": set()}
    assert exposure(a, refs, "V")
    refs = {"states": set(), "histories": {"H"}, "inputs": set()}
    assert exposure(a, refs, "V")
    refs = {"states": set(), "histories": set(), "inputs": {input_signature(a, "V")}}
    assert exposure(a, refs, "V")
    try:
        input_signature(dict(a, z=1), "V")
    except ValueError:
        pass
    else:
        raise AssertionError("target field not rejected")
    return {"status": "PASS", "NN": 0, "real_dataset_support": False}
