"""Dedicated bounded 287 model job; resource/entry identity before any import."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path("/workspaces/quoridor")
DATA = ROOT / "research-data/ai-sigma/frame23-independent-evaluation"
JOB = DATA / "prediction-r1"
TASK = "frame23-independent-evaluation-287-prediction-v1"
BOOT = Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def proc(pid):
    try:
        p = Path("/proc") / str(pid)
        stat = (p / "stat").read_text().rsplit(")", 1)[1].split()
        status = (p / "status").read_text()
        return {
            "pid": int(pid),
            "ppid": int(stat[1]),
            "pgid": int(stat[2]),
            "tick": stat[19],
            "cpu": int(stat[11]) + int(stat[12]),
            "rss": int(status.split("VmRSS:")[1].split()[0]) * 1024 if "VmRSS:" in status else 0,
            "argv": (p / "cmdline").read_bytes().decode(errors="replace").split("\0")[:-1],
            "boot": BOOT,
        }
    except (OSError, ValueError, IndexError):
        return None


def snapshot():
    return {
        int(p.name): item
        for p in Path("/proc").iterdir()
        if p.name.isdigit() and (item := proc(p.name))
    }


def compute(item):
    argv = item["argv"]
    exe = Path(argv[0]).name if argv else ""
    if exe in {"cargo", "rustc", "nnue-diagnose", "route-feature-diagnose", "quoridor-runner"}:
        return True
    if exe.startswith("python"):
        script = next((p for p in argv[1:] if p.endswith(".py")), "")
        return any(k in script for k in ("frame23", "quoridor_training", "guard.py")) and not any(
            k in script for k in ("research-job", "research-team", "research-scheduler")
        )
    return False


def main():
    JOB.mkdir(exist_ok=False)
    register = json.loads((DATA / "prediction-registration-v2.json").read_text())
    entry = DATA / "predict_frozen_future.py"
    assert register["task"] == TASK and register["entry_SHA"] == sha(entry)
    assert register["guard_SHA"] == sha(__file__) and register["NN_upper"] <= 20000
    before = snapshot()
    ancestors = {os.getpid()}
    current = os.getpid()
    while current in before and before[current]["ppid"] not in ancestors:
        current = before[current]["ppid"]
        ancestors.add(current)
    foreign = [p for pid, p in before.items() if pid not in ancestors and compute(p)]
    argv = ["/usr/bin/taskset", "-c", "3", register["python"], "-B", str(entry)]
    admission = {
        "task": TASK,
        "schema": "guarded-frozen-prediction-v1",
        "at": stamp(),
        "argv": argv,
        "entry_SHA": sha(entry),
        "guard_SHA": sha(__file__),
        "registration_SHA": sha(DATA / "prediction-registration-v2.json"),
        "foreign_compute": foreign,
        "boot": BOOT,
        "expected_output": "prediction-result-v1.json",
    }
    (JOB / "admission.json").write_text(json.dumps(admission, indent=2) + "\n")
    if foreign:
        (JOB / "process.json").write_text(
            json.dumps(
                {
                    "task": TASK,
                    "status": "NOT_STARTED_PHYSICS",
                    "NN": 0,
                    "scientific_MAX_consumed": 0,
                    "at": stamp(),
                },
                indent=2,
            )
            + "\n"
        )
        return 78
    stop = json.loads(Path(register["source_stop"]).read_text())
    assert sha(register["source_stop"]) == register["source_stop_SHA"]
    assert stop["reader_stopped"] and stop["source_writer_stopped_for_public_transition"]
    assert not stop["all_waited_current_exact_remaining"]
    for path, expected in register["frozen_inputs"].items():
        assert sha(path) == expected
    start = time.monotonic()
    started = stamp()
    seen = {}
    cause = None
    peak = 0
    with (JOB / "stdout.log").open("w") as out, (JOB / "stderr.log").open("w") as err:
        child = subprocess.Popen(argv, stdout=out, stderr=err, start_new_session=True)
        first = proc(child.pid)
        if first:
            seen[child.pid] = first
        (JOB / "actual-start.json").write_text(
            json.dumps({"task": TASK, "at": started, "identity": first, "argv": argv}, indent=2)
            + "\n"
        )
        while child.poll() is None:
            now = snapshot()
            owned = {pid for pid, p in now.items() if p["pgid"] == child.pid}
            seen.update({pid: now[pid] for pid in owned})
            peak = max(peak, sum(now[pid]["rss"] for pid in owned))
            foreign = [
                p
                for pid, p in now.items()
                if pid not in ancestors
                and pid not in owned
                and compute(p)
                and (
                    pid not in before
                    or p["tick"] != before[pid]["tick"]
                    or p["cpu"] - before[pid]["cpu"] >= 2
                )
            ]
            if foreign:
                cause = "FOREIGN_CPU"
            if peak > 1792 * 1024**2:
                cause = "RSS_GUARD"
            if time.monotonic() - start > 180:
                cause = "WALL_GUARD"
            if datetime.datetime.now(datetime.timezone.utc) >= datetime.datetime(
                2026, 10, 5, 22, 55, tzinfo=datetime.timezone.utc
            ):
                cause = "FRAME_DEADLINE"
            if cause:
                os.killpg(child.pid, signal.SIGTERM)
                break
            before = now
            time.sleep(0.05)
        try:
            code = child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            code = child.wait()
    # Reap the direct child; retain separate exactness for all recorded descendants.
    remaining = [p for pid, old in seen.items() if (p := proc(pid)) and p["tick"] == old["tick"]]
    output = DATA / "prediction-result-v1.json"
    result = json.loads(output.read_text()) if output.exists() else None
    valid = (
        code == 0
        and result is not None
        and result["task"] == TASK
        and result["schema"] == "frozen-future-prediction-v1"
        and result["PASS"]
    )
    receipt = {
        "task": TASK,
        "schema": "guarded-frozen-prediction-v1",
        "started": started,
        "ended": stamp(),
        "wall_seconds": time.monotonic() - start,
        "exit_code": code,
        "cause": cause,
        "peak_RSS": peak,
        "recorded_identities": list(seen.values()),
        "waited": True,
        "remaining": remaining,
        "current_exact_absent": not remaining,
        "output_identity_PASS": valid,
        "NN": result["physicalNN"] if valid else "UNKNOWN",
        "conservative_NN_charge": result["physicalNN"] if valid else register["NN_upper"],
        "scientific_MAX_consumed": 1,
        "targets_opened": False,
    }
    (JOB / "process.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: v for k, v in receipt.items() if k != "recorded_identities"}))
    return 0 if valid and not remaining else 1


if __name__ == "__main__":
    sys.exit(main())
