"""One-off cleanup of an explicit inventory, after independent Git restoration checks."""

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path.cwd().resolve()
OUT = ROOT / ".artifacts/research-cleanup/uer"
DATA = ROOT / "research-data/maintenance/untracked-cleanup-20261006"


def sha(stream):
    digest = hashlib.sha256()
    while block := stream.read(1024 * 1024):
        digest.update(block)
    return digest.hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args])


def check_source(row):
    path = ROOT / row["path"]
    if path.resolve() != path or not path.is_file() or path.is_symlink():
        raise ValueError("Unsafe or changed source: " + row["path"])
    state = path.lstat()
    if (state.st_dev, state.st_ino, state.st_size, state.st_mtime_ns) != (
        row["dev"],
        row["inode"],
        row["bytes"],
        row["mtime_ns"],
    ):
        raise ValueError("Original changed: " + row["path"])
    with path.open("rb") as source:
        if sha(source) != row["sha256"]:
            raise ValueError("Source hash changed: " + row["path"])


def readers(rows):
    targets = {str(ROOT / row["path"]) for row in rows}
    directories = {str((ROOT / row["path"]).parent) for row in rows}
    hits, missing = [], Counter()
    for process in Path("/proc").iterdir():
        if not process.name.isdigit() or int(process.name) == os.getpid():
            continue
        try:
            cwd = os.readlink(process / "cwd")
            if cwd in directories:
                hits.append({"pid": int(process.name), "kind": "cwd", "path": cwd})
            for descriptor in (process / "fd").iterdir():
                try:
                    target = os.readlink(descriptor)
                    if target in targets:
                        hits.append({"pid": int(process.name), "kind": "fd", "path": target})
                except FileNotFoundError:
                    continue
            arguments = (process / "cmdline").read_bytes().split(b"\0")
            for arg in arguments:
                name = os.fsdecode(arg)
                if Path(name).name in {
                    "research-job.py",
                    "research-scheduler.py",
                    "research-watch.py",
                }:
                    hits.append({"pid": int(process.name), "kind": "controller", "path": name})
                if name and not name.startswith("-"):
                    candidate = str(Path(cwd) / name) if not name.startswith("/") else name
                    if candidate in targets:
                        hits.append(
                            {"pid": int(process.name), "kind": "argument", "path": candidate}
                        )
        except FileNotFoundError:
            continue
        except PermissionError:
            missing["permission_denied_processes"] += 1
    return {
        "hits": hits,
        "limitations": dict(missing),
        "scope": "readable /proc point, not all-host certification",
    }


def verify_references(rows, saved_commit):
    grouped = defaultdict(dict)
    direct = {}
    for row in rows:
        ref = row.get("restoration")
        if not ref:
            continue
        commit = ref.get("commit", saved_commit)
        if ref["kind"] == "git-blob":
            direct[(commit, ref["path"])] = row
        else:
            key = (commit, ref["archive"])
            expected = (row["bytes"], row["sha256"])
            previous = grouped[key].setdefault(ref["member"], expected)
            if previous != expected:
                raise ValueError("Conflicting archive member identity")
    for (commit, name), row in direct.items():
        data = git("show", commit + ":" + name)
        if (len(data), hashlib.sha256(data).hexdigest()) != (row["bytes"], row["sha256"]):
            raise ValueError("Git blob restoration failed: " + name)
    count = 0
    for (commit, name), expected in grouped.items():
        found = set()
        process = subprocess.Popen(["git", "show", commit + ":" + name], stdout=subprocess.PIPE)
        try:
            with tarfile.open(fileobj=process.stdout, mode="r|*") as archive:
                for member in archive:
                    if member.name not in expected:
                        continue
                    if not member.isfile() or member.name in found:
                        raise ValueError("Ambiguous archive member: " + member.name)
                    with archive.extractfile(member) as source:
                        actual = (member.size, sha(source))
                    if actual != expected[member.name]:
                        raise ValueError("Git archive restoration failed: " + member.name)
                    found.add(member.name)
            # Drain possible tar padding before waiting for the Git process.
            while process.stdout.read(1024 * 1024):
                pass
        finally:
            process.stdout.close()
            code = process.wait()
        if code or found != set(expected):
            raise ValueError("Incomplete Git archive: " + name)
        count += len(found)
    return {"git_archives": len(grouped), "archive_members": count, "direct_git_blobs": len(direct)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()
    manifest = json.loads((DATA / "manifest.json").read_text())
    saved = json.loads((OUT / "preservation-git.json").read_text())
    commit = saved["commit"]
    for name in ["manifest.json", "unique-working-records.tar.gz"]:
        relative = str((DATA / name).relative_to(ROOT))
        if git("show", commit + ":" + relative) != (DATA / name).read_bytes():
            raise ValueError("Preservation was not committed exactly")
    rows = manifest["files"]
    untracked = set(git("ls-files", "--others", "--exclude-standard", "-z").decode().split("\0"))
    for row in rows:
        if row["path"] not in untracked:
            raise ValueError("Original no longer untracked: " + row["path"])
        check_source(row)
        if row["action"] == "move-generated-cache":
            destination = ROOT / row["destination"]
            if destination.exists() or destination.resolve() != destination:
                raise ValueError("Unsafe or occupied cache destination")
            subprocess.run(["git", "check-ignore", "--quiet", "--", row["destination"]], check=True)
    restoration = verify_references(rows, commit)
    observation = readers(rows)
    preflight = {
        "preservation_commit": commit,
        "restoration": restoration,
        "readers": observation,
        "at": datetime.now(timezone.utc).isoformat(),
        "original_files": len(rows),
    }
    (OUT / "preflight.json").write_text(json.dumps(preflight, indent=2) + "\n")
    if observation["hits"]:
        raise ValueError("Active readers; originals remain: " + json.dumps(observation["hits"]))
    if not args.apply:
        print(json.dumps(preflight))
        return
    journal = OUT / "deletion-journal.jsonl"
    if journal.exists():
        raise ValueError("Existing mutation journal; reconcile before rerun")
    actions = Counter()
    with journal.open("x") as stream:
        for row in rows:
            check_source(row)
            source = ROOT / row["path"]
            if row["action"] == "move-generated-cache":
                destination = ROOT / row["destination"]
                destination.parent.mkdir(parents=True, exist_ok=True)
                if destination.exists():
                    raise ValueError("Destination appeared")
                source.rename(destination)
                with destination.open("rb") as cache:
                    if sha(cache) != row["sha256"]:
                        raise ValueError("Moved cache identity changed")
            else:
                source.unlink()
            stream.write(
                json.dumps({"path": row["path"], "action": row["action"], "completed": True}) + "\n"
            )
            stream.flush()
            actions[row["action"]] += 1
    # rmdir only empty original directories; never recursively clean protected data.
    parents = {
        p for row in rows for p in (ROOT / row["path"]).parents if p != ROOT and ROOT in p.parents
    }
    empty = 0
    for directory in sorted(parents, key=lambda p: len(p.parts), reverse=True):
        try:
            directory.rmdir()
            empty += 1
        except (FileNotFoundError, OSError):
            continue
    missing = [row["path"] for row in rows if (ROOT / row["path"]).exists()]
    if missing:
        raise ValueError("Cleanup left original files")
    result = {
        **preflight,
        "completed_at": datetime.now(timezone.utc).isoformat(),
        "actions": dict(actions),
        "original_logical_bytes": sum(row["bytes"] for row in rows),
        "empty_directories_removed": empty,
        "all_original_paths_absent": True,
        "physical_bytes_freed": "UNMEASURED",
        "scientific_jobs": 0,
        "models_inputs_shared_db_worktrees_modified": False,
        "ignore_rules_changed": False,
    }
    (DATA / "cleanup-result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
