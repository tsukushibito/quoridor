"""One-off byte-preserving research cleanup; no deletion in preparation."""

import hashlib
import json
from pathlib import Path
import subprocess
import tarfile
import time

ROOT = Path.cwd()
OUT = ROOT / ".artifacts/research-cleanup/uer"
DATA = ROOT / "research-data/maintenance/untracked-cleanup-20261006"
LIMIT = 64 * 1024 * 1024


def digest(stream):
    h = hashlib.sha256()
    while block := stream.read(1024 * 1024):
        h.update(block)
    return h.hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args]).decode().strip()


def current(row):
    path = ROOT / row["path"]
    st = path.lstat()
    if path.is_symlink() or not path.is_file():
        raise ValueError("Changed type: " + row["path"])
    if (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns) != (
        row["dev"],
        row["inode"],
        row["bytes"],
        row["mtime_ns"],
    ):
        raise ValueError("Changed original: " + row["path"])
    with path.open("rb") as stream:
        if digest(stream) != row["sha256"]:
            raise ValueError("Changed bytes: " + row["path"])


def main():
    started = time.monotonic()
    inventory = json.loads((OUT / "inventory.json").read_text())
    head = inventory["head"]
    if git("rev-parse", "HEAD") != head:
        raise ValueError("Git head changed before preparation")
    rows = inventory["files"]
    keys = {(row["bytes"], row["sha256"]) for row in rows}
    sizes = {key[0] for key in keys}
    references = {}
    tracked = git("ls-files").splitlines()
    archives = [
        name
        for name in tracked
        if "/frame2" in name and name.endswith((".tar.gz", ".tar.xz", ".tgz", ".tar"))
    ]
    # All source archives used as references must be unchanged Git objects.
    for name in archives:
        blob = git("rev-parse", head + ":" + name)
        if git("hash-object", name) != blob:
            raise ValueError("Archive differs from Git: " + name)
        with tarfile.open(ROOT / name, "r|*") as source:
            for member in source:
                if not member.isfile() or member.size not in sizes:
                    continue
                stream = source.extractfile(member)
                with stream:
                    key = (member.size, digest(stream))
                if key in keys and key not in references:
                    references[key] = {
                        "kind": "git-archive-member",
                        "commit": head,
                        "archive": name,
                        "archive_blob": blob,
                        "member": member.name,
                    }
    # Directly tracked, equal-content source/evidence is another exact restoration source.
    for name in tracked:
        if name.endswith((".tar.gz", ".tar.xz", ".tgz", ".tar")):
            continue
        path = ROOT / name
        if path.is_symlink() or not path.is_file() or path.stat().st_size not in sizes:
            continue
        with path.open("rb") as stream:
            key = (path.stat().st_size, digest(stream))
        if key in keys and key not in references:
            blob = git("rev-parse", head + ":" + name)
            if git("hash-object", name) != blob:
                continue
            references[key] = {"kind": "git-blob", "commit": head, "path": name, "blob": blob}
    DATA.mkdir(parents=True, exist_ok=False)
    pending = {}
    plan = []
    for row in rows:
        current(row)
        name = row["path"]
        key = (row["bytes"], row["sha256"])
        record = {**row}
        if name.endswith(".lock") and row["bytes"] == 0:
            record.update(
                action="remove-empty-runtime-lock",
                reason="ended controllers; re-creatable flock file",
            )
        elif "/.mpl-cache/" in name:
            record.update(
                action="move-generated-cache",
                destination=".artifacts/research-cleanup/uer/scratch/" + name,
            )
        elif key in references:
            record.update(action="remove-verified-redundancy", restoration=references[key])
        else:
            pending.setdefault(key, row)
            record.update(
                action="preserve-then-remove",
                restoration={
                    "kind": "new-git-archive-member",
                    "archive": str((DATA / "unique-working-records.tar.gz").relative_to(ROOT)),
                    "member": pending[key]["path"],
                },
            )
        plan.append(record)
    target = DATA / "unique-working-records.tar.gz"
    with tarfile.open(target, "w:gz", compresslevel=6) as archive:
        for row in pending.values():
            current(row)
            archive.add(ROOT / row["path"], arcname=row["path"], recursive=False)
            if target.stat().st_size > LIMIT:
                raise ValueError("Preservation archive exceeds64MiB guard; originals untouched")
    if target.stat().st_size > LIMIT:
        raise ValueError("Archive overguard; originals untouched")
    expected = {row["path"]: row for row in pending.values()}
    checked = set()
    with tarfile.open(target, "r|gz") as archive:
        for member in archive:
            row = expected[member.name]
            with archive.extractfile(member) as stream:
                if member.size != row["bytes"] or digest(stream) != row["sha256"]:
                    raise ValueError("Restore mismatch: " + member.name)
            checked.add(member.name)
    if checked != set(expected):
        raise ValueError("Incomplete archive restoration")
    manifest = {
        "schema": "untracked-working-copy-cleanup-v1",
        "issue": "quoridor-uer",
        "base_commit": head,
        "originals_not_deleted_before_Git_save": True,
        "files": plan,
        "unique_new_archive_members": len(pending),
        "archive_bytes": target.stat().st_size,
        "archive_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "restoration_verified_members": len(checked),
        "scanned_relevant_archives": len(archives),
        "preparation_wall_seconds": time.monotonic() - started,
    }
    (DATA / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    counts = {}
    for row in plan:
        counts[row["action"]] = counts.get(row["action"], 0) + 1
    (OUT / "prepared-summary.json").write_text(
        json.dumps(
            {
                "counts": counts,
                "new_archive_bytes": target.stat().st_size,
                "new_unique_members": len(pending),
                "logical_original_bytes": inventory["logical_bytes"],
                "preparation_wall_seconds": manifest["preparation_wall_seconds"],
            },
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(counts), "archive_bytes", target.stat().st_size, flush=True)


if __name__ == "__main__":
    main()
