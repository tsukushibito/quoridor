import config from '../playwright.audio.config';
export default { ...config, testDir: '../tests/e2e', testMatch: ['audio.spec.ts', 'presentation.spec.ts'] };
