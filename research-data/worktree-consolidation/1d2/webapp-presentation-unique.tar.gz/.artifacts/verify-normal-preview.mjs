import { chromium, expect } from '@playwright/test';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
const base = process.env.PRESENTATION_PREVIEW || 'http://127.0.0.1:4173/';
const manifest = JSON.parse(await readFile('apps/web/public/assets/audio/manifest.json', 'utf8'));
const browser = await chromium.launch({ headless: true, args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-webgl'] });
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = []; page.on('pageerror', e => errors.push(e.message));
try {
  await page.goto(base + '?forceWebGL=1');
  await expect(page.locator('#startup-new-game')).toBeEnabled();
  const api = await page.evaluate(() => Object.keys(window).filter(key => key.startsWith('__QUORIDOR_')));
  expect(api).toEqual([]);
  for (const asset of manifest.assets) {
    const response = await page.request.get(base + 'assets/audio/' + asset.file);
    expect(response.ok()).toBe(true);
    expect(createHash('sha256').update(await response.body()).digest('hex')).toBe(asset.sha256);
  }
  await page.locator('#startup-new-game').click(); await page.locator('#dialog-start').click();
  await expect(page.locator('#startup-dialog')).toBeHidden();
  await page.locator('#open-menu').click(); await page.locator('.settings summary').click();
  await page.locator('#no-animation').check(); await page.locator('#close-menu').click();
  let ply = 0;
  for (let move = 0; move < 8; move++) {
    for (const direction of move < 7 ? ['ArrowDown', move < 3 ? 'ArrowUp' : 'ArrowLeft'] : ['ArrowDown']) {
      await page.locator('#board canvas').focus(); await page.keyboard.press(direction); await page.keyboard.press('Enter');
      ++ply;
      await expect.poll(() => page.evaluate(() => JSON.parse(localStorage.getItem('quoridor.m1.game.v1')).replay.ply)).toBe(ply);
    }
  }
  await expect(page.locator('#result-dialog')).toBeVisible(); await expect(page.locator('#result-total')).toHaveText('総手数 15手');
  await page.screenshot({ path: 'artifacts/presentation-normal-production.png' });
  await page.locator('#result-review').click(); await expect(page.locator('#review-counter')).toHaveText('振り返り 15 / 15手');
  await page.locator('#review-prev').click(); await expect(page.locator('#review-counter')).toHaveText('振り返り 14 / 15手');
  await page.locator('#review-first').click(); await expect(page.locator('#review-counter')).toHaveText('振り返り 0 / 15手');
  await page.locator('#review-last').click(); await page.locator('#review-result').click();
  await page.locator('#result-title').click(); await page.locator('#resume-game-choice').click();
  await expect(page.locator('#result-dialog')).toBeVisible();
  expect(await page.locator('#board canvas').count()).toBe(1); expect(errors).toEqual([]);
  const evidence = { base, noTestApis: true, audioHashes: manifest.assets.length, terminalPly: ply,
    reviewSeek: [15, 14, 0, 15], titleRoundTrip: true, errors };
  await writeFile('artifacts/presentation-normal-production.json', JSON.stringify(evidence, null, 2) + '\n');
  console.log(JSON.stringify(evidence));
} finally { await browser.close(); }
