// Offline desktop behavior contract for the generated static dashboard.
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('@playwright/test');
const sourceDir = dirname(fileURLToPath(import.meta.url));
const ownedTemp = mkdtempSync(join(tmpdir(), 'dashboard350-browser-'));
const html = join(ownedTemp, 'desktop-fixture.html');
let browser;

function fixture(reloaded = false) {
  const child = spawnSync(
    'python3',
    [
      '-B',
      join(sourceDir, 'research-dashboard-desktop-fixture.py'),
      html,
      ...(reloaded ? ['--reloaded'] : []),
    ],
    { encoding: 'utf8', timeout: 10000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' } },
  );
  assert.equal(child.status, 0, child.stderr);
}

try {
  fixture();
  browser = await chromium.launch({ headless: true, args: ['--disable-dev-shm-usage'] });
  const context = await browser.newContext({ viewport: { width: 1280, height: 600 } });
  const page = await context.newPage();
  const errors = [];
  const external = [];
  page.on('pageerror', (error) => errors.push(error.message));
  page.on('request', (request) => {
    if (!request.url().startsWith('file:')) external.push(request.url());
  });
  await page.goto(pathToFileURL(html).href);
  const rows = page.locator('#owners .owner-row');
  assert.equal(await rows.count(), 7, 'one row per owner');
  assert.equal(await rows.first().locator('span').count(), 4);
  assert.equal((await rows.first().innerText()).includes('Other unresolved task'), false);
  assert.equal((await rows.first().innerText()).includes('Completed history'), false);
  const clipped = await rows
    .first()
    .locator('span')
    .nth(3)
    .evaluate((node) => ({
      whiteSpace: getComputedStyle(node).whiteSpace,
      overflow: getComputedStyle(node).overflow,
      textOverflow: getComputedStyle(node).textOverflow,
      larger: node.scrollWidth > node.clientWidth,
    }));
  assert.deepEqual(clipped, {
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    larger: true,
  });
  assert.match(await page.locator('#timestamp').innerText(), /生成から\d+日.*現在の状態は未確認/);
  assert.match(await page.locator('#translation-status').innerText(), /翻訳待ち/);

  const alpha = rows.first();
  await alpha.focus();
  await page.keyboard.press('Enter');
  const dialog = page.locator('#session-dialog');
  assert.equal(await dialog.evaluate((node) => node.open), true);
  assert.equal(
    await page.locator('#dialog-close').evaluate((node) => node === document.activeElement),
    true,
  );
  assert.match(await dialog.innerText(), /その他の未完了タスク（1件）/);
  assert.match(await dialog.innerText(), /完了した履歴（1件）/);
  assert.match(await dialog.innerText(), /LONG_STAGE_/);
  assert.match(await dialog.innerText(), /LONG_NEXT_/);
  assert.match(await dialog.innerText(), /LONG_CLOSE_/);
  await dialog.locator('.original summary').first().click();
  assert.match(await dialog.locator('.original pre').first().innerText(), /LONG_TITLE_/);
  assert.match(await dialog.locator('.original pre').first().innerText(), /evil\.invalid/);
  await page.keyboard.press('Escape');
  assert.equal(await dialog.evaluate((node) => node.open), false);
  assert.equal(await alpha.evaluate((node) => node === document.activeElement), true);
  await page.keyboard.press('Space');
  assert.equal(await dialog.evaluate((node) => node.open), true);
  await page.locator('#dialog-close').click();
  assert.equal(await alpha.evaluate((node) => node === document.activeElement), true);

  const expected = [
    ['Paused owner', '人間の指示で一時停止'],
    ['Human owner', '人間の判断待ち'],
    ['Review owner', 'レビュー待ち'],
    ['Dependency owner', '依存タスク待ち'],
    ['Calculation owner', '生成時に計算ジョブの子プロセスを確認'],
    ['Unknown owner', '活動内容は未確認'],
  ];
  for (const [owner, state] of expected) {
    const row = rows.filter({ hasText: owner });
    assert.match(await row.innerText(), new RegExp(state));
  }
  const calc = rows.filter({ hasText: 'Calculation owner' });
  await calc.click();
  assert.match(await dialog.innerText(), /LLM状態：待機中/);
  assert.match(await dialog.innerText(), /子プロセスの正確な識別/);
  await page.locator('#dialog-close').click();
  const unknown = rows.filter({ hasText: 'Unknown owner' });
  await unknown.click();
  assert.match(await dialog.innerText(), /LLM状態：未読込/);
  await page.locator('#dialog-close').click();

  await page.locator('#search').fill('Other unresolved task');
  assert.equal(await page.locator('#owners .owner-row:visible').count(), 1);
  assert.match(await page.locator('#owners .owner-row:visible').innerText(), /現在の実装タスク/);
  await page.locator('#search').fill('');
  await page.locator('#waiting').check();
  assert.equal(await page.locator('#owners .owner-row:visible').count(), 4);
  await page.locator('#waiting').uncheck();
  await page.setViewportSize({ width: 1280, height: 420 });
  await page.evaluate(() => scrollTo(0, 60));
  const scrollBefore = await page.evaluate(() => scrollY);
  await alpha.click();
  await page.locator('#dialog-close').click();
  assert.equal(await page.evaluate(() => scrollY), scrollBefore, 'closing leaves scroll in place');
  assert.equal(await page.locator('#search').inputValue(), '');

  fixture(true); // Manual regeneration is separate; browser reload only rereads the file.
  assert.match(await alpha.innerText(), /現在の実装タスク/);
  await page.locator('#reload').click();
  await page.waitForLoadState('load');
  assert.match(
    await page.locator('#owners .owner-row').first().innerText(),
    /Updated file after manual generation/,
  );
  assert.equal(await page.evaluate(() => globalThis.INJECTED), undefined);
  assert.deepEqual(errors, []);
  assert.deepEqual(external, []);
  await page.screenshot({ path: join(ownedTemp, 'desktop-dashboard.png') });
  console.log(
    JSON.stringify({
      result: 'PASS',
      rows: 7,
      screenshot: join(ownedTemp, 'desktop-dashboard.png'),
      pageErrors: errors.length,
      externalRequests: external.length,
    }),
  );
  await context.close();
} finally {
  if (browser) await browser.close();
  if (process.env.DASHBOARD_KEEP_FIXTURE !== '1')
    rmSync(ownedTemp, { recursive: true, force: true });
}
